import {fetch as mobileFetch,Headers as MobileHeaders,Request as MobileRequest,Response as MobileResponse,Blob as MobileBlob,File as MobileFile,FormData as MobileFormData} from './mobile-fetch-polyfill.mjs';
import {webcrypto} from 'node:crypto';
// Loaded before the application graph. No credential or disk fallback.
if (!globalThis.crypto) globalThis.crypto = webcrypto;
if (!Promise.withResolvers) Promise.withResolvers = function () {
  let resolve, reject;
  const promise = new this((done, fail) => { resolve = done; reject = fail; });
  return {promise, resolve, reject};
};
if (!AbortSignal.any) AbortSignal.any = function (signals) {
  const controller = new AbortController(), cleanup = [];
  const abort = signal => {
    if (controller.signal.aborted) return;
    controller.abort(signal.reason);
    for (const remove of cleanup.splice(0)) remove();
  };
  for (const signal of signals) {
    if (!(signal instanceof AbortSignal)) throw new TypeError('Expected AbortSignal');
    if (signal.aborted) { abort(signal); break; }
    const listener = () => abort(signal);
    signal.addEventListener('abort', listener, {once:true});
    cleanup.push(() => signal.removeEventListener('abort', listener));
  }
  return controller.signal;
};

// iOS NodeMobile is jitless: native undici lazily compiles llhttp Wasm and exits.
// Install the complete Web API family before creating any request or response.
if(process.platform==='ios'||typeof globalThis.WebAssembly==='undefined'){
 if(typeof MobileResponse.json!=='function')MobileResponse.json=(value,init={})=>{const body=JSON.stringify(value);if(body===undefined)throw new TypeError('JSON value cannot be undefined');const headers=new MobileHeaders(init.headers);if(!headers.has('Content-Type'))headers.set('Content-Type','application/json');return new MobileResponse(body,{...init,headers});};
 class MobileFormDataCompat extends MobileFormData {
  append(name,value,filename){if(value instanceof MobileBlob&&filename!==undefined)return super.append(name,new MobileFile([value],String(filename),{type:value.type,lastModified:value.lastModified}));return super.append(name,value,filename);}
  set(name,value,filename){if(value instanceof MobileBlob&&filename!==undefined)return super.set(name,new MobileFile([value],String(filename),{type:value.type,lastModified:value.lastModified}));return super.set(name,value,filename);}
 }
 Object.assign(globalThis,{fetch:mobileFetch,Headers:MobileHeaders,Request:MobileRequest,Response:MobileResponse,FormData:MobileFormDataCompat,Blob:MobileBlob,File:MobileFile});
}
