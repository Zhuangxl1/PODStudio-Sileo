import http from 'node:http';
import {randomBytes,timingSafeEqual,createHmac} from 'node:crypto';

const UI_ORIGIN='http://127.0.0.1:4173';
const BODY_LIMIT=15*1024*1024,RESPONSE_LIMIT=1024*1024;
const NONCE_LIFETIME=2*60*1000,SESSION_LIFETIME=12*60*60*1000;
const ROUTES=new Set(['GET /health','GET /api/v1/config/github','POST /api/v1/config/github','POST /api/v1/github/inspect','POST /api/v1/upload/file','POST /api/v1/upload/base64']);
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const credential=()=>randomBytes(32).toString('hex');

/** The real service key stays in this process. Browsers receive a temporary gateway session. */
export function createDesktopGateway({serviceEndpoint='http://127.0.0.1:8080/api/v1/upload/file',serviceAuthorization,fetchImpl=fetch,now=Date.now}={}){
  const upstream=new URL(serviceEndpoint);
  if(upstream.origin!=='http://127.0.0.1:8080'||upstream.pathname!=='/api/v1/upload/file'||upstream.username||upstream.password||upstream.search||upstream.hash)throw new Error('本机图床地址无效。');
  if(typeof serviceAuthorization!=='string'||!/^Bearer [^\s\u0000-\u001f\u007f]{1,4096}$/.test(serviceAuthorization))throw new Error('本机服务授权无效。');
  const nonces=new Map(),sessions=new Map();
  const prune=()=>{for(const entries of [nonces,sessions])for(const [key,expires]of entries)if(expires<=now())entries.delete(key);};
  const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(JSON.stringify(data));};
  const fail=(res,status,message)=>json(res,status,{success:false,message});
  async function readBody(req,limit){const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>limit){const error=new Error('请求内容过大。');error.status=413;throw error;}chunks.push(chunk);}return Buffer.concat(chunks);}
  async function readResponse(response){const chunks=[];let bytes=0;for await(const chunk of response.body){bytes+=chunk.length;if(bytes>RESPONSE_LIMIT)throw new Error('响应内容过大。');chunks.push(chunk);}return Buffer.concat(chunks);}
  async function upstreamRequest(path,{method='GET',body,contentType,signal,timeoutMs=90000}={}){
    const timeout=AbortSignal.timeout(timeoutMs),combined=signal?AbortSignal.any([signal,timeout]):timeout;
    return fetchImpl(new URL(path,upstream.origin).href,{method,headers:{Authorization:serviceAuthorization,...(contentType?{'Content-Type':contentType}:{})},...(body?.length?{body}:{}),redirect:'error',signal:combined});
  }
  const server=http.createServer(async(req,res)=>{
    const ownOrigin=`http://127.0.0.1:${server.address()?.port}`;
    res.setHeader('Vary','Origin');
    if(req.headers.host!==new URL(ownOrigin).host)return fail(res,403,'请求地址不允许。');
    const origin=req.headers.origin;
    if(origin&&origin!==UI_ORIGIN&&origin!==ownOrigin&&origin!=='null')return fail(res,403,'请求来源不允许。');
    if(origin){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-POD-Launch');res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');}
    const url=new URL(req.url,ownOrigin);
    if(url.search||url.hash)return fail(res,400,'请求地址无效。');
    const route=`${req.method} ${url.pathname}`;
    if(req.method==='OPTIONS'){
      if(!origin||!['GET','POST'].includes(req.headers['access-control-request-method'])||!['/health','/__pod/connect','/api/v1/config/github','/api/v1/github/inspect','/api/v1/upload/file','/api/v1/upload/base64'].includes(url.pathname))return fail(res,403,'预检请求不允许。');
      const requested=String(req.headers['access-control-request-headers']||'').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean);
      if(requested.some(x=>!['authorization','content-type','x-pod-launch'].includes(x)))return fail(res,403,'请求头不允许。');
      if(req.headers['access-control-request-private-network']==='true')res.setHeader('Access-Control-Allow-Private-Network','true');
      res.writeHead(204,{'Cache-Control':'no-store'});return res.end();
    }
    if(route==='GET /__pod/status'){
      const challenge=req.headers['x-pod-challenge'];
      if(challenge!==undefined&&(typeof challenge!=='string'||!/^[a-f0-9]{64}$/.test(challenge)))return fail(res,400,'校验请求无效。');
      const proof=challenge?createHmac('sha256',serviceAuthorization).update(`POD Desktop Gateway v1:${challenge}:${server.address().port}`).digest('hex'):undefined;
      return json(res,200,{app:'pod-desktop-gateway',version:1,...(proof?{proof}:{})});
    }
    prune();
    if(route==='POST /__pod/launch'){
      // Only the local launcher knows the real service key. Browsers cannot issue launch links.
      if(origin||!equal(req.headers.authorization,serviceAuthorization))return fail(res,403,'启动请求未授权。');
      if(nonces.size>=100)return fail(res,429,'启动请求过多，请稍后重试。');
      const nonce=credential(),expiresAt=now()+NONCE_LIFETIME;nonces.set(nonce,expiresAt);
      return json(res,200,{success:true,data:{nonce,expiresAt}});
    }
    if(route==='POST /__pod/connect'){
      const nonce=req.headers['x-pod-launch'];
      if(!origin||typeof nonce!=='string'||!nonces.has(nonce))return fail(res,403,'启动连接已失效，请重新双击一键启动。');
      nonces.delete(nonce);
      if(sessions.size>=100)return fail(res,429,'连接会话过多，请稍后重试。');
      try{
        const readiness=await upstreamRequest('/api/v1/config/github',{timeoutMs:7000});
        if(!readiness.ok)return fail(res,503,'图床访问密钥验证失败，请重新一键启动。');
        const profile=JSON.parse((await readResponse(readiness)).toString('utf8'));
        if(profile?.success!==true||typeof profile?.data?.configured!=='boolean'||typeof profile?.data?.tokenConfigured!=='boolean')return fail(res,502,'图床配置响应无效，请更新本机服务。');
        const session=credential();sessions.set(session,now()+SESSION_LIFETIME);
        return json(res,200,{success:true,data:{provider:'urpiclink',endpoint:ownOrigin+'/api/v1/upload/file',authHeaderName:'Authorization',authValue:'Bearer '+session,configured:profile.data.configured,tokenConfigured:profile.data.tokenConfigured}});
      }catch{return fail(res,503,'无法连接本机图床，请重新双击一键启动。');}
    }
    if(!ROUTES.has(route))return fail(res,404,'接口不存在。');
    const provided=String(req.headers.authorization||'');
    const session=provided.startsWith('Bearer ')?provided.slice(7):'';
    if(!sessions.has(session))return fail(res,401,'图床连接已失效，请重新双击一键启动。');
    const controller=new AbortController();
    const disconnected=()=>{if(!res.writableEnded)controller.abort();};res.once('close',disconnected);
    try{
      const body=req.method==='POST'?await readBody(req,BODY_LIMIT):undefined;
      const response=await upstreamRequest(url.pathname,{method:req.method,body,contentType:req.headers['content-type'],signal:controller.signal});
      const output=await readResponse(response);
      res.writeHead(response.status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(output);
    }catch(error){if(!res.destroyed&&!res.writableEnded)fail(res,error.status===413?413:502,error.status===413?'请求内容超过大小限制。':'本机图床请求失败，请检查服务连接。');}
    finally{res.off('close',disconnected);}
  });
  server.requestTimeout=100000;server.headersTimeout=10000;
  return server;
}
