/** Pure whitelist projection of a completely received, parsed category response.
 * The caller must independently prove its owned-page / market / endpoint / time
 * scope and enforce the response-byte budget. This function performs no I/O.
 * It is standalone so it can also be serialized into a browser expression.
 */
export function projectCategoryDefinition(input = {}) {
  const pathHash = 'd796912ebc77a546509f75d5f4e8236a229bb0436c88a359503ab109eac027ef';
  const failed = reason => ({ accepted: false, reason, complete: false });
  const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const id = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,160}$/u.test(value);
  // Catalogue labels can contain "Basic Casual". Detect a bare Basic payload
  // only when canonical Base64 (with or without padding) encodes a colon pair.
  // Keep this pure decoder local for standalone browser/VM serialization.
  const basicCredential = value => {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    for (const match of value.matchAll(/\bBasic\s+([^\s,;]+)/giu)) {
      const encoded = match[1]; if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded)) continue;
      const bare = encoded.replace(/=+$/u, ''), remainder = bare.length % 4, padding = encoded.length - bare.length;
      if (remainder === 1 || padding && (encoded.length % 4 !== 0 || padding !== (4 - remainder) % 4)) continue;
      let buffer = 0, bits = 0, colon = false;
      for (const character of bare) {
        buffer = buffer * 64 + alphabet.indexOf(character); bits += 6;
        if (bits >= 8) { bits -= 8; if (Math.floor(buffer / 2 ** bits) === 58) colon = true; buffer %= 2 ** bits; }
      }
      if (buffer === 0 && colon) return true;
    }
    return false;
  };
  const text = (value, max) => typeof value === 'string' && value.trim().length > 0 && value.length <= max && !/[\u0000-\u001f\u007f]|(?:https?|wss?):\/\/|\bBearer\s+\S+|\b(?:password|passwd|cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret)\s*[:=]|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu.test(value) && !basicCredential(value);
  try {
    const categoryId = input?.categoryId, response = input?.response;
    if (!plain(input) || !id(categoryId) || !plain(response) || response.code !== 0 || !plain(response.data)
      || !Array.isArray(response.data.product_properties) || response.data.product_properties.length > 200) return failed('category_response_unverified');
    const properties = [], propertyIds = new Map(); let totalValues = 0, maxPerPropertyCount = 0, propertyRowsComplete = true;
    for (const row of response.data.product_properties) {
      if (!plain(row) || !id(row.id) || !text(row.name, 255)) { propertyRowsComplete = false; continue; }
      const property = { apiId: row.id, displayLabel: row.name, flags: {}, classification: {}, values: [], valid: true };
      if (propertyIds.has(row.id)) { propertyIds.get(row.id).valid = false; property.valid = false; propertyRowsComplete = false; }
      else propertyIds.set(row.id, property);
      for (const key of ['is_enum', 'is_input', 'is_necessary', 'is_multi_choice', 'is_number']) if (typeof row[key] === 'boolean') property.flags[key] = row[key];
      if (plain(row.label)) for (const key of ['key_property', 'binding_property', 'shopping_guide_property', 'legal_property']) if (typeof row.label[key] === 'boolean') property.classification[key] = row.label[key];
      if (typeof row.is_sub_cascade_properties === 'boolean') property.subCascadeProperty = row.is_sub_cascade_properties;
      if (row.cascade_values !== undefined || row.sales_cascade_properties_v2 !== undefined) property.cascadePresent = true;
      const valuesDescriptor = Object.getOwnPropertyDescriptor(row, 'values');
      const rawValues = valuesDescriptor && Object.hasOwn(valuesDescriptor, 'value') ? valuesDescriptor.value : undefined;
      property.valuesState = !valuesDescriptor ? 'not-reported' : Array.isArray(rawValues) ? 'reported-array' : 'invalid';
      if (property.valuesState === 'invalid') property.valid = false;
      if (Array.isArray(rawValues)) {
        property.observedValueCount = rawValues.length;
        maxPerPropertyCount = Math.max(maxPerPropertyCount, rawValues.length);
        // These counters cover the valid-property prefix inspected at rejection;
        // they neither identify a row nor claim an accepted/truncated catalogue.
        const limitStage = rawValues.length > 10000 ? 'property_value_count' : totalValues + rawValues.length > 32768 ? 'total_value_count' : null;
        if (limitStage) return { ...failed('category_values_limit'), limitDiagnostics: { limitStage,
          observedCount: limitStage === 'property_value_count' ? rawValues.length : totalValues + rawValues.length, maxPerPropertyCount } };
        totalValues += rawValues.length;
        const ids = new Set();
        for (const option of rawValues) {
          const invalid = !plain(option) ? 'row' : !id(option.id) ? 'id' : !text(option.name, 1024) ? 'label' : ids.has(option.id) ? 'duplicateId' : '';
          if (invalid) {
            property.valid = false;
            // Fixed counters explain a rejected option without retaining any of
            // its text, identifiers, raw data or arbitrary diagnostic strings.
            if (!property.invalidValueCounts) property.invalidValueCounts = { row: 0, id: 0, label: 0, duplicateId: 0 };
            property.invalidValueCounts[invalid]++;
            continue;
          }
          ids.add(option.id); property.values.push({ apiId: option.id, displayLabel: option.name });
        }
      }
      properties.push(property);
    }
    return { accepted: true, complete: false, source: 'observed-seller-category-definition', categoryId, endpointPathHash: pathHash, responseComplete: true, propertyRowsComplete, properties };
  } catch { return failed('category_response_unverified'); }
}

/** Optional diagnostics only: inspect the already received Composition row's
 * structure without returning scalar content or granting any field capability.
 * categoryId must come from the caller's independently verified request scope.
 */
export function projectCompositionPropertyStructure(input = {}) {
  const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
  const member = (value, key) => {
    if (!object(value) && !Array.isArray(value)) return { present: false };
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    return !descriptor ? { present: false } : Object.hasOwn(descriptor, 'value') ? { present: true, readable: true, value: descriptor.value } : { present: true, readable: false };
  };
  const own = (value, key) => member(value, key).value;
  const limits = { depth: 2, keysPerObject: 32, arraySamples: 8, nodes: 160, propertyRows: 200 };
  const output = { kind: 'composition-property-structure', version: 1, complete: false, categoryId: null, propertyId: '101057', matchedCount: null,
    matchScanComplete: false, propertyRowsInspected: 0, limits, nodesVisited: 0, filteredKeyCount: 0, omittedEntryCount: 0, truncated: false };
  const credentialShape = /gh[pousr]_|github_pat_|(?:^|[_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[_-])(?:jwt|basic|bearer)(?:$|[_-])/iu;
  const safeKey = key => typeof key === 'string' && /^[A-Za-z_][A-Za-z0-9_]{0,63}$/u.test(key)
    && !['__proto__', 'prototype', 'constructor'].includes(key)
    && !credentialShape.test(key)
    && !/token|cookie|auth|secret|password|passwd|credential|session|bearer|csrf|signature|api_?key|access_?key|private_?key|refresh|headers?|(?:^|_)(?:url|uri|email)(?:$|_)|[0-9]{6,}|[a-f0-9]{24,}/iu.test(key);
  const kind = value => value === null ? 'null' : Array.isArray(value) ? 'array' : object(value) ? 'object' : ['string', 'number', 'boolean'].includes(typeof value) ? typeof value : 'unsupported';
  const omitted = (node, count) => { if (count > 0) { node.omittedEntryCount += count; node.truncated = true; output.omittedEntryCount += count; output.truncated = true; } };
  const shape = (value, depth) => {
    if (output.nodesVisited >= limits.nodes) { output.truncated = true; return null; }
    output.nodesVisited++;
    const type = kind(value), node = { type };
    if (type !== 'object' && type !== 'array') return node;
    node.omittedEntryCount = 0; node.truncated = false;
    if (type === 'array') {
      const length = own(value, 'length');
      if (!Number.isSafeInteger(length) || length < 0) { node.unreadable = true; output.truncated = true; return node; }
      node.length = length; node.sampledCount = 0;
      if (depth >= limits.depth) { omitted(node, length); node.depthLimited = length > 0; return node; }
      node.samples = [];
      const count = Math.min(length, limits.arraySamples);
      for (let index = 0; index < count; index++) {
        if (output.nodesVisited >= limits.nodes) break;
        const item = member(value, String(index));
        if (!item.readable) { node.samples.push({ type: item.present ? 'unreadable' : 'missing' }); output.nodesVisited++; }
        else node.samples.push(shape(item.value, depth + 1));
        node.sampledCount++;
      }
      omitted(node, length - node.sampledCount); return node;
    }
    const keys = Object.keys(value); node.keyCount = keys.length; node.inspectedKeyCount = 0; node.filteredKeyCount = 0;
    if (depth >= limits.depth) { omitted(node, keys.length); node.depthLimited = keys.length > 0; return node; }
    node.keys = Object.create(null);
    for (const key of keys.slice(0, limits.keysPerObject)) {
      if (output.nodesVisited >= limits.nodes) break;
      node.inspectedKeyCount++;
      const item = member(value, key);
      if (!safeKey(key) || !item.readable) { node.filteredKeyCount++; output.filteredKeyCount++; continue; }
      node.keys[key] = shape(item.value, depth + 1);
    }
    omitted(node, keys.length - node.inspectedKeyCount); return node;
  };
  try {
    const categoryId = own(input, 'categoryId');
    if (typeof categoryId === 'string' && /^[A-Za-z0-9_-]{1,160}$/u.test(categoryId) && !credentialShape.test(categoryId)) output.categoryId = categoryId;
    const response = own(input, 'response'), properties = own(own(response, 'data'), 'product_properties');
    if (own(response, 'code') !== 0 || !Array.isArray(properties)) return output;
    const rowCount = own(properties, 'length');
    if (!Number.isSafeInteger(rowCount) || rowCount < 0) return output;
    if (rowCount > limits.propertyRows) { output.truncated = true; return output; }
    let matched;
    output.matchedCount = 0; output.matchScanComplete = true;
    for (let index = 0; index < rowCount; index++) {
      output.propertyRowsInspected++;
      const entry = member(properties, String(index)), row = entry.value, id = member(row, 'id');
      if (!entry.readable || !object(row) || !id.readable || typeof id.value !== 'string') { output.matchScanComplete = false; continue; }
      if (id.value === '101057') { output.matchedCount++; matched = row; }
    }
    if (output.matchedCount !== 1 || !output.matchScanComplete || output.categoryId === null) return output;
    output.members = {};
    for (const key of ['tip', 'label', 'cascade_values']) {
      const item = member(matched, key);
      output.members[key] = { present: item.present };
      if (item.present) {
        if (!item.readable) output.members[key].shape = { type: 'unreadable' };
        else output.members[key].shape = shape(item.value, 0);
        if (output.members[key].shape === null) output.members[key].limitReached = true;
      }
    }
    return output;
  } catch {
    delete output.members; output.matchScanComplete = false; output.diagnosticUnavailable = true; return output;
  }
}

/** QA/proposal compatibility: read only the category definition naturally requested by this owned page.
 * The resource URL and all opaque query values remain inside the browser.
 * For browser serialization, pass projectCategoryDefinition as the third fixed
 * function argument, just as securityReader is passed as the second argument.
 */
export async function readObservedCategoryDefinition(since, securityReader, projector = projectCategoryDefinition) {
  const origin = 'https://seller.us.tiktokshopglobalselling.com';
  const pathHash = 'd796912ebc77a546509f75d5f4e8236a229bb0436c88a359503ab109eac027ef';
  const failed = reason => ({ accepted: false, reason, complete: false });
  const pageMatches = () => {
    try { const u = new URL(location.href); return u.origin === origin && u.pathname === '/product/create' && !u.username && !u.password && !u.hash && u.searchParams.getAll('shop_region').length === 1 && u.searchParams.get('shop_region') === 'US'; } catch { return false; }
  };
  const secure = () => { const result = securityReader(); return result && result.detected === false; };
  const id = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,160}$/u.test(value);
  try {
    if (!pageMatches() || !Number.isFinite(since) || since < 0 || since > performance.now() || !secure()) return failed('scope_unverified');
    const resources = performance.getEntriesByType('resource');
    if (!Array.isArray(resources) || resources.length > 2000) return failed('resource_limit');
    const hashes = new Map(), categoryIds = new Set(); let chosen;
    for (const entry of resources) {
      if (!['fetch', 'xmlhttprequest'].includes(entry.initiatorType) || !Number.isFinite(entry.startTime) || entry.startTime < since || typeof entry.name !== 'string' || entry.name.length > 16384) continue;
      let u; try { u = new URL(entry.name); } catch { continue; }
      if (u.origin !== origin || u.username || u.password || u.hash || !/^\/api\/v1\/product\/category\/[^/]+\/get\/?$/u.test(u.pathname)) continue;
      if (!hashes.has(u.pathname)) {
        const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(u.pathname));
        hashes.set(u.pathname, [...new Uint8Array(bytes)].map(n => n.toString(16).padStart(2, '0')).join(''));
      }
      if (hashes.get(u.pathname) !== pathHash || u.searchParams.getAll('category_id').length !== 1 || !id(u.searchParams.get('category_id'))) continue;
      if (u.searchParams.getAll('locale').length !== 1 || u.searchParams.get('locale') !== 'zh-CN' || u.searchParams.getAll('language').length !== 1 || u.searchParams.get('language') !== 'zh-CN') continue;
      categoryIds.add(u.searchParams.get('category_id')); chosen = u;
    }
    if (!chosen || categoryIds.size !== 1) return failed('category_resource_unverified');
    if (!pageMatches() || !secure()) return failed('scope_unverified');
    const controller = new AbortController(), timer = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch(chosen.href, { method: 'GET', mode: 'same-origin', credentials: 'same-origin', redirect: 'error', signal: controller.signal });
      if (response.status < 200 || response.status >= 300 || !response.body) return failed('category_response_unavailable');
      const reader = response.body.getReader(), chunks = []; let length = 0;
      for (;;) { const part = await reader.read(); if (part.done) break; if (!(part.value instanceof Uint8Array) || (length += part.value.byteLength) > 2 * 1024 * 1024) { await reader.cancel().catch(() => {}); return failed('category_response_limit'); } chunks.push(part.value); }
      const bytes = new Uint8Array(length); let offset = 0;
      for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
      let data; try { data = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { return failed('category_response_invalid'); }
      if (!pageMatches() || !secure()) return failed('category_response_unverified');
      return projector({ categoryId: chosen.searchParams.get('category_id'), response: data });
    } finally { clearTimeout(timer); }
  } catch { return failed('category_read_failed'); }
}
