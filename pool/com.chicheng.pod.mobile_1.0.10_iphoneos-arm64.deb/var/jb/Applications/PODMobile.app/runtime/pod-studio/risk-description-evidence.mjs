import {plainDescription} from './risk-review-contract.mjs';

// Evidence semantics, not the policy/legal baseline. Old results may still be
// displayed by an old instance, but cannot skip a new-input review.
export const RISK_INPUT_VERSION='2026-11-02-description-images-2';
export const DESCRIPTION_IMAGE_LIMIT=4;
export const RISK_TOTAL_IMAGE_BYTES=24*1024*1024;
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const kinds=['empty','text','images','mixed','missing','unsupported'];
const reasons=['missing','html_limit','text_limit','unsupported_content','invalid_image','image_limit','image_read_failed','image_bytes_limit','model_unreviewed'];
const decode=value=>value.replace(/&amp;/giu,'&').replace(/&quot;/giu,'"').replace(/&apos;|&#39;/giu,"'").replace(/&#(?:x([0-9a-f]+)|(\d+));/giu,(_all,hex,decimal)=>{const code=Number.parseInt(hex||decimal,hex?16:10);return code>0&&code<=0x10ffff&&!(code>=0xd800&&code<=0xdfff)?String.fromCodePoint(code):' ';});
const attributes=tag=>[...tag.matchAll(/\s+([^\s"'=<>`/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'<>`]+)))?/gu)]
  .map(match=>({name:match[1].toLowerCase(),value:decode(match[2]??match[3]??match[4]??'').trim()}));

/** Parse only inert supplied HTML. URLs are evidence references, not commands. */
export function describeRiskDescription(value,{available=typeof value==='string'}={}){
  const raw=typeof value==='string'?value:'',htmlTruncated=raw.length>256000;
  const passive=raw.slice(0,256000).replace(/<!--[\s\S]*?(?:-->|$)/gu,' ').replace(/<script\b[^>]*>[\s\S]*?(?:<\/script\s*>|$)/giu,' ');
  const styleBlocks=passive.match(/<style\b[^>]*>[\s\S]*?(?:<\/style\s*>|$)/giu)||[];
  const inert=passive.replace(/<style\b[^>]*>[\s\S]*?(?:<\/style\s*>|$)/giu,' ');
  const fullText=decode(plainDescription(inert)).replace(/\s+/gu,' ').trim(),text=fullText.slice(0,24000),textTruncated=fullText.length>24000;
  const openingTags=inert.match(/<[a-z](?:"[^"]*"|'[^']*'|[^'">])*?>/giu)||[];
  const tags=openingTags.filter(tag=>/^<img\b/iu.test(tag)),urls=[],seen=new Set();let invalidImages=0;
  for(const tag of tags){
    const url=attributes(tag).find(attribute=>attribute.name==='src')?.value||'';
    let accepted=false;try{const parsed=new URL(url);accepted=url.length<=8192&&['https:','http:'].includes(parsed.protocol)&&!parsed.username&&!parsed.password&&!/\s/u.test(url);}catch{}
    if(!accepted){invalidImages++;continue;}if(!seen.has(url)){seen.add(url);urls.push(url);}
  }
  // CSS backgrounds and responsive alternatives are never fetched or silently
  // treated as empty, including unquoted and HTML-entity encoded attributes.
  const unsupportedContent=/<(?:svg|video|audio|iframe|object|embed|canvas|source|input)\b/iu.test(inert)
    ||styleBlocks.some(block=>/\burl\s*\(/iu.test(decode(block)))
    ||openingTags.some(tag=>attributes(tag).some(attribute=>attribute.name==='style'?/\burl\s*\(/iu.test(attribute.value)
      :['background','srcset'].includes(attribute.name)&&attribute.value!==''));
  const imageCount=urls.length+invalidImages;
  const kind=!available?'missing':text&&imageCount?'mixed':imageCount?'images':text?'text':unsupportedContent||htmlTruncated?'unsupported':'empty';
  const reasonCodes=[];if(!available)reasonCodes.push('missing');if(htmlTruncated)reasonCodes.push('html_limit');if(textTruncated)reasonCodes.push('text_limit');if(unsupportedContent)reasonCodes.push('unsupported_content');if(invalidImages)reasonCodes.push('invalid_image');if(imageCount>DESCRIPTION_IMAGE_LIMIT)reasonCodes.push('image_limit');
  return {text,urls,kind,sourceConfirmed:available,htmlTruncated,textTruncated,textCharacters:fullText.length,imageCount,invalidImages,reasonCodes};
}

/** Small, URL-free server-owned DTO. Never accept this structure from a model. */
export function riskDescriptionReview(value){
  if(value===undefined||value===null)return undefined;
  const count=key=>Number.isSafeInteger(value[key])&&value[key]>=0&&value[key]<=1000000;
  if(!plain(value)||value.inputVersion!==RISK_INPUT_VERSION||!kinds.includes(value.kind)||typeof value.sourceConfirmed!=='boolean'||typeof value.textChecked!=='boolean'||typeof value.complete!=='boolean'
    ||!['textCharacters','imageCount','imageReadCount','imageCheckedCount','unreviewedImageCount'].every(count)||!Array.isArray(value.reasonCodes)||value.reasonCodes.some(code=>!reasons.includes(code))
    ||value.imageCheckedCount>value.imageReadCount||value.imageReadCount>value.imageCount||value.unreviewedImageCount!==value.imageCount-value.imageCheckedCount)throw new Error('商品描述检查明细无效。');
  if(value.complete&&(!value.sourceConfirmed||value.reasonCodes.length||value.unreviewedImageCount||value.textCharacters>0&&!value.textChecked||value.kind==='missing'||value.kind==='unsupported'))throw new Error('商品描述检查不能虚报完成。');
  if(value.kind==='empty'&&(value.textCharacters||value.imageCount||value.textChecked||!value.sourceConfirmed))throw new Error('空描述来源明细无效。');
  return {inputVersion:RISK_INPUT_VERSION,kind:value.kind,sourceConfirmed:value.sourceConfirmed,textCharacters:value.textCharacters,textChecked:value.textChecked,imageCount:value.imageCount,imageReadCount:value.imageReadCount,imageCheckedCount:value.imageCheckedCount,unreviewedImageCount:value.unreviewedImageCount,complete:value.complete,reasonCodes:[...new Set(value.reasonCodes)]};
}

export function finishRiskDescription(evidence,{imagesRead=0,modelChecked=false,extraReasons=[]}={}){
  const reasonCodes=[...evidence.reasonCodes,...extraReasons];
  const nonempty=evidence.textCharacters>0||imagesRead>0;
  if(nonempty&&!modelChecked)reasonCodes.push('model_unreviewed');
  const imageCheckedCount=modelChecked?imagesRead:0;
  return riskDescriptionReview({inputVersion:RISK_INPUT_VERSION,kind:evidence.kind,sourceConfirmed:evidence.sourceConfirmed,textCharacters:evidence.textCharacters,textChecked:evidence.textCharacters>0&&modelChecked,imageCount:evidence.imageCount,imageReadCount:imagesRead,imageCheckedCount,unreviewedImageCount:evidence.imageCount-imageCheckedCount,reasonCodes:[...new Set(reasonCodes)],complete:evidence.sourceConfirmed&&!reasonCodes.length&&imageCheckedCount===evidence.imageCount&&(evidence.textCharacters===0||modelChecked)});
}

export const riskImageByteLength=image=>{
  const body=image.dataUrl.slice(image.dataUrl.indexOf(',')+1);return body.length/4*3-(body.endsWith('==')?2:body.endsWith('=')?1:0);
};

export function descriptionReviewError(value){
  const review=riskDescriptionReview(value);if(!review||review.complete)return '';
  const labels={missing:'源描述字段未完整读取',html_limit:'描述HTML超过本次读取上限',text_limit:'描述文字超过24000字符检查上限',unsupported_content:'描述含暂不支持的嵌入内容',invalid_image:'部分描述图缺少有效公开图片地址',image_limit:'描述图超过单次4张上限',image_read_failed:'部分描述图读取失败',image_bytes_limit:'本次图片总量超过24 MiB上限',model_unreviewed:'模型未确认已检查描述内容'};
  return [...review.reasonCodes.map(code=>labels[code]),...(review.imageCount?['描述图已检查 '+review.imageCheckedCount+' / '+review.imageCount+'，尚有 '+review.unreviewedImageCount+' 张未检查']:[])].join('；');
}
