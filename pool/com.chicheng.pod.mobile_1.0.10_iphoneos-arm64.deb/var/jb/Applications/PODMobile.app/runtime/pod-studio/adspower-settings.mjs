import {readFile,writeFile,mkdir,rename,unlink} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {homedir} from 'node:os';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';

const PROJECT=fileURLToPath(new URL('./',import.meta.url));
const defaultRoot=()=>join(process.env.APPDATA||join(homedir(),'AppData','Roaming'),'PODStudio','publishing');
const failure=(message='AdsPower 设置无法读取或保存，请检查当前 Windows 用户的权限。')=>Object.assign(new Error(message),{code:'ADS_SETTINGS',status:503});
export function validateAdsPowerEndpoint(value='http://127.0.0.1:50325'){
  let url;try{url=new URL(value);}catch{throw Object.assign(failure('请填写本机 AdsPower Local API 地址。'),{status:400});}
  if(url.protocol!=='http:'||!['127.0.0.1','localhost','[::1]'].includes(url.hostname)||url.username||url.password||url.pathname!=='/'||url.search||url.hash||!url.port||Number(url.port)<1024||Number(url.port)>65535)throw Object.assign(failure('AdsPower API 仅支持本机 1024–65535 端口的 HTTP 地址。'),{status:400});
  return url.origin;
}
function nativeSecrets(mode,path,input){return new Promise((resolvePromise,reject)=>{
  const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(PROJECT,'provider-secrets.ps1'),'-Mode',mode,'-Path',path],{windowsHide:true,stdio:['pipe','pipe','ignore']});
  let output='',settled=false;const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);if(error)reject(failure());else resolvePromise(value);};
  const timer=setTimeout(()=>{child.kill();finish(true);},10000);
  child.stdout.on('data',chunk=>{output+=chunk;if(output.length>16384){child.kill();finish(true);}});
  child.once('error',()=>finish(true));child.once('close',code=>{if(code!==0)return finish(true);try{finish(false,mode==='read'?JSON.parse(output):true);}catch{finish(true);}});
  child.stdin.on('error',()=>finish(true));child.stdin.end(input===undefined?'':JSON.stringify(input));
});}
/** API keys remain in the host's DPAPI store and are never returned to the UI. */
export function createAdsPowerSettings({root=defaultRoot(),readSecrets,writeSecrets,now=()=>new Date().toISOString()}={}){
  const configPath=join(root,'adspower-settings.json'),secretPath=join(root,'adspower-secrets.dpapi');
  const decrypt=readSecrets||(()=>nativeSecrets('read',secretPath)),encrypt=writeSecrets||(value=>nativeSecrets('write',secretPath,value));
  let config,key='',loaded=false,loading,queue=Promise.resolve();
  async function load(){if(loaded)return;if(!loading)loading=(async()=>{
    let value={};try{value=JSON.parse(await readFile(configPath,'utf8'));}catch(error){if(error.code!=='ENOENT')throw failure();}
    if(!value||typeof value!=='object'||Array.isArray(value))throw failure();
    const endpoint=validateAdsPowerEndpoint(value.endpoint||'http://127.0.0.1:50325');
    let secrets;try{secrets=await decrypt();}catch{throw failure();}
    if(!secrets||typeof secrets!=='object'||Array.isArray(secrets)||secrets.apiKey!==undefined&&(typeof secrets.apiKey!=='string'||secrets.apiKey.length>4096||/[\s\u0000-\u001f\u007f]/u.test(secrets.apiKey)))throw failure();
    key=secrets.apiKey||'';config={endpoint,updatedAt:typeof value.updatedAt==='string'?value.updatedAt:''};loaded=true;
  })();try{await loading;}finally{loading=undefined;}}
  async function publicStatus(){await load();return {configured:Boolean(key),endpoint:config.endpoint,keyConfigured:Boolean(key)};}
  async function getConnectionConfig(){await load();return {endpoint:config.endpoint,apiKey:key};}
  async function save(input){const operation=queue.then(async()=>{
    await load();if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['endpoint','apiKey','clearApiKey'].includes(k))||input.clearApiKey!==undefined&&typeof input.clearApiKey!=='boolean'||input.apiKey!==undefined&&typeof input.apiKey!=='string')throw Object.assign(failure('AdsPower 配置格式无效。'),{status:400});
    const endpoint=validateAdsPowerEndpoint(input.endpoint===undefined?config.endpoint:input.endpoint),entered=(input.apiKey||'').trim();
    if(entered.length>4096||/[\s\u0000-\u001f\u007f]/u.test(entered)||input.clearApiKey&&entered)throw Object.assign(failure('AdsPower API Key 格式无效。'),{status:400});
    const nextKey=input.clearApiKey?'':entered||key,next={endpoint,updatedAt:now()};
    await mkdir(root,{recursive:true});
    if(nextKey!==key){try{await encrypt({apiKey:nextKey});}catch{throw failure();}key=nextKey;}
    const temporary=configPath+'.'+randomBytes(8).toString('hex')+'.tmp';
    try{await writeFile(temporary,JSON.stringify(next,null,2),{flag:'wx'});await rename(temporary,configPath);}catch{throw failure();}finally{await unlink(temporary).catch(()=>{});}
    config=next;return publicStatus();
  });queue=operation.catch(()=>{});return operation;}
  return {root,load,publicStatus,getConnectionConfig,save};
}
