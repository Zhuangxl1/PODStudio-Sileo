import {hasAllCategoryAccess} from './dist/tiktok-category-access.js';
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const label=value=>typeof value==='string'&&value.trim()&&value.trim().length<=160&&!/[\u0000-\u001f\u007f]/u.test(value)&&!value.includes(' > ')&&!/^(?:[-—–]+|暂无|未选择|未设置|请选择(?:主营)?类目|N\/?A|null|undefined)$/iu.test(value.trim());
const samePath=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export function normalizedMainCategory(value,readAt){
  if(!plain(value)||value.source!=='seller-profile'||!label(value.label)||!Array.isArray(value.path)||value.path.length!==1||value.path[0]!==value.label)return null;
  return {label:value.label.trim(),path:[value.label.trim()],source:'seller-profile',...(readAt?{readAt}:typeof value.readAt==='string'?{readAt:value.readAt}:{})};
}
export const hasShopProfile=binding=>binding?.profileStatus==='ready'&&normalizedMainCategory(binding.mainCategory)!==null;
export function categoryScopeAllows(binding,path){return hasShopProfile(binding)&&Array.isArray(path)&&path.length>0&&path.every(label)&&(hasAllCategoryAccess(binding)||path[0]===binding.mainCategory.label);}
export function validCategoryBranch(value,binding,parentPath){
  if(!Array.isArray(parentPath)||!parentPath.length||parentPath.length>10||!parentPath.every(label)||!plain(value)||value.complete!==true||value.status!==undefined&&value.status!=='ready'||!samePath(value.parentPath,parentPath)||typeof value.leaf!=='boolean'||!Array.isArray(value.nodes)||value.nodes.length>2000||value.leaf&&value.nodes.length||!value.leaf&&!value.nodes.length)return null;
  const seen=new Set(),nodes=[];
  for(const node of value.nodes){if(!plain(node)||!label(node.label)||seen.has(node.label)||typeof node.disabled!=='boolean'||!samePath(node.path,[...parentPath,node.label]))return null;seen.add(node.label);nodes.push({label:node.label,path:[...parentPath,node.label],disabled:node.disabled});}
  if(!categoryScopeAllows(binding,parentPath))return null;
  return {region:binding.identity.region,mainCategory:binding.mainCategory.label,parentPath:[...parentPath],leaf:value.leaf,nodes,complete:true};
}
export function rootCategoryBranch(binding,readAt){return {shopId:binding.identity.shopId,region:binding.identity.region,parentPath:[],readAt:binding.mainCategory.readAt||readAt,source:'seller-profile-main-category',complete:true,leaf:false,nodes:[{label:binding.mainCategory.label,path:[binding.mainCategory.label],disabled:false}],issues:[]};}
export function categoryTreeView(trees,binding,readAt){
  if(!hasShopProfile(binding))return {catalogs:[],sync:{complete:false,totalBranches:0,completedBranches:0,pendingBranches:1,issues:['请先读取并保存店铺主营类目。']},pendingPaths:[]};
  const candidates=trees.filter(item=>plain(item)&&item.region===binding.identity.region&&item.mainCategory===binding.mainCategory.label&&Array.isArray(item.parentPath)&&categoryScopeAllows(binding,item.parentPath));
  const branches=new Map(candidates.map(item=>{const valid=validCategoryBranch(item,binding,item.parentPath);return [JSON.stringify(item.parentPath),valid?{...valid,...(typeof item.readAt==='string'?{readAt:item.readAt}:{}),source:'live-shop-category-menu',issues:[]}:null];}));
  const pendingPaths=[],visited=new Set(),queue=[[binding.mainCategory.label]],catalogs=[rootCategoryBranch(binding,readAt)];let completedBranches=0;
  while(queue.length){const path=queue.shift(),key=JSON.stringify(path);if(visited.has(key))continue;visited.add(key);const branch=branches.get(key);if(!branch?.complete){pendingPaths.push(path);continue;}
    completedBranches++;catalogs.push({...structuredClone(branch),shopId:binding.identity.shopId,issues:[]});
    if(!branch.leaf)for(const node of branch.nodes)if(!node.disabled)queue.push(node.path);
  }
  return {catalogs,sync:{complete:pendingPaths.length===0,totalBranches:completedBranches+pendingPaths.length,completedBranches,pendingBranches:pendingPaths.length,issues:[]},pendingPaths};
}
