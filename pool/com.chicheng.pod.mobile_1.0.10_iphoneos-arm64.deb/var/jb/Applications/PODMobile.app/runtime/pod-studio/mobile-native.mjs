import {createRequire} from 'node:module';
const require = createRequire(import.meta.url);
let binding;
export function nativeBinding() {
  if (!binding) { if(process.platform==='android'&&process.env.POD_SQLITE_BINDING){const Module=require('node:module');const module=new Module(process.env.POD_SQLITE_BINDING);process.dlopen(module,process.env.POD_SQLITE_BINDING);binding=module.exports;}else binding=require('../native/sqlite.node'); }
  return binding;
}
export function readKeychainJSON(name) {
  const raw = nativeBinding().keychainRead(name);
  return raw == null ? null : JSON.parse(raw);
}
export function writeKeychainJSON(name, value) {
  if (nativeBinding().keychainWrite(name, JSON.stringify(value)) !== true) throw new Error('手机安全设置保存失败。');
  return true;
}
