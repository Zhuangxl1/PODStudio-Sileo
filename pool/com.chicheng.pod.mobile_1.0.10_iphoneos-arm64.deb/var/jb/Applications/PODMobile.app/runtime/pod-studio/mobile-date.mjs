// Node Mobile is built without Intl. These business formats use explicit zones.
export function shanghaiTimestamp(value) {
  const date = new Date(Number(new Date(value)) + 8 * 3600000);
  if (!Number.isFinite(date.getTime())) throw new RangeError('Invalid time');
  return date.toISOString().slice(0, 19).replace(/[-:]/g, '').replace('T', '_');
}
export function newYorkDate(value) {
  const time = Number(new Date(value)), year = new Date(time).getUTCFullYear();
  // US DST rules since 2007. The app's date windows concern current commerce.
  const sunday = (month, occurrence) => 1 + (7 - new Date(Date.UTC(year, month, 1)).getUTCDay()) % 7 + (occurrence - 1) * 7;
  const start = Date.UTC(year, 2, sunday(2, 2), 7), end = Date.UTC(year, 10, sunday(10, 1), 6);
  return new Date(time + (time >= start && time < end ? -4 : -5) * 3600000).toISOString().slice(0, 10);
}
export const utcMonthName = value => ['january','february','march','april','may','june','july','august','september','october','november','december'][new Date(value).getUTCMonth()];
