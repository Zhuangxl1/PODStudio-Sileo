const MAX_PIXELS = 8_000_000;
const CORE_ALPHA = 128;
const STRONG_ALPHA = 192;
const EDGE_ALPHA = 64;

function hasSolidWhiteArtwork(rgba) {
  let core = 0;
  let opaque = 0;
  let offWhite = 0;
  for (let offset = 0; offset < rgba.length; offset += 4) {
    const alpha = rgba[offset + 3];
    if (alpha < EDGE_ALPHA) continue;
    const lightest = Math.max(rgba[offset], rgba[offset + 1], rgba[offset + 2]);
    const darkest = Math.min(rgba[offset], rgba[offset + 1], rgba[offset + 2]);
    if (alpha >= STRONG_ALPHA && (darkest < 230 || lightest - darkest > 8)) return false;
    if (lightest - darkest > 24) return false;
    if (alpha < CORE_ALPHA) continue;
    core++;
    if (alpha >= STRONG_ALPHA) opaque++;
    if (darkest < 245 || lightest - darkest > 6) offWhite++;
  }
  // Decline soft, colored or grayscale artwork rather than filling intentional tones.
  return core >= 8 && core < rgba.length / 4 && opaque >= 0.6 * core
    && offWhite <= Math.max(1, 0.005 * core);
}

function visitComponent(mask, visited, queue, start, width, height, diagonal) {
  const color = mask[start];
  let end = 1;
  let left = width, right = -1, top = height, bottom = -1;
  queue[0] = start;
  visited[start] = 1;
  for (let head = 0; head < end; head++) {
    const index = queue[head];
    const x = index % width, y = (index - x) / width;
    left = Math.min(left, x);
    right = Math.max(right, x);
    top = Math.min(top, y);
    bottom = Math.max(bottom, y);
    for (let dy = -1; dy <= 1; dy++) {
      const ny = y + dy;
      if (ny < 0 || ny >= height) continue;
      const startX = diagonal || dy === 0 ? Math.max(0, x - 1) : x;
      const endX = diagonal || dy === 0 ? Math.min(width - 1, x + 1) : x;
      for (let nx = startX; nx <= endX; nx++) {
        const neighbor = ny * width + nx;
        if (visited[neighbor] || mask[neighbor] !== color) continue;
        visited[neighbor] = 1;
        queue[end++] = neighbor;
      }
    }
  }
  return {size: end, left, right, top, bottom};
}

function removeWeakSpecks(mask, rgba, width, height, visited, queue) {
  let removed = 0;
  for (let index = 0; index < mask.length; index++) {
    if (visited[index] || mask[index] !== 1) continue;
    const {size} = visitComponent(mask, visited, queue, index, width, height, true);
    // Tiny low-opacity islands are residue. Retain even single-pixel opaque details.
    if (size > 3 || queue.subarray(0, size).some(pixel => rgba[pixel * 4 + 3] >= STRONG_ALPHA)) continue;
    for (let i = 0; i < size; i++) mask[queue[i]] = 2;
    removed += size;
  }
  for (let index = 0; index < mask.length; index++) {
    if (mask[index] === 2) mask[index] = 0;
  }
  return removed;
}

function fillPinholes(mask, rgba, width, height, visited, queue) {
  let filled = 0;
  const shortEdge = Math.min(width, height);
  const maxSpan = Math.min(6, Math.max(2, Math.round(shortEdge / 150)));
  const maxCloudSpan = Math.min(28, Math.max(maxSpan, Math.floor(shortEdge / 32)));
  const maxCloudArea = Math.min(160, Math.ceil(shortEdge / 5));
  for (let index = 0; index < mask.length; index++) {
    if (visited[index] || mask[index]) continue;
    const {size, left, right, top, bottom} = visitComponent(mask, visited, queue, index, width, height, false);
    if (left === 0 || right === width - 1 || top === 0 || bottom === height - 1) continue;
    const span = Math.max(right - left, bottom - top) + 1;
    if (span > maxCloudSpan || size > maxCloudArea) continue;
    let totalAlpha = 0;
    for (let i = 0; i < size; i++) totalAlpha += rgba[queue[i] * 4 + 3];
    const pinhole = span <= maxSpan && (size <= 2 || totalAlpha >= 16 * size);
    // Broader scuffs contain weak coverage throughout. Clear openings, such
    // as wheel slots or letter counters, are protected by the opacity check.
    const scuff = totalAlpha >= 48 * size;
    if (!pinhole && !scuff) continue;
    for (let i = 0; i < size; i++) mask[queue[i]] = 1;
    filled += size;
  }
  return filled;
}

/** Restore a near-white, solid one-ink print from its actual opacity silhouette. */
export function cleanSolidWhitePrint({width, height, rgba}) {
  const pixels = width * height;
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width <= 0 || height <= 0
    || pixels > MAX_PIXELS || !(rgba instanceof Uint8Array) || rgba.length !== pixels * 4
    || !hasSolidWhiteArtwork(rgba)) return null;

  const mask = new Uint8Array(pixels);
  for (let index = 0; index < pixels; index++) mask[index] = Number(rgba[index * 4 + 3] >= CORE_ALPHA);
  const visited = new Uint8Array(pixels);
  const queue = new Uint32Array(pixels);
  const weakSpeckPixels = removeWeakSpecks(mask, rgba, width, height, visited, queue);
  visited.fill(0);
  const filledPinholePixels = fillPinholes(mask, rgba, width, height, visited, queue);
  const result = new Uint8Array(rgba.length);
  let visiblePixels = 0, opaquePixels = 0, clearedPixels = 0, changedPixels = 0;
  for (let index = 0; index < pixels; index++) {
    const offset = index * 4;
    const originalAlpha = rgba[offset + 3];
    const x = index % width;
    const neighbors = Number(x > 0 && mask[index - 1]) + Number(x + 1 < width && mask[index + 1])
      + Number(index >= width && mask[index - width]) + Number(index + width < pixels && mask[index + width]);
    let alpha = 0;
    if (mask[index]) {
      alpha = neighbors === 4 || originalAlpha < CORE_ALPHA || originalAlpha >= 224
        ? 255 : CORE_ALPHA + Math.round((originalAlpha - CORE_ALPHA) * 127 / 96);
    } else if (neighbors && originalAlpha > EDGE_ALPHA && originalAlpha < CORE_ALPHA) {
      // Restrict original partial coverage to the first pixel outside the silhouette.
      alpha = (originalAlpha - EDGE_ALPHA) * 2;
    }
    if (alpha) {
      result[offset] = result[offset + 1] = result[offset + 2] = 255;
      result[offset + 3] = alpha;
      visiblePixels++;
      if (alpha === 255) opaquePixels++;
    } else if (originalAlpha) {
      clearedPixels++;
    }
    if (alpha !== originalAlpha || rgba[offset] !== result[offset]
      || rgba[offset + 1] !== result[offset + 1] || rgba[offset + 2] !== result[offset + 2]) changedPixels++;
  }
  if (!opaquePixels || visiblePixels === pixels) return null;
  return {
    rgba: changedPixels ? result : rgba,
    stats: {visiblePixels, opaquePixels, clearedPixels, filledPinholePixels, weakSpeckPixels, changedPixels},
  };
}
