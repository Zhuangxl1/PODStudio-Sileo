import {networkInterfaces} from 'node:os';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {isPrivateIPv4} from './lan-server.mjs';
const execute=promisify(execFile);
export function rankLanAddresses(interfaces,preferred=[]){
  const rows=[];for(const[name,list]of Object.entries(interfaces))for(const item of list||[])if(item.family==='IPv4'&&!item.internal&&isPrivateIPv4(item.address)&&!rows.some(row=>row.address===item.address))rows.push({address:item.address,virtual:/virtual|vethernet|vmware|virtualbox|docker|wsl|vpn|tailscale|zerotier|tap-|tunnel/i.test(name)});
  rows.sort((a,b)=>{const ai=preferred.indexOf(a.address),bi=preferred.indexOf(b.address);return (ai<0?1000:ai)-(bi<0?1000:bi)||Number(a.virtual)-Number(b.virtual);});
  return rows.map(row=>row.address);
}
export async function discoverLanAddresses(){
  let preferred=[];
  if(process.platform==='win32')try{const{stdout}=await execute('powershell.exe',['-NoProfile','-NonInteractive','-Command',"Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPv4DefaultGateway -and $_.IPv4Address } | Sort-Object { $_.NetIPv4Interface.InterfaceMetric } | ForEach-Object { $_.IPv4Address.IPAddress }"],{windowsHide:true,timeout:5000,maxBuffer:8192});preferred=stdout.split(/\r?\n/).map(x=>x.trim()).filter(isPrivateIPv4);}catch{}
  return rankLanAddresses(networkInterfaces(),preferred);
}
