import {createHash,randomUUID} from 'node:crypto';
import {mkdir,readFile,writeFile,rename,open,unlink} from 'node:fs/promises';
import {resolve} from 'node:path';
const fail=message=>{throw Object.assign(new Error(message),{code:'MIAOSHOU_DESCRIPTION_IMAGES',status:409});};
const decode=s=>s.replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'");
const escape=s=>s.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
function safeUrl(value){try{const u=new URL(value);return typeof value==='string'&&value.length<=4096&&u.protocol==='https:'&&!u.username&&!u.password&&!/\s/.test(value);}catch{return false;}}
const tags=/<img\b[^>]*>/gi,src=/(\s+src\s*=\s*)(["'])(.*?)\2/i;
export function descriptionImageUrls(notes){if(typeof notes!=='string'||Array.from(notes).length>10000)return [];return [...new Set((notes.match(tags)||[]).map(tag=>decode(tag.match(src)?.[3]||'')).filter(safeUrl))];}
export function replaceDescriptionImages(notes,mappings){
 const present=descriptionImageUrls(notes);if(!mappings.length||mappings.some(m=>!present.includes(m.sourceUrl)||!safeUrl(m.newUrl)))fail('当前描述图片已变化或不含所选图片，请重新读取。');
 const map=new Map(mappings.map(m=>[m.sourceUrl,m.newUrl]));
 const result=notes.replace(tags,tag=>tag.replace(src,(all,prefix,quote,value)=>map.has(decode(value))?prefix+quote+escape(map.get(decode(value)))+quote:all));
 if(Array.from(result).length>10000)fail('替换后的描述超过接口长度限制。');return result;
}
/** Generation is never retried. A durable hash ledger prevents unknown or
 * already completed generation requests from being resent after a restart. */
export function createDescriptionImageProcessor({root,client,accountScope,guard=()=>{}}){
 const tickets=new Map();let queue=Promise.resolve(),memory=[];const file=root?resolve(root,'description-image-generations-v1.json'):null;
 async function ledger(){if(!file)return memory;try{const raw=await readFile(file,'utf8');if(raw.length>1024*1024)throw Error();const a=JSON.parse(raw);if(!Array.isArray(a)||a.some(e=>!e||!/^[a-f0-9]{64}$/.test(e.key)||!['started','complete','uncertain'].includes(e.state)))throw Error();return a;}catch(e){if(e.code==='ENOENT')return [];fail('图片处理记录无法读取，请保留文件并核对。');}}
 async function save(rows){if(!file){memory=rows;return;}await mkdir(root,{recursive:true});const tmp=file+'.'+randomUUID()+'.tmp';await writeFile(tmp,JSON.stringify(rows),{flag:'wx'});await rename(tmp,file);}
 async function locked(fn){let lock;if(file){await mkdir(root,{recursive:true});try{lock=await open(file+'.lock','wx');}catch{fail('图片处理记录正在使用，请稍后核对。');}}try{return await fn();}finally{if(lock){await lock.close();await unlink(file+'.lock');}}}
 return {
   generate({info,target,imageUrls}){const run=queue.then(()=>locked(async()=>{
     guard();if(!Array.isArray(imageUrls)||!imageUrls.length||imageUrls.length>15||new Set(imageUrls).size!==imageUrls.length||Array.from(imageUrls).some(u=>!descriptionImageUrls(info.notes).includes(u)))fail('请从当前描述中选择 1–15 张图片。');
     const scope=await accountScope(),key=createHash('sha256').update(JSON.stringify([scope,target.shopId,String(info.cid),'white-background',imageUrls.slice().sort()])).digest('hex'),rows=await ledger();
     const previous=rows.find(e=>e.key===key);if(previous){const cached=[...tickets.values()].find(t=>t.key===key&&t.expires>Date.now());if(cached)return {ticket:cached.id,results:cached.results};fail('这些图片已有处理记录，结果不能重复提交，请在妙手核对。');}
     if(rows.length>=1000)fail('图片处理记录已满，请联系管理员。');
     const entry={key,state:'started',at:new Date().toISOString()};rows.push(entry);await save(rows);guard();
     try{
       const data=await client.call('descriptionMatting',{imgUrls:imageUrls,imageScene:2});guard();if(await accountScope()!==scope)fail('账号已变化，请重新核对。');
       const returned=data?.imgMattingList;if(!Array.isArray(returned))fail('图片处理结果格式无效，请在妙手核对。');
       const results=imageUrls.map(sourceUrl=>{const matches=returned.filter(r=>r.oriImageUrl===sourceUrl);const r=matches.length===1?matches[0]:null;return r?.result==='success'&&safeUrl(r.newImageUrl)?{sourceUrl,newUrl:r.newImageUrl,success:true}:{sourceUrl,success:false};});
       const id=randomUUID(),ticket={id,key,scope,shopId:target.shopId,categoryId:String(info.cid),expires:Date.now()+2*60*60*1000,results};tickets.set(id,ticket);entry.state='complete';await save(rows);return {ticket:id,results};
     }catch{entry.state='uncertain';await save(rows);fail('图片处理结果未确认，系统不会自动重试，请在妙手核对。');}
   }));queue=run.catch(()=>{});return run;},
   async resolve({ticket,sourceUrls},target,info){guard();const t=tickets.get(ticket);if(!t||t.expires<Date.now()||t.scope!==await accountScope()||t.shopId!==target.shopId||t.categoryId!==String(info.cid))fail('图片预览已过期或不属于当前店铺类目，请重新读取。');
     if(!Array.isArray(sourceUrls)||!sourceUrls.length||new Set(sourceUrls).size!==sourceUrls.length)fail('请明确选择要采用的新图片。');
     const mappings=sourceUrls.map(sourceUrl=>{const r=t.results.find(r=>r.success&&r.sourceUrl===sourceUrl);if(!r)fail('所选图片没有成功的预览结果。');return r;});
     return replaceDescriptionImages(info.notes,mappings);
   },
   async close(){await queue;tickets.clear();}
 };
}
