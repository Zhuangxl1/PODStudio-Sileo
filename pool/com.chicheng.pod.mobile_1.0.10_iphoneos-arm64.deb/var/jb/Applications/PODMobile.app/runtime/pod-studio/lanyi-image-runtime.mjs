import {createLanyiProvider} from './lanyi-provider.mjs';
import {createImageApiRuntime} from './siliconflow-runtime.mjs';

const DATA_IMAGE = /^data:(image\/(?:png|jpeg|webp));base64,/u;
const MAX_IMAGES = 6;
const MAX_BYTES = 25 * 1024 * 1024;
const MESSAGES = Object.freeze({
  LANYI_AUTH: '蓝移 API 授权失败，请检查主机 API Key 和模型权限。',
  LANYI_LIMIT: '蓝移 API 额度不足或请求频率受限，请核对账号后重试。',
  LANYI_IMAGE_LIMIT: '蓝移 API 拒绝接收过大的请求。',
  LANYI_REQUEST: '蓝移 API 未接受本次请求，请核对模型及输入格式。',
  LANYI_TIMEOUT: '蓝移 API 请求超时，请先核对原任务结果。',
  LANYI_NETWORK: '无法连接蓝移 API，请检查主机网络。',
  LANYI_UNAVAILABLE: '蓝移 API 暂时无法完成请求，请稍后核对结果。',
  LANYI_IMAGE_INPUT: '蓝移 API 仅接收总计 25 MB 以内的 PNG、JPG 或 WebP 原图。',
  LANYI_RESPONSE: '蓝移 API 未返回有效结果。',
  LANYI_IMAGE_RESPONSE: '蓝移 API 未返回有效图片。',
  LANYI_MODELS: '蓝移 API 未返回可用图像模型，请刷新模型列表。',
  LANYI_MODEL: '蓝移 API 当前图像模型不可用，请选择列表中的模型。',
  LANYI_EFFORT: '蓝移图像模型无需设置推理强度。',
  LANYI_THREAD: '会话不属于当前蓝移连接。',
  LANYI_RUNNING: '此蓝移会话还有图像任务正在运行。',
  LANYI_TURN: '任务不属于当前蓝移会话。',
  LANYI_UNSUPPORTED: '当前蓝移连接仅支持图片生成和编辑。',
});
const RUNTIME_CODES = Object.freeze({
  timeout: 'LANYI_TIMEOUT', model: 'LANYI_MODEL', effort: 'LANYI_EFFORT', request: 'LANYI_REQUEST',
  thread: 'LANYI_THREAD', running: 'LANYI_RUNNING', turn: 'LANYI_TURN', unsupported: 'LANYI_UNSUPPORTED',
});

export function lanyiImagePublicError(error) {
  const code = error?.lanyiImageError;
  return typeof code === 'string' && Object.hasOwn(MESSAGES, code) ? MESSAGES[code] : null;
}

function errorPayload(error, fallback) {
  const code = typeof error?.code === 'string' && Object.hasOwn(MESSAGES, error.code) ? error.code :
    Object.hasOwn(RUNTIME_CODES, error?.kind) ? RUNTIME_CODES[error.kind] :
    fallback === 'request' ? 'LANYI_REQUEST' : 'LANYI_IMAGE_RESPONSE';
  return {code: -32000, message: MESSAGES[code], lanyiImageError: code};
}

function buildImageBody(model, input) {
  const first = input?.[0];
  if (!Array.isArray(input) || first?.type !== 'text' || typeof first.text !== 'string' || !first.text.trim() || first.text.length > 100_000) {
    throw Object.assign(new Error(MESSAGES.LANYI_REQUEST), {code: 'LANYI_REQUEST'});
  }
  const invalid = () => Object.assign(new Error(MESSAGES.LANYI_IMAGE_INPUT), {code: 'LANYI_IMAGE_INPUT'});
  if (input.length - 1 > MAX_IMAGES) throw invalid();
  let total = 0;
  const images = input.slice(1).map(item => {
    const match = item?.type === 'image' && typeof item.url === 'string' && DATA_IMAGE.exec(item.url);
    if (!match) throw invalid();
    const length = item.url.length - match[0].length;
    if (length === 0 || length % 4 || length > Math.ceil((MAX_BYTES - total) / 3) * 4) throw invalid();
    const encoded = item.url.slice(match[0].length);
    if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded)) throw invalid();
    const bytes = Buffer.from(encoded, 'base64');
    total += bytes.length;
    if (!bytes.length || total > MAX_BYTES || bytes.toString('base64') !== encoded) throw invalid();
    return {bytes, mimeType: match[1]};
  });
  return {model, prompt: first.text, images};
}

export function createLanyiImageSpawn({apiKey, fetchImpl, imageModel, provider = createLanyiProvider({apiKey, fetchImpl})} = {}) {
  const client = {
    async listModels() {
      const {data} = await provider.listImageModels();
      if (!data.length) throw Object.assign(new Error(MESSAGES.LANYI_MODELS), {code: 'LANYI_MODELS'});
      const preferred = data.some(row => row.id === imageModel) ? imageModel : data[0].id;
      return data.map(row => ({
        ...row, hidden: false, isDefault: row.id === preferred,
        supportedReasoningEfforts: [{reasoningEffort: 'none', description: '图像模型无需推理强度'}],
        defaultReasoningEffort: 'none',
      }));
    },
    async generate(body, signal) {
      const {bytes} = await provider.generateImage({...body, signal});
      return bytes.toString('base64');
    },
  };
  return () => createImageApiRuntime(client, {runtimeName: 'pod-lanyi-image', buildImageBody, mapError: errorPayload});
}
