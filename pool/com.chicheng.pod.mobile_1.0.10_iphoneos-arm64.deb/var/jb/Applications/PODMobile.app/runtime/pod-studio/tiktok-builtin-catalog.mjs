import {readFileSync,lstatSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {writePackedCatalogLeaf,readPackedCatalogLeaf,catalogStorageValid,verifyCatalogBlobStore} from './tiktok-catalog-codec.mjs';
import {hasAllCategoryAccess} from './dist/tiktok-category-access.js';

const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const sha=v=>createHash('sha256').update(v).digest('hex');
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/u.test(v);
const label=v=>typeof v==='string'&&v===v.trim()&&v.length>0&&v.length<=160&&!/[\u0000-\u001f\u007f]| > /u.test(v);
const path=v=>Array.isArray(v)&&v.length>0&&v.length<=10&&v.every(label);
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const fail=(code,message)=>Object.assign(new Error(message),{code,status:409});
const unavailable=message=>fail('PUBLISH_CATALOG_INCOMPLETE',message||'程序内置类目库尚未完整制作，请更新完整程序包；不会在配对时抓取类目。');
const fileProofKeys=['categoryId','path','fieldCount','optionCount','bytes','sha256','file','storage'];
const publicManifestKeys=new Set(['schemaVersion','catalogId','catalogVersion','region','locale','capturedAt','source','rootsEvidence','treeDefinitionEvidence','roots','branches','leaves','coverage']);
const rootProofKeys=['version','source','complete','responseComplete','rootCount','stableSamples'];
const coverageKeys=['rootsComplete','treeComplete','allLeafSchemasComplete','totalLeaves','readyLeaves','missingBranches','missingLeaves','unavailableLeaves'];
const leafAllowed=new Set(['schemaVersion','region','locale','categoryId','path','identityPath','displayPath','categoryIds','capturedAt','fields','attributeGroups','attributeReadEvidence','supplementalComplianceFields','captureEvidence','zeroAttributeEvidence','schemaSource','publicDefinition','componentDefinition','apiDefinitionEvidence','commitVerified']);
export const PUBLIC_CATEGORY_TREE_PATH_HASH='37e84be280520e4c7905df94b9c5ffdceb339cf691b2e23b8551e5e8f75c1980';
const publicTreeNodeKeys=['id','label','parentId','leaf','displayed'];
const apiTreeProofKeys=['version','source','httpStatus','platformCode','pathHash','responseComplete','observedAt','bodyBytes','projectionSha256','nodeCount','leafCount','rootCount','displayedNodeCount','displayedLeafCount','publicNodes'];
const nodeId=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/u.test(v)&&v!=='0';

function analyzePublicTree(publicNodes){
  if(!Array.isArray(publicNodes)||!publicNodes.length||publicNodes.length>20000)throw unavailable('平台类目树节点数量无效。');
  const nodes=new Map(),children=new Map();
  for(const node of publicNodes){
    if(!plain(node)||Object.keys(node).some(k=>!publicTreeNodeKeys.includes(k))||!nodeId(node.id)||nodes.has(node.id)||!label(node.label)||!(node.parentId==='0'||nodeId(node.parentId))||typeof node.leaf!=='boolean'||typeof node.displayed!=='boolean')throw unavailable('平台类目树包含重复编号或未核验的公共节点。');
    nodes.set(node.id,node);const siblings=children.get(node.parentId)||[];siblings.push(node);children.set(node.parentId,siblings);
  }
  for(const node of nodes.values())if(node.parentId!=='0'&&!nodes.has(node.parentId)||node.leaf&&(children.get(node.id)||[]).length||!node.leaf&&!(children.get(node.id)||[]).length)throw unavailable('平台类目树含孤立节点、叶节点子项或缺失分支。');
  const segmentFor=node=>(children.get(node.parentId)||[]).filter(n=>n.label===node.label).length>1?node.label+'〔'+node.id+'〕':node.label;
  const roots=(children.get('0')||[]).map(n=>({label:n.label,path:[segmentFor(n)],categoryId:n.id,disabled:!n.displayed}));if(!roots.length)throw unavailable('平台类目树缺少大类。');
  const branches=[],leafIdsByPath=new Map(),identitiesByPath=new Map(),queue=(children.get('0')||[]).map(n=>({node:n,path:[segmentFor(n)],displayPath:[n.label],categoryIds:[n.id]})),visited=new Set();
  while(queue.length){const current=queue.shift(),node=current.node,p=current.path;if(visited.has(node.id)||!path(p))throw unavailable('平台类目树存在循环或路径越界。');visited.add(node.id);
    const next=children.get(node.id)||[],branch={parentPath:p,leaf:node.leaf,nodes:next.map(n=>({label:n.label,path:[...p,segmentFor(n)],categoryId:n.id,disabled:!n.displayed}))};branches.push(branch);identitiesByPath.set(JSON.stringify(p),{categoryId:node.id,identityPath:[...p],displayPath:[...current.displayPath],categoryIds:[...current.categoryIds]});
    if(node.leaf)leafIdsByPath.set(JSON.stringify(p),node.id);else for(const child of next)queue.push({node:child,path:[...p,segmentFor(child)],displayPath:[...current.displayPath,child.label],categoryIds:[...current.categoryIds,child.id]});
  }
  if(visited.size!==nodes.size)throw unavailable('平台类目树包含无法从大类到达的循环或孤立节点。');
  const tree=normalizedTree(roots,branches,{identity:true});return {...tree,leafIdsByPath,identitiesByPath,nodeCount:nodes.size,leafCount:leafIdsByPath.size,rootCount:roots.length,displayedNodeCount:publicNodes.filter(n=>n.displayed).length,displayedLeafCount:publicNodes.filter(n=>n.leaf&&n.displayed).length};
}

/** Build-time only: strip store authorization and verify the complete public graph. */
export function buildCapturedCategoryTree({nodes,requestEvidence}={}){
  if(!plain(requestEvidence)||requestEvidence.httpStatus!==200||requestEvidence.platformCode!==0||requestEvidence.pathHash!==PUBLIC_CATEGORY_TREE_PATH_HASH||requestEvidence.responseComplete!==true||typeof requestEvidence.observedAt!=='string'||!Number.isFinite(Date.parse(requestEvidence.observedAt))||!Number.isSafeInteger(requestEvidence.bodyBytes)||requestEvidence.bodyBytes<1||requestEvidence.bodyBytes>64*1024*1024||!Array.isArray(nodes))throw unavailable('平台类目树缺少真实成功响应及完整投影证据。');
  const publicNodes=nodes.map(n=>{const observedLabel=n?.label??n?.name;return {id:n?.id,label:typeof observedLabel==='string'?observedLabel.trim():observedLabel,parentId:n?.parentId,leaf:n?.leaf??n?.isLeaf,displayed:n?.displayed};}),tree=analyzePublicTree(publicNodes);
  const treeDefinitionEvidence={version:1,source:'observed-platform-category-tree',httpStatus:200,platformCode:0,pathHash:PUBLIC_CATEGORY_TREE_PATH_HASH,responseComplete:true,observedAt:requestEvidence.observedAt,bodyBytes:requestEvidence.bodyBytes,projectionSha256:sha(JSON.stringify(publicNodes)),...Object.fromEntries(['nodeCount','leafCount','rootCount','displayedNodeCount','displayedLeafCount'].map(k=>[k,tree[k]])),publicNodes};
  return {roots:tree.roots,branches:tree.branches,treeDefinitionEvidence,categoryIdentities:[...tree.identitiesByPath.values()]};
}

function verifiedApiTree(proof,tree){
  if(!plain(proof)||Object.keys(proof).some(k=>!apiTreeProofKeys.includes(k))||proof.version!==1||proof.source!=='observed-platform-category-tree'||proof.httpStatus!==200||proof.platformCode!==0||proof.pathHash!==PUBLIC_CATEGORY_TREE_PATH_HASH||proof.responseComplete!==true||typeof proof.observedAt!=='string'||!Number.isFinite(Date.parse(proof.observedAt))||!Number.isSafeInteger(proof.bodyBytes)||proof.bodyBytes<1||proof.bodyBytes>64*1024*1024||!hash(proof.projectionSha256)||sha(JSON.stringify(proof.publicNodes))!==proof.projectionSha256)throw unavailable('平台完整类目树响应证明无效。');
  const observed=analyzePublicTree(proof.publicNodes);if(!same(observed.roots,tree.roots)||!same(observed.branches,tree.branches)||['nodeCount','leafCount','rootCount','displayedNodeCount','displayedLeafCount'].some(k=>proof[k]!==observed[k]))throw unavailable('平台类目树公开投影、统计与内置路径不一致。');return observed;
}

function leafShape(leaf){
  return plain(leaf)&&Object.keys(leaf).every(k=>leafAllowed.has(k))&&leaf.schemaVersion===1&&/^[A-Z]{2,6}$/u.test(leaf.region||'')
    &&typeof leaf.locale==='string'&&/^[a-z]{2}(?:-[A-Z]{2})?$/u.test(leaf.locale)&&path(leaf.path)&&typeof leaf.categoryId==='string'&&/^[A-Za-z0-9_-]{1,160}$/u.test(leaf.categoryId)
    &&typeof leaf.capturedAt==='string'&&Number.isFinite(Date.parse(leaf.capturedAt))&&Array.isArray(leaf.fields)&&leaf.fields.length<=1000
    &&plain(leaf.captureEvidence)&&leaf.captureEvidence.version===1&&['build-time-observed-leaf','build-time-api-definition'].includes(leaf.captureEvidence.kind)&&leaf.captureEvidence.fieldUniverseComplete===true;
}
function cleanNodes(nodes,parent,{identity=false}={}){
  if(!Array.isArray(nodes)||!nodes.length||nodes.length>2000)throw unavailable('构建类目树包含空分支或超出范围的分支。');
  const seen=new Set();return nodes.map(node=>{
    const segment=node?.path?.at(-1),keys=identity?['label','path','disabled','categoryId']:['label','path','disabled'];
    if(!plain(node)||Object.keys(node).some(k=>!keys.includes(k))||!label(node.label)||seen.has(segment)||typeof node.disabled!=='boolean'||identity&&(!nodeId(node.categoryId)||![node.label,node.label+'〔'+node.categoryId+'〕'].includes(segment))||!same(node.path,[...parent,identity?segment:node.label]))throw unavailable('构建类目树含有重复、越界或未核验路径。');
    seen.add(segment);return {label:node.label,path:[...node.path],...(identity?{categoryId:node.categoryId}:{}),disabled:node.disabled};
  });
}
function normalizedTree(roots,branches,{identity=false}={}){
  const normalizedRoots=cleanNodes(roots,[],{identity}),byPath=new Map();
  if(!Array.isArray(branches)||branches.length>20000)throw unavailable('构建类目树数量无效。');
  for(const input of branches){
    if(!plain(input)||Object.keys(input).some(k=>!['parentPath','leaf','nodes'].includes(k))||!path(input.parentPath)||typeof input.leaf!=='boolean'||!Array.isArray(input.nodes)||input.leaf&&input.nodes.length||!input.leaf&&!input.nodes.length||byPath.has(JSON.stringify(input.parentPath)))throw unavailable('构建类目分支未完整读取或包含非公开数据。');
    byPath.set(JSON.stringify(input.parentPath),{parentPath:[...input.parentPath],leaf:input.leaf,nodes:input.leaf?[]:cleanNodes(input.nodes,input.parentPath,{identity})});
  }
  const queue=normalizedRoots.map(node=>node.path),seen=new Set(),missing=[],leaves=[],ordered=[];
  while(queue.length){const current=queue.shift(),key=JSON.stringify(current);if(seen.has(key))throw unavailable('构建类目树存在循环。');seen.add(key);const branch=byPath.get(key);if(!branch){missing.push(current);continue;}ordered.push(branch);if(branch.leaf)leaves.push(current);else for(const node of branch.nodes)queue.push(node.path);}
  if([...byPath.keys()].some(key=>!seen.has(key)))throw unavailable('构建类目树包含根目录之外的孤立分支。');
  return {roots:normalizedRoots,branches:ordered,leafPaths:leaves,leafKeys:new Set(leaves.map(p=>JSON.stringify(p))),missing,treeComplete:missing.length===0};
}
function rootProofVerified(proof,roots){return plain(proof)&&Object.keys(proof).every(k=>rootProofKeys.includes(k))&&proof.version===1&&['visible-category-root-menu','observed-platform-category-tree'].includes(proof.source)&&proof.complete===true&&proof.responseComplete===true&&proof.rootCount===roots.length&&Number.isSafeInteger(proof.stableSamples)&&proof.stableSamples>=3&&proof.stableSamples<=100;}

/** Build-time only. Never derives a missing field or option from another leaf. */
export function compileManifest({catalogId,catalogVersion=catalogId,region='US',locale='zh-CN',capturedAt,roots,rootsEvidence,treeDefinitionEvidence,branches,leaves,validateLeaf}={}){
  if(typeof catalogId!=='string'||!/^[A-Za-z0-9._-]{1,160}$/u.test(catalogId)||typeof catalogVersion!=='string'||!catalogVersion||!Number.isFinite(Date.parse(capturedAt||''))||typeof validateLeaf!=='function')throw unavailable('类目构建标识、时间或严格字段验证器缺失。');
  const tree=normalizedTree(roots,branches,{identity:treeDefinitionEvidence!==undefined}),apiTree=treeDefinitionEvidence===undefined?null:verifiedApiTree(treeDefinitionEvidence,tree),files=new Map(),entries=[],seen=new Set();
  if(!Array.isArray(leaves)||leaves.length>20000)throw unavailable('构建细分类目数量无效。');
  for(const leaf of leaves){
    if(!leafShape(leaf)||leaf.region!==region||leaf.locale!==locale||validateLeaf(leaf)!==true)throw unavailable('构建细分类目字段或下拉参数尚未全部核验。');
    const key=JSON.stringify(leaf.path);if(seen.has(key)||!tree.leafKeys.has(key)||apiTree&&apiTree.leafIdsByPath.get(key)!==leaf.categoryId)throw unavailable('构建细分类目重复或不在真实类目树中。');seen.add(key);
    const bytes=Buffer.from(JSON.stringify(leaf)),digest=sha(bytes),file='leaves/'+digest+'.json';
    if(bytes.length>32*1024*1024)throw unavailable('单个内置细分类目超过 32 MB，不能静默截断。');
    entries.push({categoryId:leaf.categoryId,path:[...leaf.path],file,sha256:digest,bytes:bytes.length,fieldCount:leaf.fields.length,optionCount:leaf.fields.reduce((n,f)=>n+(f.options?.length||0),0)});files.set(file,bytes);
  }
  if(new Set(entries.map(e=>e.categoryId)).size!==entries.length)throw unavailable('同一平台类目编号被关联多个细分类目。');
  const missingLeaves=tree.leafPaths.filter(p=>!seen.has(JSON.stringify(p))),rootsComplete=Boolean(apiTree)||rootProofVerified(rootsEvidence,tree.roots);
  const publicRootProof=Object.fromEntries(rootProofKeys.filter(k=>rootsEvidence?.[k]!==undefined).map(k=>[k,rootsEvidence[k]]));
  const manifest={schemaVersion:1,catalogId,catalogVersion,region,locale,capturedAt,source:'visible-seller-build-capture',...(apiTree?{treeDefinitionEvidence:structuredClone(treeDefinitionEvidence)}:{rootsEvidence:publicRootProof}),roots:tree.roots,branches:tree.branches,leaves:entries,
    coverage:{rootsComplete,treeComplete:tree.treeComplete,allLeafSchemasComplete:tree.treeComplete&&missingLeaves.length===0&&entries.length>0,totalLeaves:tree.leafPaths.length,readyLeaves:entries.length,missingBranches:tree.missing,missingLeaves,unavailableLeaves:[]}};
  return {manifest,files};
}

/** Streaming build output: validate and persist one public leaf at a time. */
export function writeCapturedLeaf({root,leaf,validateLeaf}={}){
  if(typeof root!=='string'||!leafShape(leaf)||typeof validateLeaf!=='function'||validateLeaf(leaf)!==true)throw unavailable('预采集细分类目尚未完整校验，不能写入分发资料。');
  const bytes=Buffer.from(JSON.stringify(leaf));if(bytes.length>32*1024*1024)throw unavailable('单个细分类目超过 32 MB，不能静默截断。');
  const digest=sha(bytes),storage=writePackedCatalogLeaf({root:resolve(root),leaf,bytes});
  return {categoryId:leaf.categoryId,path:[...leaf.path],file:'leaves/'+digest+'.json',sha256:digest,bytes:bytes.length,fieldCount:leaf.fields.length,optionCount:leaf.fields.reduce((n,f)=>n+(f.options?.length||0),0),storage};
}

/** Index-only build finalization. verifyCatalogRelease must still read every leaf. */
export function compileManifestIndex({catalogId,catalogVersion=catalogId,region='US',locale='zh-CN',capturedAt,roots,rootsEvidence,treeDefinitionEvidence,branches,leafEntries}={}){
  if(typeof catalogId!=='string'||!/^[A-Za-z0-9._-]{1,160}$/u.test(catalogId)||typeof catalogVersion!=='string'||!catalogVersion||typeof capturedAt!=='string'||!Number.isFinite(Date.parse(capturedAt)))throw unavailable('构建标识或时间缺失。');
  const tree=normalizedTree(roots,branches,{identity:treeDefinitionEvidence!==undefined}),apiTree=treeDefinitionEvidence===undefined?null:verifiedApiTree(treeDefinitionEvidence,tree),seen=new Set(),ids=new Set();if(!Array.isArray(leafEntries)||leafEntries.length>20000)throw unavailable('预采集分片索引数量无效。');
  const entries=leafEntries.map(entry=>{const key=JSON.stringify(entry?.path);if(!plain(entry)||Object.keys(entry).some(k=>!fileProofKeys.includes(k))||!path(entry.path)||!tree.leafKeys.has(key)||seen.has(key)||typeof entry.categoryId!=='string'||!/^[A-Za-z0-9_-]{1,160}$/u.test(entry.categoryId)||apiTree&&apiTree.leafIdsByPath.get(key)!==entry.categoryId||ids.has(entry.categoryId)||!hash(entry.sha256)||entry.file!=='leaves/'+entry.sha256+'.json'||!Number.isSafeInteger(entry.bytes)||entry.bytes<1||entry.bytes>32*1024*1024||!Number.isSafeInteger(entry.fieldCount)||entry.fieldCount<0||entry.fieldCount>1000||!Number.isSafeInteger(entry.optionCount)||entry.optionCount<0||entry.storage!==undefined&&!catalogStorageValid(entry.storage,entry))throw unavailable('预采集分片索引含越界、重复或不完整记录。');seen.add(key);ids.add(entry.categoryId);return structuredClone(entry);});
  const missingLeaves=tree.leafPaths.filter(p=>!seen.has(JSON.stringify(p))),rootsComplete=Boolean(apiTree)||rootProofVerified(rootsEvidence,tree.roots);
  return {schemaVersion:1,catalogId,catalogVersion,region,locale,capturedAt,source:'visible-seller-build-capture',...(apiTree?{treeDefinitionEvidence:structuredClone(treeDefinitionEvidence)}:{rootsEvidence:Object.fromEntries(rootProofKeys.filter(k=>rootsEvidence?.[k]!==undefined).map(k=>[k,rootsEvidence[k]]))}),roots:tree.roots,branches:tree.branches,leaves:entries,
    coverage:{rootsComplete,treeComplete:tree.treeComplete,allLeafSchemasComplete:tree.treeComplete&&missingLeaves.length===0&&entries.length>0,totalLeaves:tree.leafPaths.length,readyLeaves:entries.length,missingBranches:tree.missing,missingLeaves,unavailableLeaves:[]}};
}

/** Hash-verified, bounded, lazy library. No browser, network or user-data writes. */
export function createTikTokBuiltinCatalog({root=fileURLToPath(new URL('./resources/tiktok-catalog/',import.meta.url)),validateLeaf,maxCacheBytes=64*1024*1024,onBlobRead}={}){
  const directory=resolve(root),cache=new Map();let manifest,manifestHash,problem,cacheBytes=0,checked=false,tree,entriesByPath,identitiesByPath,leafCountsByRoot,disabledPaths=[];
  function load(){if(checked)return;checked=true;try{
    const dir=lstatSync(directory),p=join(directory,'manifest.json'),info=lstatSync(p);if(!dir.isDirectory()||dir.isSymbolicLink()||!info.isFile()||info.isSymbolicLink()||info.size>32*1024*1024)throw unavailable('内置类目库目录或索引无效。');
    const bytes=readFileSync(p),value=JSON.parse(bytes.toString('utf8'));
    if(!plain(value)||Object.keys(value).some(k=>!publicManifestKeys.has(k))||value.schemaVersion!==1||value.source!=='visible-seller-build-capture'||typeof value.catalogId!=='string'||!/^[A-Za-z0-9._-]{1,160}$/u.test(value.catalogId)||typeof value.catalogVersion!=='string'||!value.catalogVersion||value.catalogVersion.length>160||!/^[A-Z]{2,6}$/u.test(value.region||'')||!/^\w{2}(?:-[A-Z]{2})?$/u.test(value.locale||'')||!Number.isFinite(Date.parse(value.capturedAt||''))||typeof validateLeaf!=='function')throw unavailable('内置类目库索引格式无效。');
    if(value.treeDefinitionEvidence!==undefined&&value.rootsEvidence!==undefined)throw unavailable('内置类目树不能混入未使用的来源资料。');
    tree=normalizedTree(value.roots,value.branches,{identity:value.treeDefinitionEvidence!==undefined});const apiTree=value.treeDefinitionEvidence===undefined?null:verifiedApiTree(value.treeDefinitionEvidence,tree),coverage=value.coverage;
    if(!plain(coverage)||Object.keys(coverage).some(k=>!coverageKeys.includes(k))||!apiTree&&!rootProofVerified(value.rootsEvidence,tree.roots)||coverage.rootsComplete!==true||coverage.treeComplete!==true||coverage.allLeafSchemasComplete!==true||!tree.treeComplete||!Array.isArray(value.leaves)||value.leaves.length!==tree.leafPaths.length||coverage.totalLeaves!==tree.leafPaths.length||coverage.readyLeaves!==value.leaves.length||!Array.isArray(coverage.missingBranches)||coverage.missingBranches.length||!Array.isArray(coverage.missingLeaves)||coverage.missingLeaves.length||!Array.isArray(coverage.unavailableLeaves)||coverage.unavailableLeaves.length)throw unavailable();
    const seen=new Set(),ids=new Set();for(const entry of value.leaves){
      if(!plain(entry)||Object.keys(entry).some(k=>!fileProofKeys.includes(k))||!path(entry.path)||!tree.leafKeys.has(JSON.stringify(entry.path))||seen.has(JSON.stringify(entry.path))||typeof entry.categoryId!=='string'||!/^[A-Za-z0-9_-]{1,160}$/u.test(entry.categoryId)||apiTree&&apiTree.leafIdsByPath.get(JSON.stringify(entry.path))!==entry.categoryId||ids.has(entry.categoryId)||!hash(entry.sha256)||entry.file!=='leaves/'+entry.sha256+'.json'||!Number.isSafeInteger(entry.bytes)||entry.bytes<1||entry.bytes>32*1024*1024||!Number.isSafeInteger(entry.fieldCount)||entry.fieldCount<0||entry.fieldCount>1000||!Number.isSafeInteger(entry.optionCount)||entry.optionCount<0||entry.storage!==undefined&&!catalogStorageValid(entry.storage,entry))throw unavailable('内置类目分片索引未完整校验。');seen.add(JSON.stringify(entry.path));ids.add(entry.categoryId);
    }
    manifest=value;manifestHash=sha(bytes);entriesByPath=new Map(value.leaves.map(entry=>[JSON.stringify(entry.path),entry]));identitiesByPath=apiTree?.identitiesByPath;leafCountsByRoot=new Map();for(const entry of value.leaves)leafCountsByRoot.set(entry.path[0],(leafCountsByRoot.get(entry.path[0])||0)+1);disabledPaths=[...manifest.roots,...tree.branches.flatMap(branch=>branch.nodes)].filter(node=>node.disabled).map(node=>node.path);
  }catch(error){problem=error.code==='ENOENT'?fail('PUBLISH_CATALOG_MISSING','程序尚未附带预采集完整类目库，请安装制作完成的程序；配对只读取店名和主营类目。'):error.code?.startsWith('PUBLISH_CATALOG')?error:unavailable('内置类目库读取或校验失败，请更新完整程序包。');}}
  function requireReady(){load();if(problem)throw problem;}
  function metadata(){load();return problem?{status:problem.code==='PUBLISH_CATALOG_MISSING'?'missing':'incomplete',rootComplete:false,leafCount:0,completeLeafCount:0,issues:[problem.message]}:{status:'ready',catalogId:manifest.catalogId,version:manifest.catalogVersion,region:manifest.region,locale:manifest.locale,rootComplete:true,leafCount:manifest.leaves.length,completeLeafCount:manifest.leaves.length,manifestSha256:manifestHash,issues:[]};}
  function bindingStatus(binding){const meta=metadata();if(meta.status!=='ready')return meta;const main=binding?.mainCategory?.label,all=hasAllCategoryAccess(binding);if(binding?.identity?.region!==manifest.region||!all&&!manifest.roots.some(r=>r.label===main))return {...meta,status:'unsupported-main',rootComplete:false,leafCount:0,completeLeafCount:0,issues:['内置类目库不含该店铺的主营大类或站点，请更新完整程序包。']};const count=all?manifest.leaves.length:leafCountsByRoot.get(main)||0;return {...meta,leafCount:count,completeLeafCount:count,mainCategory:main};}
  function assertBinding(binding){requireReady();if(bindingStatus(binding).status!=='ready')throw fail('PUBLISH_CATEGORY_SCOPE','该店铺主营大类或站点不在当前内置类目库中。');}
  function catalogs(binding){const status=bindingStatus(binding);if(status.status!=='ready')return [];
    const main=binding.mainCategory.label,all=hasAllCategoryAccess(binding);return [{parentPath:[],leaf:false,complete:true,source:'builtin-category-library',readAt:manifest.capturedAt,shopId:binding.identity.shopId,region:binding.identity.region,nodes:manifest.roots.map(r=>({...structuredClone(r),disabled:r.disabled||!all&&r.label!==main})),issues:[]},
      ...tree.branches.filter(b=>all||b.parentPath[0]===main).map(b=>({...structuredClone(b),complete:true,source:'builtin-category-library',readAt:manifest.capturedAt,shopId:binding.identity.shopId,region:binding.identity.region,issues:[]}))];
  }
  function assertPathEnabled(binding,parts){if(!hasAllCategoryAccess(binding)){if(parts[0]!==binding.mainCategory.label)throw fail('PUBLISH_CATEGORY_SCOPE','不能操作其他主营大类。');return;}for(const path of disabledPaths)if(path.length<=parts.length&&path.every((part,index)=>part===parts[index]))throw fail('PUBLISH_CATEGORY_SCOPE','平台已停用此类目，不能读取或填写。');}
  function branch(binding,parentPath=[]){assertBinding(binding);if(parentPath.length)assertPathEnabled(binding,parentPath);const found=catalogs(binding).find(b=>same(b.parentPath,parentPath));if(!found)throw unavailable('该细分类目未包含在已制作的类目库中。');return found;}
  function readLeaf(binding,categoryPath){assertBinding(binding);const parts=Array.isArray(categoryPath)?categoryPath:String(categoryPath).split(' > ');assertPathEnabled(binding,parts);
    const entry=entriesByPath.get(JSON.stringify(parts));if(!entry)throw unavailable('该细分类目的属性未完整预采集，不能改为配对后临时抓取。');
    let leaf=cache.get(entry.sha256)?.leaf;
    if(!leaf){try{if(entry.storage)leaf=readPackedCatalogLeaf({root:directory,entry,onBlob:onBlobRead});else{const leavesDir=join(directory,'leaves'),file=join(directory,entry.file),dirInfo=lstatSync(leavesDir),info=lstatSync(file);if(!dirInfo.isDirectory()||dirInfo.isSymbolicLink()||!info.isFile()||info.isSymbolicLink()||info.size!==entry.bytes)throw new Error();const bytes=readFileSync(file);if(sha(bytes)!==entry.sha256)throw new Error();leaf=JSON.parse(bytes.toString('utf8'));}if(!leafShape(leaf)||leaf.region!==manifest.region||leaf.locale!==manifest.locale||leaf.categoryId!==entry.categoryId||!same(leaf.path,entry.path)||leaf.fields.length!==entry.fieldCount||leaf.fields.reduce((n,f)=>n+(f.options?.length||0),0)!==entry.optionCount||validateLeaf(leaf)!==true)throw new Error();cache.set(entry.sha256,{leaf,bytes:entry.bytes});cacheBytes+=entry.bytes;while(cacheBytes>maxCacheBytes&&cache.size){const [key,old]=cache.entries().next().value;cache.delete(key);cacheBytes-=old.bytes;}}
      catch{throw unavailable('该细分类目内置原件缺失、损坏或参数证明不完整，请更新程序包。');}}
    const identity=identitiesByPath?.get(JSON.stringify(parts));if(identity&&(leaf.identityPath!==undefined&&!same(leaf.identityPath,identity.identityPath)||leaf.displayPath!==undefined&&!same(leaf.displayPath,identity.displayPath)||leaf.categoryIds!==undefined&&!same(leaf.categoryIds,identity.categoryIds)))throw unavailable('细分类目的真实名称、编号链与平台类目树不一致。');
    return {leaf:structuredClone(leaf),entry:structuredClone(entry),...(identity?{categoryIdentity:structuredClone(identity)}:{}),manifestSha256:manifestHash,catalogId:manifest.catalogId,catalogVersion:manifest.catalogVersion};
  }
  return {metadata,bindingStatus,catalogs,branch,readLeaf,refresh:()=>{checked=false;manifest=undefined;problem=undefined;cache.clear();cacheBytes=0;disabledPaths=[];},directory};
}

/** Every indexed leaf is read and revalidated before a release can pass. */
export function verifyCatalogRelease(options={}){const refs=new Map(),catalog=createTikTokBuiltinCatalog({...options,onBlobRead:p=>{const old=refs.get(p.sha256);if(old&&JSON.stringify(old)!==JSON.stringify(p))throw unavailable('同一公共字典的压缩证明不一致。');refs.set(p.sha256,p);}}),meta=catalog.metadata();if(meta.status!=='ready')throw unavailable(meta.issues?.[0]);const m=JSON.parse(readFileSync(join(catalog.directory,'manifest.json'),'utf8'));
  let fields=0,optionCount=0;for(const root of m.roots){const binding={identity:{region:m.region,shopId:'release-check'},mainCategory:{label:root.label}};for(const entry of m.leaves.filter(e=>e.path[0]===root.label)){const read=catalog.readLeaf(binding,entry.path);fields+=read.entry.fieldCount;optionCount+=read.entry.optionCount;}}
  const blobStore=verifyCatalogBlobStore({root:catalog.directory,expectedRefs:refs});return {...meta,verified:true,roots:m.roots.length,fields,optionCount,blobStore};
}
