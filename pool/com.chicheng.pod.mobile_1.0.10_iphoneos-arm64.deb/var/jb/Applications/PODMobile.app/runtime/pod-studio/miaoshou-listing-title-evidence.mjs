import {createHash} from 'node:crypto';
import {open} from 'node:fs/promises';
import {resolve} from 'node:path';

const maxImages=24;
const maxImageBytes=8*1024*1024;
const totalImageBytes=18*1024*1024;
const imageTypes=new Set(['image/png','image/jpeg','image/webp']);
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const clean=(value,max=160)=>typeof value==='string'
  ?Array.from(value.replace(/\bhttps?:\/\/[^\s<>]+/giu,'').replace(/[\u0000-\u001f\u007f]/gu,' ').trim()).slice(0,max).join('')
  :'';
const compact=rows=>[...new Set(rows.filter(Boolean))];
const englishFacts=new Map(Object.entries({
  棉:'Cotton',纯棉:'100% Cotton',聚酯纤维:'Polyester',涤纶:'Polyester',氨纶:'Spandex',尼龙:'Nylon',亚麻:'Linen',羊毛:'Wool',
  长袖:'Long Sleeve',短袖:'Short Sleeve',无袖:'Sleeveless',常规版型:'Regular Fit',宽松型:'Relaxed Fit',修身:'Slim Fit',
  男士:'Men',女士:'Women',男女通用:'Unisex',中性:'Unisex',石洗:'Stonewash',酸洗:'Acid Wash',水洗做旧:'Distressed Wash',
}));

const factLabels=new Map([
  ['material',/^(?:fabric(?: composition| material)?|material(?: composition)?|composition|textile material|材质|面料|织物材质|面料成分|成分)$/iu],
  ['wash',/^(?:wash(?: type| finish| process)?|wash treatment|fabric finish|finishing process|manufacturing process|水洗工艺|水洗处理|水洗类型|面料工艺|加工工艺|工艺)$/iu],
  ['sleeve',/^(?:sleeve length|袖长)$/iu],
  ['fit',/^(?:fit(?: type)?|版型|合身度|包容度)$/iu],
  ['audience',/^(?:gender|target gender|department|适用人群|适用性别|性别)$/iu],
  ['printStyle',/^(?:pattern|graphic(?: style)?|图案|图案花纹|图案风格)$/iu],
]);

function valuesFor(attribute){
  const choices=attribute.attributeValues??attribute.attrValues??attribute.values??attribute.attrValueList??attribute.value??[];
  return compact((Array.isArray(choices)?choices:[choices]).slice(0,30).map(choice=>
    clean(typeof choice==='string'?choice:choice?.valueName??choice?.attrValue??choice?.name??choice?.value)));
}

export function listingTitleFacts(info,product){
  const category=clean(Array.isArray(product.categoryPath)?product.categoryPath.join(' > '):product.categoryPath||product.categoryName,500);
  const facts=category?[{key:'category',value:category}]:[];
  const attributes=[];
  for(const item of Array.isArray(info.productAttributes)?info.productAttributes.slice(0,120):[]){
    if(!plain(item))continue;
    const label=clean(item.attributeNameAlias||item.attributeName||item.name||item.attrName,120),values=valuesFor(item);
    if(label&&values.length)attributes.push({label,values});
  }
  const specifications=[];
  for(const item of Array.isArray(info.skuPropertyList)?info.skuPropertyList.slice(0,6):[]){
    if(!plain(item))continue;
    const label=clean(item.attrName,120),values=valuesFor(item);
    if(label&&values.length)specifications.push({label,values});
  }
  for(const [key,pattern] of factLabels){
    const values=compact([...attributes,...specifications].filter(row=>pattern.test(row.label)).flatMap(row=>row.values));
    if(values.length===1)facts.push({key,value:englishFacts.get(values[0])||values[0]});
  }
  return {facts,category,attributes,specifications};
}

export async function readListingTitleGallery(info,{imageReader,signal}){
  const gallery=Array.isArray(info.imgUrls)?info.imgUrls:[];
  const dimensions=(Array.isArray(info.skuPropertyList)?info.skuPropertyList:[]).map(dimension=>[
    clean(dimension?.attrName,120),
    (Array.isArray(dimension?.attrValueList)?dimension.attrValueList:[]).map(value=>[
      clean(value?.attrValue,120),typeof value?.imgUrl==='string'?value.imgUrl:'',
    ]),
  ]);
  const urls=compact([...gallery,...dimensions.flatMap(([,values])=>values.map(([,url])=>url))]
    .filter(value=>typeof value==='string'&&value.length>0));
  const total=urls.length,images=[],hashes=[];
  const downloadSignal=AbortSignal.any([signal,AbortSignal.timeout(25000)]);
  let bytesRead=0;
  for(let index=0;index<Math.min(total,maxImages)&&!downloadSignal.aborted;index+=3){
    const group=await Promise.allSettled(urls.slice(index,Math.min(index+3,maxImages))
      .map(url=>imageReader(url,{signal:downloadSignal})));
    signal.throwIfAborted();
    for(const [offset,result] of group.entries()){
      if(result.status!=='fulfilled')continue;
      const {bytes,type}=result.value||{};
      if(!Buffer.isBuffer(bytes)||!imageTypes.has(type)||!bytes.length||bytes.length>maxImageBytes||bytesRead+bytes.length>totalImageBytes)continue;
      bytesRead+=bytes.length;
      const position=index+offset;
      images.push({role:images.length?'gallery':'main',label:'商品原图 '+(position+1),dataUrl:'data:'+type+';base64,'+bytes.toString('base64')});
      hashes.push(createHash('sha256').update(bytes).digest('hex'));
    }
  }
  const read=images.length;
  const imageHash=new Map(urls.map((url,index)=>[url,hashes[index]]));
  const artworkHash=read&&total===read&&gallery.every(url=>imageHash.has(url))
    ?createHash('sha256').update(JSON.stringify([
      gallery.map(url=>imageHash.get(url)),dimensions.map(([name,values])=>[name,values.map(([value,url])=>[value,imageHash.get(url)||''])]),
    ])).digest('hex'):'';
  return {images,imageCoverage:{total,read},artworkHash};
}

async function readEvidenceFile(root,name){
  if(!root)return null;
  let file;
  try{
    file=await open(resolve(root,'title-evidence',name),'r');
    const {size}=await file.stat();
    if(!size||size>128*1024)return null;
    const data=Buffer.alloc(size+1);
    const {bytesRead}=await file.read(data,0,data.length,0);
    if(bytesRead!==size)return null;
    return JSON.parse(data.subarray(0,bytesRead).toString('utf8'));
  }catch{return null;}
  finally{await file?.close().catch(()=>{});}
}

/** Only host-reviewed records count as authorization, scoped to the actual SKU and image bytes.
 * <accountScope>-<shopId>-<detailId>.json: {version:1,market:'US',categoryId,artworkHash,
 * authorization, reviewedAt, reference, expiresAt?, approvedTerms?, excludedTerms?}.
 * search-us-<categoryId>.json: {version:1,market:'US',categoryId, rows:[{url,title,date,keyword,category,metric}]}.
 */
export async function readListingTitleEvidence(root,{accountScope,shopId,detailId,categoryId,artworkHash,now=Date.now()}){
  if(!/^[a-f0-9]{64}$/u.test(accountScope)||![shopId,detailId].every(id=>/^[1-9]\d{0,24}$/u.test(id)))return {};
  const [rights,search]=await Promise.all([
    artworkHash?readEvidenceFile(root,accountScope+'-'+shopId+'-'+detailId+'.json'):null,
    /^[1-9]\d{0,24}$/u.test(categoryId)?readEvidenceFile(root,'search-us-'+categoryId+'.json'):null,
  ]);
  const time=Date.parse(rights?.reviewedAt),expires=rights?.expiresAt===undefined?Infinity:Date.parse(rights.expiresAt);
  const usableRights=/^[1-9]\d{0,24}$/u.test(categoryId)&&rights?.version===1&&rights.market==='US'&&rights.categoryId===categoryId&&rights.artworkHash===artworkHash&&
    Boolean(clean(rights.reference,300))&&Number.isFinite(time)&&time<=now&&expires>now&&['verified','confirmed_unlicensed'].includes(rights.authorization);
  const terms=items=>Array.isArray(items)?compact(items.slice(0,50).map(item=>clean(item,80))):[];
  return {
    authorization:usableRights?rights.authorization:'unverified',
    approvedTerms:usableRights&&rights.authorization==='verified'?terms(rights.approvedTerms):[],
    excludedTerms:usableRights?terms(rights.excludedTerms):[],
    searchEvidence:search?.version===1&&search.market==='US'&&search.categoryId===categoryId&&Array.isArray(search.rows)?search.rows.slice(0,6):[],
  };
}
