import {randomBytes} from 'node:crypto';
import {runListingSuggestion} from './listing-suggestion-runner.mjs';
import {blockedMiaoshouTitleResult,isMiaoshouTitleSuggestion,validateSuggestionRequest,suggestionHash} from './listing-suggestion-contract.mjs';

export function createListingSuggestionService({findExecutable,run=runListingSuggestion,now=Date.now}={}){
  const jobs=new Map();let closed=false;
  const publicJob=job=>({id:job.id,field:job.field,productId:job.productId,snapshotHash:job.snapshotHash,status:job.status,...(job.result?{result:job.result}:{}),...(job.error?{error:job.error}:{})});
  const prune=()=>{for(const [id,job] of jobs)if(now()-job.createdAt>30*60*1000){job.controller.abort();jobs.delete(id);}};
  async function handle(req,res,{csrf,loadMiaoshouTitle}={}){
    const path=new URL(req.url,'http://localhost').pathname;
    if(!path.startsWith('/__pod/codex/listing-suggestions'))return false;
    const reply=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));return true;};
    if(!csrf)return reply(401,{success:false,message:'请刷新页面连接主机。'});prune();
    try{
      if(closed)throw new Error('建议服务已关闭。');
      if(req.method==='POST'&&path==='/__pod/codex/listing-suggestions'){
        if([...jobs.values()].filter(j=>j.status==='pending').length>=3||[...jobs.values()].filter(j=>j.owner===csrf&&j.status==='pending').length>=2)return reply(429,{success:false,message:'已有建议正在生成，请稍后重试。'});
        const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>12*1024*1024)throw new Error('商品建议请求过大。');chunks.push(chunk);}
        const input=validateSuggestionRequest(JSON.parse(Buffer.concat(chunks).toString('utf8'))),hash=suggestionHash(input);
        if(isMiaoshouTitleSuggestion(input)&&typeof loadMiaoshouTitle!=='function')return reply(503,{success:false,message:'妙手标题核对服务尚未就绪，请重新启动。'});
        const existing=[...jobs.values()].find(j=>j.owner===csrf&&j.snapshotHash===hash&&j.status==='pending');if(existing)return reply(200,{success:true,data:publicJob(existing)});
        if(jobs.size>=100)throw new Error('建议记录已满，请稍后重试。');
        const job={id:randomBytes(16).toString('hex'),owner:csrf,field:input.field,productId:input.snapshot.id,snapshotHash:hash,status:'pending',createdAt:now(),controller:new AbortController()};jobs.set(job.id,job);
        void(async()=>{
          const {signal}=job.controller;
          try{
            const source=isMiaoshouTitleSuggestion(input)?await loadMiaoshouTitle(input,{signal}):{input};
            const blocked=blockedMiaoshouTitleResult(source.titleEvidence);
            const result=blocked||await run(source.input,{codexPath:await findExecutable(),signal,now,titleEvidence:source.titleEvidence});
            await source.guard?.();
            signal.throwIfAborted();
            job.result=result;job.status='ready';
          }catch(error){
            job.status='failed';
            job.error=/[\u4e00-\u9fff]/u.test(error.message||'')?error.message:'建议生成失败，请重试。';
          }
        })();
        return reply(202,{success:true,data:publicJob(job)});
      }
      const match=/^\/__pod\/codex\/listing-suggestions\/([a-f0-9]{32})$/u.exec(path),job=match&&jobs.get(match[1]);
      if(req.method!=='GET'||!job||job.owner!==csrf)return reply(404,{success:false,message:'建议记录不存在或已过期。'});
      return reply(200,{success:true,data:publicJob(job)});
    }catch(error){return reply(400,{success:false,message:/[\u4e00-\u9fff]/u.test(error.message||'')?error.message:'建议请求无效。'});}
  }
  return {handle,close(){closed=true;for(const job of jobs.values())job.controller.abort();jobs.clear();}};
}
