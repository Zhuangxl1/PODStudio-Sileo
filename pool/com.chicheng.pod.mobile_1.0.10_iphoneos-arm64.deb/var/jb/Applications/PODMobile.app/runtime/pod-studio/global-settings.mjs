import {readFile,writeFile,mkdir,rename,open,unlink} from 'node:fs/promises';
import {resolve,join,isAbsolute} from 'node:path';
import {homedir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {spawn} from 'node:child_process';
import {validateUploadEndpoint,uploadImage} from './dist/image-upload.js';
import {createMiniToolsImageClient,MINI_TOOLS_DEFAULT_DURATION,MINI_TOOLS_MAX_BYTES,MINI_TOOLS_UPLOAD_URL} from './mini-tools-image.mjs';
import {normalizeScdnCdnDomain,SCDN_DEFAULT_CDN_DOMAIN,SCDN_UPLOAD_URL,uploadScdnImage} from './scdn-image.mjs';
import {podConfigHome,podMaterialRoot,usesFixedStorage} from './storage-root.mjs';

const PROJECT=fileURLToPath(new URL('./',import.meta.url));
const DEFAULTS={
  urpiclink:{uploadEndpoint:'http://127.0.0.1:8080/api/v1/upload/file',fileField:'file',responsePath:'data',authHeaderName:'Authorization'},
  imgurl:{uploadEndpoint:'https://www.imgurl.org/api/v3/upload',fileField:'file',responsePath:'data.url',authHeaderName:'Authorization'},
  custom:{uploadEndpoint:'',fileField:'file',responsePath:'data.url',authHeaderName:'Authorization'},
  'mini-tools':{uploadEndpoint:MINI_TOOLS_UPLOAD_URL,miniToolsUserId:'',miniToolsDuration:MINI_TOOLS_DEFAULT_DURATION},
  scdn:{uploadEndpoint:SCDN_UPLOAD_URL,scdnCdnDomain:SCDN_DEFAULT_CDN_DOMAIN},
};
const providerIds=Object.keys(DEFAULTS);
const withSecrets=new Set(['imgurl','custom','mini-tools']);
const fileLimit=provider=>provider==='mini-tools'?MINI_TOOLS_MAX_BYTES:10*1024*1024;
const fallbackList=(values,primary)=>[...new Set(Array.isArray(values)?values.filter(id=>providerIds.includes(id)&&id!==primary):[])];
export const globalConfigHome=podConfigHome;
const DEFAULT_FOLDER=()=>usesFixedStorage()?podMaterialRoot():join(homedir(),'Documents','PODStudio','素材');
const safeError=message=>new Error(message);
const repositories=values=>{if(!Array.isArray(values)||values.length>100)throw safeError('GitHub 仓库最多支持100个，请填写“用户名/仓库名”。');return [...new Set(values.map(value=>{if(typeof value!=='string')throw safeError('GitHub 仓库格式无效。');let name=value.trim();const match=name.match(/^https:\/\/api\.github\.com\/repos\/([^/]+)\/([^/]+)\/contents(?:\/.*)?$/);if(match)name=match[1]+'/'+match[2];if(!/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?\/[A-Za-z0-9._-]{1,100}$/.test(name)||['.','..'].includes(name.split('/')[1]))throw safeError('GitHub 仓库请填写“用户名/仓库名”。');return name;}))];};
function nativeSecrets(mode,path,input){return new Promise((done,reject)=>{const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(PROJECT,'provider-secrets.ps1'),'-Mode',mode,'-Path',path],{windowsHide:true,stdio:['pipe','pipe','ignore']});let output='',settled=false;const fail=()=>{if(!settled){settled=true;reject(safeError('图床密钥加密读写失败，请使用同一 Windows 账号运行软件。'));}};const timer=setTimeout(()=>{child.kill();fail();},10000);child.stdout.on('data',chunk=>{output+=chunk;if(output.length>20000){child.kill();fail();}});child.once('error',()=>{clearTimeout(timer);fail();});child.once('close',code=>{clearTimeout(timer);if(settled)return;if(code!==0)return fail();settled=true;try{done(mode==='read'?JSON.parse(output):true);}catch{reject(safeError('本机图床密钥保存格式无效。'));}});child.stdin.end(input===undefined?'':JSON.stringify(input));});}
export function createGlobalSettings({root=globalConfigHome(),serviceAuthorization,fetchImpl=fetch,readSecrets,writeSecrets,defaultFolder=DEFAULT_FOLDER(),fixedMaterialFolder,initialProfile,now=Date.now}={}){
  const configPath=join(root,'global-settings.json'),secretPath=join(root,'global-provider-secrets.dpapi');
  const decrypt=readSecrets||(()=>nativeSecrets('read',secretPath)),encrypt=writeSecrets||(value=>nativeSecrets('write',secretPath,value));
  const miniTools=createMiniToolsImageClient({fetchImpl});
  const cooldowns=new Map();
  let settings,credentials={},loading,queue=Promise.resolve();
  const safeProfile=value=>value&&typeof value.configured==='boolean'&&typeof value.tokenConfigured==='boolean'?{configured:value.configured,tokenConfigured:value.tokenConfigured}:null;
  let profileCache=safeProfile(initialProfile),profileCheckedAt=profileCache?now():null,profileRefresh,profileFailed=false,profileRequest=0,profileApplied=0;
  const rememberProfile=(value,request)=>{const profile=safeProfile(value);if(profile&&request>=profileApplied){profileApplied=request;profileCache=profile;profileCheckedAt=now();profileFailed=false;}return value;};
  const serial=operation=>{const next=queue.then(operation,operation);queue=next.catch(()=>{});return next;};
  async function service(path,{method='GET',body,timeout=30000}={}){
    const controller=new AbortController();let timer;
    const operation=(async()=>{let response;try{response=await fetchImpl('http://127.0.0.1:8080'+path,{method,headers:{Authorization:serviceAuthorization,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:controller.signal});}catch{throw safeError('无法连接本机 GitHub 图床服务。');}let value;try{value=await response.json();}catch{throw safeError('图床服务响应无效。');}if(!response.ok||value?.success!==true||!value.data||typeof value.data!=='object')throw safeError(response.status===401?'图床服务访问密钥无效，请重新启动软件。':'GitHub 检测或保存失败，请检查 Token、仓库权限和网络连接。');return value.data;})();
    try{return await Promise.race([operation,new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(safeError('无法连接本机 GitHub 图床服务。'));},timeout);})]);}finally{clearTimeout(timer);}
  }
  function refreshPublicProfile(){
    if(profileRefresh||profileCheckedAt!==null&&now()-profileCheckedAt<30000)return;
    // Public designer metadata must remain usable while the image host is slow
    // or offline. Native settings and actual uploads still report live errors.
    const request=++profileRequest,pending=Promise.resolve().then(()=>service('/api/v1/config/github',{timeout:6000})).then(value=>rememberProfile(value,request)).catch(()=>{if(request>=profileApplied){profileApplied=request;profileFailed=true;profileCheckedAt=now();}});
    profileRefresh=pending;void pending.finally(()=>{if(profileRefresh===pending)profileRefresh=undefined;});
  }
  async function load(){
    if(settings)return;
    if(!loading)loading=(async()=>{
      let saved={};try{saved=JSON.parse(await readFile(configPath,'utf8'));if(!saved||typeof saved!=='object'||Array.isArray(saved))throw new Error();}catch(error){if(error.code!=='ENOENT')throw safeError('全局设置文件无法读取，请检查主机用户目录权限。');}
      const primary=providerIds.includes(saved.uploadProvider)?saved.uploadProvider:'urpiclink';
      const selectedFolder=typeof saved.materialFolder==='string'&&isAbsolute(saved.materialFolder)?resolve(saved.materialFolder):null;
      const materialFolder=fixedMaterialFolder?await fixedMaterialFolder(selectedFolder):selectedFolder||defaultFolder;
      const candidate={version:1,updatedAt:typeof saved.updatedAt==='string'?saved.updatedAt:'',uploadProvider:primary,fallbackProviders:fallbackList(saved.fallbackProviders,primary),materialFolder,providers:Object.fromEntries(Object.entries(DEFAULTS).map(([id,value])=>[id,Object.fromEntries(Object.entries(value).map(([key,fallback])=>[key,typeof saved.providers?.[id]?.[key]==='string'?saved.providers[id][key]:fallback]))]))};
      candidate.providers['mini-tools'].uploadEndpoint=MINI_TOOLS_UPLOAD_URL;
      candidate.providers.scdn.uploadEndpoint=SCDN_UPLOAD_URL;
      const decrypted=await decrypt();if(!decrypted||typeof decrypted!=='object'||Array.isArray(decrypted))throw safeError('本机图床密钥保存格式无效。');
      const loadedCredentials={};for(const id of withSecrets)if(typeof decrypted[id]==='string'){if(decrypted[id].length>4096||/[\r\n\0]/.test(decrypted[id]))throw safeError('本机图床密钥保存格式无效。');loadedCredentials[id]=decrypted[id];}
      settings=candidate;credentials=loadedCredentials;
    })();
    const pending=loading;try{await pending;}finally{if(loading===pending)loading=undefined;}
  }
  async function ensureLoaded(){await load();return settings;}
  const providerOrder=snapshot=>[snapshot.uploadProvider,...snapshot.fallbackProviders];
  const authConfigured=(provider,stored)=>Boolean(provider==='urpiclink'?serviceAuthorization:stored[provider]);
  function isConfigured(provider,fields,stored){
    if(provider==='urpiclink')return profileCache?.configured===true;
    if(provider==='imgurl')return Boolean(fields.uploadEndpoint&&stored.imgurl);
    if(provider==='mini-tools')return Boolean(fields.miniToolsUserId&&stored['mini-tools']);
    return Boolean(fields.uploadEndpoint);
  }
  async function read(){
    await load();
    const snapshot=structuredClone(settings),stored=credentials,provider=snapshot.uploadProvider;
    const request=++profileRequest;
    const profile=await service('/api/v1/config/github').then(value=>rememberProfile(value,request)).catch(error=>{
      if(provider==='urpiclink')throw error;
      return profileCache||{};
    });
    const providers=Object.fromEntries(providerIds.map(id=>[id,{...snapshot.providers[id],authConfigured:authConfigured(id,stored)}]));
    return {...providers[provider],uploadProvider:provider,fallbackProviders:snapshot.fallbackProviders,
      materialFolder:snapshot.materialFolder,githubRepositories:repositories(profile.repositories||[]),
      tokenConfigured:profile.tokenConfigured===true,providers};
  }
  async function publicStatus(){
    await load();
    const order=providerOrder(settings),provider=settings.uploadProvider;
    if(order.includes('urpiclink'))refreshPublicProfile();
    const ready=order.filter(id=>isConfigured(id,settings.providers[id],credentials));
    const uploadServiceState=ready.some(id=>id!=='urpiclink')||!order.includes('urpiclink')?'ready':profileFailed?'unavailable':profileCache?'ready':'checking';
    return {uploadProvider:provider,configured:ready.length>0,tokenConfigured:provider==='urpiclink'?profileCache?.tokenConfigured===true:Boolean(credentials[provider]),
      maxFileBytes:Math.max(...(ready.length?ready:[provider]).map(fileLimit)),uploadServiceState,
      materialFolderName:settings.materialFolder.split(/[\\/]/).filter(Boolean).at(-1)||'共享素材',revision:settings.updatedAt,global:true};
  }
  async function save(input){return serial(async()=>{
    await load();if(!input||typeof input!=='object'||Array.isArray(input))throw safeError('全局设置内容无效。');
    const primary=input.uploadProvider,provider=input.profileProvider??primary;
    if(!providerIds.includes(primary)||!providerIds.includes(provider))throw safeError('请选择有效的图床服务。');
    if(input.fallbackProviders!==undefined&&(!Array.isArray(input.fallbackProviders)||input.fallbackProviders.some(id=>!providerIds.includes(id))))throw safeError('请选择有效的备用图床。');
    if(typeof input.materialFolder!=='string'||!isAbsolute(input.materialFolder.trim())||input.materialFolder.includes('\0'))throw safeError('请选择有效的主机素材文件夹。');
    if(input.materialFolder.includes('\ufffd'))throw safeError('素材目录包含乱码字符，请用“选择文件夹”重新选择正确目录。');
    const selectedFolder=resolve(input.materialFolder.trim());
    const materialFolder=fixedMaterialFolder?await fixedMaterialFolder(selectedFolder):selectedFolder,candidate=structuredClone(settings),fields={...settings.providers[provider]};
    const authorization=typeof input.authValue==='string'?input.authValue.trim():'';
    if(authorization.length>4096||/[\r\n\0]/.test(authorization))throw safeError('图床授权内容无效。');
    const nextCredentials={...credentials};
    if(provider==='urpiclink')Object.assign(fields,DEFAULTS.urpiclink);
    else if(provider==='mini-tools'){
      const profile=await miniTools.check({userId:input.miniToolsUserId??fields.miniToolsUserId,
        duration:input.miniToolsDuration??fields.miniToolsDuration,apiKey:authorization||credentials[provider]});
      Object.assign(fields,{uploadEndpoint:MINI_TOOLS_UPLOAD_URL,miniToolsUserId:profile.userId,miniToolsDuration:profile.duration});
      if(authorization)nextCredentials[provider]=profile.apiKey;
    }
    else if(provider==='scdn')Object.assign(fields,{uploadEndpoint:SCDN_UPLOAD_URL,
      scdnCdnDomain:normalizeScdnCdnDomain(input.scdnCdnDomain??fields.scdnCdnDomain)});
    else{fields.uploadEndpoint=validateUploadEndpoint(String(input.uploadEndpoint||DEFAULTS[provider].uploadEndpoint));if(provider==='imgurl'&&new URL(fields.uploadEndpoint).origin+new URL(fields.uploadEndpoint).pathname!=='https://www.imgurl.org/api/v3/upload'&&new URL(fields.uploadEndpoint).origin+new URL(fields.uploadEndpoint).pathname!=='https://imgurl.org/api/v3/upload')throw safeError('ImgURL 请使用官方 /api/v3/upload 接口。');fields.fileField=String(input.fileField||'file').trim();fields.responsePath=String(input.responsePath||'').trim();fields.authHeaderName=String(input.authHeaderName||'Authorization').trim();if(!fields.fileField||fields.fileField.length>128||/[\r\n\0]/.test(fields.fileField))throw safeError('上传文件字段无效。');if(fields.responsePath.length>512||fields.responsePath.split('.').some(x=>['__proto__','constructor','prototype'].includes(x)))throw safeError('返回URL字段无效。');if(!/^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/.test(fields.authHeaderName)||/^(?:content-type|content-length|host|cookie|set-cookie|origin|referer|connection)$/i.test(fields.authHeaderName))throw safeError('授权请求头名称无效。');}
    const token=typeof input.githubToken==='string'?input.githubToken.trim():'';if(token.length>4096||/\s/.test(token))throw safeError('GitHub Token 格式无效，请填 Token 原文。');
    const selectedRepos=input.githubRepositories===undefined?undefined:repositories(input.githubRepositories);
    await mkdir(materialFolder,{recursive:true});const probe=join(materialFolder,'.pod-write-'+randomBytes(8).toString('hex'));try{const handle=await open(probe,'wx');await handle.close();}catch{throw safeError('素材文件夹不可写，请选择有读写权限的文件夹。');}finally{await unlink(probe).catch(()=>{});}
    if(provider==='urpiclink'&&(token||selectedRepos!==undefined)){const profile=await service('/api/v1/config/github'),changed=selectedRepos!==undefined&&JSON.stringify(selectedRepos)!==JSON.stringify(repositories(profile.repositories||[]));if(token||changed)await service('/api/v1/config/github',{method:'POST',body:{...(token?{token}:{}),...(changed?{repositories:selectedRepos}:{})}});}
    if((provider==='custom'||provider==='imgurl')&&authorization)nextCredentials[provider]=authorization;
    candidate.uploadProvider=primary;
    candidate.fallbackProviders=fallbackList(input.fallbackProviders??settings.fallbackProviders,primary);
    candidate.materialFolder=materialFolder;candidate.providers[provider]=fields;candidate.updatedAt=new Date().toISOString();
    await mkdir(root,{recursive:true});
    const temporary=configPath+'.'+randomBytes(8).toString('hex')+'.tmp';
    let credentialsSaved=false;
    try{
      await writeFile(temporary,JSON.stringify(candidate,null,2),{flag:'wx'});
      if(withSecrets.has(provider)&&nextCredentials[provider]!==credentials[provider]){
        await encrypt(nextCredentials);
        credentialsSaved=true;
      }
      await rename(temporary,configPath);
    }catch(error){
      if(credentialsSaved)await encrypt(credentials).catch(()=>{});
      if(withSecrets.has(provider)&&error.message?.startsWith('图床密钥'))throw error;
      throw safeError('全局设置未能保存，请检查主机用户目录权限。');
    }finally{await unlink(temporary).catch(()=>{});}
    if(nextCredentials[provider]!==credentials[provider]||
      Object.keys(fields).some(key=>fields[key]!==settings.providers[provider][key]))cooldowns.delete(provider);
    settings=candidate;credentials=nextCredentials;return read();
  });}
  async function inspect(token=''){if(typeof token!=='string'||token.length>4096||/\s/.test(token.trim()))throw safeError('GitHub Token 格式无效。');return service('/api/v1/github/inspect',{method:'POST',body:{token:token.trim()}});}
  function uploadVia(provider,file,fields,stored,signal){
    if(provider==='mini-tools')return miniTools.upload(file,{userId:fields.miniToolsUserId,
      duration:fields.miniToolsDuration,apiKey:stored[provider]},{signal});
    if(provider==='scdn')return uploadScdnImage(file,{scdnCdnDomain:fields.scdnCdnDomain,fetchImpl,signal});
    return uploadImage(file,{endpoint:fields.uploadEndpoint,provider,fileField:fields.fileField,responsePath:fields.responsePath,
      authHeaderName:fields.authHeaderName,authValue:provider==='urpiclink'?serviceAuthorization:stored[provider]||'',signal,fetchImpl});
  }
  async function upload(bytes,contentType,{signal}={}){
    await load();
    const snapshot=settings,stored=credentials,order=providerOrder(snapshot);
    const form=await new Request('http://127.0.0.1/',{method:'POST',headers:{'Content-Type':contentType||''},body:bytes}).formData();
    const file=form.get('file');
    if(!(file instanceof Blob))throw safeError('未收到有效的效果图。');
    if(order.length>1&&order.includes('urpiclink')&&!profileCache){
      const request=++profileRequest;
      await service('/api/v1/config/github',{timeout:6000}).then(value=>rememberProfile(value,request)).catch(()=>{});
    }
    const candidates=order.length===1?order:order.filter(id=>isConfigured(id,snapshot.providers[id],stored));
    const errors=[];
    for(const provider of candidates){
      signal?.throwIfAborted();
      const cooling=cooldowns.get(provider);
      if(cooling&&cooling.until>now()){
        errors.push(cooling.error);
        continue;
      }
      if(cooling)cooldowns.delete(provider);
      try{return await uploadVia(provider,file,snapshot.providers[provider],stored,signal);}
      catch(error){
        signal?.throwIfAborted();
        if(error?.name!=='PodImageUploadError'||![413,429].includes(error.status))throw error;
        if(error.status===429){
          const delay=Number.isSafeInteger(error.retryAfterMs)&&error.retryAfterMs>=0?error.retryAfterMs:5000;
          cooldowns.set(provider,{until:now()+delay,error});
        }
        errors.push(error);
      }
    }
    if(errors.length===1)throw errors[0];
    if(!errors.length)throw Object.assign(safeError('请先配置可用的图床。'),{name:'PodImageUploadError',status:400,code:'POD_UPLOAD_FAILOVER_UNCONFIGURED'});
    const sizeOnly=errors.every(error=>error.status===413);
    throw Object.assign(safeError(sizeOnly?'所选图床均无法接收这张图片。':'所选图床额度受限或无法接收这张图片。'),{
      name:'PodImageUploadError',status:sizeOnly?413:429,code:sizeOnly?'POD_UPLOAD_FAILOVER_SIZE':'POD_UPLOAD_FAILOVER_QUOTA',
    });
  }
  return {load:ensureLoaded,read,save,inspect,publicStatus,upload,getFolder:()=>{if(!settings)throw safeError('全局设置尚未加载。');return settings.materialFolder;},root};
}
