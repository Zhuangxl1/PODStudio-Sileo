import {lookup} from 'node:dns/promises';
import {get as httpsGet} from 'node:https';
import {isIPv4} from 'node:net';
import {setTimeout as waitForUapiSlot} from 'node:timers/promises';
import {createMiaoshouProxyGet} from './miaoshou-image-proxy.mjs';

const MAX_BYTES=25*1024*1024,RETRYABLE_HTTP=new Set([429,502,503,504]);
const IMAGE_TYPES=new Set(['image/png','image/jpeg','image/webp']);
const GENERIC_IMAGE_TYPES=new Set(['','image/jpg','image/pjpeg','application/octet-stream','binary/octet-stream']);
function detectedImageType(bytes){
  if(bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'image/png';
  if(bytes.subarray(0,3).equals(Buffer.from([255,216,255])))return 'image/jpeg';
  if(bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return 'image/webp';
  return '';
}
const CONNECTION_CODES=new Set(['ECONNRESET','ECONNABORTED','EPIPE','ETIMEDOUT','ESOCKETTIMEDOUT','EAI_AGAIN']);
const FALLBACK_READ_ERRORS=new Set(['SOURCE_IMAGE_TIMEOUT','SOURCE_IMAGE_CONNECTION','SOURCE_IMAGE_INCOMPLETE','SOURCE_IMAGE_DOWNLOAD']);
const imageError=(code,message,{retryable=false,status=502,...extra}={})=>Object.assign(new Error(message),{sourceImageError:true,code,status,retryable,...extra});
function readableError(error){
  if(error?.sourceImageError)return error;
  const code=String(error?.code||error?.cause?.code||'');
  if(['ETIMEDOUT','ESOCKETTIMEDOUT'].includes(code)||['TimeoutError','AbortError'].includes(error?.name))return imageError('SOURCE_IMAGE_TIMEOUT','主图下载超时，请稍后重试或从本地上传图片。',{retryable:true});
  if(CONNECTION_CODES.has(code))return imageError('SOURCE_IMAGE_CONNECTION','下载采集箱主图时连接中断，请稍后重试或从本地上传图片。',{retryable:true});
  if(code==='ENOTFOUND')return imageError('SOURCE_IMAGE_DNS','无法找到主图服务器，请稍后重试或从本地上传图片。');
  if(/CERT|TLS|SSL/.test(code))return imageError('SOURCE_IMAGE_TLS','主图服务器的安全连接验证失败，请核对图片来源或从本地上传图片。');
  return imageError('SOURCE_IMAGE_DOWNLOAD','采集箱主图下载失败，请稍后重试或从本地上传图片。');
}
export function publicImageIPv4(ip){const p=ip.split('.').map(Number);if(p.length!==4||p.some(n=>!Number.isInteger(n)||n<0||n>255))return false;const[a,b]=p;return !(a===0||a===10||a===127||a>=224||a===169&&b===254||a===172&&b>=16&&b<=31||a===192&&(b===168||b===0||b===2)||a===198&&(b===18||b===19||b===51)||a===203&&b===0||a===100&&b>=64&&b<=127);}

const publicFallbackHost=host=>host==='raw.githubusercontent.com'||/^(?:[a-z0-9-]+\.)+ttcdn-us\.com$/u.test(host);
const fakeProxyAddress=record=>typeof record?.address==='string'&&isIPv4(record.address)&&/^198\.(?:18|19)\./u.test(record.address);
const publicAnswers=rows=>Array.isArray(rows)&&rows.length>0&&rows.every(record=>typeof record?.address==='string'&&isIPv4(record.address)&&publicImageIPv4(record.address));
const addressUnavailable=()=>imageError('SOURCE_IMAGE_DNS','主机代理返回了占位地址，暂时无法核验原图服务器的公网地址。');

function queryPublicDns(host,resolver,ip,{signal,timeoutMs}){
  const url=new URL(resolver);
  url.search=new URLSearchParams({name:host,type:'A'}).toString();
  const dnsSignal=AbortSignal.timeout(Math.max(1,Math.min(2500,Math.floor(timeoutMs))));
  return new Promise((resolve,reject)=>{
    // Reach the fixed resolver over verified HTTPS without asking the intercepted system DNS again.
    const request=httpsGet(url,{signal:signal?AbortSignal.any([signal,dnsSignal]):dnsSignal,agent:false,
      headers:{Accept:'application/dns-json'},lookup:(_host,options,callback)=>options.all?callback(null,[{address:ip,family:4}]):callback(null,ip,4)},response=>{
      if(response.statusCode!==200){response.resume();reject(addressUnavailable());return;}
      let body='',length=0;
      response.once('error',reject);
      response.setEncoding('utf8');
      response.on('data',chunk=>{
        length+=Buffer.byteLength(chunk);
        if(length>16384){reject(addressUnavailable());response.destroy();return;}
        body+=chunk;
      });
      response.once('end',()=>{
        try{
          const result=JSON.parse(body),question=Array.isArray(result.Question)?result.Question[0]:result.Question;
          if(result.Status!==0||question?.type!==1||question.name?.toLowerCase().replace(/\.$/u,'')!==host||!Array.isArray(result.Answer))throw addressUnavailable();
          resolve(result.Answer.filter(row=>row?.type===1).map(row=>({address:row.data,family:4})));
        }catch(error){reject(error);}
      });
    });
    request.once('error',reject);
  });
}
async function lookupPublicImageHost(host,{signal,timeoutMs}){
  const deadline=Date.now()+timeoutMs;
  for(const [resolver,ip] of [['https://doh.pub/resolve','1.12.12.12'],['https://dns.alidns.com/resolve','223.5.5.5']]){
    const remaining=deadline-Date.now();
    if(remaining<=0||signal?.aborted)break;
    try{
      const records=await queryPublicDns(host,resolver,ip,{signal,timeoutMs:remaining});
      if(publicAnswers(records))return records;
    }catch{}
  }
  throw addressUnavailable();
}

const defaultImageGet=createMiaoshouProxyGet({isPublicIPv4:publicImageIPv4});
export function createMiaoshouImageReader({lookupImpl=lookup,lookupPublicImpl=lookupPublicImageHost,getImpl=defaultImageGet,uapiFetch=globalThis.fetch,wait,timeoutMs=20000}={}){
  const budget=Number.isFinite(timeoutMs)&&timeoutMs>0?Math.min(timeoutMs,20000):20000;
  const readWithUapi=createUapiImageReader({fetchImpl:uapiFetch,maxBytes:MAX_BYTES,detectImageType:detectedImageType});
  const timeout=()=>imageError('SOURCE_IMAGE_TIMEOUT','主图下载超时，请稍后重试或从本地上传图片。',{retryable:true});
  const canceled=()=>Object.assign(imageError('SOURCE_IMAGE_ABORTED','主图下载已取消。',{status:409}),{name:'AbortError'});
  const checkSignal=signal=>{if(signal?.aborted)throw canceled();};
  async function withSignal(work,signal,milliseconds){
    checkSignal(signal);let timer,abort;
    try{return await Promise.race([Promise.resolve().then(()=>{checkSignal(signal);return work();}),new Promise((_resolve,reject)=>{
      if(Number.isFinite(milliseconds))timer=setTimeout(()=>reject(timeout()),milliseconds);
      if(signal){abort=()=>reject(canceled());signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();}
    })]);}finally{clearTimeout(timer);if(abort)signal.removeEventListener('abort',abort);}
  }
  async function retryWait(milliseconds,signal){
    if(wait)return withSignal(()=>wait(milliseconds),signal);
    checkSignal(signal);let timer,abort;
    try{await new Promise((resolve,reject)=>{
      timer=setTimeout(resolve,milliseconds);
      if(signal){abort=()=>reject(canceled());signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();}
    });}finally{clearTimeout(timer);if(abort)signal.removeEventListener('abort',abort);}
  }
  async function resolveAddress(address,remaining,signal){
    checkSignal(signal);
    let url;try{url=new URL(address);}catch{throw imageError('SOURCE_IMAGE_URL','采集箱主图地址无效。',{status:400});}
    if(url.protocol!=='https:'||url.username||url.password||url.port&&url.port!=='443')throw imageError('SOURCE_IMAGE_URL','采集箱主图地址无效。',{status:400});
    if(remaining<=0)throw timeout();
    let records=await withSignal(()=>lookupImpl(url.hostname,{family:4,all:true}),signal,remaining);
    checkSignal(signal);
    if(publicFallbackHost(url.hostname)&&Array.isArray(records)&&records.length>0&&records.every(fakeProxyAddress)){
      try{records=await withSignal(()=>lookupPublicImpl(url.hostname,{signal,timeoutMs:remaining}),signal,remaining);}
      catch{checkSignal(signal);throw addressUnavailable();}
      if(!publicAnswers(records))throw addressUnavailable();
    }
    if(!publicAnswers(records))throw imageError('SOURCE_IMAGE_URL','采集箱主图地址不可用。',{status:400});
    return {url,records:records.map(record=>({address:record.address,family:4}))};
  }
  function download(url,records,remaining,signal){
    if(remaining<=0)return Promise.reject(timeout());
    return new Promise((resolve,reject)=>{
      let request,timer,settled=false;
      const abort=()=>finish(canceled());
      const finish=(error,result)=>{
        if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);
        if(error||result?.redirect)request?.destroy();
        if(error)reject(readableError(error));else resolve(result);
      };
      signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted){abort();return;}
      timer=setTimeout(()=>finish(timeout()),remaining);
      try{
        request=getImpl(url,{lookup:(_host,options,callback)=>{if(typeof options==='function'){callback=options;options={};}return options?.all?callback(null,records):callback(null,records[0].address,4);},headers:{Accept:'image/png,image/jpeg,image/webp'},rejectUnauthorized:true,timeout:remaining},response=>{
          if(settled){response.on?.('error',()=>{});response.destroy?.();return;}
          response.on('error',error=>finish(error));
          response.on('aborted',()=>finish(imageError('SOURCE_IMAGE_INCOMPLETE','主图下载中断，尚未取得完整图片，请稍后重试。',{retryable:true})));
          response.on('close',()=>{if(response.complete===false||response.readableAborted)finish(imageError('SOURCE_IMAGE_INCOMPLETE','主图下载中断，尚未取得完整图片，请稍后重试。',{retryable:true}));});
          if([301,302,303,307,308].includes(response.statusCode)){
            let redirect;try{if(typeof response.headers?.location!=='string'||!response.headers.location.trim())throw Error();redirect=new URL(response.headers.location,url).href;}
            catch{response.resume();return finish(imageError('SOURCE_IMAGE_REDIRECT','主图跳转地址无效，请更新来源图片或从本地上传。',{status:400}));}
            response.resume();return finish(null,{redirect});
          }
          if(response.statusCode!==200){
            const httpStatus=Number(response.statusCode),retryable=RETRYABLE_HTTP.has(httpStatus);
            const rawRetry=response.headers?.['retry-after'];let retryAfterMs=0;
            if(rawRetry){const seconds=Number(rawRetry),delay=Number.isFinite(seconds)?seconds*1000:Date.parse(rawRetry)-Date.now();if(Number.isFinite(delay))retryAfterMs=Math.max(0,delay);}
            response.resume();return finish(imageError('SOURCE_IMAGE_HTTP','主图服务器暂时无法提供图片（HTTP '+httpStatus+'），请稍后重试或从本地上传图片。',{retryable:retryable&&retryAfterMs<=30000,httpStatus,retryAfterMs}));
          }
          const type=String(response.headers?.['content-type']||'').split(';')[0].trim().toLowerCase();
          if(!IMAGE_TYPES.has(type)&&!GENERIC_IMAGE_TYPES.has(type)){response.resume();return finish(imageError('SOURCE_IMAGE_FORMAT','主图不是支持的 PNG、JPG 或 WebP 图片。',{status:400}));}
          const declared=Number(response.headers?.['content-length']);
          if(Number.isFinite(declared)&&declared>MAX_BYTES)return finish(imageError('SOURCE_IMAGE_TOO_LARGE','主图超过 25 MB。',{status:413}));
          let bytes=0;const chunks=[];
          response.on('data',chunk=>{if(settled)return;bytes+=chunk.length;if(bytes>MAX_BYTES)return finish(imageError('SOURCE_IMAGE_TOO_LARGE','主图超过 25 MB。',{status:413}));chunks.push(Buffer.from(chunk));});
          response.on('end',()=>{
            if(settled)return;
            if(response.complete===false||response.readableAborted||Number.isFinite(declared)&&declared>=0&&bytes!==declared)return finish(imageError('SOURCE_IMAGE_INCOMPLETE','主图下载中断，尚未取得完整图片，请稍后重试。',{retryable:true}));
            if(!bytes)return finish(imageError('SOURCE_IMAGE_EMPTY','主图服务器返回了空图片，请更新来源图片或从本地上传。',{status:400}));
            const image=Buffer.concat(chunks),imageType=IMAGE_TYPES.has(type)?type:detectedImageType(image);
            if(!imageType)return finish(imageError('SOURCE_IMAGE_FORMAT','主图没有可识别的 PNG、JPG 或 WebP 文件内容。',{status:400}));
            finish(null,{type:imageType,bytes:image});
          });
        });
        request.on('timeout',()=>finish(timeout()));request.on('error',error=>finish(error));
        if(settled)request.destroy();
      }catch(error){finish(error);}
    });
  }
  return async function readImage(address,options=0){
    const depth=options&&typeof options==='object'&&!Array.isArray(options)?options.depth??0:options,
      signal=options&&typeof options==='object'&&!Array.isArray(options)?options.signal:undefined,
      usePublicFallback=options?.usePublicFallback===true;
    if(!Number.isInteger(depth)||depth<0||depth>3)throw imageError('SOURCE_IMAGE_REDIRECT','采集箱主图地址跳转次数过多。',{status:400});
    if(signal!==undefined&&(!signal||typeof signal.aborted!=='boolean'||typeof signal.addEventListener!=='function'||typeof signal.removeEventListener!=='function'))throw imageError('SOURCE_IMAGE_OPTIONS','主图下载取消参数无效。',{status:400});
    checkSignal(signal);
    for(let attempt=0;;attempt++){
      let fallbackAddress;
      try{
        const deadline=Date.now()+budget;let current=address;
        for(let hop=depth;hop<=3;hop++){
          const {url,records}=await resolveAddress(current,deadline-Date.now(),signal);
          // Forward only a verified, unsigned CDN URL, never a redirected URL or credentials.
          if(usePublicFallback&&hop===depth&&publicFallbackHost(url.hostname)&&url.href.length<=4096&&!url.href.includes('?')&&!url.href.includes('#'))fallbackAddress=url.href;
          const result=await download(url,records,deadline-Date.now(),signal);
          checkSignal(signal);
          if(!result.redirect)return result;
          fallbackAddress=undefined;
          if(hop===3)throw imageError('SOURCE_IMAGE_REDIRECT','采集箱主图地址跳转次数过多。',{status:400});
          current=result.redirect;
        }
      }catch(original){
        if(signal?.aborted)throw canceled();
        const error=readableError(original);
        if(!error.retryable||attempt>=2){
          if(fallbackAddress&&(FALLBACK_READ_ERRORS.has(error.code)||RETRYABLE_HTTP.has(error.httpStatus)||error.httpStatus===500)){
            try{const image=await readWithUapi(fallbackAddress,{signal});checkSignal(signal);return image;}
            catch{checkSignal(signal);}
          }
          error.attempts=attempt+1;
          if(attempt>0)error.message+='（已自动重试 '+attempt+' 次，仍未成功）';
          throw error;
        }
        await retryWait(Math.max(1000*2**attempt,error.retryAfterMs||0),signal);
      }
    }
  };
}
const ENDPOINT='https://uapis.cn/api/v1/image/tobase64';
const INVALID_IMAGE='UApiPro 未返回可用的原图。';
const MAX_ACTIVE=3, REQUEST_INTERVAL_MS=260, TIMEOUT_MS=8000;

async function boundedJson(response,limit,signal){
  if(!response.body||Number(response.headers.get('content-length'))>limit){
    await response.body?.cancel().catch(()=>{});
    throw new Error(INVALID_IMAGE);
  }
  const reader=response.body.getReader(),chunks=[];
  let length=0,done=false;
  try{
    while(!done){
      signal.throwIfAborted();
      const part=await reader.read();
      done=part.done;
      if(done)break;
      length+=part.value.byteLength;
      if(length>limit)throw new Error(INVALID_IMAGE);
      chunks.push(Buffer.from(part.value));
    }
    return JSON.parse(Buffer.concat(chunks,length).toString('utf8'));
  }finally{
    if(!done)await reader.cancel().catch(()=>{});
    reader.releaseLock();
  }
}

function createUapiImageReader({fetchImpl=globalThis.fetch,maxBytes,detectImageType}){
  const encodedLimit=4*Math.ceil(maxBytes/3);
  let active=0,nextStart=0,cooldownUntil=0;
  return async function readWithUapi(sourceUrl,{signal}={}){
    const timeoutSignal=AbortSignal.timeout(TIMEOUT_MS);
    const requestSignal=signal?AbortSignal.any([signal,timeoutSignal]):timeoutSignal;
    while(active>=MAX_ACTIVE||Date.now()<nextStart){
      if(Date.now()<cooldownUntil)throw new Error('UApiPro 暂时限流。');
      await waitForUapiSlot(Math.max(75,nextStart-Date.now()),undefined,{signal:requestSignal});
    }
    requestSignal.throwIfAborted();
    if(Date.now()<cooldownUntil)throw new Error('UApiPro 暂时限流。');
    nextStart=Date.now()+REQUEST_INTERVAL_MS;
    active++;
    try{
      const url=new URL(ENDPOINT);
      url.searchParams.set('url',sourceUrl);
      const response=await fetchImpl(url,{headers:{Accept:'application/json'},redirect:'error',credentials:'omit',signal:requestSignal});
      if(response.status===429){
        const header=response.headers.get('retry-after');
        const delay=header?(Number.isFinite(Number(header))?Number(header)*1000:Date.parse(header)-Date.now()):NaN;
        cooldownUntil=Math.max(cooldownUntil,Date.now()+Math.max(1000,Number.isFinite(delay)?delay:60000));
      }
      if(response.status!==200||response.headers.get('content-type')?.split(';')[0].trim().toLowerCase()!=='application/json'){
        await response.body?.cancel().catch(()=>{});
        throw new Error(INVALID_IMAGE);
      }
      const payload=await boundedJson(response,encodedLimit+4096,requestSignal);
      requestSignal.throwIfAborted();
      const data=typeof payload?.base64==='string'?payload.base64:'';
      const separator=data.indexOf(',');
      const mediaType=separator>0&&separator<=32?/^data:(image\/(?:png|jpe?g|webp));base64$/iu.exec(data.slice(0,separator))?.[1].toLowerCase():'';
      const encoded=data.slice(separator+1),content=encoded.replace(/={1,2}$/u,'');
      if(!mediaType||!content||encoded.length>encodedLimit||encoded.length%4!==0||/[^A-Za-z0-9+/]/u.test(content))throw new Error(INVALID_IMAGE);
      const bytes=Buffer.from(encoded,'base64'),type=detectImageType(bytes);
      if(bytes.length>maxBytes||type!==(mediaType==='image/jpg'?'image/jpeg':mediaType))throw new Error(INVALID_IMAGE);
      return {type,bytes};
    }finally{
      active--;
    }
  };
}

export const readMiaoshouImage=createMiaoshouImageReader();
