import {createHash, randomUUID} from 'node:crypto';
import {mkdir, readFile, readdir, rename, unlink, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const MAX_BYTES = 10 * 1024 * 1024;
const ID = /^[a-f0-9]{64}$/u;
const TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
export const MIAOSHOU_SIZE_CHART_REQUEST_BYTES = Math.ceil(MAX_BYTES / 3) * 4 + 4096;
const error = (message, status = 400) => Object.assign(new Error(message), {status});
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

function matchesType(bytes, type) {
  if (type === 'image/png') return bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if (type === 'image/jpeg') return bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  return type === 'image/webp' && bytes.subarray(0,4).toString('ascii') === 'RIFF'
    && bytes.subarray(8,12).toString('ascii') === 'WEBP';
}

function chartName(value) {
  return (typeof value === 'string' ? value.split(/[\\/]/u).at(-1) : '')
    .replace(/[\x00-\x1f\x7f]/gu, '').trim().slice(0, 160) || '尺码图';
}

function chartUrl(value) {
  if (typeof value !== 'string' || value.length > 255) return undefined;
  try {
    const url = new URL(value);
    if (url.protocol === 'https:' && !url.username && !url.password && url.href.length <= 255) return url.href;
  } catch {}
}

async function writeAtomic(path, data, guard) {
  const temporary = path + '.' + randomUUID() + '.tmp';
  try {
    await writeFile(temporary, data, {flag:'wx'});
    await guard();
    await rename(temporary, path);
  } finally { await unlink(temporary).catch(() => {}); }
}

/** Account scoped, version independent library under the host's persistent settings root. */
export function createMiaoshouSizeChartLibrary({root} = {}) {
  const pending = new Map();
  function directory(scope) {
    if (!ID.test(scope || '')) throw error('尺码表账号无效。');
    return resolve(root, 'size-chart-library', scope);
  }
  async function metadata(dir, id) {
    try {
      const row = JSON.parse(await readFile(resolve(dir, id + '.json'), 'utf8'));
      if (row.id === id && TYPES.has(row.type) && Number.isInteger(row.size) && row.size > 0 && row.size <= MAX_BYTES)
        return {id, name:chartName(row.name), type:row.type, size:row.size, url:chartUrl(row.url), updatedAt:Number(row.updatedAt)||0};
    } catch (err) { if (err.code !== 'ENOENT' && !(err instanceof SyntaxError)) throw err; }
    return null;
  }
  return {
    async list(scope) {
      const dir = directory(scope);
      const files = await readdir(dir).catch(err => { if (err.code === 'ENOENT') return []; throw err; });
      const items = [];
      for (const name of files) if (name.endsWith('.json') && ID.test(name.slice(0,-5))) {
        const row = await metadata(dir,name.slice(0,-5));
        if (row) items.push(row);
      }
      return items.sort((a,b) => b.updatedAt-a.updatedAt || a.id.localeCompare(b.id));
    },
    async read(scope,id) {
      if (typeof id !== 'string' || !ID.test(id)) throw error('尺码图编号无效。');
      const dir = directory(scope), row = await metadata(dir,id);
      if (!row) throw error('未找到这张尺码图。',404);
      const bytes = await readFile(resolve(dir,id+'.image')).catch(err=>{if(err.code==='ENOENT')throw error('未找到这张尺码图。',404);throw err;});
      if (bytes.length !== row.size || digest(bytes) !== id || !matchesType(bytes,row.type)) throw error('尺码图文件无法校验，请重新导入。',409);
      return {bytes,type:row.type};
    },
    async save(scope, {name,type,data,url} = {}, guard = () => {}) {
      const dir = directory(scope), link = chartUrl(url);
      if (!TYPES.has(type) || typeof data !== 'string' || data.length > MIAOSHOU_SIZE_CHART_REQUEST_BYTES
        || !/^[A-Za-z0-9+/]+={0,2}$/u.test(data) || (url && !link)) throw error('请选择 10 MB 以内的 PNG、JPG 或 WebP 尺码图。');
      const bytes = Buffer.from(data,'base64');
      if (!bytes.length || bytes.length > MAX_BYTES || !matchesType(bytes,type)) throw error('尺码图格式不正确或超过 10 MB。');
      const id = digest(bytes), key = resolve(dir,id);
      const task = (pending.get(key) || Promise.resolve()).catch(() => {}).then(async () => {
        await guard();
        const prior = await metadata(dir,id);
        if (prior && (!link || prior.url === link)) return prior;
        await mkdir(dir,{recursive:true});
        const record = {id,name:prior?.name || chartName(name),type,size:bytes.length,url:link || prior?.url,updatedAt:Date.now()};
        if (!prior) await writeAtomic(key+'.image',bytes,guard);
        await writeAtomic(key+'.json',JSON.stringify(record),guard);
        return record;
      });
      pending.set(key,task);
      try {return await task;} finally {if(pending.get(key)===task)pending.delete(key);}
    },
  };
}
