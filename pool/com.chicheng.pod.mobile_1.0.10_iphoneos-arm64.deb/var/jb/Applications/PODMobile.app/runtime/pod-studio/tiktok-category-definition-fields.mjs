import { createHash } from 'node:crypto';
import { createObservedInputCandidate, createCategoryDefinitionInputDraftCandidate, observedInputLabels } from './dist/tiktok-input-evidence.js';

// This mapper consumes only a verified read result and a normal visible snapshot.
// It performs no browser, network, filesystem or publishing operations.
const limits = Object.freeze({ controls: 5000, fields: 1000, properties: 200, options: 10000, totalOptions: 20000 });
const groupKinds = Object.freeze({ 'attribute-key': '关键属性', 'attribute-optional': '可选属性' });
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value)
  && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
const own = (value, key) => { if (!plain(value)) return undefined; const descriptor = Object.getOwnPropertyDescriptor(value, key); return descriptor && Object.hasOwn(descriptor, 'value') ? descriptor.value : undefined; };
const validId = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,160}$/u.test(value);
// Same pure Basic-payload check as the standalone catalogue projectors.
const basicCredential = value => {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  for (const match of value.matchAll(/\bBasic\s+([^\s,;]+)/giu)) {
    const encoded = match[1]; if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded)) continue;
    const bare = encoded.replace(/=+$/u, ''), remainder = bare.length % 4, padding = encoded.length - bare.length;
    if (remainder === 1 || padding && (encoded.length % 4 !== 0 || padding !== (4 - remainder) % 4)) continue;
    let buffer = 0, bits = 0, colon = false;
    for (const character of bare) {
      buffer = buffer * 64 + alphabet.indexOf(character); bits += 6;
      if (bits >= 8) { bits -= 8; if (Math.floor(buffer / 2 ** bits) === 58) colon = true; buffer %= 2 ** bits; }
    }
    if (buffer === 0 && colon) return true;
  }
  return false;
};
const validText = (value, max) => typeof value === 'string' && value.trim().length > 0 && value.length <= max
  && !/[\u0000-\u001f\u007f]|(?:https?|wss?):\/\/|\bBearer\s+\S+|\b(?:password|passwd|cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret)\s*[:=]|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu.test(value) && !basicCredential(value);
const editable = control => ['input', 'textarea', 'select'].includes(own(control, 'tag')) || ['combobox', 'textbox'].includes(own(control, 'role'));
const propertySection = property => {
  const classification = own(property, 'classification'), guide = own(classification, 'shopping_guide_property'), legal = own(classification, 'legal_property');
  return typeof guide !== 'boolean' || typeof legal !== 'boolean' ? null : guide ? '关键属性' : legal ? '' : '可选属性';
};
const keyFor = (section, label, ordinal) => 'dom-' + createHash('sha256').update([section, label, ordinal].join('\0')).digest('hex').slice(0, 24);

export function buildCategoryDefinitionFields(input = {}) {
  return mapCategoryDefinitionFields(input, false);
}

// Opt-in only: preserve the complete observed field universe after all global
// proofs pass. A rejected slot has no option IDs or editable completeness proof.
export function buildPartialCategoryDefinitionFields(input = {}) {
  return mapCategoryDefinitionFields(input, true);
}

function mapCategoryDefinitionFields({ definition, snapshot, scopeVerified } = {}, allowPartial) {
  let diagnosticField = null, diagnosticProperty = null, diagnosticRelation = null, failedChecks = [];
  const manufacturerInputs = []; let manufacturerInputsTruncated = false;
  const bool = value => typeof value === 'boolean' ? value : null;
  const count = value => Number.isSafeInteger(value) && value >= 0 && value <= 100000 ? value : null;
  const fieldMetadata = control => ({ label: validText(own(control, 'label'), 255) ? own(control, 'label') : null,
    section: Object.values(groupKinds).includes(own(control, 'section')) ? own(control, 'section') : null,
    tag: ['div', 'span', 'input', 'textarea', 'select'].includes(own(control, 'tag')) ? own(control, 'tag') : null,
    role: ['combobox', 'textbox'].includes(own(control, 'role')) ? own(control, 'role') : null,
    multiple: bool(own(control, 'multiple')), required: bool(own(control, 'required')), disabled: bool(own(control, 'disabled')), readOnly: bool(own(control, 'readOnly')) });
  const failed = reason => ({ accepted: false, ...(allowPartial ? { complete: false } : {}), fields: [], attributeGroups: [], reason,
    diagnostics: { version: 1, kind: 'category-definition-mapper-rejection', reason, field: diagnosticField, property: diagnosticProperty, relation: diagnosticRelation, failedChecks } });
  const withManufacturerDiagnostics = result => manufacturerInputs.length && result.diagnostics
    ? { ...result, diagnostics: { ...result.diagnostics, manufacturerInputs, manufacturerInputsTruncated } } : result;
  if (scopeVerified !== true) return failed('scope_unverified');
  if (!plain(snapshot) || own(snapshot, 'busy') !== false || own(own(snapshot, 'securityChallenge'), 'detected') !== false
    || !Array.isArray(own(snapshot, 'guidanceDialogs')) || own(snapshot, 'guidanceDialogs').length !== 0) return failed('snapshot_not_ready');
  const categoryId = own(definition, 'categoryId'), properties = own(definition, 'properties');
  if (!plain(definition) || own(definition, 'accepted') !== true || own(definition, 'source') !== 'observed-seller-category-definition'
    || !validId(categoryId) || own(definition, 'responseComplete') !== true || own(definition, 'propertyRowsComplete') !== true
    || own(definition, 'truncated') !== undefined && own(definition, 'truncated') !== false
    || !Array.isArray(properties) || properties.length > limits.properties) return failed('definition_unverified');
  const controls = own(snapshot, 'controls');
  if (!Array.isArray(controls) || controls.length > limits.controls) return failed('attribute_controls_invalid');
  const actual = controls.filter(control => Object.values(groupKinds).includes(own(control, 'section')) && editable(control));
  if (!actual.length || actual.length > limits.fields) return failed('attribute_controls_invalid');
  const signatures = new Set(), counts = new Map();
  for (const control of actual) {
    diagnosticField = fieldMetadata(control);
    const label = own(control, 'label'), section = own(control, 'section'), multiple = own(control, 'multiple');
    if (!validText(label, 255) || typeof multiple !== 'boolean' || typeof own(control, 'required') !== 'boolean'
      || own(control, 'disabled') !== false || own(control, 'readOnly') === true) return failed('attribute_descriptor_invalid');
    const signature = JSON.stringify([section, label, multiple]);
    if (signatures.has(signature)) return failed('attribute_relation_ambiguous');
    signatures.add(signature); const ordinalKey = section + '\0' + label; counts.set(ordinalKey, (counts.get(ordinalKey) || 0) + 1);
  }
  diagnosticField = null;
  const groups = own(snapshot, 'attributeGroups'), attributeGroups = [], seenGroups = new Set();
  if (!Array.isArray(groups) || groups.length !== Object.keys(groupKinds).length) return failed('attribute_census_incomplete');
  for (const group of groups) {
    const groupId = own(group, 'groupId'), kind = own(group, 'kind');
    if (!Object.hasOwn(groupKinds, groupId) || groupKinds[groupId] !== kind || seenGroups.has(groupId)
      || ['expanded', 'fieldRowsVerified', 'scanComplete'].some(key => own(group, key) !== true) || own(group, 'truncated') !== false) return failed('attribute_census_incomplete');
    seenGroups.add(groupId); const count = actual.filter(control => own(control, 'section') === kind).length;
    if (['candidateFieldCount', 'candidateControlCount', 'labelledControlCount', 'normalisedControlCount'].some(key => own(group, key) !== count)
      || ['missingLabelCount', 'unknownControlCount', 'unresolvedCount'].some(key => own(group, key) !== 0)
      || own(group, 'capturedControlCount') !== undefined && own(group, 'capturedControlCount') !== count) return failed('attribute_census_incomplete');
    attributeGroups.push({ groupId, kind, expanded: true, fieldRowsVerified: true, scanComplete: true, truncated: false,
      candidateFieldCount: count, candidateControlCount: count, labelledControlCount: count, normalisedControlCount: count,
      missingLabelCount: 0, unknownControlCount: 0, unresolvedCount: 0, capturedControlCount: count });
  }
  const propertyIds = new Map(), ordinals = new Map(), usedProperties = new Set(), fields = [], inputCandidates = [], definitionInputDraftCandidates = []; let totalOptions = 0;
  for (const property of properties) { const id = own(property, 'apiId'); if (validId(id)) propertyIds.set(id, (propertyIds.get(id) || 0) + 1); }
  const flagNames = ['is_enum', 'is_input', 'is_necessary', 'is_multi_choice', 'is_number'];
  const propertyMetadata = property => {
    const propertyId = own(property, 'apiId'), flags = own(property, 'flags'), values = own(property, 'values'), issues = own(property, 'issues');
    return { apiPropertyId: validId(propertyId) ? propertyId : null, valid: bool(own(property, 'valid')),
      subCascadeProperty: bool(own(property, 'subCascadeProperty')),
      cascadePresent: bool(own(property, 'cascadePresent')), truncated: bool(own(property, 'truncated')),
      hasCascadeValues: own(property, 'cascadeValues') !== undefined, hasSaleCascadeProperties: own(property, 'saleCascadeProperties') !== undefined,
      issuesPresent: issues !== undefined, issuesCount: Array.isArray(issues) ? count(issues.length) : null,
      invalidValueCounts: plain(own(property, 'invalidValueCounts')) ? Object.fromEntries(['row', 'id', 'label', 'duplicateId'].map(key => [key, count(own(own(property, 'invalidValueCounts'), key))])) : null,
      observedValueCount: count(own(property, 'observedValueCount')), valuesCount: Array.isArray(values) ? count(values.length) : null,
      definitionPropertyIdCount: count(propertyIds.get(propertyId)), propertyAlreadyUsed: usedProperties.has(propertyId),
      flags: Object.fromEntries(flagNames.map(key => [key, bool(own(flags, key))])),
      flagTypes: Object.fromEntries(flagNames.map(key => [key, typeof own(flags, key)])),
      classification: Object.fromEntries(['key_property', 'binding_property', 'shopping_guide_property', 'legal_property'].map(key => [key, bool(own(own(property, 'classification'), key))])) };
  };
  const mapControl = (control, slot) => {
    diagnosticField = fieldMetadata(control); diagnosticProperty = null; diagnosticRelation = null; failedChecks = [];
    const label = own(control, 'label'), section = own(control, 'section'), multiple = own(control, 'multiple'), required = own(control, 'required');
    const named = properties.filter(property => own(property, 'displayLabel') === label);
    const sameMultiple = named.filter(property => own(own(property, 'flags'), 'is_multi_choice') === multiple);
    const candidates = sameMultiple.filter(property => propertySection(property) === section);
    diagnosticRelation = { namedCount: named.length, sameMultipleCount: sameMultiple.length, candidateCount: candidates.length,
      unverifiedMultiplicityCount: named.filter(property => typeof own(own(property, 'flags'), 'is_multi_choice') !== 'boolean').length,
      unverifiedSectionCount: sameMultiple.filter(property => propertySection(property) === null).length,
      candidatesTruncated: named.length > 8, candidates: named.slice(0, 8).map(property => ({ ...propertyMetadata(property),
        sameMultiple: own(own(property, 'flags'), 'is_multi_choice') === multiple, mappedSection: propertySection(property) })) };
    if (named.some(property => [section, null].includes(propertySection(property)) && typeof own(own(property, 'flags'), 'is_multi_choice') !== 'boolean')) return failed('property_relation_unverified');
    if (sameMultiple.some(property => propertySection(property) === null)) return failed('property_relation_unverified');
    if (candidates.length !== 1) return failed('property_relation_ambiguous');
    const property = candidates[0], flags = own(property, 'flags'), propertyId = own(property, 'apiId'), values = own(property, 'values'), observed = own(property, 'observedValueCount');
    const issues = own(property, 'issues'); diagnosticProperty = propertyMetadata(property);
    failedChecks = [
      ['PROPERTY_NOT_VALID', own(property, 'valid') !== true], ['CASCADE_PRESENT', own(property, 'cascadePresent') !== undefined && own(property, 'cascadePresent') !== false],
      ['PROPERTY_TRUNCATED', own(property, 'truncated') !== undefined && own(property, 'truncated') !== false],
      ['CASCADE_VALUES_PRESENT', own(property, 'cascadeValues') !== undefined], ['SALE_CASCADE_PROPERTIES_PRESENT', own(property, 'saleCascadeProperties') !== undefined],
      ['ISSUES_UNVERIFIED', issues !== undefined && (!Array.isArray(issues) || issues.length > 0)], ['PROPERTY_ID_INVALID', !validId(propertyId)],
      ['PROPERTY_ID_NOT_UNIQUE', propertyIds.get(propertyId) !== 1], ['PROPERTY_ID_ALREADY_USED', usedProperties.has(propertyId)],
      ...['is_enum', 'is_input', 'is_necessary', 'is_multi_choice'].map(key => ['FLAG_NOT_BOOLEAN_' + key.toUpperCase(), typeof own(flags, key) !== 'boolean'])
    ].filter(([, rejected]) => rejected).map(([name]) => name);
    if (failedChecks.length) return failed('mapped_property_unverified');
    if (own(flags, 'is_necessary') !== required) return failed('required_mismatch');
    if (!Array.isArray(values) || values.length > limits.options || totalOptions + values.length > limits.totalOptions) return failed('mapped_options_incomplete');
    const ids = new Set();
    for (const option of values) {
      const id = own(option, 'apiId');
      if (!validId(id) || ids.has(id) || !validText(own(option, 'displayLabel'), 1024)) return failed('mapped_options_incomplete');
      ids.add(id);
    }
    const field = { ...slot, apiCategoryId: categoryId, apiPropertyId: propertyId, options: [], optionsComplete: true };
    if (own(flags, 'is_enum') === true) {
      if (!values.length || !Number.isSafeInteger(observed) || observed !== values.length
        || !(own(control, 'role') === 'combobox' || own(control, 'tag') === 'select')) return failed('mapped_options_incomplete');
      field.controlType = 'select'; field.valueKind = 'api-id'; field.options = values.map(option => ({ value: own(option, 'apiId'), label: own(option, 'displayLabel') }));
      field.optionsEvidence = { kind: 'observed-category-definition', categoryId, propertyId, observedCount: observed, declaredCount: values.length,
        observedOptionIds: values.map(option => own(option, 'apiId')), responseComplete: true, fieldAssociationVerified: true, scopeVerified: true, truncated: false };
    } else if (own(flags, 'is_input') === true && !values.length && (observed === undefined || observed === 0)) field.controlType = 'text';
    else return failed('mapped_property_kind_unverified');
    const definitionInputDraft = allowPartial && field.controlType === 'text' && observedInputLabels.includes(label)
      && ['div', 'span'].includes(own(control, 'tag')) && own(control, 'role') === 'combobox' && own(property, 'valuesState') === 'not-reported';
    if (definitionInputDraft) field.optionsComplete = false;
    const definitionInputDraftCandidate = definitionInputDraft ? createCategoryDefinitionInputDraftCandidate({ field, property, categoryId, control }) : null;
    const inputCandidate = allowPartial && !definitionInputDraft ? createObservedInputCandidate({ field, property, categoryId, control }) : null;
    if (allowPartial && field.controlType === 'text' && observedInputLabels.includes(label)
      && ['div', 'span'].includes(own(control, 'tag')) && own(control, 'role') === 'combobox' && !inputCandidate && !definitionInputDraftCandidate) return failed('mapped_property_kind_unverified');
    totalOptions += values.length; usedProperties.add(propertyId); return { field, ...(allowPartial ? { inputCandidate, definitionInputDraftCandidate } : {}) };
  };
  let firstFailure = null;
  for (const [fieldIndex, control] of actual.entries()) {
    const label = own(control, 'label'), section = own(control, 'section'), ordinalKey = section + '\0' + label;
    const ordinal = (ordinals.get(ordinalKey) || 0) + 1; ordinals.set(ordinalKey, ordinal);
    const slot = { key: keyFor(section, label, ordinal), label, section, ordinal, groupCount: counts.get(ordinalKey),
      multiple: own(control, 'multiple'), required: own(control, 'required') };
    const result = mapControl(control, slot);
    // Optional private diagnostics only. Never attach labels, API identifiers,
    // selectors, field values or arbitrary property strings to these rows.
    if (allowPartial && observedInputLabels.includes(label)) {
      if (manufacturerInputs.length >= 6) manufacturerInputsTruncated = true;
      else {
        const property = diagnosticProperty, relation = diagnosticRelation, flags = property?.flags || {}, types = property?.flagTypes || {};
        const coreOwner = ['div', 'span'].includes(own(control, 'tag')) && own(control, 'role') === 'combobox';
        const knownCount = property?.observedValueCount !== null && property?.observedValueCount !== undefined;
        const checks = [...failedChecks,
          ...((relation?.candidateCount ?? 0) !== 1 ? ['PROPERTY_RELATION_NOT_UNIQUE'] : []),
          ...(!knownCount ? [result.definitionInputDraftCandidate ? 'VALUES_NOT_REPORTED' : 'OBSERVED_VALUE_COUNT_UNKNOWN'] : property.observedValueCount !== 0 ? ['OBSERVED_VALUES_NOT_ZERO'] : []),
          ...(property?.valuesCount === null || property?.valuesCount === undefined ? ['VALUES_ARRAY_UNVERIFIED'] : property.valuesCount !== 0 ? ['VALUES_NOT_ZERO'] : []),
          ...(flags.is_enum !== false ? ['ENUM_NOT_FALSE'] : []), ...(flags.is_input !== true ? ['INPUT_NOT_TRUE'] : []),
          ...(typeof flags.is_necessary === 'boolean' && flags.is_necessary !== slot.required ? ['INPUT_REQUIRED_MISMATCH'] : []),
          ...(typeof flags.is_multi_choice === 'boolean' && flags.is_multi_choice !== slot.multiple ? ['INPUT_MULTIPLE_MISMATCH'] : []),
          ...(!coreOwner ? ['OWNER_NOT_CORE_COMPOSITE'] : []), ...(slot.ordinal !== 1 || slot.groupCount !== 1 ? ['INPUT_FIELD_NOT_UNIQUE'] : [])];
        manufacturerInputs.push({ fieldIndex, candidateCreated: Boolean(result.inputCandidate || result.definitionInputDraftCandidate), definitionDraftCandidateCreated: Boolean(result.definitionInputDraftCandidate),
          reason: result.inputCandidate ? 'input_candidate_ready' : result.definitionInputDraftCandidate ? 'definition_input_draft_ready' : result.field ? 'not_core_input_candidate' : result.reason,
          checks: [...new Set(checks)].slice(0, 32), coreOwner, observedCountKnown: knownCount, observedCountZero: knownCount && property.observedValueCount === 0,
          projectedValuesArray: Number.isSafeInteger(property?.valuesCount), values0: property?.valuesCount === 0,
          apiFlags: Object.fromEntries(['is_enum', 'is_input', 'is_necessary', 'is_multi_choice'].map(key => [key, bool(flags[key])])),
          apiFlagTypes: Object.fromEntries(['is_enum', 'is_input', 'is_necessary', 'is_multi_choice'].map(key => [key, ['boolean', 'undefined', 'string', 'number', 'object'].includes(types[key]) ? types[key] : 'unknown'])),
          namedCount: count(relation?.namedCount), sameMultipleCount: count(relation?.sameMultipleCount), candidateCount: count(relation?.candidateCount) });
      }
    }
    if (result.field) { fields.push(result.field); if (result.inputCandidate) inputCandidates.push(result.inputCandidate); if (result.definitionInputDraftCandidate) definitionInputDraftCandidates.push(result.definitionInputDraftCandidate); }
    else {
      if (!allowPartial) return result;
      firstFailure ||= result;
      fields.push({ ...slot, controlType: 'select', options: [], optionsComplete: false, unavailableReason: result.reason });
    }
  }
  const candidates = { ...(inputCandidates.length ? { inputCandidates } : {}), ...(definitionInputDraftCandidates.length ? { definitionInputDraftCandidates } : {}) };
  if (firstFailure) return withManufacturerDiagnostics({ ...firstFailure, partialFieldsVerified: true, fields, attributeGroups, ...candidates });
  if (allowPartial && (inputCandidates.length || definitionInputDraftCandidates.length)) return withManufacturerDiagnostics({ ...failed('mapped_property_kind_unverified'), partialFieldsVerified: true, fields, attributeGroups, ...candidates });
  if (!fields.some(field => field.controlType === 'select')) return allowPartial ? withManufacturerDiagnostics({ ...failed('no_enum_attributes'), partialFieldsVerified: true, fields, attributeGroups, ...candidates }) : failed('no_enum_attributes');
  return { accepted: true, ...(allowPartial ? { complete: true, partialFieldsVerified: true, ...(inputCandidates.length ? { inputCandidates } : {}) } : {}), fields, attributeGroups, reason: 'accepted' };
}
