import {readFile,writeFile,mkdir,rename,unlink,stat,lstat,open} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {join,resolve,sep} from 'node:path';
import {createHash,randomBytes,randomUUID} from 'node:crypto';
import {normalizeObservedInputEvidence,observedInputEvidenceMatches} from './dist/tiktok-input-evidence.js';
import {supplementalComplianceTargets,normalizeSupplementalComplianceField,supplementalComplianceFieldMatches} from './dist/tiktok-supplemental-compliance.js';
import {normalizedMainCategory,hasShopProfile,categoryScopeAllows,validCategoryBranch,categoryTreeView} from './tiktok-shop-category-cache.mjs';
import {createTikTokSchemaStore} from './tiktok-schema-store.mjs';
import {createTikTokBuiltinCatalog} from './tiktok-builtin-catalog.mjs';
import {validateApiCategoryLeaf} from './tiktok-build-api-schema.mjs';
import {API_SCHEMA_SOURCE} from './dist/tiktok-builtin-api-proof.js';
import {validateBuiltinAttributeValues} from './dist/tiktok-builtin-attribute-state.js';
import {attributeValueEntries,isCustomAttributeValue,attributeOptionValueAllowed,customAttributeConstraints} from './dist/tiktok-attribute-values.js';
import {categoryAccessView,hasAllCategoryAccess} from './dist/tiktok-category-access.js';
import {assertTikTokSalesSpecificationsCompatible,normalizedTikTokSalesSpecifications} from './dist/tiktok-sales-publishing-compatibility.js';

const PREFIX='/__pod/publishing',JSON_LIMIT=4*1024*1024;
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const text=value=>typeof value==='string'?value.trim():'';
const validId=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/u.test(value);
const sha=value=>createHash('sha256').update(value).digest('hex');
const fail=(code,message,status=400)=>Object.assign(new Error(message),{code,status});
const canonical=value=>Array.isArray(value)?'['+value.map(canonical).join(',')+']':plain(value)?'{'+Object.keys(value).sort().map(key=>JSON.stringify(key)+':'+canonical(value[key])).join(',')+'}':JSON.stringify(value);
const publicEnvironment=value=>({id:text(value?.id),no:text(value?.no),name:text(value?.name),group:text(value?.group),platform:text(value?.platform)});
const safeCodes=new Set(['PUBLISH_REUSE_UNAVAILABLE','PUBLISH_CATALOG_MISSING','PUBLISH_CATALOG_INCOMPLETE','PUBLISH_IDENTITY_UNOBSERVED','PUBLISH_CATEGORY_SCOPE','PUBLISH_STORE_UNVERIFIED','PUBLISH_BINDING_CHANGED','ADS_SETTINGS','ADS_UNAVAILABLE','ADS_RESPONSE','ADS_KEY_REQUIRED','ADS_RATE_LIMIT','ADS_REQUEST','ADS_ENVIRONMENT','ADS_CONNECTION','ADS_LIST_LIMIT','PUBLISH_INVALID','PUBLISH_CONFLICT','PUBLISH_NOT_FOUND','PUBLISH_UNAVAILABLE','PUBLISH_STORAGE','PUBLISH_ASSET','PUBLISH_SIZE','PUBLISH_IDENTITY','PUBLISH_CANCELLED','PUBLISH_REVIEW','PUBLISH_SCHEMA']);
const safeMessages={PUBLISH_IDENTITY_UNOBSERVED:'当前商品页的店铺信息尚未完整读取，已保留现有配对；请等待页面加载后重试。',PUBLISH_BINDING_CHANGED:'入队后店铺绑定已变化，请重新核验店铺并保存任务；未填写或发布。',PUBLISH_STORE_UNVERIFIED:'未读取到可验证的店铺编号、店铺名称及站点，请先打开对应环境检查登录状态。',PUBLISH_STORAGE:'上架任务保存失败，请检查主机用户目录权限。',PUBLISH_UNAVAILABLE:'自动上架服务尚未就绪，请检查主机连接。',PUBLISH_IDENTITY:'当前环境登录的店铺与绑定店铺不一致，本次已停止，未继续提交。',PUBLISH_REVIEW:'提交结果需要人工复核，请在对应店铺后台确认，勿重复发布。'};
const storeReasonMessages={product_guidance_blocked:'商品页被“上传图片即可生成草稿”引导层遮挡，请在对应 AdsPower 环境中关闭该引导后重试读取。',not_official_page:'当前环境未能打开 TikTok 官方商品页，请检查该环境网络与登录状态后重试。',page_not_ready:'商品页尚未就绪，请等待页面载入完成后重试读取。',browser_read_failed:'浏览器读取失败，请检查该 AdsPower 环境状态后重试。',security_verification_required:'当前商品页需要安全验证，请在对应 AdsPower 环境中人工完成验证后重试读取。',access_restricted:'当前商品页访问受限，请换用可进入添加商品页面的环境，或恢复访问权限后重试。'};
const identityReadMessages={
  login_required:'当前 AdsPower 环境需要重新登录 TikTok；已保留现有店铺配对，请登录后重试。',
  security_verification_required:'当前商品页需要安全验证；已保留现有配对，请在对应 AdsPower 环境完成人工验证后重试。',
  product_guidance_blocked:'商品页被“上传图片即可生成草稿”引导层遮挡；已保留现有配对，请在对应 AdsPower 环境关闭该引导后重试。',
  page_not_ready:'商品编辑页在等待期限内仍未就绪；已保留现有配对，请检查店铺网络和页面加载状态后重试。',
  identity_not_ready:'商品页的店铺名称或地区在等待期限内仍未完整显示；已保留现有配对，请等待页面加载完成后重试。',
  identity_missing:'当前商品页未完整显示可核验的店铺信息；已保留现有配对，请确认页面加载和登录状态后重试。',
  shop_menu_blocked:'店铺信息菜单仍遮挡商品页；已保留现有配对，请在对应 AdsPower 环境关闭菜单后重试。',
  not_official_page:'当前环境未能打开 TikTok 官方商品页；已保留现有配对，请检查该环境网络与登录状态后重试。',
  browser_read_failed:'读取 AdsPower 浏览器页面失败；已保留现有配对，请确认对应环境仍在运行并检查浏览器连接后重试。',
};
const publicError=error=>{
  if(!safeCodes.has(error?.code))return {code:'PUBLISH_UNAVAILABLE',message:safeMessages.PUBLISH_UNAVAILABLE};
  const unobserved=error.code==='PUBLISH_IDENTITY_UNOBSERVED',details=unobserved?inspectionDetails(error):null;
  const message=unobserved&&Object.hasOwn(identityReadMessages,details.reasonCode)?identityReadMessages[details.reasonCode]
    :error.code==='PUBLISH_STORE_UNVERIFIED'&&Object.hasOwn(storeReasonMessages,error.reasonCode)?storeReasonMessages[error.reasonCode]:safeMessages[error.code]||error.message;
  return {code:error.code,message,...(unobserved?details:{})};
};
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));};
const timestamp=now=>{const value=now();return value instanceof Date?value.toISOString():typeof value==='number'?new Date(value).toISOString():String(value);};
const finalStates=new Set(['succeeded','filled','draft_saved','failed','needs_review','cancelled']);
const productKeys=new Set(['schemaVersion','id','name','shop','style','placementId','sizes','skuTemplateSizes','salesSpecifications','salesSpecificationAxis','variants','assets','gallery','details','sizeChart','video','profile','updatedAt','createdAt','skuDate','sharedArtwork','artworkRevision','renderPending','familyKey','familyKeys','templateIds','selectionSchemaVersion','fillCategoryAttributes']);
const reuseUnavailable=()=>fail('PUBLISH_REUSE_UNAVAILABLE','该记录的完整商品资料或图片、视频原件已丢失或变化，无法完整复用；原记录仍保留，请重新导入缺失原件。',409);
const reusableProfileKeys=['category','brand','description','weight','length','width','height','price','stock','warehouse','skuPrefix','currency','gtinType','gtinCode','listPrice','auctionStartingPrice','originPrice','priceIncludeVat','specialProductListingType','sizeChartReference','sizes','properties','qualifications','warehouseStocks','inputLanguage','productHighlights','searchKeywords','scheduleEnabled','scheduledAt','categoryAttributes','stockMode'];
const reusableRowKeys=['price','stock','sku','gtinType','gtinCode','listPrice','auctionStartingPrice','originPrice','priceIncludeVat','warehouseStocks','stockMode'];
const reusableVariantKeys=['id','color','colorEnglish','colorHex','selected','familyKey','style','styleEnglish','specType','images','factoryProduct','factoryColor','price','stock','skuPrefix','gtinType','gtinCode','listPrice','auctionStartingPrice','originPrice','priceIncludeVat','warehouseStocks','stockMode','sizeOverrides','enabledSizes','skuOnly','templateId','imageSourceTemplateId','salesSpecificationValues','placementId','renderState','manual','artworkRevision','exportAssetId'];
const reusableAssetKeys=['id','name','type','assetId','role','origin','templateId','imageStage','sourceRevision','renderId'];
const pickBusinessFields=(value,keys)=>Object.fromEntries(keys.filter(key=>Object.hasOwn(value,key)).map(key=>[key,value[key]]));

async function body(req,limit){const chunks=[];let size=0,tooLarge=false;for await(const chunk of req){size+=chunk.length;if(size>limit){tooLarge=true;chunks.length=0;}else if(!tooLarge)chunks.push(chunk);}if(tooLarge)throw fail('PUBLISH_SIZE','上传内容超过允许大小。',413);return Buffer.concat(chunks);}
async function requestJSON(req){if(String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase()!=='application/json')throw fail('PUBLISH_INVALID','请使用 JSON 提交上架操作。');let value;try{value=JSON.parse((await body(req,JSON_LIMIT)).toString('utf8'));}catch(error){if(error.code==='PUBLISH_SIZE')throw error;throw fail('PUBLISH_INVALID','上架操作内容不是有效 JSON。');}if(!plain(value))throw fail('PUBLISH_INVALID','上架操作参数无效。');return value;}
function fields(input,allowed){if(Object.keys(input).some(key=>!allowed.includes(key)))throw fail('PUBLISH_INVALID','上架操作含有不支持的参数。');}
function identity(value){if(!plain(value)||!validId(value.shopId)||!text(value.shopName)||text(value.shopName).length>160||!/^[A-Z]{2,6}$/u.test(value.region)||value.idKind!==undefined&&value.idKind!==''&&!['shop_id','shop_code','profile-environment'].includes(value.idKind))throw fail('PUBLISH_STORE_UNVERIFIED','未读取到可验证的店铺环境、店铺名称及站点，请先打开对应环境检查登录状态。',409);return {shopId:value.shopId,shopName:text(value.shopName),region:value.region,...(value.idKind?{idKind:value.idKind}:{}),...(value.region==='US'&&value.regionSource==='seller-url-market'?{regionSource:value.regionSource}:{})};}
const inspectReasons=new Set(['login_required','page_not_ready','product_guidance_blocked','security_verification_required','access_restricted','identity_missing','identity_not_ready','shop_menu_blocked','browser_read_failed','not_official_page','category_read_incomplete','category_unavailable','identity_mismatch','IDENTITY_INCOMPLETE']);
function inspectionDetails(result){
  const reasonCode=inspectReasons.has(result?.reasonCode)?result.reasonCode:'IDENTITY_INCOMPLETE',observed=plain(result?.diagnostics)?result.diagnostics:{},diagnostics={};
  for(const key of ['shopIdFound','shopNameFound','regionFound'])if(typeof observed[key]==='boolean')diagnostics[key]=observed[key];
  if(Number.isSafeInteger(observed.categoryControlCount)&&observed.categoryControlCount>=0)diagnostics.categoryControlCount=observed.categoryControlCount;
  if(typeof observed.pageTitle==='string')diagnostics.pageTitle=observed.pageTitle.replace(/(?:https?|wss?):\/\/\S+/giu,'[url]').replace(/(?:token|secret|password|api[_ -]?key|cookie|authorization)\s*[:=]\s*\S+/giu,'[redacted]').replace(/[\u0000-\u001f\u007f]/gu,' ').slice(0,160);
  if(typeof observed.hostname==='string'&&/^[a-z0-9.-]{1,253}$/iu.test(observed.hostname))diagnostics.hostname=observed.hostname;
  return {reasonCode,diagnostics};
}
function pairedIdentityEvidence(result,environment,binding){
  const proof=result?.pairedIdentityEvidence,actual=result?.identity;
  if(!binding||binding.verificationStatus!=='verified'||!hasShopProfile(binding)||environment?.id!==binding.environmentId||!plain(proof)||proof.version!==1||proof.source!=='visible-product-page-paired-profile'||proof.environmentId!==binding.environmentId||proof.shopMenuClosed!==true||typeof proof.shopCodeObserved!=='boolean'||!plain(actual)||proof.shopName!==text(actual.shopName)||proof.region!==actual.region||proof.shopName!==binding.identity.shopName||proof.region!==binding.identity.region||proof.shopCodeObserved!==Boolean(text(actual.shopId)))return null;
  return {version:1,source:proof.source,environmentId:proof.environmentId,shopName:proof.shopName,region:proof.region,shopCodeObserved:proof.shopCodeObserved,shopMenuClosed:true};
}
function inspectedIdentity(result,{environment,previous,pairedPage=false,verificationRead=false}={}){try{
  const failedVerification=verificationRead&&pairedPage&&result?.status==='needs_review';
  if(failedVerification&&result.reasonCode==='identity_mismatch')throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
  let value=result?.identity;
  if(pairedPage&&previous?.verificationStatus==='verified'&&hasShopProfile(previous)&&environment?.id===previous.environmentId){
    if(plain(value)&&(text(value.shopName)&&text(value.shopName)!==previous.identity.shopName||text(value.region)&&value.region!==previous.identity.region||previous.identity.idKind!=='profile-environment'&&text(value.shopId)&&value.shopId!==previous.identity.shopId))throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
    if(failedVerification)throw fail('PUBLISH_IDENTITY_UNOBSERVED',safeMessages.PUBLISH_IDENTITY_UNOBSERVED,409);
    if(!plain(value)||!validId(value.shopId)||!text(value.shopName)||!/^[A-Z]{2,6}$/u.test(value.region)){
      if(plain(value)&&!text(value.shopId)&&pairedIdentityEvidence(result,environment,previous))return structuredClone(previous.identity);
      throw fail('PUBLISH_IDENTITY_UNOBSERVED',safeMessages.PUBLISH_IDENTITY_UNOBSERVED,409);
    }
  }
  if(failedVerification)throw fail('PUBLISH_IDENTITY_UNOBSERVED',safeMessages.PUBLISH_IDENTITY_UNOBSERVED,409);
  if(!pairedPage&&environment&&normalizedMainCategory(result?.mainCategory)&&plain(value)&&text(value.shopName)&&/^[A-Z]{2,6}$/u.test(value.region)&&!validId(value.shopId)){value=previous&&previous.environmentId===environment.id&&previous.identity.shopName===text(value.shopName)&&previous.identity.region===value.region?previous.identity:{...value,shopId:'env-'+environment.id,idKind:'profile-environment'};}
  return identity(value);
}catch(error){Object.assign(error,inspectionDetails(result));throw error;}}
const sameIdentity=(first,second)=>first.region===second.region&&(first.idKind==='profile-environment'||second.idKind==='profile-environment'?first.shopName===second.shopName&&(first.idKind!==second.idKind||first.shopId===second.shopId):first.shopId===second.shopId&&(!first.idKind||!second.idKind||first.idKind===second.idKind));
function capabilitySummary(input){return plain(input)?Object.fromEntries(Object.entries(input).filter(([key,value])=>/^[A-Za-z][A-Za-z0-9_]{0,60}$/u.test(key)&&typeof value==='boolean')):{};}
function categoryPath(value){if(typeof value==='string'&&value.trim()&&value.length<=1024&&!/[\u0000-\u001f\u007f]/u.test(value))return value.trim();if(Array.isArray(value)&&value.length&&value.length<=10&&value.every(item=>typeof item==='string'&&item.trim()&&item.length<=160&&!/[\u0000-\u001f\u007f]/u.test(item)))return value.map(item=>item.trim()).join(' > ');throw fail('PUBLISH_INVALID','请选择实际的完整商品类目。');}
const domProofTrue=['ownerRevalidated','associationVerified','paneIdentityVerifiable','emptyQueryVerified','finiteGeometry','flowVerified','completeMounted','atTop','atBottom','positionsComplete'];
const domProofFalse=['virtualMarker','ariaHidden','busy','countConflict','truncated'];
const domProofZero=['disabledRowCount','moreControlCount','unknownChildCount','unknownOptionControlCount','missingLabelCount','duplicateLabelCount','coverageGapCount','coverageOverlapCount'];
const domProofOne=['ownerCount','popupCount','innerListboxCount','scrollPaneCount'];
const domProofCounts=['rowCount','normalisedOptionCount','selectableOptionCount'];
const domProofSamples=['stableSamples','topStableSamples','bottomStableSamples'];
const domDescriptorKeys=['label','section','ordinal','groupCount','multiple','required','controlType'];
function domBasicCredential(value){
  const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  for(const match of value.matchAll(/\bBasic\s+([^\s,;]+)/giu)){
    const encoded=match[1];if(!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded))continue;
    const bare=encoded.replace(/=+$/u,''),remainder=bare.length%4,padding=encoded.length-bare.length;
    if(remainder===1||padding&&(encoded.length%4!==0||padding!==(4-remainder)%4))continue;
    let buffer=0,bits=0,colon=false;
    for(const character of bare){buffer=buffer*64+alphabet.indexOf(character);bits+=6;if(bits>=8){bits-=8;if(Math.floor(buffer/2**bits)===58)colon=true;buffer%=2**bits;}}
    if(buffer===0&&colon)return true;
  }
  return false;
}
const domLabel=value=>typeof value==='string'&&value===value.replace(/\s+/gu,' ').trim()&&value.length>0&&value.length<=1024
  &&!/[\u0000-\u001f\u007f]|(?:https?|wss?):\/\/|\bBearer\s+\S+|\b(?:password|passwd|cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret)\s*[:=]|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_|\b(?:sk|rk)[-_][A-Za-z0-9]{12,}|eyJ[A-Za-z0-9_-]{12,}\./iu.test(value)&&!domBasicCredential(value);
function domEvidenceMatchesOptions(field,categoryId){
  const proof=field.optionsEvidence,options=field.options;
  if(!plain(proof)||proof.kind!=='observed-seller-option-list'||proof.version!==1||proof.coverageKind!=='complete-mounted-list'||field.valueKind!=='dom-label'||field.controlType!=='select'
    ||field.apiCategoryId!==undefined||field.apiPropertyId!==undefined||!validId(categoryId)||proof.categoryId!==categoryId||proof.fieldKey!==field.key
    ||!plain(proof.descriptor)||domDescriptorKeys.some(key=>proof.descriptor[key]!==field[key])||!Array.isArray(options)||!options.length||options.length>10000
    ||!Array.isArray(proof.orderedLabels)||proof.orderedLabels.length!==options.length||domProofSamples.some(key=>!Number.isSafeInteger(proof[key])||proof[key]<4||proof[key]>100)||proof.stableSamples!==Math.min(proof.topStableSamples,proof.bottomStableSamples)
    ||domProofTrue.some(key=>proof[key]!==true)||domProofFalse.some(key=>proof[key]!==false)||domProofZero.some(key=>proof[key]!==0)||domProofOne.some(key=>proof[key]!==1)
    ||domProofCounts.some(key=>proof[key]!==options.length)||!Object.hasOwn(proof,'declaredTotal')||proof.declaredTotal!==null&&proof.declaredTotal!==options.length)return false;
  const labels=options.map(option=>option?.label);
  return new Set(labels).size===labels.length&&options.every((option,index)=>plain(option)&&domLabel(option.label)&&option.value===option.label&&proof.orderedLabels[index]===option.label);
}
function optionsEvidence(value){
  if(!plain(value)||!['native-select','virtual-list','visible-list','observed-category-definition','observed-seller-option-list'].includes(value.kind))throw fail('PUBLISH_INVALID','下拉选项完整性证据无效，请重新读取。');
  const output={kind:value.kind};
  if(value.kind==='observed-seller-option-list'){
    const invalid=()=>fail('PUBLISH_INVALID','DOM 属性选项的独立完整性证据格式无效，请重新读取。');
    if(value.version!==undefined){if(value.version!==1)throw invalid();output.version=1;}
    if(value.coverageKind!==undefined){if(value.coverageKind!=='complete-mounted-list')throw invalid();output.coverageKind=value.coverageKind;}
    if(value.categoryId!==undefined){if(!validId(value.categoryId))throw invalid();output.categoryId=value.categoryId;}
    if(value.fieldKey!==undefined){if(typeof value.fieldKey!=='string'||!/^dom-[a-f0-9]{24}$/u.test(value.fieldKey))throw invalid();output.fieldKey=value.fieldKey;}
    if(value.descriptor!==undefined){
      if(!plain(value.descriptor))throw invalid();const descriptor={};
      for(const key of domDescriptorKeys)if(value.descriptor[key]!==undefined){const item=value.descriptor[key];if(['multiple','required'].includes(key)?typeof item!=='boolean':['ordinal','groupCount'].includes(key)?!Number.isSafeInteger(item)||item<1||item>1000:key==='controlType'?item!=='select':typeof item!=='string'||!item.trim()||item.length>(key==='label'?255:160)||/[\u0000-\u001f\u007f]/u.test(item))throw invalid();descriptor[key]=item;}
      output.descriptor=descriptor;
    }
    if(value.orderedLabels!==undefined){if(!Array.isArray(value.orderedLabels)||value.orderedLabels.length>10000||value.orderedLabels.some(label=>!domLabel(label)))throw invalid();output.orderedLabels=[...value.orderedLabels];}
    for(const key of [...domProofTrue,...domProofFalse])if(value[key]!==undefined){if(typeof value[key]!=='boolean')throw invalid();output[key]=value[key];}
    for(const key of [...domProofZero,...domProofOne,...domProofCounts,...domProofSamples])if(value[key]!==undefined){if(!Number.isSafeInteger(value[key])||value[key]<0||value[key]>(domProofSamples.includes(key)?100:10000))throw invalid();output[key]=value[key];}
    if(value.declaredTotal!==undefined){if(value.declaredTotal!==null&&(!Number.isSafeInteger(value.declaredTotal)||value.declaredTotal<0||value.declaredTotal>10000))throw invalid();output.declaredTotal=value.declaredTotal;}
    return output;
  }
  if(value.kind==='observed-category-definition'){
    for(const key of ['categoryId','propertyId'])if(value[key]!==undefined){if(!validId(value[key]))throw fail('PUBLISH_INVALID','API 属性证据编号格式无效，请重新读取。');output[key]=value[key];}
    for(const key of ['observedCount','declaredCount'])if(value[key]!==undefined){if(!Number.isSafeInteger(value[key])||value[key]<0||value[key]>10000)throw fail('PUBLISH_INVALID','API 属性原始选项计数无效，请重新读取。');output[key]=value[key];}
    for(const key of ['responseComplete','fieldAssociationVerified','scopeVerified','truncated'])if(value[key]!==undefined){if(typeof value[key]!=='boolean')throw fail('PUBLISH_INVALID','API 属性关联与完整性标记无效，请重新读取。');output[key]=value[key];}
    if(value.observedOptionIds!==undefined){if(!Array.isArray(value.observedOptionIds)||value.observedOptionIds.length>10000||value.observedOptionIds.some(id=>!validId(id)))throw fail('PUBLISH_INVALID','API 属性原始选项编号列表无效，请重新读取。');output.observedOptionIds=[...value.observedOptionIds];}
    return output;
  }
  for(const key of ['stableSamples','optionCount','observedOptionCount','selectableOptionCount','declaredTotalCount'])if(value[key]!==undefined){if(key==='declaredTotalCount'&&value[key]===null)continue;if(!Number.isSafeInteger(value[key])||value[key]<(key==='stableSamples'?1:0))throw fail('PUBLISH_INVALID','下拉选项完整性计数无效，请重新读取。');output[key]=value[key];}
  for(const key of ['visitedTop','visitedBottom'])if(value[key]!==undefined){if(typeof value[key]!=='boolean')throw fail('PUBLISH_INVALID','下拉选项边界证据无效，请重新读取。');output[key]=value[key];}
  return output;
}
function inputEvidenceData(value){try{return normalizeObservedInputEvidence(value);}catch{throw fail('PUBLISH_INVALID','本地草稿输入证据格式无效，请重新读取实际控件。');}}
function schemaIssues(value){
  if(!Array.isArray(value))return [];
  return value.filter(item=>typeof item==='string').slice(0,20).map(item=>{
    if(/\b(?:raw[_ -]?stack|stack[_ -]?trace)\b|(?:^|[\r\n])\s*at\s|\b(?:Error|TypeError|ReferenceError|RangeError|SyntaxError)\s*:|<(?:input|textarea|select)\b|\b(?:Bearer|Basic)\s+\S+/iu.test(item)
      ||/\b(?:password|passwd|cookie|set-cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret|input[_ -]?value|field[_ -]?value|value|values)\b["']?\s*[:=]|(?:输入(?:框)?|填写|字段|控件)(?:内容|值|原文)\s*[:：=]/iu.test(item))return '商家页面读取失败，敏感详情已隐藏，请查看本机诊断。';
    return item.replace(/(?:[a-z][a-z0-9+.-]*:\/\/|www\.)[^\s<>"']+/giu,'[url]').replace(/data:[^\s<>"']+/giu,'[data]').replace(/[\u0000-\u001f\u007f]/gu,' ').replace(/\s+/gu,' ').trim().slice(0,300);
  }).filter(Boolean);
}
// Persist a bounded description of the operation, never page values, refs or traces.
const draftPhases=new Set(['connecting','verifying-shop','preparing','reading_category','filling_product','filling_skus','uploading_images','checking_product','saving_draft','draft_saved','filled','submitting']);
const draftFields=new Set(['商品类目','商品名称','商品描述','搜索关键词','商品亮点','类目属性','销售规格','商品图片','主图','详情图','尺码表','视频','价格与库存','商品核对','保存草稿','发布商品']);
const draftOperations=new Set(['click','fill','select','check','upload','read','verify','save_draft','publish']);
const draftDiagnosticCodes=new Set(['SELLER_CONTROL_STALE','SELLER_CONTROL_AMBIGUOUS','SELLER_CONTROL_OBSCURED','SELLER_ACTION_UNCONFIRMED','SELLER_OPERATION_FAILED','SELLER_CANCELLED']);
function draftDiagnostics(value){
  if(!plain(value))return null;
  const output={version:1};
  if(draftPhases.has(value.phase))output.phase=value.phase;
  if(draftFields.has(value.field))output.field=value.field;
  if(draftOperations.has(value.operation))output.operation=value.operation;
  if(draftDiagnosticCodes.has(value.code))output.code=value.code;
  if(Number.isSafeInteger(value.recoveryAttempts)&&value.recoveryAttempts>=0&&value.recoveryAttempts<=2)output.recoveryAttempts=value.recoveryAttempts;
  if(['not_dispatched','dispatched','unknown'].includes(value.dispatchState))output.dispatchState=value.dispatchState;
  if(typeof value.draftSaveAttempted==='boolean')output.draftSaveAttempted=value.draftSaveAttempted;
  return Object.keys(output).length>1?output:null;
}
function attributeKind(value){if(typeof value!=='string')return '';const match=value.replace(/\s+/gu,' ').replace(/^\*\s*/u,'').trim().match(/^(关键属性|可选属性|Key attributes|Optional attributes)(?:\s*[（(]\s*\d+\s*[）)])?$/iu);return match?/^(?:关键属性|Key attributes)$/iu.test(match[1])?'关键属性':'可选属性':'';}
const attributeSection=value=>Boolean(attributeKind(value));
const groupKinds={'attribute-key':'关键属性','attribute-optional':'可选属性'},groupBooleans=['expanded','scanComplete','truncated','fieldRowsVerified'],groupCounts=['candidateControlCount','labelledControlCount','normalisedControlCount','missingLabelCount','unknownControlCount','unresolvedCount','capturedControlCount'];
function validAttributeGroup(group){return plain(group)&&typeof group.groupId==='string'&&typeof group.kind==='string'&&Object.hasOwn(groupKinds,group.groupId)&&groupKinds[group.groupId]===group.kind&&groupBooleans.every(key=>typeof group[key]==='boolean')&&(group.candidateFieldCount===null||Number.isSafeInteger(group.candidateFieldCount)&&group.candidateFieldCount>=0)&&groupCounts.every(key=>Number.isSafeInteger(group[key])&&group[key]>=0);}
function attributeGroupsData(value){
  if(!Array.isArray(value)||value.length>10||value.some(group=>!validAttributeGroup(group)))throw fail('PUBLISH_INVALID','属性分组扫描记录格式无效，请重新读取。');
  return value.map(group=>({groupId:group.groupId,kind:group.kind,...Object.fromEntries(groupBooleans.map(key=>[key,group[key]])),candidateFieldCount:group.candidateFieldCount,...Object.fromEntries(groupCounts.map(key=>[key,group[key]]))}));
}
function attributeGroupIssues(fields,groups){
  if(groups===undefined)return [];
  if(!Array.isArray(groups)||!groups.length||groups.length>10||groups.some(group=>!validAttributeGroup(group)))return ['尚未读取到有效的实际属性分组扫描记录，请重新读取。'];
  const issues=[],kinds=new Set(groups.map(group=>group.kind));
  if(new Set(groups.map(group=>group.groupId)).size!==groups.length||kinds.size!==groups.length)issues.push('实际属性分组编号或类型重复，无法确认各组字段覆盖。');
  if(fields.some(field=>!kinds.has(attributeKind(field?.section))))issues.push('属性分组扫描记录尚未覆盖全部已读取字段，请重新读取。');
  if(groups.some(group=>!group.expanded||!group.scanComplete||!group.fieldRowsVerified||group.truncated))issues.push('属性分组尚未确认展开、完整扫描或字段行结构，请重新读取。');
  if(groups.some(group=>group.candidateFieldCount===null))issues.push('属性分组字段候选数量尚未知，不能确认读取完整。');
  if(groups.some(group=>group.missingLabelCount||group.unknownControlCount||group.unresolvedCount))issues.push('属性分组仍有缺少标签、未知或尚未解决的字段候选，请重新读取。');
  if(groups.some(group=>{const count=fields.filter(field=>attributeKind(field?.section)===group.kind).length;return group.candidateFieldCount!==null&&group.candidateFieldCount!==count||['candidateControlCount','labelledControlCount','normalisedControlCount','capturedControlCount'].some(key=>group[key]!==count);}))issues.push('属性分组候选、归一、标签、采集数量与实际字段数量不一致，请重新读取。');
  return issues;
}
function evidenceMatchesOptions(field){
  const proof=field.optionsEvidence;
  if(proof?.kind==='observed-category-definition'){
    const count=field.options.length,ids=field.options.map(option=>option?.value);
    return plain(proof)&&field.valueKind==='api-id'&&validId(field.apiCategoryId)&&validId(field.apiPropertyId)&&proof.categoryId===field.apiCategoryId&&proof.propertyId===field.apiPropertyId&&count>0&&count<=10000&&Number.isSafeInteger(proof.observedCount)&&proof.observedCount===count&&Number.isSafeInteger(proof.declaredCount)&&proof.declaredCount===count&&proof.responseComplete===true&&proof.fieldAssociationVerified===true&&proof.scopeVerified===true&&proof.truncated===false&&Array.isArray(proof.observedOptionIds)&&proof.observedOptionIds.length===count&&ids.every(validId)&&new Set(ids).size===count&&proof.observedOptionIds.every((id,index)=>validId(id)&&id===ids[index])&&new Set(proof.observedOptionIds).size===count;
  }
  if(field.valueKind==='api-id')return false;
  if(proof===undefined)return true;
  if(!plain(proof)||!['native-select','visible-list','virtual-list'].includes(proof.kind)||!Number.isSafeInteger(proof.stableSamples)||proof.stableSamples<4)return false;
  for(const key of ['optionCount','observedOptionCount','selectableOptionCount','declaredTotalCount'])if(proof[key]!==undefined&&!(key==='declaredTotalCount'&&proof[key]===null)&&(!Number.isSafeInteger(proof[key])||proof[key]<0))return false;
  const count=field.options.length;
  if(proof.optionCount!==undefined&&proof.optionCount!==count||proof.selectableOptionCount!==undefined&&proof.selectableOptionCount!==count||proof.observedOptionCount!==undefined&&proof.observedOptionCount<count)return false;
  if(proof.visitedTop!==undefined&&proof.visitedTop!==true||proof.visitedBottom!==undefined&&proof.visitedBottom!==true)return false;
  if(proof.kind==='native-select')return proof.optionCount===count&&(proof.declaredTotalCount===undefined||proof.declaredTotalCount===null||proof.declaredTotalCount===(proof.observedOptionCount??count));
  return proof.visitedTop===true&&proof.visitedBottom===true&&proof.selectableOptionCount===count&&Number.isSafeInteger(proof.observedOptionCount)&&proof.observedOptionCount>=count&&(proof.declaredTotalCount===undefined||proof.declaredTotalCount===null||proof.declaredTotalCount===proof.observedOptionCount);
}
const fieldUnavailableReasons=new Set(['property_relation_unverified','property_relation_ambiguous','mapped_property_unverified','required_mismatch','mapped_options_incomplete','mapped_property_kind_unverified','field_proof_unverified']);
const fieldEvidenceFlags=['scopeVerified','responseComplete','definitionRowsComplete','identityVerified','categoryPathVerified','fieldUniverseComplete'];
function attributeReadEvidenceData(value){
  if(!plain(value)||value.version!==1||value.kind!=='observed-category-definition-fields'||!validId(value.categoryId)
    ||!Number.isSafeInteger(value.stableSamples)||value.stableSamples<0||value.stableSamples>100||fieldEvidenceFlags.some(key=>typeof value[key]!=='boolean'))throw fail('PUBLISH_INVALID','属性字段读取范围证据无效，请重新读取。');
  return {version:1,kind:value.kind,categoryId:value.categoryId,stableSamples:value.stableSamples,...Object.fromEntries(fieldEvidenceFlags.map(key=>[key,value[key]]))};
}
function fieldScopeVerified(schema,binding,now){
  const evidence=schema.attributeReadEvidence,scope=schema.fieldEditingScope,readAt=Date.parse(schema.readAt||'');
  if(!binding||(binding.verificationStatus!==undefined&&binding.verificationStatus!=='verified')||schema.source!=='live-shop'||!Number.isFinite(now)||!Number.isFinite(readAt)||readAt>now
    ||schema.bindingId!==binding.id||schema.shopId!==binding.identity.shopId||schema.region!==binding.identity.region||!text(schema.categoryPath)
    ||Object.hasOwn(schema,'lastReadFailure')||![undefined,'category_read_incomplete'].includes(schema.reasonCode)||!['ready','needs_review'].includes(schema.status)||typeof schema.complete!=='boolean')return false;
  if(!plain(scope)||scope.version!==1||scope.source!=='visible-seller-dom-and-category-api'||scope.bindingId!==binding.id||scope.shopId!==schema.shopId||scope.region!==schema.region
    ||scope.categoryPath!==schema.categoryPath||scope.readAt!==schema.readAt||!validId(scope.categoryId)||binding.identity.idKind&&scope.idKind!==binding.identity.idKind)return false;
  return capturedCensusVerified(schema,scope.categoryId);
}
function capturedCensusVerified(schema,categoryId){
  const evidence=schema.attributeReadEvidence;
  if(!plain(evidence)||evidence.version!==1||evidence.kind!=='observed-category-definition-fields'||evidence.categoryId!==categoryId
    ||!Number.isSafeInteger(evidence.stableSamples)||evidence.stableSamples<3||evidence.stableSamples>100||fieldEvidenceFlags.some(key=>evidence[key]!==true))return false;
  const fields=schema.fields,groups=schema.attributeGroups;
  if(!Array.isArray(fields)||!fields.length||fields.length>1000||!Array.isArray(groups)||groups.length!==2||attributeGroupIssues(fields,groups).length
    ||!['关键属性','可选属性'].every(kind=>groups.some(group=>group.kind===kind)))return false;
  const keys=new Set(),signatures=new Set(),properties=new Set(),counts=new Map(),ordinals=new Map();
  for(const field of fields){
    if(!plain(field)||!['关键属性','可选属性'].includes(field.section)||!text(field.label)||field.label.length>255||/[\u0000-\u001f\u007f]/u.test(field.label)
      ||typeof field.key!=='string'||field.key!=='dom-'+sha([field.section,field.label,field.ordinal].join('\0')).slice(0,24)||keys.has(field.key)||typeof field.required!=='boolean'||typeof field.multiple!=='boolean'
      ||!Number.isSafeInteger(field.ordinal)||field.ordinal<1||!Number.isSafeInteger(field.groupCount)||field.groupCount<field.ordinal
      ||!['select','text'].includes(field.controlType)||!Array.isArray(field.options)||field.options.length>10000||typeof field.optionsComplete!=='boolean')return false;
    keys.add(field.key);const signature=JSON.stringify([field.section,field.label,field.multiple]);if(signatures.has(signature))return false;signatures.add(signature);
    const group=JSON.stringify([field.section,field.label]);counts.set(group,(counts.get(group)||0)+1);if(!ordinals.has(group))ordinals.set(group,new Set());if(ordinals.get(group).has(field.ordinal))return false;ordinals.get(group).add(field.ordinal);
    if(field.apiCategoryId!==undefined&&field.apiCategoryId!==categoryId||field.apiPropertyId!==undefined&&(!validId(field.apiPropertyId)||properties.has(field.apiPropertyId)))return false;
    if(field.apiPropertyId!==undefined)properties.add(field.apiPropertyId);
    if(field.unavailableReason!==undefined&&(!fieldUnavailableReasons.has(field.unavailableReason)||field.controlType!=='select'||field.options.length||field.optionsComplete!==false
      ||['apiCategoryId','apiPropertyId','valueKind','optionsEvidence','inputEvidence'].some(key=>field[key]!==undefined)))return false;
  }
  return fields.every(field=>field.groupCount===counts.get(JSON.stringify([field.section,field.label])));
}
function independentlyEditableField(field,categoryId){
  if(Object.hasOwn(field,'inputEvidence'))return observedInputEvidenceMatches(field,categoryId);
  if(field.valueKind==='dom-label'||field.optionsEvidence?.kind==='observed-seller-option-list')return field.unavailableReason===undefined&&field.optionsComplete===true&&domEvidenceMatchesOptions(field,categoryId);
  return field.controlType==='select'&&field.unavailableReason===undefined&&field.valueKind==='api-id'&&field.apiCategoryId===categoryId&&field.optionsComplete===true
    &&Array.isArray(field.options)&&field.options.length>0&&field.options.every(option=>plain(option)&&text(option.label)&&option.label.length<=1024)
    &&field.optionsEvidence?.kind==='observed-category-definition'&&evidenceMatchesOptions(field);
}
function supplementalComplianceData(value){
  if(!Array.isArray(value)||value.length>2)throw fail('PUBLISH_INVALID','商品合规补充字段格式无效，请重新读取。');
  let fields;try{fields=value.map(normalizeSupplementalComplianceField);}catch{throw fail('PUBLISH_INVALID','商品合规补充字段证明格式无效，请重新读取。');}
  if(new Set(fields.map(field=>field.key)).size!==fields.length)throw fail('PUBLISH_INVALID','商品合规补充字段重复，请重新读取。');
  return fields;
}
function supplementalComplianceView(schema,verified){
  if(schema.supplementalComplianceFields===undefined)return {};
  const fields=Array.isArray(schema.supplementalComplianceFields)?schema.supplementalComplianceFields:[],properties=new Set((schema.fields||[]).filter(field=>field.apiPropertyId!==undefined).map(field=>field.apiPropertyId));
  const collectionVerified=Array.isArray(schema.supplementalComplianceFields)&&fields.length<=2&&new Set(fields.map(field=>field?.key)).size===fields.length
    &&fields.every(field=>supplementalComplianceTargets.some(target=>field?.key===target.key&&field?.label===target.label));
  const duplicate=fields.some((field,index)=>field.apiPropertyId!==undefined&&(properties.has(field.apiPropertyId)||fields.some((other,otherIndex)=>otherIndex!==index&&other.apiPropertyId===field.apiPropertyId)));
  return {supplementalComplianceFields:fields.slice(0,2).flatMap(observed=>{
    let field;try{field=normalizeSupplementalComplianceField(observed);}catch{const target=supplementalComplianceTargets.find(item=>item.key===observed?.key&&item.label===observed?.label);if(!target)return [];field={...target};}
    const editable=verified&&collectionVerified&&!duplicate&&supplementalComplianceFieldMatches(field,schema.attributeReadEvidence?.categoryId);
    if(editable)return [{...field,editable:true}];
    const {apiCategoryId,apiPropertyId,valueKind,optionsEvidence,complianceEvidence,...slot}=field;
    return [{...slot,options:[],optionsComplete:false,unavailableReason:'compliance_proof_unverified',editable:false}];
  })};
}
function fieldEditingView(schema,binding,now){
  if(schema.attributeReadEvidence===undefined&&schema.fieldEditingScope===undefined&&schema.supplementalComplianceFields===undefined&&!schema.fields?.some(field=>plain(field)&&Object.hasOwn(field,'editable')))return schema;
  const verified=fieldScopeVerified(schema,binding,now);
  return {...schema,...supplementalComplianceView(schema,verified),...(!verified?{complete:false,status:'needs_review',issues:schemaIssues([...(Array.isArray(schema.issues)?schema.issues:[]),'属性字段的整体范围或完整扫描证据尚未核验，请重新读取。'])}:{}),fields:(schema.fields||[]).map(observedField=>{
    let field=observedField;
    if(field.optionsEvidence?.kind==='observed-seller-option-list')try{field={...field,optionsEvidence:optionsEvidence(field.optionsEvidence)};}catch{const {optionsEvidence:discarded,...slot}=field;field=slot;}
    if(Object.hasOwn(field,'inputEvidence'))try{field={...field,inputEvidence:inputEvidenceData(field.inputEvidence)};}catch{const {inputEvidence:discarded,...slot}=field;field=slot;}
    const editable=verified&&independentlyEditableField(field,schema.attributeReadEvidence.categoryId);
    if(verified&&!editable&&field.controlType==='select'&&field.unavailableReason===undefined){
      const {apiCategoryId,apiPropertyId,valueKind,optionsEvidence,inputEvidence,...slot}=field;
      return {...slot,options:[],optionsComplete:false,unavailableReason:'field_proof_unverified',editable:false};
    }
    return {...field,editable};
  })};
}
function schemaCompletenessIssues(fields,groups){
  if(!Array.isArray(fields)||!fields.length)return ['尚未读取到真实关键属性或可选属性，请重新读取类目。'];
  const issues=[],selects=fields.filter(field=>plain(field)&&field.controlType==='select');
  if(fields.some(field=>plain(field)&&(field.valueKind==='dom-label'||field.optionsEvidence?.kind==='observed-seller-option-list')))issues.push('DOM 选项已独立核验，仅供本地选择；发布值映射尚未核验。');
  if(fields.some(field=>plain(field)&&Object.hasOwn(field,'inputEvidence')))issues.push('文本输入仅供本地草稿，尚未核验商家后台确认与保存方式，不能发布。');
  if(fields.some(field=>plain(field)&&field.unavailableReason!==undefined))issues.push('部分实际属性字段尚未核验，不能发布当前类目。');
  if(fields.some(field=>plain(field)&&(['apiCategoryId','apiPropertyId'].some(key=>field[key]!==undefined&&!validId(field[key]))||field.valueKind!==undefined&&(!['api-id','dom-label'].includes(field.valueKind)||field.controlType!=='select')||['observed-category-definition','observed-seller-option-list'].includes(field.optionsEvidence?.kind)&&field.controlType!=='select')))issues.push('属性字段编号或值类型无效，请重新读取实际字段关联。');
  const categories=fields.filter(field=>plain(field)&&field.apiCategoryId!==undefined).map(field=>field.apiCategoryId),apiFields=selects.filter(field=>field.valueKind==='api-id'||field.optionsEvidence?.kind==='observed-category-definition'),properties=apiFields.map(field=>field.apiPropertyId);
  if(new Set(categories).size>1)issues.push('API 属性来自不同类目，不能作为当前类目的完整选项。');
  if(new Set(properties).size!==properties.length)issues.push('API 属性编号重复关联多个字段，请重新核验实际字段。');
  if(fields.some(field=>!plain(field)||!attributeSection(field.section)))issues.push('读取结果包含普通字段或非关键/可选属性分组，不能标记为完整类目属性。');
  if(!selects.length)issues.push('尚未读取到真实属性下拉选项，请重新读取关键属性或可选属性。');
  if(selects.some(field=>!Array.isArray(field.options)||!field.options.length||field.options.some(option=>!plain(option)||!text(option.value)||!text(option.label))))issues.push('部分属性下拉没有真实可用选项，请重新读取。');
  if(selects.some(field=>field.optionsComplete!==true))issues.push('部分属性下拉选项尚未完整读取，请重新读取。');
  if(selects.some(field=>Array.isArray(field.options)&&field.valueKind!=='api-id'&&field.optionsEvidence?.kind!=='observed-category-definition'&&!evidenceMatchesOptions(field)))issues.push('下拉选项计数、边界或静稳证明与已读取选项不一致，请重新读取。');
  if(apiFields.some(field=>Array.isArray(field.options)&&!evidenceMatchesOptions(field)))issues.push('API 属性的原始编号、计数、字段关联或完整响应证据不足，请重新读取。');
  return [...issues,...attributeGroupIssues(fields,groups)];
}
function normalizeSchemaReadiness(input){
  const {complete:claimedComplete,status:claimedStatus,issues:rawIssues,reasonCode,...schema}=input,blockers=schemaCompletenessIssues(schema.fields,schema.attributeGroups),observedIssues=schemaIssues(rawIssues),claimedReady=claimedComplete===true||claimedStatus==='ready',complete=claimedComplete===true&&claimedStatus==='ready'&&reasonCode===undefined&&!Object.hasOwn(schema,'lastReadFailure')&&!blockers.length&&!observedIssues.length;
  const supplemental=Object.hasOwn(schema,'supplementalComplianceFields')&&(!Array.isArray(schema.supplementalComplianceFields)||schema.supplementalComplianceFields.length>0);
  if(supplemental)blockers.push('商品合规补充选项仅供本地草稿，后台提交尚未核验，不能发布。');
  const ready=complete&&!supplemental;
  const issues=ready?[]:schemaIssues([...((claimedReady||!observedIssues.length)?blockers:[]),...observedIssues]);
  if(!ready&&!issues.length)issues.push('类目读取尚未完成，请重新读取真实属性与下拉选项。');
  return {...schema,complete:ready,status:ready?'ready':'needs_review',...(Array.isArray(rawIssues)||!ready?{issues}:{}),...(inspectReasons.has(reasonCode)?{reasonCode}:claimedReady&&!ready?{reasonCode:'category_read_incomplete'}:{})};
}
function schemaData(input,path){
  if(!plain(input)||!Array.isArray(input.fields)||input.fields.length>1000)throw fail('PUBLISH_INVALID','店铺属性读取结果无效。');
  const seen=new Set(),output=input.fields.map(field=>{
    if(!plain(field)||!text(field.label)||field.label.length>255||!text(field.key)||field.key.length>255||seen.has(field.key)||field.options!==undefined&&(!Array.isArray(field.options)||field.options.length>10000))throw fail('PUBLISH_INVALID','店铺属性字段读取不完整，请重新读取。');seen.add(field.key);
    for(const key of ['ordinal','groupCount'])if(field[key]!==undefined&&(!Number.isSafeInteger(field[key])||field[key]<1))throw fail('PUBLISH_INVALID','店铺属性字段序号或分组总数无效，请重新读取。');
    if(field.ordinal!==undefined&&field.groupCount!==undefined&&field.ordinal>field.groupCount)throw fail('PUBLISH_INVALID','店铺属性字段序号超出分组总数，请重新读取。');
    for(const key of ['apiCategoryId','apiPropertyId'])if(field[key]!==undefined&&!validId(field[key]))throw fail('PUBLISH_INVALID','API 属性字段编号格式无效，请重新读取。');
    if(field.valueKind!==undefined&&!['api-id','dom-label'].includes(field.valueKind)||field.valueKind==='dom-label'&&field.controlType!=='select')throw fail('PUBLISH_INVALID','属性值类型无效，请重新读取。');
    if(input.attributeReadEvidence!==undefined&&['multiple','required','optionsComplete'].some(key=>typeof field[key]!=='boolean'))throw fail('PUBLISH_INVALID','部分属性字段缺少实际布尔描述，请重新读取。');
    const options=field.options===undefined?null:field.options.map(option=>{if(!plain(option)||typeof option.value!=='string'||typeof option.label!=='string'||option.value.length>1024||option.label.length>1024)throw fail('PUBLISH_INVALID','店铺属性选项读取不完整，请重新读取。');return {value:option.value,label:option.label};});
    return {label:field.label,key:field.key,options,optionsComplete:field.optionsComplete===true,multiple:field.multiple===true,required:field.required===true,section:typeof field.section==='string'?field.section.slice(0,160):'',...(field.ordinal!==undefined?{ordinal:field.ordinal}:{}),...(field.groupCount!==undefined?{groupCount:field.groupCount}:{}),...Object.fromEntries(['apiCategoryId','apiPropertyId'].filter(key=>field[key]!==undefined).map(key=>[key,field[key]])),...(field.controlType==='select'&&['api-id','dom-label'].includes(field.valueKind)?{valueKind:field.valueKind}:{}),...(field.optionsEvidence!==undefined?{optionsEvidence:optionsEvidence(field.optionsEvidence)}:{}),...(field.inputEvidence!==undefined?{inputEvidence:inputEvidenceData(field.inputEvidence)}:{}),...(field.unavailableReason!==undefined?{unavailableReason:fieldUnavailableReasons.has(field.unavailableReason)?field.unavailableReason:'field_proof_unverified'}:{}),...(typeof field.type==='string'?{type:field.type.slice(0,40)}:{}),...(typeof field.controlType==='string'?{controlType:field.controlType.slice(0,40)}:{})};
  });
  return normalizeSchemaReadiness({categoryPath:path,fields:output,complete:input.complete===true,status:input.status==='ready'?'ready':'needs_review',source:'live-shop',...(input.supplementalComplianceFields!==undefined?{supplementalComplianceFields:supplementalComplianceData(input.supplementalComplianceFields)}:{}),...(input.attributeReadEvidence!==undefined?{attributeReadEvidence:attributeReadEvidenceData(input.attributeReadEvidence)}:{}),...(input.attributeGroups!==undefined?{attributeGroups:attributeGroupsData(input.attributeGroups)}:{}),...(Array.isArray(input.issues)?{issues:input.issues}:{}),...(inspectReasons.has(input.reasonCode)?{reasonCode:input.reasonCode}:input.reasonCode!==undefined&&(input.complete===true||input.status==='ready')?{reasonCode:'category_read_incomplete'}:{})});
}
const zeroEvidenceKeys=['version','source','categoryId','responseComplete','applicablePropertyCount','allSectionsScanned','candidateControlCount','unknownControlCount','scopeVerified','stableSamples'];
function zeroBuiltinEvidence(leaf){const e=leaf.zeroAttributeEvidence;return plain(e)&&Object.keys(e).every(k=>zeroEvidenceKeys.includes(k))&&e.version===1&&e.source==='build-time-zero-attribute-census'&&e.categoryId===leaf.categoryId&&e.responseComplete===true&&e.applicablePropertyCount===0&&e.allSectionsScanned===true&&e.candidateControlCount===0&&e.unknownControlCount===0&&e.scopeVerified===true&&Number.isSafeInteger(e.stableSamples)&&e.stableSamples>=3&&e.stableSamples<=100&&Array.isArray(leaf.fields)&&leaf.fields.length===0;}
const builtinLeafKeys=new Set(['schemaVersion','region','locale','categoryId','path','capturedAt','fields','attributeGroups','attributeReadEvidence','supplementalComplianceFields','captureEvidence','zeroAttributeEvidence']);
const buildCaptureKeys=['version','kind','fieldUniverseComplete'];
const apiLeafMetadataKeys=['schemaSource','publicDefinition','componentDefinition','apiDefinitionEvidence','commitVerified'];
/** Sanitizes a real build-time observation. This is not a runtime shop read. */
export function sanitizeObservedLeaf(observed,options={}){
  const {region='US',locale='zh-CN'}=options;
  if(observed?.schemaSource===API_SCHEMA_SOURCE){if(!validateApiCategoryLeaf(observed)||observed.region!==region||observed.locale!==locale||options.capturedAt!==undefined&&options.capturedAt!==observed.capturedAt)throw fail('PUBLISH_CATALOG_INCOMPLETE','预采集 API 定义及组件关系尚未完整核验，不能作为内置参数。',409);return structuredClone(observed);}
  const capturedAt=options.capturedAt??new Date().toISOString();
  if(!plain(observed)||observed.source!=='visible-seller-dom-and-category-api'||!Array.isArray(observed.categoryPath)||typeof capturedAt!=='string'||!Number.isFinite(Date.parse(capturedAt)))throw fail('PUBLISH_CATALOG_INCOMPLETE','构建时的真实细分类目读取尚未完成。',409);
  if(observed.zeroAttributeEvidence!==undefined){const leaf={schemaVersion:1,region,locale,categoryId:observed.zeroAttributeEvidence?.categoryId,path:[...observed.categoryPath],capturedAt,fields:[],attributeGroups:[],zeroAttributeEvidence:structuredClone(observed.zeroAttributeEvidence),captureEvidence:{version:1,kind:'build-time-observed-leaf',fieldUniverseComplete:true}};if(!Array.isArray(observed.fields)||observed.fields.length||!validateBuiltinLeaf(leaf))throw fail('PUBLISH_CATALOG_INCOMPLETE','零属性类目缺少完整定义响应及全页零控件证据。',409);return leaf;}
  if(!validId(observed.attributeReadEvidence?.categoryId))throw fail('PUBLISH_CATALOG_INCOMPLETE','构建时的真实细分类目缺少平台编号。',409);
  const normalized=schemaData(observed,categoryPath(observed.categoryPath)),categoryId=normalized.attributeReadEvidence.categoryId;
  if(!capturedCensusVerified(normalized,categoryId)||!normalized.fields.every(f=>independentlyEditableField(f,categoryId))||normalized.supplementalComplianceFields?.length)throw fail('PUBLISH_CATALOG_INCOMPLETE','构建时必须完整读取该细分类目的全部字段和下拉参数，不能用缺省值补齐。',409);
  const leaf={schemaVersion:1,region,locale,categoryId,path:[...observed.categoryPath],capturedAt,fields:normalized.fields.map(f=>{const {editable,...publicField}=f;return publicField;}),attributeGroups:normalized.attributeGroups,attributeReadEvidence:normalized.attributeReadEvidence,captureEvidence:{version:1,kind:'build-time-observed-leaf',fieldUniverseComplete:true}};
  if(!validateBuiltinLeaf(leaf))throw fail('PUBLISH_CATALOG_INCOMPLETE','预采集细分类目的公开数据校验失败。',409);return leaf;
}
export function validateBuiltinLeaf(leaf){
  try{
    if(leaf?.schemaSource===API_SCHEMA_SOURCE)return validateApiCategoryLeaf(leaf)===true;
    if(!plain(leaf)||Object.keys(leaf).some(k=>!builtinLeafKeys.has(k))||leaf.schemaVersion!==1||!/^[A-Z]{2,6}$/u.test(leaf.region||'')||!/^[a-z]{2}(?:-[A-Z]{2})?$/u.test(leaf.locale||'')||!validId(leaf.categoryId)||!Array.isArray(leaf.path)||typeof leaf.capturedAt!=='string'||!Number.isFinite(Date.parse(leaf.capturedAt||''))||!plain(leaf.captureEvidence)||Object.keys(leaf.captureEvidence).some(k=>!buildCaptureKeys.includes(k))||leaf.captureEvidence.version!==1||leaf.captureEvidence.kind!=='build-time-observed-leaf'||leaf.captureEvidence.fieldUniverseComplete!==true)return false;
    categoryPath(leaf.path);
    if(zeroBuiltinEvidence(leaf))return leaf.attributeReadEvidence===undefined&&leaf.supplementalComplianceFields===undefined&&(leaf.attributeGroups===undefined||Array.isArray(leaf.attributeGroups)&&leaf.attributeGroups.length===0);
    if(leaf.zeroAttributeEvidence!==undefined)return false;
    const normalized=schemaData(leaf,categoryPath(leaf.path));
    return canonical(normalized.fields)===canonical(leaf.fields)&&canonical(normalized.attributeGroups)===canonical(leaf.attributeGroups)&&canonical(normalized.attributeReadEvidence)===canonical(leaf.attributeReadEvidence)&&capturedCensusVerified(normalized,leaf.categoryId)&&normalized.fields.every(f=>independentlyEditableField(f,leaf.categoryId)&&domLabel(f.label)&&!/^(?:品牌|品牌名称|授权品牌|已授权品牌|brand)$/iu.test(f.label)&&f.options.every(o=>domLabel(o.label)))&&(!normalized.supplementalComplianceFields||normalized.supplementalComplianceFields.length===0);
  }catch{return false;}
}

function cleanJSON(value,depth=0){if(depth>16)throw fail('PUBLISH_INVALID','商品资料层级过深。');if(value===null||typeof value==='boolean')return value;if(typeof value==='string'){if(value.length>200000)throw fail('PUBLISH_INVALID','商品资料文字过长。');return value;}if(typeof value==='number'&&Number.isFinite(value))return value;if(Array.isArray(value)){if(value.length>5000)throw fail('PUBLISH_INVALID','商品资料项目过多。');return value.map(item=>cleanJSON(item,depth+1));}if(plain(value)){if(Object.keys(value).length>5000)throw fail('PUBLISH_INVALID','商品资料字段过多。');return Object.fromEntries(Object.entries(value).map(([key,item])=>{if(['__proto__','prototype','constructor','localPath','_publishAuthorized','snapshot','artworks'].includes(key)||/(?:password|cookie|authorization|authValue|apiKey|accessToken|refreshToken|secret)/iu.test(key))throw fail('PUBLISH_INVALID','商品资料不能包含本机路径、浏览器凭据或原始编辑快照。');return [key,cleanJSON(item,depth+1)];}));}throw fail('PUBLISH_INVALID','商品资料需要可保存的普通字段。');}
function productData(input,assets,{forSubmission=true}={}){
  if(!plain(input)||Object.keys(input).some(key=>!productKeys.has(key)))throw fail('PUBLISH_INVALID','商品资料格式无效。');
  const product=cleanJSON(input);
  try{const specifications=forSubmission?assertTikTokSalesSpecificationsCompatible(product):normalizedTikTokSalesSpecifications(product);if(specifications)product.salesSpecifications=specifications;}
  catch(error){throw fail('PUBLISH_INVALID',error.message);}
  if(!text(product.name)||product.name.length>255||!plain(product.profile)||!text(product.profile.category)||!Array.isArray(product.variants)||!product.variants.some(item=>item.selected!==false)||product.variants.length>500||!Array.isArray(product.assets)||product.assets.length>100||!Array.isArray(product.gallery)||!product.gallery.length||product.gallery.length>9||product.renderPending===true)throw fail('PUBLISH_INVALID','请先完成标题、类目、商品图片、规格与保存贴图，再上架。');
  const ids=new Set();
  for(const asset of product.assets){if(!plain(asset)||!validId(asset.id)||ids.has(asset.id)||!/^[a-f0-9]{64}$/u.test(asset.assetId||'')||!assets.has(asset.assetId)||!assets.get(asset.assetId).mime.startsWith('image/')||asset.imageStage==='blank'||asset.url)throw fail('PUBLISH_ASSET','商品图片尚未上传到主机，或仍为空白模板，请完成贴图后重试。');ids.add(asset.id);}
  for(const id of [...product.gallery,...(product.details||[]),...(product.sizeChart?[product.sizeChart]:[]),...product.variants.filter(item=>item.selected!==false).flatMap(item=>item.images||[])])if(!ids.has(id))throw fail('PUBLISH_ASSET','商品图片引用不完整，请重新读取图片。');
  if(product.video&&(!plain(product.video)||!assets.has(product.video.assetId)||!assets.get(product.video.assetId).mime.startsWith('video/')))throw fail('PUBLISH_ASSET','商品视频原件尚未上传到主机。');
  return product;
}
function assetType(mime,bytes){
  if(mime==='image/png'&&bytes.length>=24&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))&&bytes.toString('ascii',12,16)==='IHDR'&&bytes.readUInt32BE(16)>0&&bytes.readUInt32BE(20)>0&&bytes.readUInt32BE(16)*bytes.readUInt32BE(20)<=40000000)return 'png';
  if(mime==='image/jpeg'&&bytes.length>=4&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return 'jpg';
  if(['video/mp4','video/quicktime'].includes(mime)&&bytes.length>=12&&bytes.toString('ascii',4,8)==='ftyp')return mime==='video/mp4'?'mp4':'mov';
  if(mime==='video/x-matroska'&&bytes.length>=4&&bytes.subarray(0,4).equals(Buffer.from([26,69,223,163])))return 'mkv';
  if(['video/x-msvideo','video/avi'].includes(mime)&&bytes.length>=12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='AVI ')return 'avi';
  throw fail('PUBLISH_ASSET','上传原件的格式与文件内容不一致。');
}
function publicJob(job){return {id:job.id,requestId:job.requestId,action:job.action||'publish',...(job.sourceDraft?{sourceDraft:structuredClone(job.sourceDraft)}:{}),status:job.status,name:job.product.name,createdAt:job.createdAt,updatedAt:job.updatedAt,targets:structuredClone(job.targets),cancelRequested:job.cancelRequested===true};}
async function verifyAssetFile(path,item){const info=await stat(path);if(!info.isFile()||info.size!==item.size)throw new Error();const digest=createHash('sha256');for await(const chunk of createReadStream(path))digest.update(chunk);if(digest.digest('hex')!==item.id)throw new Error();}
async function spoolAsset(req,assetRoot,limit){
  const temporary=join(assetRoot,'.upload-'+randomBytes(16).toString('hex')+'.tmp'),digest=createHash('sha256');let handle,size=0,header=Buffer.alloc(0),tooLarge=false,writeFailed=false;
  try{try{handle=await open(temporary,'wx');}catch{writeFailed=true;}for await(const chunk of req){size+=chunk.length;if(size>limit){tooLarge=true;continue;}if(tooLarge||writeFailed)continue;if(header.length<32)header=Buffer.concat([header,chunk.subarray(0,32-header.length)]);digest.update(chunk);let offset=0;try{while(offset<chunk.length){const written=await handle.write(chunk,offset,chunk.length-offset);if(!written.bytesWritten)throw new Error();offset+=written.bytesWritten;}}catch{writeFailed=true;}}if(handle){try{await handle.close();}catch{writeFailed=true;}handle=null;}if(tooLarge)throw fail('PUBLISH_SIZE','上传内容超过允许大小。',413);if(writeFailed)throw fail('PUBLISH_STORAGE',safeMessages.PUBLISH_STORAGE,503);if(!size)throw fail('PUBLISH_ASSET','上传原件不能为空。');return {temporary,id:digest.digest('hex'),size,header};}
  catch(error){if(handle)await handle.close().catch(()=>{});await unlink(temporary).catch(()=>{});throw error;}
}

/** Durable host queue. Browser connections and credentials never enter persisted records. */
export function createTikTokPublishingService({root,settings,ads,rpa,now=Date.now,idFactory=randomUUID,schemaCacheTtlMs=30*60*1000,catalogRoot,builtinCatalog,catalogPolicy='prebuilt-only'}={}){
  if(!root||!settings?.publicStatus||!ads?.connectEnvironment)throw new Error('多店铺上架服务连接不完整。');
  const home=resolve(root),assetRoot=join(home,'assets'),statePath=join(home,'publishing-state.json');
  const schemaStore=createTikTokSchemaStore({root:home});
  const prebuiltOnly=catalogPolicy!=='legacy-live';
  const catalog=builtinCatalog||createTikTokBuiltinCatalog({...(catalogRoot?{root:catalogRoot}:{}),validateLeaf:validateBuiltinLeaf});
  let state={version:1,bindings:[],schemas:[],assets:[],jobs:[],categoryTrees:[],categoryRoots:[]},loaded=false,loading,persistQueue=Promise.resolve(),closed=false,worker=null,controller=null,configuring=false,activeConnections=0;
  const pairing=new Map(),categorySyncing=new Map(),schemaSyncing=new Map();
  const assetMap=()=>new Map(state.assets.map(asset=>[asset.id,asset]));
  const bindingFor=id=>state.bindings.find(binding=>binding.id===id);
  const verifiedBinding=binding=>binding&&(binding.verificationStatus===undefined||binding.verificationStatus==='verified');
  const schemaInScope=(schema,binding)=>verifiedBinding(binding)&&hasShopProfile(binding)&&schema.shopId===binding.identity.shopId&&schema.region===binding.identity.region&&categoryScopeAllows(binding,String(schema.categoryPath||'').split(' > '));
  function treeView(binding){if(prebuiltOnly){const meta=catalog.bindingStatus(binding),catalogs=hasShopProfile(binding)?catalog.catalogs(binding):[];return {catalogs,sync:{complete:meta.status==='ready',rootCatalogComplete:meta.rootComplete===true,totalBranches:catalogs.length,completedBranches:meta.status==='ready'?catalogs.length:0,pendingBranches:0,issues:meta.issues||[]},pendingPaths:[]};}const view=categoryTreeView(state.categoryTrees,binding,timestamp(now));if(hasShopProfile(binding)){const observed=state.categoryRoots.find(item=>plain(item)&&item.region===binding.identity.region&&item.complete===true),roots=new Set([binding.mainCategory.label,...(observed?.nodes||[]).map(item=>item.label),...state.bindings.filter(item=>hasShopProfile(item)&&item.identity.region===binding.identity.region).map(item=>item.mainCategory.label),...state.categoryTrees.filter(item=>plain(item)&&item.region===binding.identity.region&&typeof item.mainCategory==='string').map(item=>item.mainCategory)]);view.catalogs[0].nodes=[...roots].map(label=>({label,path:[label],disabled:label!==binding.mainCategory.label}));view.sync.rootCatalogComplete=Boolean(observed);view.sync.complete=view.sync.complete&&Boolean(observed);}return view;}
  function bindingView(binding){const copy=structuredClone(binding),view=treeView(copy);copy.categoryAccess=categoryAccessView(binding);copy.categoryCatalog=view.catalogs;copy.categorySync={...view.sync,issues:schemaIssues(prebuiltOnly?view.sync.issues:binding.categorySyncIssues)};copy.schemaSync=schemaSyncView(binding);if(prebuiltOnly)copy.builtinCatalog=catalog.bindingStatus(binding);if(!hasShopProfile(copy))copy.profileStatus='needs_profile';return copy;}
  function assertCategoryScope(binding,path){
    if(!hasShopProfile(binding))throw fail('PUBLISH_CATEGORY_SCOPE','请先完成该店铺的首次配对，读取并保存主营类目。',403);
    const parts=Array.isArray(path)?path:categoryPath(path).split(' > ');
    if(!categoryScopeAllows(binding,parts))throw fail('PUBLISH_CATEGORY_SCOPE','该类目不属于此店铺已配对的主营类目，不能读取或填写。',403);
    const view=prebuiltOnly?treeView(binding):categoryTreeView(state.categoryTrees,binding,timestamp(now));
    for(const catalog of view.catalogs)for(const node of catalog.nodes)if(node.disabled&&node.path.length<=parts.length&&node.path.every((part,index)=>part===parts[index]))throw fail('PUBLISH_CATEGORY_SCOPE','此店铺的该细分类目不可操作。',403);
    if(view.sync.complete&&!view.catalogs.some(catalog=>JSON.stringify(catalog.parentPath)===JSON.stringify(parts)))throw fail('PUBLISH_CATEGORY_SCOPE','所选细分类目不在此店铺已同步的主营类目中。',403);
  }
  function storeBranch(binding,observed,parent){const branch=validCategoryBranch(observed,binding,parent);if(!branch)throw fail('PUBLISH_SCHEMA','类目分支尚未完整读取，请继续同步。',409);const record={...branch,readAt:timestamp(now),source:'live-shop-category-menu',issues:[]};state.categoryTrees=state.categoryTrees.filter(item=>!(item.region===record.region&&item.mainCategory===record.mainCategory&&canonical(item.parentPath)===canonical(record.parentPath)));state.categoryTrees.push(record);return record;}
  function draftSchemaComplete(schema,binding){
    if(schema?.source==='builtin-category-library')return builtinScopeVerified(schema,binding);
    if(!plain(schema)||!verifiedBinding(binding)||!hasShopProfile(binding)||schema.bindingId!==binding.id||schema.shopId!==binding.identity.shopId||schema.region!==binding.identity.region||!categoryScopeAllows(binding,String(schema.categoryPath||'').split(' > '))||Object.hasOwn(schema,'lastReadFailure')||schema.source!=='live-shop'||!Array.isArray(schema.fields)||!schema.fields.length||!Number.isFinite(Date.parse(schema.readAt||''))||Date.parse(schema.readAt)>Date.parse(timestamp(now)))return false;
    if(schema.supplementalComplianceFields!==undefined&&(!Array.isArray(schema.supplementalComplianceFields)||schema.supplementalComplianceFields.length>0))return false;
    if(fieldScopeVerified(schema,binding,Date.parse(timestamp(now))))return schema.fields.every(field=>independentlyEditableField(field,schema.attributeReadEvidence.categoryId));
    return schema.complete===true&&schema.status==='ready'&&schema.reasonCode===undefined&&!schemaCompletenessIssues(schema.fields,schema.attributeGroups).length&&!schemaIssues(schema.issues).length;
  }
  const cacheView=(schema,binding=state.bindings.find(item=>item.id===schema.bindingId))=>{
    const revision=schema.summaryOnly===true?schema.schemaStorage?.sha256:undefined;schema=schemaStore.materialize(schema);
    let view=schema;
    if(Object.hasOwn(schema,'lastReadFailure')){
      const failed=schema.lastReadFailure,code=safeCodes.has(failed?.code)?failed.code:'PUBLISH_UNAVAILABLE',failedAt=typeof failed?.failedAt==='string'&&Number.isFinite(Date.parse(failed.failedAt))?failed.failedAt:undefined;
      view={...schema,complete:false,status:'needs_review',reasonCode:'category_read_incomplete',issues:schemaIssues([...(Array.isArray(schema.issues)?schema.issues:[]),'最近一次类目读取未成功，请重新读取真实属性后再选择。']),lastReadFailure:{code,...(failedAt?{failedAt}:{})}};
    }
    const edited=fieldEditingView(view,binding,Date.parse(timestamp(now)));return {...edited,draftComplete:draftSchemaComplete(edited,binding),...(revision?{schemaRevision:revision}:{})};
  };
  const summaryView=schema=>({...structuredClone(schema),...(Object.hasOwn(schema,'lastReadFailure')||!schemaStore.summaryAvailable(schema)?{draftComplete:false,complete:false,status:'needs_review'}:{})});
  const visibleSchemas=()=>state.schemas.filter(schema=>state.bindings.some(binding=>schemaInScope(schema,binding))).map(schema=>schema.summaryOnly===true?summaryView(schema):cacheView(schema));
  function invalidateBindings(matches,code){let changed=false;for(const binding of state.bindings)if(matches(binding)){binding.verificationStatus='needs_review';binding.verificationReasonCode=code==='PUBLISH_IDENTITY'?'PUBLISH_IDENTITY':'PUBLISH_STORE_UNVERIFIED';binding.invalidatedAt=timestamp(now);for(const schema of state.schemas)if(schema.summaryOnly===true&&schema.bindingId===binding.id){schema.lastReadFailure={code:code==='PUBLISH_IDENTITY'?'PUBLISH_IDENTITY':'PUBLISH_STORE_UNVERIFIED',failedAt:timestamp(now)};}else if(schema.fieldEditingScope?.bindingId===binding.id){delete schema.fieldEditingScope;schema.fields=schema.fields.map(field=>({...field,editable:false}));}changed=true;}return changed;}
  function failedSchemaRead(binding,path,error){const schema=state.schemas.find(item=>item.shopId===binding.identity.shopId&&item.region===binding.identity.region&&item.categoryPath===path);if(!schema)return false;schema.lastReadFailure={code:publicError(error).code,failedAt:timestamp(now)};return true;}

  const builtinIdentity=read=>read.categoryIdentity||{identityPath:read.leaf.identityPath||read.leaf.path,displayPath:read.leaf.displayPath||read.leaf.path,...(read.leaf.categoryIds?{categoryIds:read.leaf.categoryIds}:{})};
  function builtinScopeVerified(schema,binding){
    if(!prebuiltOnly||!verifiedBinding(binding)||!hasShopProfile(binding)||schema?.source!=='builtin-category-library'||schema.bindingId!==binding.id||schema.shopId!==binding.identity.shopId||schema.region!==binding.identity.region)return false;
    try{
      const read=catalog.readLeaf(binding,schema.categoryPath),leaf=read.leaf,p=schema.libraryScope,identity=builtinIdentity(read),api=leaf.schemaSource===API_SCHEMA_SOURCE;
      return plain(p)&&p.version===1&&p.verified===true&&p.catalogId===read.catalogId&&p.catalogVersion===read.catalogVersion&&p.manifestSha256===read.manifestSha256&&p.leafSha256===read.entry.sha256&&p.categoryId===leaf.categoryId&&p.bindingId===binding.id&&p.shopId===binding.identity.shopId&&p.region===binding.identity.region&&p.categoryPath===schema.categoryPath&&p.mainCategory===binding.mainCategory.label&&(!hasAllCategoryAccess(binding)||canonical(p.categoryAccess)===canonical(categoryAccessView(binding)))&&p.capturedAt===leaf.capturedAt&&schema.readAt===leaf.capturedAt&&schema.schemaRevision===read.entry.sha256
        &&['identityPath','displayPath','categoryIds'].every(k=>canonical(schema[k])===canonical(identity[k]))
        &&canonical(schema.fields.map(({editable,...f})=>f))===canonical(leaf.fields)&&canonical(schema.attributeGroups)===canonical(api?undefined:leaf.attributeGroups||[])&&canonical(schema.attributeReadEvidence)===canonical(leaf.attributeReadEvidence)&&canonical(schema.zeroAttributeEvidence)===canonical(leaf.zeroAttributeEvidence)&&canonical(schema.buildCaptureEvidence)===canonical(leaf.captureEvidence)
        &&apiLeafMetadataKeys.every(k=>canonical(schema[k])===canonical(leaf[k]));
    }catch{return false;}
  }
  function projectedBuiltinSchema(binding,path){
    if(!verifiedBinding(binding)||!hasShopProfile(binding))throw fail('PUBLISH_CATEGORY_SCOPE','请先读取并保存店铺名称和主营类目。',403);assertCategoryScope(binding,path);
    const read=catalog.readLeaf(binding,path),leaf=read.leaf,identity=builtinIdentity(read),api=leaf.schemaSource===API_SCHEMA_SOURCE;
    return {source:'builtin-category-library',categoryPath:path,identityPath:structuredClone(identity.identityPath),displayPath:structuredClone(identity.displayPath),...(identity.categoryIds?{categoryIds:structuredClone(identity.categoryIds)}:{}),bindingId:binding.id,shopId:binding.identity.shopId,region:binding.identity.region,readAt:leaf.capturedAt,complete:true,draftComplete:true,status:'ready',schemaRevision:read.entry.sha256,fields:leaf.fields.map(f=>({...f,editable:true})),...(api?Object.fromEntries(apiLeafMetadataKeys.map(k=>[k,structuredClone(leaf[k])])):{attributeGroups:leaf.attributeGroups||[],attributeReadEvidence:leaf.attributeReadEvidence}),...(leaf.zeroAttributeEvidence?{zeroAttributeEvidence:leaf.zeroAttributeEvidence}:{}),buildCaptureEvidence:leaf.captureEvidence,issues:[],
      libraryScope:{version:1,catalogId:read.catalogId,catalogVersion:read.catalogVersion,manifestSha256:read.manifestSha256,leafSha256:read.entry.sha256,categoryId:leaf.categoryId,bindingId:binding.id,shopId:binding.identity.shopId,region:binding.identity.region,categoryPath:path,mainCategory:binding.mainCategory.label,categoryAccess:categoryAccessView(binding),capturedAt:leaf.capturedAt,verified:true}};
  }
  function cachedSchema(binding,path,{persistent=false}={}){
    if(prebuiltOnly)throw fail('PUBLISH_SCHEMA','内置类目参数用于商品草稿，最终上架由用户人工检查；不能据此自动发布。',409);
    if(!verifiedBinding(bindingFor(binding.id)))throw fail('PUBLISH_IDENTITY','绑定店铺需要重新核验，请重新读取并绑定真实店铺。',409);
    const schema=schemaStore.materialize(state.schemas.find(item=>item.shopId===binding.identity.shopId&&item.region===binding.identity.region&&item.categoryPath===path)),age=Date.parse(timestamp(now))-Date.parse(schema?.readAt||'');
    if(!schema||Object.hasOwn(schema,'lastReadFailure')||schema.reasonCode!==undefined||schema.source!=='live-shop'||schema.complete!==true||schema.status!=='ready'||Object.hasOwn(schema,'supplementalComplianceFields')&&(!Array.isArray(schema.supplementalComplianceFields)||schema.supplementalComplianceFields.length>0)||!Number.isFinite(age)||age< -300000||!persistent&&age>schemaCacheTtlMs||schemaCompletenessIssues(schema.fields,schema.attributeGroups).length||schemaIssues(schema.issues).length||schema.attributeReadEvidence!==undefined&&!fieldScopeVerified(schema,binding,Date.parse(timestamp(now))))throw fail('PUBLISH_SCHEMA','该目标店铺的当前类目属性尚未完整读取或已过期，请重新读取真实下拉选项。',409);
    return schema;
  }
  function cachedFillSchema(binding,path,{persistent=false}={}){
    if(prebuiltOnly)return projectedBuiltinSchema(binding,path);
    if(!verifiedBinding(bindingFor(binding.id)))throw fail('PUBLISH_IDENTITY','绑定店铺需要重新核验，请重新读取真实店铺。',409);
    const schema=schemaStore.materialize(state.schemas.find(item=>item.bindingId===binding.id&&item.shopId===binding.identity.shopId&&item.region===binding.identity.region&&item.categoryPath===path));
    const age=Date.parse(timestamp(now))-Date.parse(schema?.readAt||'');
    if(!schema||!Number.isFinite(age)||age<0||!persistent&&age>schemaCacheTtlMs||Object.hasOwn(schema,'lastReadFailure'))throw fail('PUBLISH_SCHEMA','目标店铺的类目字段尚未读取或已过期，请重新读取。',409);
    if(persistent&&!draftSchemaComplete(schema,binding))throw fail('PUBLISH_SCHEMA','目标店铺该细分类目的属性或下拉选项尚未完整预读，请完成参数同步后保存到草稿箱。',409);
    if(fieldScopeVerified(schema,binding,Date.parse(timestamp(now))))return schema;
    return cachedSchema(binding,path,{persistent});
  }
  function mappedProductFields(product,binding,{fillOnly=false,persistent=false}={}){
    const path=categoryPath(product.profile.category);assertCategoryScope(binding,path);const schema=fillOnly?cachedFillSchema(binding,path,{persistent}):cachedSchema(binding,path);
    const scoped=fillOnly?product.fillCategoryAttributes:product.profile.liveCategoryAttributes;
    const scopedValues=scoped?.[binding.id]?.[path];
    if(fillOnly&&(!plain(scoped)||!plain(scopedValues)))throw fail('PUBLISH_SCHEMA','该保存结果缺少目标店铺当前类目的独立字段值，请重新保存后填写。',409);
    let values=fillOnly&&scoped!==undefined?(plain(scopedValues)?scopedValues:{}):product.profile.categoryAttributes||{};
    const known=new Map(schema.fields.map(field=>[field.key,field]));
    if(!fillOnly&&schema.fields.some(field=>field.valueKind==='dom-label'||field.optionsEvidence?.kind==='observed-seller-option-list'))throw fail('PUBLISH_SCHEMA','DOM 选项仅供本地选择，发布值映射尚未核验。',409);
    if(!fillOnly&&schema.fields.some(field=>Object.hasOwn(field,'inputEvidence')))throw fail('PUBLISH_SCHEMA','文本输入仅供本地草稿，尚未核验后台提交方式，不能发布。',409);
    if(!plain(values))throw fail('PUBLISH_SCHEMA','类目属性需要按实际字段填写。',409);
    const present=value=>value!==undefined&&value!==null&&(typeof value!=='string'||value.trim()!=='')&&(!Array.isArray(value)||value.some(item=>typeof item!=='string'||item.trim()!==''));
    if(supplementalComplianceTargets.some(field=>present((scopedValues||{})[field.key])))throw fail('PUBLISH_SCHEMA','商品合规补充选项仅供本地草稿，后台提交尚未核验，不能发布。',409);
    if(Object.keys(values).some(key=>present(values[key])&&!known.has(key)))throw fail('PUBLISH_SCHEMA','商品含有未映射的类目属性，请使用目标店铺刚读取的真实属性填写。',409);
    let descriptors=schema.fields;
    if(schema.schemaSource===API_SCHEMA_SOURCE){const conditional=validateBuiltinAttributeValues(schema,values);if(!conditional.valid)throw fail('PUBLISH_SCHEMA',conditional.issues.slice(0,5).map(issue=>issue.message).join('；'),409);values=conditional.submittedValues;descriptors=conditional.activeFields;}
    const fields=[];
    for(const descriptor of descriptors){
      const value=values[descriptor.key];
      if(fillOnly&&present(value)&&schema.attributeReadEvidence!==undefined&&!independentlyEditableField(descriptor,(schema.source==='builtin-category-library'?schema.libraryScope.categoryId:schema.fieldEditingScope?.categoryId)))throw fail('PUBLISH_SCHEMA','目标店铺字段尚未核验，不能填写：'+descriptor.label,409);
      if(!present(value)){if(descriptor.required)throw fail('PUBLISH_SCHEMA','目标店铺缺少必填属性：'+descriptor.label,409);continue;}
      const entries=attributeValueEntries(value),api=schema.schemaSource===API_SCHEMA_SOURCE;
      if(!entries.length||entries.some(item=>typeof item==='string'?!item.trim():!api||!isCustomAttributeValue(item)||!attributeOptionValueAllowed(descriptor,item)))throw fail('PUBLISH_SCHEMA','类目属性值格式无效，请重新选择真实选项。',409);
      const selectedLabels=new Set((descriptor.options||[]).filter(option=>entries.includes(option.value)).map(option=>option.label));
      if(!descriptor.multiple&&entries.length>1)throw fail('PUBLISH_SCHEMA','单选属性不能填写多个选项。',409);
      if(descriptor.controlType==='select'&&entries.some(entry=>api?!attributeOptionValueAllowed(descriptor,entry):!descriptor.options.some(option=>option.value===entry)))throw fail('PUBLISH_SCHEMA','类目属性值不在目标店铺的真实下拉选项或已允许的自定义范围中，请重新填写。',409);
      const custom=entries.some(isCustomAttributeValue);
      if(custom&&entries.filter(isCustomAttributeValue).some(entry=>entry.value!==entry.value.trim()))throw fail('PUBLISH_SCHEMA','请移除自定义属性值的首尾空格。',409);
      if(custom&&entries.filter(isCustomAttributeValue).some(entry=>descriptor.options.some(option=>option.label.toLowerCase()===entry.value.toLowerCase())))throw fail('PUBLISH_SCHEMA','自定义文字与已有预设选项相同，请选择该预设选项后再保存。',409);
      fields.push({key:descriptor.key,label:descriptor.label,section:descriptor.section,...(descriptor.ordinal!==undefined?{ordinal:descriptor.ordinal}:{}),...(descriptor.groupCount!==undefined?{groupCount:descriptor.groupCount}:{}),...Object.fromEntries(['apiCategoryId','apiPropertyId','valueKind'].filter(key=>descriptor[key]!==undefined).map(key=>[key,descriptor[key]])),value:structuredClone(value),...(api?{expectedControlType:descriptor.controlType,...(descriptor.inputType?{expectedInputType:descriptor.inputType}:{}),commitVerified:false}:{}),...(custom?{allowCustomInput:true,customValueMode:customAttributeConstraints(descriptor).mode,customInputConstraints:customAttributeConstraints(descriptor),customPresetOptionCount:descriptor.options.length,customPresetOptions:structuredClone(descriptor.options)}:{}),...(fillOnly&&descriptor.valueKind==='api-id'?{fillOptions:structuredClone(descriptor.options.filter(option=>entries.includes(option.value)||selectedLabels.has(option.label)))}:{})});
    }
    return {fields,categoryPath:structuredClone(schema.displayPath||path.split(' > ')),...(schema.categoryIds?{categoryIds:structuredClone(schema.categoryIds),categoryId:schema.libraryScope.categoryId}:{}),...(schema.identityPath?{identityPath:structuredClone(schema.identityPath)}:{}),profile:{...structuredClone(product.profile),categoryAttributes:Object.fromEntries(fields.map(field=>[field.key,structuredClone(field.value)]))}};
  }
  const safePersist=async()=>{const operation=persistQueue.then(async()=>{const temporary=statePath+'.'+randomBytes(8).toString('hex')+'.tmp';try{await mkdir(home,{recursive:true});const schemas=[];for(const record of state.schemas)schemas.push(await schemaStore.externalize(record));schemaStore.validateBudget(schemas);const serialized={...state,schemas},bytes=Buffer.from(JSON.stringify(serialized));if(bytes.length>64*1024*1024)throw fail('PUBLISH_STORAGE','主机任务和缓存索引超过 64 MB，请归档历史任务后继续。',503);await writeFile(temporary,bytes,{flag:'wx'});await rename(temporary,statePath);state.schemas=schemas;}catch(error){if(error.code==='PUBLISH_SCHEMA')throw error;throw fail('PUBLISH_STORAGE',safeMessages.PUBLISH_STORAGE,503);}finally{await unlink(temporary).catch(()=>{});}});persistQueue=operation.catch(()=>{});return operation;};

  function aggregate(job){job.updatedAt=timestamp(now);if(job.targets.some(target=>target.status==='running'))job.status='running';else if(job.targets.some(target=>target.status==='queued'))job.status='queued';else if(job.targets.some(target=>target.status==='needs_review'))job.status='needs_review';else if(job.targets.every(target=>target.status==='succeeded'))job.status='succeeded';else if(job.targets.every(target=>target.status==='draft_saved'))job.status='draft_saved';else if(job.targets.every(target=>target.status==='filled'))job.status='filled';else if(job.targets.every(target=>target.status==='cancelled'))job.status='cancelled';else job.status='failed';}
  async function load(){if(loaded)return;if(!loading)loading=(async()=>{try{const info=await stat(statePath);if(info.size>64*1024*1024)throw new Error();const value=JSON.parse(await readFile(statePath,'utf8'));if(value.version!==1||!['bindings','schemas','assets','jobs'].every(key=>Array.isArray(value[key]))||value.schemas.some(schema=>!plain(schema)))throw new Error();if(value.categoryTrees!==undefined&&!Array.isArray(value.categoryTrees))throw new Error();if(value.categoryRoots!==undefined&&!Array.isArray(value.categoryRoots))throw new Error();state={...value,categoryTrees:value.categoryTrees||[],categoryRoots:value.categoryRoots||[]};}catch(error){if(error.code!=='ENOENT')throw fail('PUBLISH_STORAGE',safeMessages.PUBLISH_STORAGE,503);}let changed=false;state.schemas=state.schemas.map(schema=>{if(schema.summaryOnly===true){if(!schemaStore.referenceValid(schema)){changed=true;return {...Object.fromEntries(['bindingId','shopId','region','categoryPath','readAt','source'].map(key=>[key,schema[key]])),fields:[],complete:false,status:'needs_review',reasonCode:'category_read_incomplete',draftComplete:false,issues:['类目缓存索引损坏，请重新读取该细分类目。'],lastReadFailure:{code:'PUBLISH_SCHEMA',failedAt:timestamp(now)}};}return schema;}if(Object.hasOwn(schema,'lastReadFailure'))return schema;const normalized=normalizeSchemaReadiness(schema);if(JSON.stringify(normalized)!==JSON.stringify(schema))changed=true;return normalized;});for(const job of state.jobs)for(const target of job.targets)if(target.status==='running'){if(job.action==='save_draft'&&target.phase==='saving_draft')target.diagnostics={...(draftDiagnostics(target.diagnostics)||{}),version:1,draftSaveAttempted:true};if(draftPhases.has(target.phase))target.failedPhase=target.phase;target.status='needs_review';target.phase='interrupted';target.error={code:'PUBLISH_REVIEW',message:safeMessages.PUBLISH_REVIEW};aggregate(job);changed=true;}await mkdir(assetRoot,{recursive:true});loaded=true;if(changed)await safePersist();})();try{await loading;}finally{loading=undefined;}}
  async function hydrate(product,{fillOnly=false}={}){const entries=assetMap();async function local(asset){const item=entries.get(asset.assetId);if(!item||!/^[a-f0-9]{64}\.(?:png|jpg|mp4|mov|mkv|avi)$/u.test(item.filename))throw fail('PUBLISH_ASSET','主机商品原件不可用，请重新上传。');const path=resolve(assetRoot,item.filename);if(!path.startsWith(assetRoot+sep))throw fail('PUBLISH_ASSET','主机商品原件路径无效。');await verifyAssetFile(path,item).catch(()=>{throw fail('PUBLISH_ASSET','主机商品原件已丢失或变化，请重新上传。');});return {...asset,localPath:path,mime:item.mime,size:item.size};}return {...structuredClone(product),assets:await Promise.all(product.assets.map(local)),video:product.video?await local(product.video):null,_publishAuthorized:!fillOnly};}
  function reusableProduct(job){
    try{
      // Historical jobs contain frozen business data, never the editable print
      // snapshots. Copy only known workbench fields, not platform receipts/IDs.
      const source=productData(job.product,assetMap(),{forSubmission:false}),product={...source,profile:pickBusinessFields(source.profile,reusableProfileKeys),
        variants:source.variants.map(value=>{if(!plain(value))throw reuseUnavailable();const variant=pickBusinessFields(value,reusableVariantKeys);if(value.sizeOverrides!==undefined){if(!plain(value.sizeOverrides))throw reuseUnavailable();variant.sizeOverrides=Object.fromEntries(Object.entries(value.sizeOverrides).map(([size,row])=>{if(!plain(row))throw reuseUnavailable();return [size,pickBusinessFields(row,reusableRowKeys)];}));}return variant;}),
        assets:source.assets.map(value=>pickBusinessFields(value,reusableAssetKeys)),video:source.video?pickBusinessFields(source.video,['id','name','assetId']):null};
      const ids=new Set(product.assets.map(value=>value.id));
      for(const variant of product.variants){if(variant.images!==undefined&&!Array.isArray(variant.images))throw reuseUnavailable();for(const id of [...(variant.images||[]),...(variant.exportAssetId?[variant.exportAssetId]:[])])if(!ids.has(id))throw reuseUnavailable();}
      return product;
    }catch{throw reuseUnavailable();}
  }
  async function reusableMedia(product,assetId){
    // The URL is not a disk path. A hash must belong to this exact frozen job,
    // even when another job uploaded an otherwise valid local asset.
    const referenced=product.assets.some(value=>value.assetId===assetId)||product.video?.assetId===assetId;
    if(!referenced)throw fail('PUBLISH_NOT_FOUND','该任务没有引用此商品原件。',404);
    let handle;
    try{
      const item=assetMap().get(assetId),image=item?.mime==='image/png'||item?.mime==='image/jpeg',video=['video/mp4','video/quicktime','video/x-matroska','video/x-msvideo','video/avi'].includes(item?.mime);
      if(!item||item.id!==assetId||!image&&!video||!Number.isSafeInteger(item.size)||item.size<=0||item.size>(image?10:100)*1024*1024||typeof item.name!=='string'||!text(item.name)||item.name.length>255||/[\\/\u0000-\u001f\u007f]/u.test(item.name)||typeof item.filename!=='string'||!new RegExp('^'+assetId+'\\.(?:png|jpg|mp4|mov|mkv|avi)$','u').test(item.filename))throw reuseUnavailable();
      if(product.assets.some(value=>value.assetId===assetId)&&!image||product.video?.assetId===assetId&&!video)throw reuseUnavailable();
      const path=resolve(assetRoot,item.filename);if(!path.startsWith(assetRoot+sep))throw reuseUnavailable();
      const before=await lstat(path);if(!before.isFile()||before.isSymbolicLink()||before.size!==item.size)throw reuseUnavailable();
      handle=await open(path,'r');const opened=await handle.stat();
      const sameFile=info=>info.isFile()&&info.size===before.size&&info.dev===before.dev&&info.ino===before.ino&&info.mtimeMs===before.mtimeMs&&info.ctimeMs===before.ctimeMs;
      if(!sameFile(opened))throw reuseUnavailable();
      const bytes=Buffer.alloc(item.size+1);let count=0;
      while(count<bytes.length){const result=await handle.read(bytes,count,bytes.length-count,count);if(!result.bytesRead)break;count+=result.bytesRead;}
      const after=await handle.stat(),current=await lstat(path);
      if(count!==item.size||!sameFile(after)||!sameFile(current)||current.isSymbolicLink())throw reuseUnavailable();
      const content=bytes.subarray(0,count),extension=assetType(item.mime,content);
      if(item.filename!==assetId+'.'+extension||sha(content)!==assetId)throw reuseUnavailable();
      return {bytes:content,metadata:{assetId,name:item.name,mime:item.mime,size:item.size},extension};
    }catch{throw reuseUnavailable();}finally{if(handle)await handle.close().catch(()=>{});}
  }
  async function reuseJob(job){
    const product=reusableProduct(job),media=[];
    for(const assetId of new Set([...product.assets.map(value=>value.assetId),...(product.video?[product.video.assetId]:[])]))media.push((await reusableMedia(product,assetId)).metadata);
    return {product,source:{jobId:job.id,action:job.action||'publish',status:job.status,name:product.name,createdAt:job.createdAt,updatedAt:job.updatedAt},bindingIds:[...new Set((job.targets||[]).map(value=>value.bindingId).filter(validId))],media};
  }
  async function execute(job,target){
    const binding=bindingFor(target.bindingId);
    const recordPhase=phase=>{target.phase=phase;if(draftPhases.has(phase)){const at=timestamp(now),history=Array.isArray(target.phaseHistory)?target.phaseHistory:[];if(history.at(-1)?.phase!==phase)target.phaseHistory=[...history,{phase,at}].slice(-24);target.updatedAt=at;job.updatedAt=at;}};
    const recordDiagnostics=value=>{const next=draftDiagnostics(value);if(!next)return;const previous=draftDiagnostics(target.diagnostics)||{};target.diagnostics={...previous,...next,...(previous.draftSaveAttempted===true?{draftSaveAttempted:true}:{}),...(previous.recoveryAttempts>Number(next.recoveryAttempts||0)?{recoveryAttempts:previous.recoveryAttempts}:{})};};
    controller=new AbortController();target.status='running';recordPhase('connecting');target.startedAt=timestamp(now);aggregate(job);await safePersist();let publishStarted=false;const saveRemoteDraft=job.action==='save_draft',fillOnly=saveRemoteDraft||job.action==='fill_draft';
    try{
      if(!binding)throw fail('PUBLISH_BINDING_CHANGED',safeMessages.PUBLISH_BINDING_CHANGED,409);
      const expected=target.expectedBinding;
      if(fillOnly&&!expected||expected&&(!plain(expected)||expected.environmentId!==binding.environmentId||canonical(expected.identity)!==canonical(binding.identity)||saveRemoteDraft&&canonical(expected.mainCategory)!==canonical(binding.mainCategory)||expected.categoryAccess!==undefined&&canonical(expected.categoryAccess)!==canonical(categoryAccessView(binding))))throw fail('PUBLISH_BINDING_CHANGED',safeMessages.PUBLISH_BINDING_CHANGED,409);
      const frozenBinding=canonical([binding.environmentId,binding.identity,binding.mainCategory,categoryAccessView(binding)]);
      const assertCurrentBinding=()=>{const current=bindingFor(target.bindingId);if(!current||!verifiedBinding(current)||canonical([current.environmentId,current.identity,current.mainCategory,categoryAccessView(current)])!==frozenBinding)throw fail('PUBLISH_BINDING_CHANGED',safeMessages.PUBLISH_BINDING_CHANGED,409);assertCategoryScope(current,job.product.profile.category);};assertCurrentBinding();
      assertCategoryScope(binding,job.product.profile.category);
      if(prebuiltOnly){if(job.action==='publish')throw fail('PUBLISH_SCHEMA','内置类目资料只用于草稿，不能自动发布商品。',409);catalog.readLeaf(binding,job.product.profile.category);if(!rpa?.verifyShop)throw fail('PUBLISH_UNAVAILABLE','当前程序缺少商品页核对能力；不会为同步商品重复读取商家主页。',503);}
      const {environment,connection}=await ads.connectEnvironment(binding.environmentId);assertCurrentBinding();if(hasAllCategoryAccess(binding)&&!hasAllCategoryAccess({...binding,environment:publicEnvironment(environment)}))throw fail('PUBLISH_BINDING_CHANGED',safeMessages.PUBLISH_BINDING_CHANGED,409);if(controller.signal.aborted)throw fail('PUBLISH_CANCELLED','任务已取消。');
      recordPhase('verifying-shop');await safePersist();
      if(prebuiltOnly&&!rpa?.verifyShop)throw fail('PUBLISH_UNAVAILABLE','当前程序缺少商品页核对能力；不会为同步商品重复读取商家主页。',503);
      if(!(rpa?.verifyShop||rpa?.inspect)||!(saveRemoteDraft?rpa?.saveDraft:fillOnly?rpa?.fillDraft:rpa?.publish))throw fail('PUBLISH_UNAVAILABLE',safeMessages.PUBLISH_UNAVAILABLE,503);
      const current=inspectedIdentity(await (rpa.verifyShop||rpa.inspect).call(rpa,{environment,connection,binding:structuredClone(binding),signal:controller.signal}),{environment,previous:binding,pairedPage:true,verificationRead:true});assertCurrentBinding();if(!sameIdentity(current,binding.identity))throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
      const checkedMapping=mappedProductFields(job.product,binding,{fillOnly,persistent:saveRemoteDraft}),derived=fillOnly?job.targetMappings?.[binding.id]:checkedMapping;if(fillOnly&&(!derived||canonical(derived)!==canonical(checkedMapping)))throw fail('PUBLISH_SCHEMA','保存任务的目标店铺字段已变化，请重新读取并保存后再填写。',409);const product={...await hydrate(job.product,{fillOnly}),...derived};assertCurrentBinding();if(controller.signal.aborted)throw fail('PUBLISH_CANCELLED','任务已取消。');
      recordPhase('preparing');await safePersist();assertCurrentBinding();if(controller.signal.aborted)throw fail('PUBLISH_CANCELLED','任务已取消。');publishStarted=true;
      const result=await (saveRemoteDraft?rpa.saveDraft:fillOnly?rpa.fillDraft:rpa.publish).call(rpa,{connection,binding:structuredClone(binding),product,assetRoot,signal:controller.signal,onPhase:async(value,detail)=>{assertCurrentBinding();const phase=typeof value==='string'?value:value?.phase;if(typeof phase==='string'&&/^[a-z][a-z0-9_-]{0,50}$/u.test(phase)){recordPhase(phase);if(saveRemoteDraft&&phase==='saving_draft')recordDiagnostics({draftSaveAttempted:true});recordDiagnostics(typeof value==='string'?detail?.diagnostics:value?.diagnostics);await safePersist();assertCurrentBinding();}}});
      assertCurrentBinding();
      recordDiagnostics(result?.diagnostics);
      if(fillOnly){
        if(plain(result)){target.fillIssues=schemaIssues(result.issues||[]);target.pageRetained=result.pageRetained===true;}
        if(saveRemoteDraft){
          if(!plain(result)||result.status!=='draft_saved'||result.pageRetained!==true||!plain(result.receipt)||result.receipt.status!=='draft_saved'||result.receipt.submitted!==false||result.receipt.draftSaved!==true||result.receipt.saveAcknowledged!==true||result.receipt.source!=='visible-seller-dom'
            ||result.receipt.shopId!==binding.identity.shopId||result.receipt.region!==binding.identity.region||canonical(result.receipt.categoryPath)!==canonical(derived.categoryPath)||!Array.isArray(result.checks)||!result.checks.length||result.checks.some(item=>item.ok!==true))throw fail('PUBLISH_REVIEW','TikTok 草稿保存结果尚未确认，请到对应店铺草稿箱检查。',409);
          target.status='draft_saved';target.phase='awaiting-review';target.receipt={status:'draft_saved',submitted:false,draftSaved:true,saveAcknowledged:true,source:'visible-seller-dom',pageRetained:true,shopId:binding.identity.shopId,region:binding.identity.region,categoryPath:structuredClone(derived.categoryPath),...(validId(result.receipt.draftId)?{draftId:result.receipt.draftId}:{}),confirmedAt:timestamp(now),sourceDraft:structuredClone(job.sourceDraft)};return;
        }
        if(!plain(result)||result.status!=='filled'||result.pageRetained!==true||!plain(result.receipt)||result.receipt.status!=='filled'||result.receipt.submitted!==false
          ||result.receipt.shopId!==binding.identity.shopId||result.receipt.region!==binding.identity.region||canonical(result.receipt.categoryPath)!==canonical(derived.categoryPath)||!Array.isArray(result.checks)||!result.checks.length||result.checks.some(item=>item.ok!==true))
          throw fail('PUBLISH_REVIEW','商品填写尚未完整确认，请到对应店铺页面检查已填内容。',409);
        target.status='filled';target.phase='awaiting-review';target.receipt={status:'filled',submitted:false,pageRetained:true,shopId:binding.identity.shopId,region:binding.identity.region,categoryPath:structuredClone(derived.categoryPath),confirmedAt:timestamp(now),sourceDraft:structuredClone(job.sourceDraft)};
        return;
      }
      if(!plain(result)||!['succeeded','published','success'].includes(result.status)||!validId(result.productId))throw fail('PUBLISH_REVIEW',safeMessages.PUBLISH_REVIEW,409);
      target.status='succeeded';target.phase='completed';target.productId=result.productId;
      if(typeof result.url==='string'){try{const url=new URL(result.url);if(url.protocol==='https:'&&/(?:^|\.)tiktok(?:shopglobalselling)?\.com$/u.test(url.hostname)&&!url.username&&!url.password)target.url=url.href;}catch{}}
      target.receipt={status:'succeeded',productId:result.productId,confirmedAt:timestamp(now)};
    }catch(error){recordDiagnostics(error?.diagnostics);const stoppedPhase=target.diagnostics?.code&&draftPhases.has(target.diagnostics.phase)?target.diagnostics.phase:target.phase;if(draftPhases.has(stoppedPhase))target.failedPhase=stoppedPhase;if(!publishStarted&&['PUBLISH_IDENTITY','PUBLISH_STORE_UNVERIFIED'].includes(error?.code))invalidateBindings(item=>item.environmentId===binding?.environmentId,error.code);target.status=publishStarted||error?.code==='PUBLISH_BINDING_CHANGED'?'needs_review':controller.signal.aborted?'cancelled':'failed';target.error=publishStarted?{code:'PUBLISH_REVIEW',message:fillOnly?(target.fillIssues?.length?'填写未完成：'+target.fillIssues[0]+'；未执行发布。':'填写结果需要人工检查，请到对应店铺查看；未执行发布。'):safeMessages.PUBLISH_REVIEW}:publicError(error);target.phase=target.status;}
    finally{target.finishedAt=timestamp(now);aggregate(job);await safePersist();controller=null;}
  }
  function schedule(){if(closed||configuring||worker)return;worker=Promise.resolve().then(async()=>{await load();while(!closed){const job=state.jobs.find(item=>item.targets.some(target=>target.status==='queued'));if(!job)break;const target=job.targets.find(item=>item.status==='queued');if(job.cancelRequested){target.status='cancelled';target.phase='cancelled';aggregate(job);await safePersist();continue;}await execute(job,target);}}).catch(()=>{}).finally(()=>{worker=null;});}
  async function status(){await load();const config=await settings.publicStatus();return {...config,...(prebuiltOnly?{categoryDataSource:'builtin-category-library',builtinCatalog:catalog.metadata()}:{}),available:Boolean(rpa?.inspect&&rpa?.publish),assetUpload:true,fillDraftAvailable:Boolean(rpa?.inspect&&rpa?.fillDraft),saveDraftAvailable:Boolean(rpa?.inspect&&rpa?.saveDraft),taskCounts:Object.fromEntries(['queued','running','succeeded','filled','draft_saved','failed','needs_review','cancelled'].map(key=>[key,state.jobs.filter(job=>job.status===key).length]))};}
  async function pairShop(environmentId,{force=false}={}){
    const cached=state.bindings.find(item=>item.environmentId===environmentId&&verifiedBinding(item)&&hasShopProfile(item));
    if(cached&&!force)return {binding:bindingView(cached),reused:true};
    if(pairing.has(environmentId))return pairing.get(environmentId);
    const operation=(async()=>{
      let environment,result,actual;const previous=state.bindings.find(item=>item.environmentId===environmentId&&verifiedBinding(item));
      try{if(!rpa?.inspect)throw fail('PUBLISH_UNAVAILABLE',safeMessages.PUBLISH_UNAVAILABLE,503);const connected=await ads.connectEnvironment(environmentId);environment=connected.environment;result=await rpa.inspect({environment,connection:connected.connection});actual=inspectedIdentity(result,{environment,previous});}
      catch(error){if(invalidateBindings(item=>item.environmentId===environmentId,error?.code))await safePersist();throw error;}
      const mainCategory=normalizedMainCategory(result.mainCategory,timestamp(now));if(!mainCategory||result.status!==undefined&&result.status!=='ready'||result.complete===false)throw fail('PUBLISH_CATEGORY_SCOPE','尚未从商家主页完整读取并确认店铺主营类目，请检查页面加载后重新配对。',409);
      if(actual.idKind==='profile-environment'&&previous&&previous.identity.idKind!=='profile-environment'&&previous.identity.shopName===actual.shopName&&previous.identity.region===actual.region)actual=structuredClone(previous.identity);
      const id='shop-'+sha(canonical([environment.id,actual.shopId,actual.region])).slice(0,40),existing=bindingFor(id);
      invalidateBindings(item=>item.environmentId===environment.id&&!sameIdentity(item.identity,actual),'PUBLISH_IDENTITY');
      if(existing&&!sameIdentity(existing.identity,actual))for(const schema of state.schemas)if(schema.shopId===existing.identity.shopId&&schema.region===existing.identity.region){schema.complete=false;schema.status='needs_review';schema.reasonCode='identity_mismatch';schema.issues=['店铺标识类型已变化，请重新读取真实类目属性。'];}
      const binding={id,environmentId:environment.id,environment:publicEnvironment(environment),identity:actual,mainCategory,profileStatus:'ready',capabilities:capabilitySummary(result.capabilities),verificationStatus:'verified',verifiedAt:timestamp(now),createdAt:existing?.createdAt||timestamp(now)};
      state.bindings=state.bindings.filter(item=>item.id!==id);state.bindings.push(binding);await safePersist();return {binding:bindingView(binding),reused:false};
    })();pairing.set(environmentId,operation);try{return await operation;}finally{if(pairing.get(environmentId)===operation)pairing.delete(environmentId);}
  }
  async function readCatalog(binding,parent,{force=false,synchronize=false}={}){
    if(prebuiltOnly){if(!verifiedBinding(binding)||!hasShopProfile(binding))throw fail('PUBLISH_CATEGORY_SCOPE','请先读取并保存该店铺名称和主营类目。',403);if(force)catalog.refresh();const result=catalog.branch(binding,parent),view=bindingView(binding);return {catalog:result,binding:view,categorySync:view.categorySync,reused:true,source:'builtin-category-library'};}
    if(!verifiedBinding(binding))throw fail('PUBLISH_IDENTITY','请先绑定并确认真实店铺。',409);
    if(!hasShopProfile(binding))throw fail('PUBLISH_CATEGORY_SCOPE','请先读取并保存店铺主营类目。',403);
    if(parent.length)assertCategoryScope(binding,parent);
    let view=treeView(binding);
    const cached=view.catalogs.find(item=>canonical(item.parentPath)===canonical(parent));
    if(!force&&(!synchronize&&cached?.complete||synchronize&&view.sync.complete&&view.sync.rootCatalogComplete))return {catalog:cached||view.catalogs[0],binding:bindingView(binding),categorySync:view.sync,reused:true};
    if(!parent.length&&!synchronize&&!force)return {catalog:view.catalogs[0],binding:bindingView(binding),categorySync:view.sync,reused:true};
    const key=binding.id;if(categorySyncing.has(key))return categorySyncing.get(key);
    const operation=(async()=>{
      const frozen=canonical([binding.environmentId,binding.identity,binding.mainCategory]);
      if(force){state.categoryTrees=state.categoryTrees.filter(item=>!(item.region===binding.identity.region&&item.mainCategory===binding.mainCategory.label&&(!parent.length||parent.every((part,index)=>item.parentPath[index]===part))));view=categoryTreeView(state.categoryTrees,binding,timestamp(now));}
      if(!(rpa?.readCategoryTree||rpa?.readCategories))throw fail('PUBLISH_UNAVAILABLE','当前主机尚不支持读取店铺类目。',503);
      const {connection}=await ads.connectEnvironment(binding.environmentId);let issues=[],read=0;
      const checkBinding=()=>{const current=bindingFor(binding.id);if(!current||canonical([current.environmentId,current.identity,current.mainCategory])!==frozen)throw fail('PUBLISH_BINDING_CHANGED',safeMessages.PUBLISH_BINDING_CHANGED,409);};
      if(synchronize&&rpa.readCategories&&!state.categoryRoots.some(item=>plain(item)&&item.region===binding.identity.region&&item.complete===true)){
        const roots=await rpa.readCategories({connection,binding:structuredClone(binding),parentPath:[]});checkBinding();
        if(!sameIdentity(inspectedIdentity(roots,{environment:{id:binding.environmentId},previous:binding,pairedPage:true}),binding.identity))throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
        const valid=roots.complete===true&&roots.status==='ready'&&roots.leaf===false&&Array.isArray(roots.nodes)&&roots.nodes.length>0&&roots.nodes.length<=2000&&canonical(roots.parentPath)===canonical([])&&new Set(roots.nodes.map(node=>node.label)).size===roots.nodes.length&&roots.nodes.every(node=>plain(node)&&typeof node.label==='string'&&node.label.trim()===node.label&&node.label.length>0&&node.label.length<=160&&!/[\u0000-\u001f\u007f]/u.test(node.label)&&typeof node.disabled==='boolean'&&canonical(node.path)===canonical([node.label]));
        if(valid){state.categoryRoots=state.categoryRoots.filter(item=>item.region!==binding.identity.region);state.categoryRoots.push({region:binding.identity.region,complete:true,readAt:timestamp(now),source:'live-shop-category-menu',nodes:roots.nodes.map(node=>({label:node.label,path:[node.label],disabled:node.disabled}))});}else issues.push(...schemaIssues(roots.issues||['全部大类菜单尚未完整读取。']));
      }
      if(synchronize&&rpa.readCategoryTree){
        const observed=await rpa.readCategoryTree({connection,binding:structuredClone(binding),cachedCatalogs:structuredClone(view.catalogs),maxBranches:20});checkBinding();
        if(!sameIdentity(inspectedIdentity(observed,{environment:{id:binding.environmentId},previous:binding,pairedPage:true}),binding.identity))throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
        if(!Array.isArray(observed.catalogs)||observed.catalogs.length>20000)throw fail('PUBLISH_SCHEMA','主营类目分支读取结果无效。',409);
        for(const catalog of observed.catalogs){if(plain(catalog)&&catalog.complete===true&&validCategoryBranch(catalog,binding,catalog.parentPath)){storeBranch(binding,catalog,catalog.parentPath);read++;}else issues.push(...schemaIssues(catalog?.issues||['部分主营类目分支尚未完整读取。']));}issues.push(...schemaIssues(observed.issues));
      }else{
        let paths=synchronize?view.pendingPaths:parent.length?[parent]:view.pendingPaths;
        for(let index=0;index<20&&paths.length;index++){
          const path=paths[0],observed=await rpa.readCategories({connection,binding:structuredClone(binding),parentPath:path});checkBinding();
          if(!sameIdentity(inspectedIdentity(observed,{environment:{id:binding.environmentId},previous:binding,pairedPage:true}),binding.identity))throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
          const valid=validCategoryBranch(observed,binding,path);if(!valid){issues.push(...schemaIssues(observed?.issues||['店铺类目分支尚未完整读取。']));break;}storeBranch(binding,observed,path);read++;
          paths=synchronize?categoryTreeView(state.categoryTrees,binding,timestamp(now)).pendingPaths:[];
        }
      }
      binding.categorySyncIssues=issues;await safePersist();const latest=bindingView(binding);latest.categorySync.issues=issues;
      return {catalog:latest.categoryCatalog.find(item=>canonical(item.parentPath)===canonical(parent))||{shopId:binding.identity.shopId,region:binding.identity.region,parentPath:parent,complete:false,leaf:false,nodes:[],issues},binding:latest,categorySync:{...latest.categorySync,branchesRead:read},reused:false};
    })();categorySyncing.set(key,operation);try{return await operation;}finally{if(categorySyncing.get(key)===operation)categorySyncing.delete(key);}
  }
  function schemaSyncView(binding){
    if(prebuiltOnly){const meta=catalog.bindingStatus(binding);return {complete:meta.status==='ready',totalLeaves:meta.leafCount||0,completedLeaves:meta.completeLeafCount||0,pendingLeaves:0,failedLeaves:meta.status==='ready'?0:1,issues:meta.issues||[],pendingPaths:[],source:'builtin-category-library'};}
    const tree=categoryTreeView(state.categoryTrees,binding,timestamp(now)),leaves=tree.catalogs.filter(item=>item.leaf).map(item=>item.parentPath.join(' > '));
    const failures=(binding.schemaSyncFailures||[]).filter(item=>leaves.includes(item.categoryPath)),failedPaths=new Set(failures.map(item=>item.categoryPath));
    let completedLeaves=0;const pendingPaths=[];
    for(const path of leaves){let complete=false;try{const record=state.schemas.find(item=>item.bindingId===binding.id&&item.shopId===binding.identity.shopId&&item.region===binding.identity.region&&item.categoryPath===path);complete=record?.summaryOnly===true?record.draftComplete===true&&!Object.hasOwn(record,'lastReadFailure')&&schemaStore.summaryAvailable(record):draftSchemaComplete(cachedFillSchema(binding,path,{persistent:true}),binding);}catch{}if(complete)completedLeaves++;else if(!failedPaths.has(path))pendingPaths.push(path);}
    return {complete:tree.sync.complete&&leaves.length>0&&completedLeaves===leaves.length,totalLeaves:leaves.length,completedLeaves,pendingLeaves:pendingPaths.length,failedLeaves:failures.length,issues:failures.map(item=>({categoryPath:item.categoryPath,code:item.code,message:item.message})),pendingPaths};
  }
  async function readSchema(binding,path,{force=false,connection}={}){
    if(prebuiltOnly){if(force)catalog.refresh();return projectedBuiltinSchema(binding,path);}
    assertCategoryScope(binding,path);if(!verifiedBinding(binding))throw fail('PUBLISH_IDENTITY','绑定店铺需要重新核验。',409);
    const existing=state.schemas.find(item=>item.bindingId===binding.id&&item.shopId===binding.identity.shopId&&item.region===binding.identity.region&&item.categoryPath===path);
    if(!force&&existing&&!Object.hasOwn(existing,'lastReadFailure')){const cached=cacheView(existing,binding);if(cached.draftComplete===true)return cached;}
    try{
      if(!rpa?.readCategory)throw fail('PUBLISH_UNAVAILABLE','当前后台尚不支持读取店铺属性。',503);if(!connection)({connection}=await ads.connectEnvironment(binding.environmentId));
      const frozen=canonical([binding.environmentId,binding.identity,binding.mainCategory]),observed=await rpa.readCategory({connection,binding:structuredClone(binding),categoryPath:path}),claimsReady=observed?.status==='ready'||observed?.complete===true,claimsFieldScope=observed?.attributeReadEvidence!==undefined;
      if(canonical([bindingFor(binding.id)?.environmentId,bindingFor(binding.id)?.identity,bindingFor(binding.id)?.mainCategory])!==frozen)throw fail('PUBLISH_BINDING_CHANGED',safeMessages.PUBLISH_BINDING_CHANGED,409);
      if(observed?.reasonCode==='identity_mismatch')throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);if(['identity_missing','login_required'].includes(observed?.reasonCode))throw Object.assign(fail('PUBLISH_STORE_UNVERIFIED',safeMessages.PUBLISH_STORE_UNVERIFIED,409),inspectionDetails(observed));if((claimsReady||claimsFieldScope||observed?.identity!==undefined)&&!sameIdentity(inspectedIdentity(observed,{environment:{id:binding.environmentId},previous:binding,pairedPage:true}),binding.identity))throw fail('PUBLISH_IDENTITY',safeMessages.PUBLISH_IDENTITY,409);
      if(((claimsReady||claimsFieldScope)&&observed?.categoryPath===undefined)||(observed?.categoryPath!==undefined&&categoryPath(observed.categoryPath)!==path))throw fail('PUBLISH_SCHEMA','读取到的实际类目缺失或与所选类目不一致，请重新读取。',409);
      const pairedProof=pairedIdentityEvidence(observed,{id:binding.environmentId},binding);let schema={...schemaData(observed,path),bindingId:binding.id,shopId:binding.identity.shopId,region:binding.identity.region,readAt:timestamp(now),...(pairedProof?{pairedIdentityEvidence:pairedProof}:{})};
      if(observed.source==='visible-seller-dom-and-category-api'&&schema.attributeReadEvidence){const candidate={...schema,fieldEditingScope:{version:1,source:observed.source,bindingId:binding.id,shopId:binding.identity.shopId,region:binding.identity.region,categoryPath:path,categoryId:schema.attributeReadEvidence.categoryId,readAt:schema.readAt,...(binding.identity.idKind?{idKind:binding.identity.idKind}:{})}};if(fieldScopeVerified(candidate,binding,Date.parse(timestamp(now))))schema=candidate;}
      schema=fieldEditingView(schema,binding,Date.parse(timestamp(now)));schema={...schema,draftComplete:draftSchemaComplete(schema,binding)};state.schemas=state.schemas.filter(item=>!(item.shopId===schema.shopId&&item.region===schema.region&&item.categoryPath===path));state.schemas.push(schema);binding.schemaSyncFailures=(binding.schemaSyncFailures||[]).filter(item=>item.categoryPath!==path);await safePersist();return cacheView(state.schemas.find(item=>item.bindingId===binding.id&&item.shopId===binding.identity.shopId&&item.region===binding.identity.region&&item.categoryPath===path),binding);
    }catch(error){const changed=['PUBLISH_IDENTITY','PUBLISH_STORE_UNVERIFIED'].includes(error?.code)?invalidateBindings(item=>item.environmentId===binding.environmentId,error.code):failedSchemaRead(binding,path,error);if(changed)await safePersist();throw error;}
  }
  async function synchronizeSchemas(binding,{force=false}={}){
    if(prebuiltOnly){if(!verifiedBinding(binding)||!hasShopProfile(binding))throw fail('PUBLISH_CATEGORY_SCOPE','请先读取并保存店铺名称和主营类目。',403);if(force)catalog.refresh();const meta=catalog.bindingStatus(binding);if(meta.status!=='ready')catalog.branch(binding,[]);const view=bindingView(binding);return {schemas:[],binding:view,schemaSync:view.schemaSync,reused:true,source:'builtin-category-library'};}
    if(!verifiedBinding(binding)||!hasShopProfile(binding))throw fail('PUBLISH_CATEGORY_SCOPE','请先完成店铺主营类目的首次配对。',403);
    if(schemaSyncing.has(binding.id))return schemaSyncing.get(binding.id);
    const operation=(async()=>{
      if(force){binding.schemaSyncFailures=[];await safePersist();}const progress=schemaSyncView(binding),schemas=[];
      if(progress.pendingPaths.length){const {connection}=await ads.connectEnvironment(binding.environmentId);for(const path of progress.pendingPaths.slice(0,3)){
        try{const schema=await readSchema(binding,path,{force:true,connection});schemas.push(schema);if(!draftSchemaComplete(schema,binding))throw fail('PUBLISH_SCHEMA','该细分类目的属性、必填规则或下拉选项尚未完整读取。',409);}
        catch(error){const safe=publicError(error);binding.schemaSyncFailures=(binding.schemaSyncFailures||[]).filter(item=>item.categoryPath!==path);binding.schemaSyncFailures.push({categoryPath:path,code:safe.code,message:safe.message,failedAt:timestamp(now)});await safePersist();if(['PUBLISH_IDENTITY','PUBLISH_STORE_UNVERIFIED','PUBLISH_BINDING_CHANGED'].includes(error.code))break;}
      }}
      const view=bindingView(binding);return {schemas:structuredClone(schemas),binding:view,schemaSync:view.schemaSync};
    })();schemaSyncing.set(binding.id,operation);try{return await operation;}finally{if(schemaSyncing.get(binding.id)===operation)schemaSyncing.delete(binding.id);}
  }
  async function uploadAsset(req){
    const mime=String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase(),image=['image/png','image/jpeg'].includes(mime),video=['video/mp4','video/quicktime','video/x-matroska','video/x-msvideo','video/avi'].includes(mime);
    if(!image&&!video)throw fail('PUBLISH_ASSET','仅支持 PNG/JPEG 图片和 MP4/MOV/MKV/AVI 视频。');let name;try{name=decodeURIComponent(req.headers['x-pod-filename']||'');}catch{throw fail('PUBLISH_ASSET','上传原件名称无效。');}if(!name||name.length>255||/[\\/\u0000-\u001f\u007f]/u.test(name))throw fail('PUBLISH_ASSET','上传原件名称无效。');
    const uploaded=await spoolAsset(req,assetRoot,(image?10:100)*1024*1024);
    try{const extension=assetType(mime,uploaded.header),id=uploaded.id,filename=id+'.'+extension;let record=state.assets.find(item=>item.id===id);if(record&&record.mime!==mime)throw fail('PUBLISH_ASSET','相同原件的格式声明不一致。');
      const path=join(assetRoot,filename);let exists=false;try{await stat(path);exists=true;}catch(error){if(error.code!=='ENOENT')throw fail('PUBLISH_STORAGE',safeMessages.PUBLISH_STORAGE,503);}
      if(exists)await verifyAssetFile(path,{id,size:uploaded.size}).catch(()=>{throw fail('PUBLISH_ASSET','已保存的原件校验失败。');});else await rename(uploaded.temporary,path);
      if(!record){record={id,name,mime,size:uploaded.size,filename,createdAt:timestamp(now)};state.assets.push(record);await safePersist();}return {id:record.id,name,mime:record.mime,size:record.size};
    }finally{await unlink(uploaded.temporary).catch(()=>{});}
  }
  function assertConnectionOpen(){if(closed)throw fail('PUBLISH_UNAVAILABLE','上架服务已停止。',503);if(configuring)throw fail('PUBLISH_CONFLICT','正在保存 AdsPower 配置，请稍后重试。',409);}
  async function configureAdsPower(input){
    assertConnectionOpen();
    if(activeConnections||worker||pairing.size||categorySyncing.size||schemaSyncing.size)throw fail('PUBLISH_CONFLICT','后台正在使用 AdsPower，请等待任务完成后修改配置。',409);
    configuring=true;
    try{await load();if(closed)throw fail('PUBLISH_UNAVAILABLE','上架服务已停止。',503);if(state.jobs.some(j=>j.targets.some(t=>['queued','running'].includes(t.status))))throw fail('PUBLISH_CONFLICT','请等待 AdsPower 排队任务完成后修改配置。',409);const result=await settings.save(input);ads.invalidateCatalog?.();return result;}finally{configuring=false;if(!closed&&state.jobs.some(j=>j.targets.some(t=>t.status==='queued')))schedule();}
  }
  async function probeAdsPower(){assertConnectionOpen();activeConnections++;try{return await ads.status();}finally{activeConnections--;}}
  async function handle(req,res,{isHost=false}={}){
    const url=new URL(req.url,'http://127.0.0.1'),route=req.method+' '+url.pathname;
    const match=url.pathname.match(/^\/__pod\/publishing\/jobs\/([A-Za-z0-9_-]{1,160})(?:\/(cancel))?$/u);
    const reuseMatch=url.pathname.match(/^\/__pod\/publishing\/jobs\/([A-Za-z0-9_-]{1,160})\/reuse$/u),mediaMatch=url.pathname.match(/^\/__pod\/publishing\/jobs\/([A-Za-z0-9_-]{1,160})\/assets\/([a-f0-9]{64})$/u);
    const allowed=new Set(['GET '+PREFIX+'/status','POST '+PREFIX+'/config','GET '+PREFIX+'/environments','POST '+PREFIX+'/shops/inspect','GET '+PREFIX+'/shops','GET '+PREFIX+'/schemas','POST '+PREFIX+'/schemas/read','POST '+PREFIX+'/schemas/synchronize','POST '+PREFIX+'/categories/read','POST '+PREFIX+'/assets','POST '+PREFIX+'/jobs','GET '+PREFIX+'/jobs']);
    if(url.search&&route!=='GET '+PREFIX+'/schemas'||!allowed.has(route)&&!(match&&(req.method==='GET'&&!match[2]||req.method==='POST'&&match[2]==='cancel'))&&!(reuseMatch&&req.method==='POST')&&!(mediaMatch&&req.method==='GET'))return json(res,404,{success:false,code:'PUBLISH_NOT_FOUND',message:'多店铺上架接口不存在。'});
    let connectionHeld=false;
    try{
      if(route!=='POST '+PREFIX+'/config'){assertConnectionOpen();activeConnections++;connectionHeld=true;}
      await load();if(closed)throw fail('PUBLISH_UNAVAILABLE','上架服务已停止。',503);let data;
      if(route==='GET '+PREFIX+'/status')data={...await status(),canConfigure:isHost===true};
      else if(route==='POST '+PREFIX+'/config'){if(!isHost)throw fail('PUBLISH_INVALID','AdsPower API 配置只能在主机修改。',403);data=await configureAdsPower(await requestJSON(req));}
      else if(route==='GET '+PREFIX+'/environments')data={environments:(await ads.listEnvironments()).map(publicEnvironment)};
      else if(route==='POST '+PREFIX+'/shops/inspect'){
        const input=await requestJSON(req);fields(input,['environmentId','force']);if(!validId(input.environmentId)||input.force!==undefined&&typeof input.force!=='boolean')throw fail('PUBLISH_INVALID','请选择有效的 AdsPower 环境。');data=await pairShop(input.environmentId,{force:input.force===true});
      }else if(route==='GET '+PREFIX+'/shops')data={bindings:state.bindings.map(bindingView),schemas:prebuiltOnly?[]:structuredClone(visibleSchemas()),...(prebuiltOnly?{builtinCatalog:catalog.metadata()}:{} )};
      else if(route==='GET '+PREFIX+'/schemas'){
        if([...url.searchParams.keys()].some(key=>!['bindingId','categoryPath'].includes(key)||url.searchParams.getAll(key).length!==1))throw fail('PUBLISH_INVALID','属性缓存检索参数无效。');const bindingId=url.searchParams.get('bindingId'),binding=bindingId?bindingFor(bindingId):null;if(bindingId&&!binding)throw fail('PUBLISH_NOT_FOUND','绑定店铺不存在。',404);const requestedPath=url.searchParams.has('categoryPath')?categoryPath(url.searchParams.get('categoryPath')):null,schemas=prebuiltOnly?(binding&&requestedPath?[projectedBuiltinSchema(binding,requestedPath)]:[]):(binding?state.schemas.filter(schema=>schemaInScope(schema,binding)&&(!requestedPath||schema.categoryPath===requestedPath)).map(schema=>schema.summaryOnly===true&&!requestedPath?summaryView(schema):cacheView(schema,binding)):visibleSchemas()).filter(schema=>!requestedPath||schema.categoryPath===requestedPath);data={schemas:structuredClone(schemas),schema:schemas.length===1?structuredClone(schemas[0]):null};
      }
      else if(route==='POST '+PREFIX+'/categories/read'){
        const input=await requestJSON(req);fields(input,['bindingId','parentPath','force','synchronize']);const binding=bindingFor(input.bindingId);if(!binding)throw fail('PUBLISH_NOT_FOUND','绑定店铺不存在。',404);
        const parent=input.parentPath??[];if(!Array.isArray(parent)||parent.length>9||parent.some(x=>typeof x!=='string'||!x.trim()||x.length>160||/[\u0000-\u001f\u007f]/u.test(x))||['force','synchronize'].some(key=>input[key]!==undefined&&typeof input[key]!=='boolean'))throw fail('PUBLISH_INVALID','类目路径无效。');data=await readCatalog(binding,parent,{force:input.force===true,synchronize:input.synchronize===true});
      }
      else if(route==='POST '+PREFIX+'/schemas/read'){
        const input=await requestJSON(req);fields(input,['bindingId','categoryPath','force']);const binding=bindingFor(input.bindingId);if(!binding)throw fail('PUBLISH_NOT_FOUND','请先读取并绑定真实店铺。',404);if(input.force!==undefined&&typeof input.force!=='boolean')throw fail('PUBLISH_INVALID','刷新参数无效。');data={schema:await readSchema(binding,categoryPath(input.categoryPath),{force:input.force===true})};
      }else if(route==='POST '+PREFIX+'/schemas/synchronize'){
        const input=await requestJSON(req);fields(input,['bindingId','force']);const binding=bindingFor(input.bindingId);if(!binding)throw fail('PUBLISH_NOT_FOUND','绑定店铺不存在。',404);if(input.force!==undefined&&typeof input.force!=='boolean')throw fail('PUBLISH_INVALID','刷新参数无效。');data=await synchronizeSchemas(binding,{force:input.force===true});
      }else if(route==='POST '+PREFIX+'/assets')data={asset:await uploadAsset(req)};
      else if(route==='POST '+PREFIX+'/jobs'){
        const input=await requestJSON(req);fields(input,['requestId','targets','product','action']);if(!['publish','fill_draft','save_draft'].includes(input.action)||!validId(input.requestId)||!Array.isArray(input.targets)||!input.targets.length||input.targets.length>50||new Set(input.targets).size!==input.targets.length||input.targets.some(id=>!validId(id)||!bindingFor(id)))throw fail('PUBLISH_INVALID','请选择 1–50 个已绑定店铺，并明确执行填写或发布。');
        const product=productData(input.product,assetMap());if(['fill_draft','save_draft'].includes(input.action)&&(!validId(product.id)||typeof product.updatedAt!=='string'||!Number.isFinite(Date.parse(product.updatedAt))||!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})$/u.test(product.updatedAt)))throw fail('PUBLISH_INVALID','请先保存商品草稿，再使用该保存结果填写店铺。');const contentHash=sha(canonical({targets:input.targets,product,action:input.action})),existing=state.jobs.find(job=>job.requestId===input.requestId);
        if(existing){if(existing.contentHash!==contentHash)throw fail('PUBLISH_CONFLICT','该发布请求编号已用于其他内容，请重新发起。',409);data={job:publicJob(existing),reused:true};}
        else{const targetMappings={};for(const bindingId of input.targets)targetMappings[bindingId]=mappedProductFields(product,bindingFor(bindingId),{fillOnly:input.action!=='publish',persistent:input.action==='save_draft'});if(state.jobs.length>=10000)throw fail('PUBLISH_INVALID','本机发布任务过多，请先归档历史任务。',409);const createdAt=timestamp(now),job={id:idFactory(),requestId:input.requestId,action:input.action,contentHash,product,...(input.action!=='publish'?{sourceDraft:{id:product.id,updatedAt:product.updatedAt,contentHash:sha(canonical(product))},targetMappings}:{}),status:'queued',targets:input.targets.map(bindingId=>({bindingId,shopName:bindingFor(bindingId).identity.shopName,region:bindingFor(bindingId).identity.region,expectedBinding:{environmentId:bindingFor(bindingId).environmentId,identity:structuredClone(bindingFor(bindingId).identity),...(hasAllCategoryAccess(bindingFor(bindingId))?{categoryAccess:categoryAccessView(bindingFor(bindingId))}:{}),...(input.action==='save_draft'?{mainCategory:structuredClone(bindingFor(bindingId).mainCategory)}:{})},status:'queued',phase:'queued'})),createdAt,updatedAt:createdAt,cancelRequested:false};if(!validId(job.id))throw fail('PUBLISH_STORAGE',safeMessages.PUBLISH_STORAGE,503);state.jobs.push(job);await safePersist();data={job:publicJob(job),reused:false};schedule();}
      }else if(route==='GET '+PREFIX+'/jobs')data={jobs:state.jobs.slice().reverse().map(publicJob)};
      else if(reuseMatch){const input=await requestJSON(req);fields(input,[]);const job=state.jobs.find(item=>item.id===reuseMatch[1]);if(!job)throw fail('PUBLISH_NOT_FOUND','上架任务不存在。',404);data=await reuseJob(job);}
      else if(mediaMatch){const job=state.jobs.find(item=>item.id===mediaMatch[1]);if(!job)throw fail('PUBLISH_NOT_FOUND','上架任务不存在。',404);const media=await reusableMedia(reusableProduct(job),mediaMatch[2]),filename=encodeURIComponent(media.metadata.name).replace(/[!'()*]/gu,char=>'%'+char.charCodeAt(0).toString(16).toUpperCase());res.writeHead(200,{'Content-Type':media.metadata.mime,'Content-Length':media.metadata.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-POD-Content-SHA256':media.metadata.assetId,'Content-Disposition':'attachment; filename="asset-'+media.metadata.assetId+'.'+media.extension+'"; filename*=UTF-8\'\''+filename});return res.end(media.bytes);}
      else if(match){const job=state.jobs.find(item=>item.id===match[1]);if(!job)throw fail('PUBLISH_NOT_FOUND','上架任务不存在。',404);if(req.method==='POST'){const input=await requestJSON(req);fields(input,[]);job.cancelRequested=true;for(const target of job.targets)if(target.status==='queued'){target.status='cancelled';target.phase='cancelled';}if(job.targets.some(target=>target.status==='running'))controller?.abort();aggregate(job);await safePersist();}data={job:publicJob(job)};}
      return json(res,200,{success:true,data});
    }catch(error){const safe=publicError(error);return json(res,[400,401,403,404,409,413,429,503].includes(error.status)?error.status:503,{success:false,...safe,...(isHost&&error.code==='PUBLISH_STORE_UNVERIFIED'?inspectionDetails(error):{})});}finally{if(connectionHeld)activeConnections--;}
  }
  async function ready(){await load();schedule();return status();}
  async function close(){closed=true;ads.close?.();controller?.abort();if(worker)await worker;await persistQueue;}
  return {handle,close,ready,assetRoot,configureAdsPower,probeAdsPower};
}
