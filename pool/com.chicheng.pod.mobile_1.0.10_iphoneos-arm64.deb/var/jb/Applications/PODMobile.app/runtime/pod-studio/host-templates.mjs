import {createHash, randomBytes} from 'node:crypto';
import {lstat, mkdir, open, readFile, readdir, realpath, rename, unlink, writeFile} from 'node:fs/promises';
import {resolve, join, relative, sep, extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {availableParallelism} from 'node:os';
import {Worker, isMainThread, parentPort, workerData} from 'node:worker_threads';
import {inspectHostImage} from './host-materials.mjs';
import {parseTemplateLibraryPath, defaultTemplateRegions, templateGroupKey, validateTemplateCalibration, aspectCompatible, HOST_TEMPLATE_PLACEMENTS, OPTIONAL_TEMPLATE_POSITIONS, TEMPLATE_PRINT_POSITIONS, confirmedTemplatePositions} from './dist/template-library-schema.js';
import {normalizeRegionPreset, regionPresetFilename, MAX_REGION_PRESET_BYTES} from './dist/region-presets.js';
import {universalGeometryKey, universalGeometryName, geometryFullyConfirmed, selectUniversalGeometry} from './dist/universal-region-geometry.js';

const PROJECT = fileURLToPath(new URL('./', import.meta.url));
const MAX_FILES = 10_000, MAX_ENTRIES = 100_000, MAX_BYTES = 25 * 1024 * 1024, MAX_INDEX_BYTES = 16 * 1024 * 1024;
const META = '.pod-template-meta', POSITIONS = TEMPLATE_PRINT_POSITIONS;
const MAX_PRESET_BYTES = MAX_REGION_PRESET_BYTES;
const SCAN_CONCURRENCY = Math.min(4, Math.max(1, availableParallelism() - 1));
const SCAN_WORKER_ROLE = 'pod-template-image-inspector';
const TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
const hex = value => createHash('sha256').update(value).digest('hex');
const token = () => randomBytes(16).toString('hex');
const validId = value => typeof value === 'string' && /^ht-[a-f0-9]{64}$/.test(value);
const validHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const clone = value => JSON.parse(JSON.stringify(value));
const portable = value => value.split(sep).join('/');
const inside = (root, path) => path === root || path.startsWith(root + sep);
const problem = (message, code = 'TEMPLATE_INVALID', status = 400) => Object.assign(new Error(message), {name: 'HostTemplateError', code, status});
const sanitize = cause => cause?.name === 'HostTemplateError' ? cause : problem('主机模板库读写失败，请检查模板目录权限和可用空间。', 'TEMPLATE_ACCESS', 503);
const identity = info => ({size: info.size, mtimeMs: info.mtimeMs, ctimeMs: info.ctimeMs, dev: info.dev, ino: info.ino});
const sameIdentity = (first, second) => ['size', 'mtimeMs', 'ctimeMs', 'dev', 'ino'].every(key => Number.isFinite(first?.[key]) && first[key] === second?.[key]);
const nextNumber = (...values) => Math.max(Date.now(), ...values.filter(Number.isSafeInteger).map(value => value + 1));
const pathId = value => 'ht-' + hex('pod-host-template-v1\0' + (process.platform === 'win32' ? value.toLowerCase() : value));

// Use this shipped module as the worker entry so the launcher and all package
// variants resolve the same validator and image-format limits.
if (!isMainThread && workerData === SCAN_WORKER_ROLE) {
  parentPort.on('message', async input => {
    try {
      const image = Buffer.from(input.buffer, input.byteOffset, input.byteLength);
      const {width, height, mime, bytes} = await inspectHostImage(image);
      parentPort.postMessage({width, height, mime, fileRevision: hex(bytes)});
    } catch (error) {
      if (error?.name !== 'HostMaterialError') throw error;
      parentPort.postMessage({invalid: true});
    }
  });
}

function createScanWorker() {
  const worker = new Worker(new URL(import.meta.url), {workerData: SCAN_WORKER_ROLE, execArgv: []});
  let pending, failure;
  const fail = () => {
    failure ||= problem('模板图片校验线程已停止，请重新扫描。', 'TEMPLATE_SCAN_WORKER', 503);
    pending?.reject(failure);
    pending = null;
  };
  worker.on('error', fail);
  worker.on('exit', fail);
  worker.on('message', result => {
    const work = pending;
    pending = null;
    work?.resolve(result);
  });
  return {
    inspect(bytes) {
      if (failure) return Promise.reject(failure);
      return new Promise((resolve, reject) => {
        pending = {resolve, reject};
        try {
          const owned = Uint8Array.from(bytes);
          worker.postMessage(owned, [owned.buffer]);
        } catch { fail(); }
      });
    },
    close: () => worker.terminate(),
  };
}

function checkedNaming(path) {
  try {return parseTemplateLibraryPath(path);} catch (cause) {throw problem(cause.message, 'TEMPLATE_NAME');}
}
function checkedCalibration(placementId, patch, base) {
  try {return validateTemplateCalibration(placementId, patch, base);} catch (cause) {throw problem(cause.message, 'TEMPLATE_REGION');}
}

/** Project-local, shared templates. Original filenames and images are never changed. */
export function createHostTemplateStore({projectRoot = PROJECT, libraryRoot = resolve(projectRoot, '模板库'), onScanProgress, universalGeometry = false} = {}) {
  let state, loading;
  const protect = action => {
    try {return Promise.resolve(action()).catch(cause => {throw sanitize(cause);});}
    catch (cause) {return Promise.reject(sanitize(cause));}
  };
  const write = (current, action) => {
    const pending = current.queue.then(action).catch(cause => {throw sanitize(cause);});
    current.queue = pending.catch(() => {}); return pending;
  };
  async function metadataDirectory(root, subdirectory = '') {
    let path = root;
    for (const part of [META, ...(subdirectory ? [subdirectory] : [])]) {
      path = join(path, part);
      try {await mkdir(path);} catch (cause) {if (cause.code !== 'EEXIST') throw cause;}
      const info = await lstat(path);
      if (!info.isDirectory() || info.isSymbolicLink() || !inside(root, await realpath(path))) throw problem('模板元数据目录无效，不能使用符号链接或目录联接。', 'TEMPLATE_ACCESS', 503);
    }
    return path;
  }
  async function context() {
    if (state) return state;
    if (loading) return loading;
    loading = (async () => {
      await mkdir(resolve(libraryRoot), {recursive: true});
      const root = await realpath(resolve(libraryRoot));
      if (!(await lstat(root)).isDirectory()) throw problem('模板库目录无效。', 'TEMPLATE_ACCESS', 503);
      const meta = await metadataDirectory(root), indexPath = join(meta, 'index.json');
      const current = {root, meta, indexPath, files: new Map(), calibrations: new Map(), groups: new Map(), masks: new Map(), blanks: new Map(), revision: token(),
        universal: new Map(), universalMigrationCompleted: false, queue: Promise.resolve(), scanPromise: null, needsScan: true, scanning: false, scanProgress: null, scanError: '', scannedAt: null};
      let saved;
      try {
        const info = await lstat(indexPath);
        if (info.isSymbolicLink() || !info.isFile() || info.size > MAX_INDEX_BYTES) throw problem('模板索引文件无效或过大，请保留原文件并检查模板库。', 'TEMPLATE_ACCESS', 503);
        saved = JSON.parse(await readFile(indexPath, 'utf8'));
        if (saved?.version !== 1 || !Array.isArray(saved.files) || saved.files.length > MAX_FILES || !Array.isArray(saved.calibrations) || !Array.isArray(saved.groups) || !Array.isArray(saved.masks) ||
          saved.calibrations.length > MAX_FILES || saved.groups.length > MAX_FILES || saved.masks.length > MAX_FILES ||
          saved.blanks !== undefined && (!Array.isArray(saved.blanks) || saved.blanks.length > MAX_FILES)) throw problem('模板索引版本或数据无效，请保留原文件并检查模板库。', 'TEMPLATE_ACCESS', 503);
      } catch (cause) {
        if (cause.code !== 'ENOENT') throw cause?.name === 'HostTemplateError' ? cause : problem('模板索引无法读取，请保留原文件并检查目录权限。', 'TEMPLATE_ACCESS', 503);
      }
      if (saved) {
        if (/^[a-f0-9]{32}$/.test(saved.revision || '')) current.revision = saved.revision;
        if (typeof saved.scannedAt === 'string') current.scannedAt = saved.scannedAt;
        current.universalMigrationCompleted = saved.universalMigrationCompleted === true;
        for (const entry of Array.isArray(saved.universal) ? saved.universal.slice(0, MAX_FILES) : []) {
          try {
            const [key, family] = entry;
            if (!key || universalGeometryKey(family) !== key || !Number.isSafeInteger(family.version) || family.version < 1 || !Array.isArray(family.variants) || !family.variants.length || family.variants.length > 32) continue;
            const variants = family.variants.map(value => {
              const geometry = validUniversalVariant(family, value), anchor = value.anchor ? validUniversalVariant(family, value.anchor) : geometry;
              if (!Number.isSafeInteger(value.revision) || value.revision < 1) throw new Error();
              const refs = {};
              for (const position of confirmedTemplatePositions(family.placementId, geometry)) if (validMaskRef(value.maskRefs?.[position])) refs[position] = value.maskRefs[position];
              return {...geometry, anchor, revision:value.revision, layoutId:/^[a-f0-9]{32}$/.test(value.layoutId||'')?value.layoutId:token(), maskRefs:refs, ...(validHash(value.sourceFileRevision)?{sourceFileRevision:value.sourceFileRevision}:{})};
            });
            current.universal.set(key, {key,style:family.style,placementId:family.placementId,name:universalGeometryName(family),version:family.version,variants});
          } catch {}
        }
        for (const file of saved.files) {
          try {
            const naming = checkedNaming(file.sourcePath);
            if (file.id !== pathId(file.sourcePath) || !validHash(file.fileRevision) || !TYPES.has(file.mime) ||
              !Number.isSafeInteger(file.width) || file.width < 1 || !Number.isSafeInteger(file.height) || file.height < 1 || file.width * file.height > 40_000_000 ||
              !Number.isSafeInteger(file.size) || file.size < 1 || file.size > MAX_BYTES) continue;
            current.files.set(file.id, {...file, ...naming});
          } catch {}
        }
        for (const [id, calibration] of saved.calibrations) {
          if (!validId(id) || !calibration || !validHash(calibration.fileRevision) || !Number.isSafeInteger(calibration.regionRevision) || calibration.regionRevision < 0) continue;
          try {current.calibrations.set(id, {...calibration, ...checkedCalibration(calibration.placementId, calibration)});} catch {}
        }
        for (const [key, group] of saved.groups) {
          if (typeof key !== 'string' || key.length > 2048 || !group || !Array.isArray(group.variants) || group.variants.length > 32) continue;
          const variants = [];
          for (const variant of group.variants) {
            try {
              if (!Number.isSafeInteger(variant.width) || variant.width < 1 || !Number.isSafeInteger(variant.height) || variant.height < 1 || !Number.isSafeInteger(variant.regionRevision)) continue;
              variants.push({...variant, ...checkedCalibration(group.placementId, variant)});
            } catch {}
          }
          current.groups.set(key, {...group, variants});
        }
        for (const [id, entry] of saved.masks) {
          if (!validId(id) || !entry || !validHash(entry.fileRevision) || !entry.positions || typeof entry.positions !== 'object') continue;
          const positions = {};
          for (const position of POSITIONS) {
            const mask = entry.positions[position];
            if (mask?.version === 1 && validHash(mask.blob) && Number.isSafeInteger(mask.width) && Number.isSafeInteger(mask.height) && mask.width > 0 && mask.height > 0 && mask.width <= 2048 && mask.height <= 2048 && mask.width * mask.height <= 4_194_304) positions[position] = mask;
          }
          current.masks.set(id, {...entry, positions});
        }
        for (const [id, entry] of saved.blanks || []) if (validId(id) && validHash(entry?.fileRevision) && typeof entry.verified === 'boolean' && Number.isSafeInteger(entry.updatedAt)) current.blanks.set(id, entry);
      }
      state = current; return current;
    })();
    try {return await loading;} finally {loading = null;}
  }
  async function save(current) {
    await metadataDirectory(current.root);
    const revision = token(), data = JSON.stringify({version: 1, revision, scannedAt: current.scannedAt, files: [...current.files.values()],
      calibrations: [...current.calibrations], groups: [...current.groups], masks: [...current.masks], blanks: [...current.blanks],
      ...(current.universalMigrationCompleted || current.universal.size ? {universalMigrationCompleted:current.universalMigrationCompleted, universal:[...current.universal]} : {})});
    if (Buffer.byteLength(data) > MAX_INDEX_BYTES) throw problem('模板校准索引已达到大小限制，请分开整理模板库。', 'TEMPLATE_LIMIT', 413);
    const temporary = join(current.meta, 'index.' + token() + '.tmp');
    try {await writeFile(temporary, data, {flag: 'wx', mode: 0o600}); await rename(temporary, current.indexPath); current.revision = revision;}
    finally {await unlink(temporary).catch(() => {});}
  }
  async function storedMasks(current,refs,positions) {
    if(!refs||typeof refs!=='object'||Array.isArray(refs)||Object.keys(refs).some(position=>!positions.includes(position)))throw problem('区域文件的遮挡快照无效，请重新保存模板。','TEMPLATE_MASK',503);
    const output={};
    for(const [position,mask] of Object.entries(refs)){
      if(mask?.version!==1||!validHash(mask.blob)||![mask.width,mask.height].every(size=>Number.isSafeInteger(size)&&size>0&&size<=2048))throw problem('区域文件的遮挡快照无效，请重新保存模板。','TEMPLATE_MASK',503);
      const directory=await metadataDirectory(current.root,'masks'),path=join(directory,mask.blob+'.bin'),info=await lstat(path);
      if(!info.isFile()||info.isSymbolicLink()||info.size!==mask.width*mask.height||!inside(current.root,await realpath(path)))throw problem('区域文件的遮挡快照无法读取，请检查模板库。','TEMPLATE_ACCESS',503);
      const bytes=await readFile(path);if(bytes.length!==mask.width*mask.height||hex(bytes)!==mask.blob)throw problem('区域文件的遮挡快照已损坏，请重新保存模板。','TEMPLATE_MASK',503);
      output[position]={version:1,width:mask.width,height:mask.height,encoding:'base64',data:bytes.toString('base64')};
    }
    return output;
  }
  async function presetForGroup(current, key) {
    const group=current.groups.get(key);if(!group)return null;
    let parts;try{parts=JSON.parse(key);}catch{return null;}
    if(!Array.isArray(parts)||parts.length!==3||parts[2]!==group.placementId)return null;
    const variants=[],required=HOST_TEMPLATE_PLACEMENTS[group.placementId];let withMasks=false,updatedAt=0;
    for(const variant of group.variants) {
      if(!required?.every(position=>variant.confirmed?.[position]===true))continue;
      const positions=confirmedTemplatePositions(group.placementId,variant);
      const source={width:variant.width,height:variant.height,updatedAt:variant.updatedAt??variant.regionRevision??0};
      for(const field of ['regions','confirmed','regionModes','printContours'])source[field]=Object.fromEntries(positions.filter(position=>variant[field]?.[position]!==undefined).map(position=>[position,variant[field][position]]));
      const shared=sharedMaskRefs(current,key,variant);
      if(Object.hasOwn(variant,'presetMasks')||Object.keys(shared.refs).length){source.printMasks=await storedMasks(current,shared.refs,positions);withMasks=true;}
      variants.push(source);updatedAt=Math.max(updatedAt,source.updatedAt);
    }
    if(!variants.length)return null;
    try{return normalizeRegionPreset({kind:'pod-print-regions',version:withMasks?2:1,shop:parts[0],style:parts[1],placementId:group.placementId,key,updatedAt,variants});}catch(cause){throw problem(cause.message,'TEMPLATE_REGION',503);}
  }
  // Legacy JSON backups remain available for an unambiguous universal layout.
  // The older portable format cannot represent two layouts of the same ratio.
  async function portableForUniversal(current, template) {
    if(!universalGeometry)return null;
    const family=current.universal.get(universalGeometryKey(template));
    if(!family||family.variants.some((value,index)=>family.variants.slice(0,index).some(other=>aspectCompatible(value,other))))return null;
    const variants=[];
    let updatedAt=0;
    for(const variant of family.variants){
      const positions=confirmedTemplatePositions(family.placementId,variant);
      const source={width:variant.width,height:variant.height,updatedAt:variant.revision};
      for(const field of ['regions','confirmed','regionModes','printContours'])source[field]=Object.fromEntries(positions.filter(position=>variant[field]?.[position]!==undefined).map(position=>[position,variant[field][position]]));
      source.printMasks=await storedMasks(current,variant.maskRefs,positions);
      variants.push(source);updatedAt=Math.max(updatedAt,source.updatedAt);
    }
    return normalizeRegionPreset({kind:'pod-print-regions',version:2,shop:template.shop,style:template.style,placementId:family.placementId,updatedAt,variants});
  }
  async function writePresetArtifact(current, preset) {
    const record=normalizeRegionPreset(preset),directory=await metadataDirectory(current.root,'region-presets'),path=join(directory,record.fileName);
    if(!inside(directory,path)||record.fileName!==path.slice(directory.length+1))throw problem('印花区域文件名无效。','TEMPLATE_NAME');
    const data=JSON.stringify(record,null,2)+'\n';if(Buffer.byteLength(data)>MAX_PRESET_BYTES)throw problem('印花区域文件过大，请拆分款式。','TEMPLATE_LIMIT',413);
    try {
      const info=await lstat(path);if(!info.isFile()||info.isSymbolicLink()||info.size>MAX_PRESET_BYTES||!inside(directory,await realpath(path)))throw problem('印花区域文件无效，不能覆盖符号链接或过大文件。','TEMPLATE_ACCESS',503);
      let existing;const content=await readFile(path,'utf8');try{existing=normalizeRegionPreset(JSON.parse(content));}catch{throw problem('印花区域文件无法读取，请保留原文件并检查模板库。','TEMPLATE_ACCESS',503);}
      if(existing.key!==record.key)throw problem('印花区域文件名称冲突，请保留原文件并调整款式名称。','TEMPLATE_NAME',409);
      if(content===data)return record;
    } catch(cause) {if(cause.code!=='ENOENT')throw cause;}
    const temporary=join(directory,'.preset-'+token()+'.tmp');
    try{await writeFile(temporary,data,{flag:'wx',mode:0o600});await rename(temporary,path);}finally{await unlink(temporary).catch(()=>{});}
    return record;
  }
  async function saveRegionPreset(input) {
    let record;try{record=normalizeRegionPreset(input);}catch(cause){throw problem(cause.message,'TEMPLATE_REGION');}
    if(Buffer.byteLength(JSON.stringify(record))>MAX_PRESET_BYTES)throw problem('印花区域文件过大，请拆分款式。','TEMPLATE_LIMIT',413);
    const current=await ready();
    return write(current,async()=>{
      const old=current.groups.get(record.key);
      if(!old&&current.groups.size>=MAX_FILES)throw problem('印花区域文件数量已达到上限，请整理款式后重试。','TEMPLATE_LIMIT',413);
      const group=clone(old||{placementId:record.placementId,variants:[]}),regionRevision=nextNumber(...group.variants.map(item=>item.regionRevision));
      for(const incoming of record.variants){const index=group.variants.findIndex(item=>aspectCompatible(item,incoming)),next={...checkedCalibration(record.placementId,incoming),width:incoming.width,height:incoming.height,updatedAt:incoming.updatedAt,regionRevision};if(Object.hasOwn(incoming,'printMasks'))next.presetMasks=await storeMasks(current,incoming.printMasks);if(index<0)group.variants.push(next);else group.variants[index]=next;}
      if(group.variants.length>32)throw problem('同款模板的宽高比类型过多，请拆分款式后再校准。','TEMPLATE_LIMIT',413);
      const draft={...current,groups:new Map(current.groups)};draft.groups.set(record.key,group);
      // Validate the complete candidate before committing. Replacing a corrupt
      // or oversized old snapshot remains possible without reading its old blob.
      const combined=await presetForGroup(draft,record.key);await save(draft);current.groups=draft.groups;current.revision=draft.revision;
      // The primary group is already durable. A failed artifact can be repaired by
      // listing or saving again; report that the file is not yet available.
      try{return await writePresetArtifact(current,combined);}catch{throw problem('印花区域已保存，但独立区域文件写入失败；请检查模板目录权限后重新加载区域文件重试。','TEMPLATE_PRESET_FILE',503);}
    });
  }
  async function checkedFile(current, sourcePath) {
    checkedNaming(sourcePath);
    let path = current.root;
    for (const part of sourcePath.split('/')) {
      path = join(path, part); const info = await lstat(path);
      if (info.isSymbolicLink()) throw problem('模板不允许使用符号链接或目录联接。', 'TEMPLATE_ACCESS', 503);
    }
    const actual = await realpath(path), info = await lstat(actual);
    if (!inside(current.root, actual) || !info.isFile() || info.size < 1 || info.size > MAX_BYTES) throw problem('模板文件不存在、过大或无法读取。', 'TEMPLATE_ACCESS', 503);
    return {path: actual, info};
  }
  async function original(current, file, verifiedPath) {
    const checked = verifiedPath ?? await checkedFile(current, file.sourcePath), handle = await open(checked.path, 'r');
    try {
      const before = await handle.stat();
      if (!sameIdentity(identity(checked.info), before)) throw problem('模板原图已变化，请重新加载模板库。', 'TEMPLATE_FILE_CHANGED', 409);
      const bytes = await handle.readFile(), after = await handle.stat();
      if (bytes.length > MAX_BYTES || bytes.length !== before.size || !sameIdentity(identity(before), after)) throw problem('模板原图已变化，请重新加载模板库。', 'TEMPLATE_FILE_CHANGED', 409);
      return {bytes, path: checked.path, info: after};
    } finally {await handle.close();}
  }
  function canRecoverPreset(current, file, key, migration=false) {
    return (migration||file.placementId === 'front-back') && file.validated === true && !file.requiresReview
      && !current.calibrations.has(file.id) && !current.groups.has(key) && !current.masks.has(file.id);
  }
  async function readSavedPreset(current, file, key) {
    const directory = join(current.meta, 'region-presets');
    try {
      const directoryInfo = await lstat(directory);
      if (!directoryInfo.isDirectory() || directoryInfo.isSymbolicLink() || !inside(current.meta, await realpath(directory))) return null;
      const path = join(directory, regionPresetFilename(file));
      const info = await lstat(path);
      if (!info.isFile() || info.isSymbolicLink() || info.size > MAX_PRESET_BYTES || !inside(directory, await realpath(path))) return null;
      const handle = await open(path, 'r');
      let bytes;
      try {
        if (!sameIdentity(identity(info), await handle.stat())) return null;
        bytes = await handle.readFile();
        if (bytes.length !== info.size || !sameIdentity(identity(info), await handle.stat())) return null;
      } finally {await handle.close();}
      const preset = normalizeRegionPreset(JSON.parse(bytes.toString('utf8')));
      if (preset.key !== key) return null;
      // An orphan portable preset has no historical file hash. Inherit only its
      // exact group and canvas size, and keep active calibration authoritative.
      const variant = preset.variants.find(value => value.width === file.width && value.height === file.height);
      if (!variant) return null;
      const refs = Object.fromEntries(Object.entries(variant.printMasks || {}).map(([position, mask]) => [
        position, {version: 1, width: mask.width, height: mask.height, blob: hex(Buffer.from(mask.data, 'base64'))}
      ]));
      return {variant, refs};
    } catch {
      // An unreadable or invalid orphan is not a calibration.
      return null;
    }
  }
  async function recoveredPreset(current, file, cache = new Map(), migration=false) {
    const key = templateGroupKey(file);
    if (!canRecoverPreset(current, file, key, migration)) return null;
    const cacheKey = JSON.stringify([key, file.width, file.height]);
    if (!cache.has(cacheKey)) cache.set(cacheKey, readSavedPreset(current, file, key));
    const recovery = await cache.get(cacheKey);
    const latest = current.files.get(file.id);
    return latest?.fileRevision === file.fileRevision && canRecoverPreset(current, latest, key, migration) ? recovery : null;
  }
  function validUniversalVariant(family,value) {
    if (![value?.width,value?.height].every(size=>Number.isSafeInteger(size)&&size>0)||value.width*value.height>40_000_000) throw problem('通用区域底图尺寸无效。');
    const setup=checkedCalibration(family.placementId,value);
    if(!geometryFullyConfirmed({...setup,placementId:family.placementId})) throw problem('请先确认模板的所有印花位置。','TEMPLATE_REGION');
    return {...setup,width:value.width,height:value.height,placementId:family.placementId};
  }
  function upsertUniversal(current,template,value,maskRefs,revision,preferred) {
    const key=universalGeometryKey(template);
    if(!key)throw problem('通用区域缺少款式或印花位置。','TEMPLATE_REGION');
    const old=current.universal.get(key),style=old?.style || template.style.trim(),placementId=template.placementId;
    if(!old&&current.universal.size>=MAX_FILES)throw problem('通用区域数量已达到上限。','TEMPLATE_LIMIT',413);
    const variants=[...(old?.variants||[])],index=preferred?variants.indexOf(preferred):-1;
    const geometry=validUniversalVariant({placementId},value);
    const variant={...geometry,anchor:index<0?geometry:variants[index].anchor,revision,layoutId:index<0?token():variants[index].layoutId,maskRefs,
      ...(validHash(template.fileRevision)?{sourceFileRevision:template.fileRevision}:{})};
    if(index>=0)variants[index]=variant;
    else {if(variants.length>=32)throw problem('该款式的底图布局种类过多，请先整理模板。','TEMPLATE_LIMIT',413);variants.push(variant);}
    const family={key,style,placementId,name:universalGeometryName({style,placementId}),version:(old?.version||0)+1,variants};
    current.universal.set(key,family);return family;
  }
  function sameUniversalGeometry(placementId,variant,setup,refs) {
    const positions=new Set([...confirmedTemplatePositions(placementId,variant),...confirmedTemplatePositions(placementId,setup)]);
    return [...positions].every(position=>sameMaskGeometry(variant,setup,position)
      && JSON.stringify(variant.maskRefs[position]||null)===JSON.stringify(refs[position]||null));
  }
  function universalReceipt(family,revision,updatedCount) {
    return {key:family.key,name:family.name,version:family.version,revision,updatedCount};
  }
  function setupFor(current,file,recovered) {
    if(recovered&&!canRecoverPreset(current,file,templateGroupKey(file)))recovered=null;
    const legacy=legacySetupFor(current,file,recovered);
    if(!universalGeometry||legacy.calibrationStatus==='review')return legacy;
    const family=current.universal.get(universalGeometryKey(file));if(!family)return legacy;
    const own=current.calibrations.get(file.id),bound=own?.fileRevision===file.fileRevision&&own.universalLayoutId
      ? family.variants.find(item=>item.layoutId===own.universalLayoutId&&aspectCompatible(item,file)):null;
    const variant=bound||selectUniversalGeometry(family.variants,file,{...legacy,placementId:file.placementId});
    if(!variant||legacy.regionRevision>variant.revision)return legacy;
    return {...checkedCalibration(file.placementId,variant),regionRevision:variant.revision,
      inherited:true,needsCalibration:false,calibrationStatus:'ready',reviewReason:'',universalFamily:family,universalVariant:variant};
  }
  async function migrateUniversal(current) {
    const candidates=[],recoveries=new Map(),verifiedMasks=new Map();
    const verifyRefs=async refs=>{
      const valid={};
      for(const [position,mask] of Object.entries(refs)){
        const key=JSON.stringify([mask.blob,mask.width,mask.height]);
        if(!verifiedMasks.has(key))verifiedMasks.set(key,storedMasks(current,{[position]:mask},[position]).then(()=>true,()=>false));
        if(await verifiedMasks.get(key))valid[position]=mask;
      }
      return valid;
    };
    for(const [key,group] of current.groups){
      let identity;try{identity=JSON.parse(key);}catch{continue;}
      if(!Array.isArray(identity)||identity.length!==3||identity[2]!==group.placementId)continue;
      const template={style:identity[1],placementId:identity[2]};
      for(const value of group.variants){
        if(!geometryFullyConfirmed({...value,placementId:template.placementId}))continue;
        const source=current.files.get(value.sourceId);
        if(value.sourceId&&(!source||source.requiresReview||templateGroupKey(source)!==key))continue;
        candidates.push({template:source||template,value,refs:sharedMaskRefs(current,key,value).refs,revision:value.regionRevision,rank:1});
      }
    }
    for(const file of current.files.values()){
      const value=current.calibrations.get(file.id);
      if(value?.fileRevision===file.fileRevision&&!file.requiresReview&&geometryFullyConfirmed(value)){
        candidates.push({template:file,value:{...value,width:file.width,height:file.height},refs:effectiveMasks(current,file,legacySetupFor(current,file)),revision:value.regionRevision,rank:0});
        continue;
      }
      const recovery=await recoveredPreset(current,file,recoveries,true);
      if(recovery)candidates.push({template:file,value:recovery.variant,refs:recovery.refs,portableMasks:recovery.variant.printMasks,revision:recovery.variant.updatedAt,rank:-1});
    }
    // Process each known layout newest first; legacy data never replaces an
    // already edited universal variant, and stale original files are excluded.
    candidates.sort((a,b)=>b.revision-a.revision||b.rank-a.rank||String(a.template.sourcePath||'').localeCompare(String(b.template.sourcePath||'')));
    const migrated=new Set();let revision=nextNumber(...candidates.slice(0,1).map(item=>item.revision),...Array.from(current.universal.values(),family=>Math.max(...family.variants.map(value=>value.revision))));
    for(const {template,value,refs:sourceRefs,portableMasks} of candidates){
      const key=universalGeometryKey(template);if(!key)continue;
      const refs=portableMasks?sourceRefs:await verifyRefs(sourceRefs);
      const family=current.universal.get(key),baseline={...value,placementId:template.placementId};
      const preferred=selectUniversalGeometry(family?.variants||[],{...template,width:value.width,height:value.height},baseline);
      if(preferred){
        if(!migrated.has(preferred))continue;
        const missing=confirmedTemplatePositions(template.placementId,preferred).filter(position=>!preferred.maskRefs[position]&&refs[position]&&sameMaskGeometry(preferred,baseline,position));
        if(portableMasks&&missing.length)await storeMasks(current,Object.fromEntries(missing.map(position=>[position,portableMasks[position]])));
        for(const position of missing)preferred.maskRefs[position]=refs[position];
      }else if((family?.variants.length||0)<32){
        if(portableMasks&&Object.keys(portableMasks).length)await storeMasks(current,portableMasks);
        const next=upsertUniversal(current,template,value,{...refs},revision++,null);
        migrated.add(next.variants.at(-1));
      }
    }
  }
  async function listUniversalRegionPresets(options={}) {
    if(!universalGeometry)return [];
    const current=await ready(true),families=[];
    let bytes=0;
    for(const family of current.universal.values()){
      if(options.style&&universalGeometryKey({style:options.style,placementId:family.placementId})!==family.key||options.placementId&&options.placementId!==family.placementId)continue;
      const {variants,...identity}=family;
      const records=[];
      for(const {maskRefs,...variant} of variants){
        if(options.metadataOnly===true||options.metadataOnly==='1'){records.push(variant);continue;}
        for(const mask of Object.values(maskRefs)) bytes+=4*Math.ceil(mask.width*mask.height/3);
        if(bytes>MAX_PRESET_BYTES)throw problem('请按款式和印花位置读取通用区域。','TEMPLATE_LIMIT',413);
        records.push({...variant,printMasks:await storedMasks(current,maskRefs,confirmedTemplatePositions(family.placementId,variant))});
      }
      families.push({...identity,variants:records});
    }
    return families.sort((a,b)=>a.name.localeCompare(b.name)||a.key.localeCompare(b.key));
  }
  async function saveUniversalRegionPreset(input,{seed=false,expectedRevision}={}) {
    if(!universalGeometry)throw problem('主机尚未启用通用印花区域。','TEMPLATE_ACCESS',503);
    let record;try{record=normalizeRegionPreset(input);}catch(cause){throw problem(cause.message,'TEMPLATE_REGION');}
    if(record.variants.length!==1||expectedRevision!==undefined&&(!Number.isSafeInteger(expectedRevision)||expectedRevision<0))throw problem('每次只保存一个已确认的通用底图布局。','TEMPLATE_REGION');
    const current=await ready(true),value=record.variants[0],target={...record,width:value.width,height:value.height};
    return write(current,async()=>{
      const family=current.universal.get(universalGeometryKey(record)),geometry={...value,placementId:record.placementId};
      let preferred=selectUniversalGeometry(family?.variants||[],target,geometry);
      if(expectedRevision>0){
        const matches=(family?.variants||[]).filter(item=>item.revision===expectedRevision&&aspectCompatible(item,target));
        if(preferred?.revision!==expectedRevision){
          if(matches.length!==1)throw problem('通用区域已更新，请重新加载后保存。','TEMPLATE_CONFLICT',409);
          preferred=matches[0];
        }
      }
      if(seed&&preferred)return {universalPreset:universalReceipt(family,preferred.revision,0),records:[]};
      if(expectedRevision===0&&preferred)throw problem('通用区域已更新，请重新加载后保存。','TEMPLATE_CONFLICT',409);
      const members=[...current.files.values()].filter(file=>universalGeometryKey(file)===universalGeometryKey(record));
      const recoveryCache=new Map(),recoveryById=new Map();
      for(const file of members)recoveryById.set(file.id,await recoveredPreset(current,file,recoveryCache));
      const revision=nextNumber(...(family?.variants||[]).map(item=>item.revision),...members.map(file=>setupFor(current,file,recoveryById.get(file.id)).regionRevision));
      const refs=Object.hasOwn(value,'printMasks')?await storeMasks(current,value.printMasks)
        :Object.fromEntries(Object.entries(preferred?.maskRefs||{}).filter(([position])=>
          !OPTIONAL_TEMPLATE_POSITIONS.includes(position)||sameMaskGeometry(preferred,geometry,position)));
      if(preferred&&sameUniversalGeometry(record.placementId,preferred,geometry,refs))
        return {universalPreset:universalReceipt(family,preferred.revision,0),records:[]};
      const draft={...current,universal:new Map(current.universal)},next=upsertUniversal(draft,record,value,refs,revision,preferred);
      const records=[];let applied=0;
      for(const file of members){
        const recovery=recoveryById.get(file.id),before=setupFor(current,file,recovery),after=setupFor(draft,file,recovery);
        if(after.universalVariant?.revision===revision)applied++;
        if(before.regionRevision!==after.regionRevision||before.universalFamily?.version!==after.universalFamily?.version)records.push(dto(draft,file,recovery));
      }
      await save(draft);current.universal=draft.universal;current.revision=draft.revision;
      return {universalPreset:universalReceipt(next,revision,applied),records};
    });
  }
  function legacySetupFor(current, file, recovered) {
    const calibration = current.calibrations.get(file.id), group = current.groups.get(templateGroupKey(file));
    const variant = group?.variants.find(value => aspectCompatible(value, file));
    const own = calibration?.fileRevision === file.fileRevision ? calibration : null;
    const stale = !!calibration && !own || file.requiresReview && !own;
    const inherited = !own && !stale && (variant || recovered?.variant);
    const selected = own || inherited || null, base = checkedCalibration(file.placementId, selected || {});
    if (stale) for (const position of confirmedTemplatePositions(file.placementId,base)) base.confirmed[position] = false;
    const incompatible = !own && !stale && !!group?.variants.length && !variant;
    const ready = file.positions.every(position => base.confirmed[position] === true);
    return {...base, regionRevision: Math.max(file.setupRevision || 0, own?.regionRevision || 0, inherited?.regionRevision || 0, recovered?.variant.updatedAt || 0),
      inherited: !!inherited, needsCalibration: !ready, calibrationStatus: stale ? 'review' : incompatible ? 'incompatible' : ready ? 'ready' : 'pending',
      reviewReason: stale ? '原图已变化，请重新框选并确认印花区域。' : incompatible ? '同款底图宽高比不同，请为此模板手动框选区域。' : ready ? '' : '首次使用请手动框选并确认印花区域。'};
  }
  const validMaskRef = mask => mask?.version === 1 && validHash(mask.blob)
    && [mask.width, mask.height].every(size => Number.isSafeInteger(size) && size > 0 && size <= 2048);
  function boundMasks(current, file) {
    const entry=current.masks.get(file.id);
    return entry?.fileRevision===file.fileRevision ? entry.positions : {};
  }
  function sameMaskGeometry(first,second,position) {
    return first?.confirmed?.[position]===true && second?.confirmed?.[position]===true
      && JSON.stringify([first.regions?.[position],first.regionModes?.[position]||'rectangle',first.printContours?.[position]||[]])
        ===JSON.stringify([second.regions?.[position],second.regionModes?.[position]||'rectangle',second.printContours?.[position]||[]]);
  }
  /** Resolve immutable group refs without changing calibrations or materializing per-color masks. */
  function sharedMaskRefs(current,key,variant) {
    const refs={},sources={};
    if(!variant)return {refs,sources};
    const group=current.groups.get(key),positions=confirmedTemplatePositions(group?.placementId,variant);
    for(const position of positions){
      const ref=variant.presetMasks?.[position],binding=variant.presetMaskSources?.[position];
      const sourceId=binding?.id||variant.sourceId;
      const source=sourceId&&current.files.get(sourceId),setup=source&&legacySetupFor(current,source);
      const sourceValid=!sourceId || source&&templateGroupKey(source)===key&&aspectCompatible(source,variant)
        && (!binding||binding.fileRevision===source.fileRevision)
        && setup.calibrationStatus!=='review'&&sameMaskGeometry(setup,variant,position);
      if(validMaskRef(ref)&&sourceValid){refs[position]=ref;if(binding)sources[position]=binding;else if(source)sources[position]={id:source.id,fileRevision:source.fileRevision};continue;}
      // A canonical ref with an invalid source is stale, not an absent legacy snapshot.
      if(ref!==undefined)continue;
      const candidates=new Map();
      for(const peer of current.files.values()){
        if(templateGroupKey(peer)!==key||!aspectCompatible(peer,variant)||current.masks.get(peer.id)?.shareable===false)continue;
        const peerSetup=legacySetupFor(current,peer),mask=boundMasks(current,peer)[position];
        if(peerSetup.calibrationStatus==='review'||!sameMaskGeometry(peerSetup,variant,position)||!validMaskRef(mask))continue;
        candidates.set(JSON.stringify([mask.width,mask.height,mask.blob]),{mask,source:{id:peer.id,fileRevision:peer.fileRevision}});
      }
      if(candidates.size===1){const selected=candidates.values().next().value;refs[position]=selected.mask;sources[position]=selected.source;}
    }
    return {refs,sources};
  }
  function effectiveMasks(current,file,setup=setupFor(current,file)) {
    const own=boundMasks(current,file),output={...own};
    if(setup.calibrationStatus==='review')return output;
    if(setup.universalVariant)return {...setup.universalVariant.maskRefs};
    const key=templateGroupKey(file),variant=current.groups.get(key)?.variants.find(value=>aspectCompatible(value,file));
    if(!variant)return output;
    const shared=sharedMaskRefs(current,key,variant).refs;
    for(const position of confirmedTemplatePositions(file.placementId,setup))if(output[position]===undefined&&sameMaskGeometry(setup,variant,position)&&shared[position])output[position]=shared[position];
    return output;
  }
  function dto(current, file, recovered) {
    if(recovered&&!canRecoverPreset(current,file,templateGroupKey(file)))recovered=null;
    const setup=setupFor(current,file,recovered),bound=setup.universalVariant?effectiveMasks(current,file,setup):{...recovered?.refs,...effectiveMasks(current,file,setup)};
    const blank = current.blanks.get(file.id), blankVerified = blank?.fileRevision === file.fileRevision && blank.verified === true;
    const maskPositions = POSITIONS.filter(position => bound[position]
      && (!OPTIONAL_TEMPLATE_POSITIONS.includes(position) || setup.confirmed[position]===true));
    return {id: file.id, ...checkedNaming(file.sourcePath), width: file.width, height: file.height, size: file.size, mime: file.mime,
      sourcePath: file.sourcePath, fileRevision: file.fileRevision, custom: true, shared: true, hostTemplate: true, library: 'host',
      regions: setup.regions, confirmed: setup.confirmed, regionModes: setup.regionModes, printContours: setup.printContours, regionRevision: setup.regionRevision,
      revision: hex(JSON.stringify([file.fileRevision, setup.regionRevision, setup.calibrationStatus])).slice(0, 32),
      inherited: setup.inherited, ...(setup.universalFamily?{universalGeometry:{name:setup.universalFamily.name,version:setup.universalFamily.version,revision:setup.universalVariant.revision,layoutId:setup.universalVariant.layoutId}}:{}), needsCalibration: setup.needsCalibration, calibrationStatus: setup.calibrationStatus, reviewReason: setup.reviewReason,
      blankVerified, blankVerifiedAt: blankVerified ? blank.updatedAt : 0,
      hasPrintMasks: !!maskPositions.length, maskPositions, maskRevision: maskPositions.length ? hex(JSON.stringify(['effective-mask-v2',file.fileRevision,maskPositions.map(position => [position,bound[position],setup.regions[position],setup.regionModes[position],setup.printContours[position]||[]])])) : 'none',
      masksLoaded: !maskPositions.length, createdAt: file.createdAt, updatedAt: file.updatedAt};
  }
  async function detail(current, file, recovered) {
    if(recovered&&!canRecoverPreset(current,file,templateGroupKey(file)))recovered=null;
    const setup=setupFor(current,file,recovered),record=dto(current,file,recovered),printMasks={},bound=effectiveMasks(current,file,setup);
    for (const position of record.maskPositions) {
      if(!bound[position]&&!setup.universalVariant&&recovered?.variant.printMasks?.[position]){
        printMasks[position]=clone(recovered.variant.printMasks[position]);continue;
      }
      const mask = bound[position], directory = await metadataDirectory(current.root, 'masks'), path = join(directory, mask.blob + '.bin');
      const info = await lstat(path);
      if (!info.isFile() || info.isSymbolicLink() || info.size !== mask.width * mask.height || !inside(current.root, await realpath(path))) throw problem('模板遮挡蒙版无法读取，请检查模板库。', 'TEMPLATE_ACCESS', 503);
      const bytes = await readFile(path);
      if (hex(bytes) !== mask.blob) throw problem('模板遮挡蒙版已变化，请重新保存。', 'TEMPLATE_ACCESS', 503);
      printMasks[position] = {version: 1, width: mask.width, height: mask.height, encoding: 'base64', data: bytes.toString('base64')};
    }
    return {...record, printMasks, masksLoaded: true};
  }
  function summaryFor(current) {
    return {total: current.files.size, revision: current.revision,
      ...(universalGeometry?{universalRevision:hex(JSON.stringify([...current.universal].map(([key,family])=>[key,family.version]))).slice(0,32)}:{}),scanning: current.scanning, scanProgress: current.scanProgress ? {...current.scanProgress} : null,
      scanError: current.scanError, scannedAt: current.scannedAt, library: 'host'};
  }
  async function scanState(current) {
    const found = new Map(), pending = new Map(), skippedReasons = {name: 0, invalidImage: 0, access: 0, symlink: 0, depth: 0};
    let scannedEntries = 0, validFiles = 0, skipped = 0, limited = false, lastSaved = Date.now();
    const progress = stage => {
      const update = {stage, scannedEntries, validFiles, skipped}; current.scanProgress = update;
      if (typeof onScanProgress === 'function') try {const result = onScanProgress({...update}); if (result?.then) void Promise.resolve(result).catch(() => {});} catch {}
    };
    const skip = reason => {skipped++; skippedReasons[reason]++;};
    const publish = async final => {
      const batch = new Map(pending); pending.clear();
      if (!final && !batch.size) return;
      await write(current, async () => {
        let updated = false;
        for (const [id, candidate] of batch) {
          const previous = current.files.get(id), calibration = current.calibrations.get(id);
          const contentChanged = !!previous && previous.fileRevision !== candidate.fileRevision || !previous && !!calibration && calibration.fileRevision !== candidate.fileRevision;
          const file = {...candidate, createdAt: previous?.createdAt || candidate.createdAt, updatedAt: previous?.fileRevision === candidate.fileRevision ? previous.updatedAt : candidate.updatedAt,
            requiresReview: calibration?.fileRevision === candidate.fileRevision ? false : contentChanged || previous?.requiresReview || false,
            setupRevision: contentChanged ? nextNumber(previous?.setupRevision, calibration?.regionRevision, previous ? setupFor(current, previous).regionRevision : 0) : previous?.setupRevision || 0};
          if (JSON.stringify(file) !== JSON.stringify(previous)) {current.files.set(id, file); updated = true;}
        }
        if (final) {
          if (!limited) for (const id of current.files.keys()) if (!found.has(id)) {current.files.delete(id); updated = true;}
          current.scannedAt = new Date().toISOString();
        }
        if (updated) current.revision = token();
        if (final && universalGeometry && !limited && !current.universalMigrationCompleted) {
          const draft = {...current, universal:new Map(current.universal), universalMigrationCompleted:true};
          await migrateUniversal(draft);
          await save(draft); current.universal=draft.universal; current.universalMigrationCompleted=true; current.revision=draft.revision;
          lastSaved=Date.now();
        } else if (final || Date.now() - lastSaved >= 1500) {await save(current); lastSaved = Date.now();}
      });
    };
    const workers = [], queued = [];
    async function inspectCandidate({sourcePath, naming}, lane) {
      let checked, id, cached, originalFile;
      try {
        checked = await checkedFile(current, sourcePath);
        id = pathId(sourcePath);
        cached = current.files.get(id);
        if (cached?.validated !== true || !sameIdentity(cached, checked.info)) {
          originalFile = await original(current, {sourcePath}, checked);
        }
      } catch { return {reason: 'access'}; }

      const image = originalFile
        ? await (workers[lane] ||= createScanWorker()).inspect(originalFile.bytes)
        : cached;
      if (image.invalid) return {reason: 'invalidImage'};
      const now = new Date().toISOString();
      return {file: {id, sourcePath, ...naming, width: image.width, height: image.height, mime: image.mime,
        fileRevision: image.fileRevision, validated: true, ...identity(checked.info),
        createdAt: cached?.createdAt || checked.info.birthtime.toISOString(), updatedAt: now}};
    }

    async function flushCandidates() {
      if (!queued.length) return;
      const batch = queued.splice(0);
      const settled = await Promise.allSettled(batch.map(inspectCandidate));
      const failure = settled.find(item => item.status === 'rejected');
      if (failure) throw failure.reason;
      for (const {value: {file, reason}} of settled) {
        if (reason) { skip(reason); continue; }
        validFiles++;
        found.set(file.id, file);
        pending.set(file.id, file);
      }
    }

    progress('scanning');
    try {
      const shops = await readdir(current.root, {withFileTypes: true});
      for (const shop of shops) {
        if (++scannedEntries > MAX_ENTRIES) {limited = true; break;}
        if (shop.name === META || shop.name.startsWith('.')) continue;
        const shopPath = join(current.root, shop.name);
        const shopInfo = await lstat(shopPath).catch(() => null);
        if (!shopInfo) {skip('access'); continue;}
        if (shopInfo.isSymbolicLink()) {skip('symlink'); continue;}
        if (!shopInfo.isDirectory()) {if (/\.(png|jpe?g|webp)$/i.test(shop.name)) skip('name'); continue;}
        if (!inside(current.root, await realpath(shopPath))) {skip('symlink'); continue;}
        let entries;
        try {entries = await readdir(shopPath, {withFileTypes: true});} catch {skip('access'); continue;}
        for (const entry of entries) {
          if (++scannedEntries > MAX_ENTRIES || validFiles >= MAX_FILES) {limited = true; break;}
          if (scannedEntries % 25 === 0) {
            await flushCandidates();
            await publish(false);
            progress('scanning');
            await new Promise(done => setImmediate(done));
            if (validFiles >= MAX_FILES) {limited = true; break;}
          }
          if (entry.isSymbolicLink()) {skip('symlink'); continue;}
          if (entry.isDirectory()) {skip('depth'); continue;}
          if (!/\.(png|jpe?g|webp)$/i.test(entry.name)) continue;
          const sourcePath = portable(join(shop.name, entry.name));
          let naming;
          try {naming = checkedNaming(sourcePath);} catch {skip('name'); continue;}
          queued.push({sourcePath, naming});
          if (queued.length >= Math.min(SCAN_CONCURRENCY, MAX_FILES - validFiles)) await flushCandidates();
        }
        if (limited) break;
      }
      await flushCandidates();
    } finally {
      await Promise.allSettled(workers.map(worker => worker.close()));
    }
    await publish(true); progress('complete');
    return {...summaryFor(current), count: current.files.size, scannedEntries, validFiles, skipped, skippedReasons, limited, message: `已载入 ${current.files.size} 个主机模板${skipped ? `，${skipped} 项未载入` : ''}。`};
  }
  function startScan(current) {
    if (current.scanPromise) return current.scanPromise;
    current.needsScan = false; current.scanning = true; current.scanError = '';
    const pending = Promise.resolve().then(() => scanState(current)).catch(cause => {const safe = sanitize(cause); current.scanError = safe.message; current.scanProgress = {...current.scanProgress, stage: 'failed'}; throw safe;});
    current.scanPromise = pending;
    const finish = () => {if (current.scanPromise === pending) {current.scanPromise = null; current.scanning = false;}};
    void pending.then(finish, finish); return pending;
  }
  async function ready(background = false) {
    const current = await context(); if (background && current.needsScan) void startScan(current).catch(() => {}); return current;
  }
  async function storeMasks(current, value) {
    if (value === null) return {};
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw problem('模板遮挡蒙版格式无效。', 'TEMPLATE_MASK');
    const positions = {};
    for (const [position, input] of Object.entries(value)) {
      if (!POSITIONS.includes(position)) throw problem('遮挡蒙版位置无效。', 'TEMPLATE_MASK');
      if (input === null) {delete positions[position]; continue;}
      if (input?.version !== 1 || !Number.isSafeInteger(input.width) || !Number.isSafeInteger(input.height) || input.width < 1 || input.height < 1 || input.width > 2048 || input.height > 2048 || input.width * input.height > 4_194_304) throw problem('遮挡蒙版尺寸无效，最大支持 2048 × 2048。', 'TEMPLATE_MASK');
      let bytes;
      if (typeof input.data === 'string') {
        if (input.encoding !== undefined && input.encoding !== 'base64' || input.data.length > 5_592_408 || input.data.length % 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(input.data)) throw problem('遮挡蒙版编码无效。', 'TEMPLATE_MASK');
        bytes = Buffer.from(input.data, 'base64');
        if (bytes.toString('base64') !== input.data) throw problem('遮挡蒙版编码无效。', 'TEMPLATE_MASK');
      } else if ((Array.isArray(input.data) || input.data instanceof Uint8Array) && input.data.length === input.width * input.height) {
        if (Array.from(input.data).some(value => !Number.isInteger(value) || value < 0 || value > 255)) throw problem('遮挡蒙版像素无效。', 'TEMPLATE_MASK');
        bytes = Buffer.from(input.data);
      } else throw problem('遮挡蒙版像素无效。', 'TEMPLATE_MASK');
      if (bytes.length !== input.width * input.height) throw problem('遮挡蒙版像素数量与尺寸不符。', 'TEMPLATE_MASK');
      const blob = hex(bytes), directory = await metadataDirectory(current.root, 'masks'), path = join(directory, blob + '.bin');
      try {await writeFile(path, bytes, {flag: 'wx', mode: 0o600});}
      catch (cause) {
        if (cause.code !== 'EEXIST') throw cause;
        const info = await lstat(path);
        if (info.isSymbolicLink() || !info.isFile() || info.size !== bytes.length || hex(await readFile(path)) !== blob) throw problem('模板蒙版文件冲突，请检查模板库。', 'TEMPLATE_MASK', 409);
      }
      positions[position] = {version: 1, width: input.width, height: input.height, blob};
    }
    return positions;
  }
  async function saveCalibration(id, patch) {
    if (!validId(id)) throw problem('模板编号无效。');
    if (!patch || typeof patch !== 'object' || !Number.isSafeInteger(patch.expectedRevision) || !validHash(patch.expectedFileRevision)) throw problem('请重新加载模板后保存区域。', 'TEMPLATE_CONFLICT', 409);
    if (patch.syncUniversal !== undefined && typeof patch.syncUniversal !== 'boolean') throw problem('通用区域保存状态无效。');
    if (patch.blankVerified !== undefined && typeof patch.blankVerified !== 'boolean') throw problem('干净底图确认状态无效。');
    const current = await ready(), snapshot = current.files.get(id);
    if (!snapshot) throw problem('主机模板不存在，请刷新模板库。', 'TEMPLATE_NOT_FOUND', 404);
    const originalFile = await original(current, snapshot);
    if (hex(originalFile.bytes) !== patch.expectedFileRevision) {void startScan(current).catch(() => {}); throw problem('模板原图已变化，请重新加载后框选区域。', 'TEMPLATE_FILE_CHANGED', 409);}
    return write(current, async () => {
      const file=current.files.get(id),recoveries=new Map(),recovered=file&&await recoveredPreset(current,file,recoveries);
      const base=file&&setupFor(current,file,recovered);
      if (!file || file.fileRevision !== patch.expectedFileRevision || base.regionRevision !== patch.expectedRevision) throw problem('模板区域已被其他设备修改，请重新加载后再保存。', 'TEMPLATE_CONFLICT', 409);
      const next = checkedCalibration(file.placementId, patch, base);
      const confirmedPositions=confirmedTemplatePositions(file.placementId,next);
      const removedSleeves=OPTIONAL_TEMPLATE_POSITIONS.filter(position=>patch.regions?.[position]===null);
      const groupKey = templateGroupKey(file), members = [...current.files.values()].filter(value => templateGroupKey(value) === groupKey);
      const universalSave = universalGeometry && patch.syncUniversal === true && geometryFullyConfirmed({...next, placementId:file.placementId});
      const family = universalSave ? current.universal.get(universalGeometryKey(file)) : null;
      const universalMembers = universalSave ? [...current.files.values()].filter(value => universalGeometryKey(value) === universalGeometryKey(file)) : [];
      const peers=new Map([...members,...universalMembers].map(target=>[target.id,target])),recoveryById=new Map([[id,recovered]]);
      for(const target of peers.values())if(target.id!==id)recoveryById.set(target.id,await recoveredPreset(current,target,recoveries));
      const regionRevision=nextNumber(base.regionRevision,...Array.from(peers.values(),target=>setupFor(current,target,recoveryById.get(target.id)).regionRevision),...(family?.variants||[]).map(value=>value.revision));
      const areaChanged = JSON.stringify([next.regions, next.confirmed, next.regionModes, next.printContours]) !== JSON.stringify([base.regions, base.confirmed, base.regionModes, base.printContours]);
      const syncGroup = !universalSave && patch.syncGroup !== false && areaChanged && file.positions.some(position => next.confirmed[position]);
      const calibration = {...next, placementId: file.placementId, fileRevision: file.fileRevision, regionRevision};
      let masks;
      if (Object.hasOwn(patch, 'printMasks')) masks = await storeMasks(current, patch.printMasks);
      else if(!base.universalVariant&&recovered?.variant.printMasks){
        const retained=Object.fromEntries(Object.entries(recovered.variant.printMasks).filter(([position])=>sameMaskGeometry(next,base,position)));
        if(Object.keys(retained).length)masks=await storeMasks(current,retained);
      }
      if(removedSleeves.length){
        masks??={...boundMasks(current,file)};
        for(const position of removedSleeves)delete masks[position];
      }
      if(masks)for(const position of OPTIONAL_TEMPLATE_POSITIONS)if(next.confirmed[position]!==true)delete masks[position];
      const draft = {...current, calibrations: new Map(current.calibrations), groups: new Map(current.groups), masks: new Map(current.masks), blanks: new Map(current.blanks), universal:new Map(current.universal)};
      const skipped = [], updates = [];
        draft.calibrations.set(id, calibration);
        if (masks !== undefined) draft.masks.set(id, {fileRevision: file.fileRevision, positions: masks,shareable:patch.syncGroup!==false});
        if (patch.blankVerified !== undefined) draft.blanks.set(id, {fileRevision: file.fileRevision, verified: patch.blankVerified, updatedAt: Date.now()});
        if (syncGroup) {
          const group = clone(current.groups.get(groupKey) || {placementId: file.placementId, variants: []});
          const index = group.variants.findIndex(value => aspectCompatible(value, file));
          const variantSetup = checkedCalibration(file.placementId, {}, index < 0 ? {} : group.variants[index]);
          for (const position of confirmedPositions) if (next.confirmed[position]) for (const field of ['regions', 'confirmed', 'regionModes']) variantSetup[field][position] = clone(next[field][position]);
          for (const position of confirmedPositions) if (next.confirmed[position]) {delete variantSetup.printContours[position]; if (next.printContours[position]) variantSetup.printContours[position] = clone(next.printContours[position]);}
          const variant = {...variantSetup, width: file.width, height: file.height, sourceId: id, regionRevision, updatedAt: Date.now()};
          if (index < 0) {if (group.variants.length >= 32) throw problem('同款模板的宽高比类型过多，请拆分款式后再校准。', 'TEMPLATE_LIMIT', 413); group.variants.push(variant);} else group.variants[index] = variant;
          draft.groups.set(groupKey, group);
          for (const target of members) {
            if (target.id === id) continue;
            const setup = setupFor(current, target, recoveryById.get(target.id));
            if (!aspectCompatible(file, target)) {skipped.push({id: target.id, reason: 'aspect-ratio'}); continue;}
            if (setup.calibrationStatus === 'review') {skipped.push({id: target.id, reason: 'image-changed'}); continue;}
            const removalRegions=Object.fromEntries(removedSleeves.map(position=>[position,null]));
            const targetSetup = checkedCalibration(target.placementId, {regions:removalRegions}, setup);
            for (const position of confirmedPositions) if (next.confirmed[position]) for (const field of ['regions', 'confirmed', 'regionModes']) targetSetup[field][position] = clone(next[field][position]);
            for (const position of confirmedPositions) if (next.confirmed[position]) {delete targetSetup.printContours[position]; if (next.printContours[position]) targetSetup.printContours[position] = clone(next.printContours[position]);}
            checkedCalibration(target.placementId, targetSetup);
            draft.calibrations.set(target.id, {...targetSetup, placementId: target.placementId, fileRevision: target.fileRevision, regionRevision});
            const previousMasks=draft.masks.get(target.id);
            if(previousMasks?.fileRevision===target.fileRevision&&removedSleeves.some(position=>previousMasks.positions[position])){
              const positions={...previousMasks.positions};
              for(const position of removedSleeves)delete positions[position];
              draft.masks.set(target.id,{...previousMasks,positions});
            }
          }
        }
        // Keep an existing shared snapshot when another color has never chosen
        // a mask. Explicit all-255 masks remain deliberate replacements.
        if(!universalSave&&patch.syncGroup!==false&&file.positions.every(position=>next.confirmed[position]===true)){
          const group=clone(draft.groups.get(groupKey)||{placementId:file.placementId,variants:[]}),index=group.variants.findIndex(value=>aspectCompatible(value,file));
          const prior=current.groups.get(groupKey)?.variants.find(value=>aspectCompatible(value,file));
          const previous=sharedMaskRefs(current,groupKey,prior),bound=boundMasks(draft,file),presetMasks={},presetMaskSources={};
          for(const position of confirmedPositions){
            if(bound[position]){presetMasks[position]=clone(bound[position]);presetMaskSources[position]={id,fileRevision:file.fileRevision};}
            else if(previous.refs[position]&&sameMaskGeometry(next,prior,position)){presetMasks[position]=clone(previous.refs[position]);if(previous.sources[position])presetMaskSources[position]=clone(previous.sources[position]);}
          }
          const variant={...next,width:file.width,height:file.height,sourceId:id,regionRevision,updatedAt:Date.now(),presetMasks,presetMaskSources};
          if(index<0){if(group.variants.length>=32)throw problem('同款模板的宽高比类型过多，请拆分款式后再校准。','TEMPLATE_LIMIT',413);group.variants.push(variant);}else group.variants[index]=variant;
          draft.groups.set(groupKey,group);
        }
      let universalPreset=null;
      if (universalSave) {
        const geometry={...next, placementId:file.placementId,width:file.width,height:file.height};
        const preferred=base.universalVariant || selectUniversalGeometry(family?.variants||[],file,geometry);
        const sourceMasks=masks ?? effectiveMasks(current,file,base);
        const refs=Object.fromEntries(confirmedPositions.map(position=>[position,sourceMasks[position]]).filter(([,ref])=>ref));
        const currentBlank=current.blanks.get(id);
        const unchangedBlank=patch.blankVerified===undefined||patch.blankVerified===(currentBlank?.fileRevision===file.fileRevision&&currentBlank.verified===true);
        if(base.universalVariant&&unchangedBlank&&sameUniversalGeometry(file.placementId,base.universalVariant,geometry,refs)){
          return {records:[await detail(current,file,recovered)],revision:current.revision,updatedCount:0,skipped,groupKey,regionPreset:null,universalPreset:universalReceipt(family,base.universalVariant.revision,0)};
        }
        const familyNext=upsertUniversal(draft,file,geometry,refs,regionRevision,preferred);
        calibration.universalLayoutId=familyNext.variants.find(item=>item.revision===regionRevision).layoutId;
        let applied=1;
        for (const target of universalMembers) {
          if(target.id===id)continue;
          const recovery=recoveryById.get(target.id),previous=setupFor(current,target,recovery),setup=setupFor(draft,target,recovery);
          if(setup.universalVariant?.revision===regionRevision) {updates.push(dto(draft,target,recovery));applied++;}
          else {
            if(previous.regionRevision!==setup.regionRevision||previous.universalFamily?.version!==setup.universalFamily?.version)updates.push(dto(draft,target,recovery));
            skipped.push({id:target.id,reason:setup.calibrationStatus==='review'?'image-changed':!aspectCompatible(file,target)?'aspect-ratio':'layout'});
          }
        }
        universalPreset=universalReceipt(familyNext,regionRevision,applied);
        updates.unshift(await detail(draft,file));
      }
      await save(draft);
      current.calibrations = draft.calibrations; current.groups = draft.groups; current.masks = draft.masks; current.blanks = draft.blanks;
      current.universal=draft.universal; current.revision = draft.revision;
      if(!universalSave)for(const target of members){
        const recovery=await recoveredPreset(current,target,recoveries);
        updates.push(target.id===id?await detail(current,target,recovery):dto(current,target,recovery));
      }
      let regionPreset=null;
      if(!universalSave&&file.positions.every(position=>next.confirmed[position]===true)){
        try{const record=await presetForGroup(current,groupKey);if(record){await writePresetArtifact(current,record);regionPreset={saved:true,fileName:record.fileName,key:record.key};}}catch(cause){regionPreset={saved:false,message:/32 MB|过大/.test(cause.message||'')?'模板区域已保存，但区域文件的遮挡数据超出上限；请拆分款式后重新保存。':'模板区域已保存，但独立区域文件写入失败；请检查模板目录权限后重新加载区域文件重试。'};}
      }
      return {records: updates, revision: current.revision, updatedCount: universalPreset?.updatedCount ?? (syncGroup ? members.length - skipped.length : 1), skipped, groupKey, regionPreset, ...(universalPreset?{universalPreset}:{})};
    });
  }
  const summary = () => protect(async () => summaryFor(await ready(true)));
  return {
    summary, status: summary,
    list: (options = {}) => protect(async () => {
      const current = await ready(true), query = String(options.query || '').trim().toLocaleLowerCase().slice(0, 256);
      const matching = [...current.files.values()].filter(file => (!query || [file.shop, file.style, file.colorName, file.sourcePath].join('\n').toLocaleLowerCase().includes(query)) &&
        (!options.shop || file.shop === options.shop) && (!options.style || file.style === options.style) && (!options.placementId || file.placementId === options.placementId))
        .sort((a, b) => a.sourcePath.localeCompare(b.sourcePath));
      const all = options.all === true, pageSize = all ? MAX_FILES : Math.min(500, Math.max(1, Math.floor(Number(options.pageSize) || 60)));
      const page = all ? 1 : Math.min(Math.max(1, Math.floor(Number(options.page) || 1)), Math.max(1, Math.ceil(matching.length / pageSize)));
      const recoveries=new Map(),records=[];
      for(const file of matching.slice((page-1)*pageSize,page*pageSize))records.push(dto(current,file,await recoveredPreset(current,file,recoveries)));
      return {...summaryFor(current), records, items: records, total: matching.length, page, pageSize, complete: all && !query && !options.shop && !options.style && !options.placementId};
    }),
    get: (id, {includeMasks = true} = {}) => protect(async () => {
      if (!validId(id)) throw problem('模板编号无效。');
      const current = await ready(), file = current.files.get(id); if (!file) return null;
      try {
        const loaded = await original(current, file);
        if (hex(loaded.bytes) !== file.fileRevision) {void startScan(current).catch(() => {}); return null;}
        const recovered=await recoveredPreset(current,file),latest=current.files.get(id);
        if(latest?.fileRevision!==file.fileRevision)throw problem('模板原图已更新，请重新加载后再试。','TEMPLATE_CONFLICT',409);
        return {...(includeMasks?await detail(current,latest,recovered):dto(current,latest,recovered)),path:loaded.path};
      } catch (cause) {if (cause?.name === 'HostTemplateError') throw cause; return null;}
    }),
    scan: () => protect(async () => startScan(await ready())),
    saveCalibration: (id, patch) => protect(() => saveCalibration(id, patch)),
    listRegionPresets: (options={}) => protect(async()=>{
      const current=await ready(true);
      return write(current,async()=>{
        const records=[];let totalBytes=0;
        const keys=new Set(current.groups.keys());
        const exact=options.shop&&options.style&&Object.hasOwn(HOST_TEMPLATE_PLACEMENTS,options.placementId);
        if(exact&&universalGeometry)keys.add(templateGroupKey({shop:options.shop,style:options.style,placementId:options.placementId}));
        for(const key of keys){
          let parts;try{parts=JSON.parse(key);}catch{continue;}
          if(options.shop&&parts[0]!==options.shop||options.style&&parts[1]!==String(options.style).trim()||options.placementId&&parts[2]!==options.placementId)continue;
          const shared=exact?await portableForUniversal(current,{shop:parts[0],style:parts[1],placementId:parts[2]}):null;
          const record=shared||await presetForGroup(current,key);if(!record||options.shop&&record.shop!==options.shop||options.style&&record.style!==String(options.style).trim()||options.placementId&&record.placementId!==options.placementId)continue;
          totalBytes+=Buffer.byteLength(JSON.stringify(record));if(totalBytes>MAX_PRESET_BYTES)throw problem('区域文件列表过大，请按店铺、款式和位置筛选后读取。','TEMPLATE_LIMIT',413);
          // A derived download must not create an orphan shop preset on disk.
          if(!shared)await writePresetArtifact(current,record);records.push(record);
        }
        return records.sort((a,b)=>a.name.localeCompare(b.name)||a.key.localeCompare(b.key));
      });
    }),
    saveRegionPreset: preset => protect(()=>saveRegionPreset(preset)),
    listUniversalRegionPresets: options => protect(()=>listUniversalRegionPresets(options)),
    saveUniversalRegionPreset: (preset, options) => protect(()=>saveUniversalRegionPreset(preset,options)),
    idle: async () => {if (loading) await loading.catch(() => {}); if (state) await Promise.allSettled([state.scanPromise, state.queue].filter(Boolean));},
  };
}
