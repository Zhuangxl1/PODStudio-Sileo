import {spawn,execFile} from 'node:child_process';
import {access} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {promisify} from 'node:util';
import net from 'node:net';
import {randomBytes,createHmac,timingSafeEqual} from 'node:crypto';
import {createDesignerServer} from './server.mjs';
import {createDesktopGateway} from './desktop-gateway.mjs';
import {fixedImageEnvironment,migratePodStorage,podConfigHome,usesFixedStorage} from './storage-root.mjs';

const project=fileURLToPath(new URL('./',import.meta.url));
const script=fileURLToPath(import.meta.url);
const imageOrigin='http://127.0.0.1:8080',uiOrigin='http://127.0.0.1:4173';
const execute=promisify(execFile);
const pause=ms=>new Promise(done=>setTimeout(done,ms));
class StartupError extends Error{}
const report=message=>{if(process.connected)process.send({type:'progress',message});};
async function jsonRequest(url,{method='GET',headers,timeout=2500}={}){
  const response=await fetch(url,{method,headers,redirect:'error',signal:AbortSignal.timeout(timeout),cache:'no-store'});
  if(!response.ok)throw new StartupError('本机接口未就绪。');
  return response.json();
}
function occupied(port){return new Promise(done=>{const socket=net.connect({host:'127.0.0.1',port});const finish=value=>{socket.destroy();done(value);};socket.setTimeout(700,()=>finish(true));socket.once('connect',()=>finish(true));socket.once('error',()=>finish(false));});}
async function listen(server,port){await new Promise((done,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',()=>{server.off('error',reject);done();});});return server;}
async function serviceKey(){
  if(process.env.UPLOAD_TOKEN?.trim()){
    const key=process.env.UPLOAD_TOKEN.trim();
    if(!/^[^\s\u0000-\u001f\u007f]{1,4096}$/.test(key)||/^(?:github_pat_|gh[pousr]_)/i.test(key))throw new StartupError('UPLOAD_TOKEN 格式无效。请使用独立的本机服务访问密钥。');
    return 'Bearer '+key;
  }
  try{
    const root=usesFixedStorage()?['-ConfigRoot',podConfigHome()]:[];
    const {stdout}=await execute('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',resolve(project,'integrations/urpiclink/read-service-key.ps1'),'-ForLauncher',...root],{windowsHide:true,timeout:10000,maxBuffer:16384});
    const value=stdout.trim();if(!/^Bearer [a-fA-F0-9]{64}$/.test(value))throw new Error();return value;
  }catch{throw new StartupError('无法读取当前 Windows 账号的图床访问密钥。请使用启动图床时的同一账号运行一键启动器。');}
}
async function imageReady(){try{const result=await jsonRequest(imageOrigin+'/health');return result.success===true&&typeof result.configured==='boolean'&&result.authRequired===true;}catch{return false;}}
export async function findDesignerURL(directory=project,exists=access){
  for(const file of [resolve(directory,'../output/POD服装设计器.html'),resolve(directory,'POD服装设计器.html')]){try{await exists(file);return pathToFileURL(file).href;}catch{}}
  return uiOrigin+'/';
}
async function ensureImageService(owned,notify=report){
  if(await imageReady()){
    if(usesFixedStorage())throw new StartupError('GitHub 图床已在运行，请先退出原启动器或关闭原图床服务，再使用固定数据目录启动。');
    notify('已复用正在运行的 GitHub 图床。');return;
  }
  if(await occupied(8080))throw new StartupError('8080 端口已被其他服务占用，无法启动 GitHub 图床。请释放该端口后重试。');
  const directory=resolve(project,'integrations/urpiclink'),binary=resolve(directory,'bin/urpiclink.exe');
  try{await access(binary);}catch{throw new StartupError('缺少图床程序 integrations/urpiclink/bin/urpiclink.exe，请使用完整的一键启动版。');}
  notify('正在启动 GitHub 图床…');
  const child=spawn(binary,[],{cwd:directory,detached:true,windowsHide:true,stdio:'ignore',env:{...process.env,...fixedImageEnvironment(),URPICLINK_HOST:'127.0.0.1',URPICLINK_PORT:'8080'}});
  owned.image=child;let failed=false;child.on('error',()=>{failed=true;});child.unref();
  for(let attempt=0;attempt<30;attempt++){if(failed||child.exitCode!==null)break;if(await imageReady())return;await pause(250);}
  throw new StartupError('GitHub 图床启动失败。请检查本机图床程序和配置后重试。');
}
async function ensureDesigner(owned){
  if(await occupied(4173)){
    try{const result=await jsonRequest(uiOrigin+'/__pod/designer-status');if(result.app==='pod-designer'&&result.version===1){report('已复用正在运行的设计器。');return;}}catch{}
    // Older POD servers already serve the updated files. Reuse their origin so saved data stays accessible.
    try{const response=await fetch(uiOrigin+'/',{redirect:'error',signal:AbortSignal.timeout(2500)});const html=await response.text();if(response.ok&&html.includes('id="settings-dialog"')&&html.includes('id="settings-upload-fields"')){report('已复用正在运行的设计器。');return;}}catch{}
    throw new StartupError('4173 端口被其他程序占用。请释放该端口后重新启动设计器。');
  }
  owned.designer=await listen(createDesignerServer(),4173);report('设计器已启动。');
}
async function issueLaunch(port,authorization){
  const result=await jsonRequest(`http://127.0.0.1:${port}/__pod/launch`,{method:'POST',headers:{Authorization:authorization}});
  if(result?.success!==true||!/^[a-f0-9]{64}$/.test(result?.data?.nonce||''))throw new Error();
  return result.data.nonce;
}
async function ensureGateway(owned,authorization){
  for(let port=4174;port<=4183;port++){
    if(await occupied(port)){
      try{
        const challenge=randomBytes(32).toString('hex');
        const status=await jsonRequest(`http://127.0.0.1:${port}/__pod/status`,{timeout:1000,headers:{'X-POD-Challenge':challenge}});
        const expected=createHmac('sha256',authorization).update(`POD Desktop Gateway v1:${challenge}:${port}`).digest('hex');
        if(status.app==='pod-desktop-gateway'&&status.version===1&&typeof status.proof==='string'&&/^[a-f0-9]{64}$/.test(status.proof)&&timingSafeEqual(Buffer.from(status.proof),Buffer.from(expected)))return {port,nonce:await issueLaunch(port,authorization)};
      }catch{}
      continue;
    }
    const gateway=createDesktopGateway({serviceAuthorization:authorization});
    try{await listen(gateway,port);owned.gateway=gateway;return {port,nonce:await issueLaunch(port,authorization)};}catch(error){gateway.close();if(error.code!=='EADDRINUSE')throw error;}
  }
  throw new StartupError('本机自动连接端口不可用，请关闭多余的 POD 启动进程后重试。');
}
async function openDesigner(url){
  await new Promise((done,reject)=>{const child=spawn('rundll32.exe',['url.dll,FileProtocolHandler',url],{detached:true,windowsHide:true,stdio:'ignore'});child.once('error',()=>reject(new StartupError('无法打开默认浏览器，请检查 Windows 默认浏览器设置。')));child.once('spawn',()=>{child.unref();done();});});
}
async function runWorker(){
  const owned={};
  let startupFinished=false;
  const cleanup=()=>{owned.gateway?.close();owned.designer?.close();owned.image?.kill();};
  process.once('disconnect',()=>{if(!startupFinished){cleanup();process.exit(1);}});
  try{
    if(usesFixedStorage()){
      if(await occupied(5180))throw new StartupError('POD 局域网服务已在运行，请先退出旧版或从现有启动器打开设计器。');
      if(await migratePodStorage({onProgress:()=>report('正在迁移本机数据到固定 POD 程序包目录…')}))report('固定 POD 数据目录已就绪。');
    }
    await ensureImageService(owned);report('正在自动验证本机图床密钥…');
    const {authorization,profile}=await readImageServiceProfile();
    const designerURL=await findDesignerURL();
    if(designerURL.startsWith('http:'))await ensureDesigner(owned);
    const {port,nonce}=await ensureGateway(owned,authorization);
    await openDesigner(`${designerURL}#pod-launch=${port}.${nonce}`);
    startupFinished=true;
    if(process.connected){process.send({type:'ready',message:profile.data.configured?'GitHub 图床已自动连接，设计器已打开。':'图床已自动连接。请在打开的设置页首次填写 GitHub Token 和仓库。'});process.disconnect();}
  }catch(error){
    startupFinished=true;cleanup();
    if(process.connected){process.send({type:'failed',message:error instanceof StartupError?error.message:'一键启动失败。请检查本机运行时和服务端口后重试。'});process.disconnect();}process.exitCode=1;
  }
}
function runParent(){
  return new Promise(done=>{
    let finished=false;
    const child=spawn(process.execPath,[script,'--worker'],{cwd:project,detached:true,windowsHide:true,stdio:['ignore','ignore','ignore','ipc']});child.unref();
    const finish=(success,message)=>{if(finished)return;finished=true;clearTimeout(timer);if(message)console.log(message);if(child.connected)child.disconnect();if(!success)process.exitCode=1;done();};
    const timer=setTimeout(()=>finish(false,'启动超时，请检查本机图床和运行时后重试。'),45000);
    child.on('message',message=>{if(message?.type==='progress')console.log(message.message);if(message?.type==='ready')finish(true,message.message);if(message?.type==='failed')finish(false,message.message);});
    child.once('error',()=>finish(false,'无法启动后台进程，请检查 Node.js 运行时。'));
    child.once('exit',code=>{if(!finished)finish(false,code?'后台启动失败，请检查本机图床配置。':'后台进程未完成启动。');});
  });
}
if(process.argv[1]&&resolve(process.argv[1])===script){
  if(process.platform!=='win32'){console.error('一键启动器需要 Windows。');process.exitCode=1;}
  else if(process.argv.includes('--worker'))await runWorker();else await runParent();
}
export async function readImageServiceProfile(){
  try{
    const authorization=await serviceKey();
    const profile=await jsonRequest(imageOrigin+'/api/v1/config/github',{headers:{Authorization:authorization},timeout:5000});
    if(profile?.success===true&&typeof profile.data?.configured==='boolean')return {authorization,profile};
  }catch{}
  throw new StartupError('本机图床密钥验证失败。请使用启动图床时的同一 Windows 账号，或检查自定义 UPLOAD_TOKEN。');
}
export {serviceKey as readServiceAuthorization,ensureImageService,occupied as servicePortOccupied,StartupError};
