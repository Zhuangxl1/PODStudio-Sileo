import {randomUUID} from 'node:crypto';
import {miniToolsUploadHint,parseUploadRetryAfter} from './dist/image-upload.js';
import {validateImageUrl} from './dist/xlsx-template.js';

const API_ORIGIN = 'https://api.mini-tools.uk';
const USAGE_URL = API_ORIGIN + '/v1/usage';
export const MINI_TOOLS_UPLOAD_URL = API_ORIGIN + '/v1/upload';
export const MINI_TOOLS_MAX_BYTES = 5 * 1024 * 1024;
export const MINI_TOOLS_DEFAULT_DURATION = '30-day';
const DURATIONS = new Set(['1-day','7-day','30-day','permanent']);
const EXTENSIONS = Object.freeze({'image/jpeg':'jpg','image/png':'png','image/gif':'gif','image/webp':'webp'});
const FAILURE_CODES = Object.freeze({
  400:'POD_UPLOAD_MINI_TOOLS_REQUEST',
  401:'POD_UPLOAD_MINI_TOOLS_AUTH',
  403:'POD_UPLOAD_MINI_TOOLS_FORBIDDEN',
  409:'POD_UPLOAD_MINI_TOOLS_CONFLICT',
  413:'POD_UPLOAD_MINI_TOOLS_SIZE',
  415:'POD_UPLOAD_MINI_TOOLS_FORMAT',
  429:'POD_UPLOAD_MINI_TOOLS_QUOTA',
});

function providerError(status, code) {
  return Object.assign(new Error(miniToolsUploadHint(code,status)),{name:'PodImageUploadError',status,code});
}

export function miniToolsCredentials({userId, apiKey, duration = MINI_TOOLS_DEFAULT_DURATION} = {}) {
  const normalizedUserId = typeof userId === 'string' ? userId.trim() : '';
  const normalizedKey = typeof apiKey === 'string' ? apiKey.trim().replace(/^Bearer\s+/i,'') : '';
  if (!/^[a-zA-Z0-9._-]{1,160}$/u.test(normalizedUserId)) throw new Error('请填写有效的 Mini Tools 用户 ID。');
  if (!/^[\x21-\x7e]{1,4096}$/u.test(normalizedKey)) throw new Error('请填写有效的 Mini Tools API Key。');
  if (!DURATIONS.has(duration)) throw new Error('请选择有效的 Mini Tools 图片保留期限。');
  return {userId:normalizedUserId,apiKey:normalizedKey,duration};
}

async function readJson(response) {
  const reader = response.body?.getReader?.();
  if (!reader) throw providerError(502,'POD_UPLOAD_MINI_TOOLS_RESULT');
  const decoder = new TextDecoder();
  let size = 0, result = '';
  try {
    for (;;) {
      const {value,done} = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 128 * 1024) throw providerError(502,'POD_UPLOAD_MINI_TOOLS_RESULT');
      result += decoder.decode(value,{stream:true});
    }
    return JSON.parse(result+decoder.decode());
  } catch {
    throw providerError(502,'POD_UPLOAD_MINI_TOOLS_RESULT');
  } finally {
    void reader.cancel().catch(()=>{});
    reader.releaseLock();
  }
}

export function createMiniToolsImageClient({fetchImpl = fetch} = {}) {
  async function request(url,credentials,{method,body,signal,idempotencyKey,timeout}) {
    signal?.throwIfAborted();
    const requestSignal = AbortSignal.timeout(timeout);
    const headers = {
      Accept:'application/json',
      'X-API-User-ID':credentials.userId,
      Authorization:'Bearer '+credentials.apiKey,
      ...(idempotencyKey ? {'Idempotency-Key':idempotencyKey} : {}),
    };
    let response;
    try {
      response = await fetchImpl(url,{
        method,headers,...(body ? {body} : {}),
        redirect:'error',credentials:'omit',signal:signal ? AbortSignal.any([signal,requestSignal]) : requestSignal,
      });
    } catch {
      signal?.throwIfAborted();
      throw providerError(502,'POD_UPLOAD_MINI_TOOLS_TRANSPORT');
    }
    if (!response.ok) {
      const code = FAILURE_CODES[response.status];
      const error=code ? providerError(response.status,code) : providerError(502,'POD_UPLOAD_MINI_TOOLS_UNAVAILABLE');
      if(response.status===429){
        error.retryAfterMs=parseUploadRetryAfter(response.headers.get('Retry-After'));
        if(error.retryAfterMs===undefined){
          const data=await readJson(response).catch(()=>null);
          const quota=data?.usage?.[credentials.duration==='permanent'?'permanent':'temporary'];
          const resetAt=Date.parse(quota?.reset_at);
          if(quota?.remaining===0&&Number.isFinite(resetAt)&&resetAt>Date.now())error.retryAfterMs=resetAt-Date.now();
        }else void response.body?.cancel().catch(()=>{});
      }else void response.body?.cancel().catch(()=>{});
      throw error;
    }
    const data = await readJson(response);
    signal?.throwIfAborted();
    return data;
  }

  async function check(settings,{signal} = {}) {
    const credentials = miniToolsCredentials(settings);
    let result;
    try{result=await request(USAGE_URL,credentials,{method:'GET',signal,timeout:10000});}
    catch(error){
      if(error?.code==='POD_UPLOAD_MINI_TOOLS_TRANSPORT')throw new Error('主机无法读取 Mini Tools 账号额度，请检查网络后重试。');
      throw error;
    }
    const quota = result?.usage?.[credentials.duration==='permanent' ? 'permanent' : 'temporary'];
    if (result?.success!==true || typeof quota?.enabled!=='boolean') throw providerError(502,'POD_UPLOAD_MINI_TOOLS_RESULT');
    if (!quota.enabled) throw new Error(credentials.duration==='permanent'
      ? '当前 Mini Tools 账号未开通永久图片存储，请选择账号支持的保留期限。'
      : '当前 Mini Tools 账号未开通临时图片存储。');
    return credentials;
  }

  async function upload(file,settings,{signal} = {}) {
    const credentials = miniToolsCredentials(settings);
    if (!(file instanceof Blob) || !file.size) throw providerError(400,'POD_UPLOAD_MINI_TOOLS_REQUEST');
    const mime=file.type.toLowerCase();
    if (!Object.hasOwn(EXTENSIONS,mime)) throw providerError(415,'POD_UPLOAD_MINI_TOOLS_FORMAT');
    if (file.size > MINI_TOOLS_MAX_BYTES) throw providerError(413,'POD_UPLOAD_MINI_TOOLS_SIZE');
    const body = new FormData();
    body.append('duration',credentials.duration);
    body.append('file',file,'pod-effect.'+EXTENSIONS[mime]);
    const options = {method:'POST',body,signal,idempotencyKey:randomUUID(),timeout:40000};
    let result;
    try {
      result = await request(MINI_TOOLS_UPLOAD_URL,credentials,options);
    } catch (error) {
      if (error?.code!=='POD_UPLOAD_MINI_TOOLS_TRANSPORT') throw error;
      // An interrupted response may already have consumed quota. Replay the same upload intent.
      result = await request(MINI_TOOLS_UPLOAD_URL,credentials,options);
    }
    const item = result?.uploaded?.[0];
    if (result?.success!==true || result.uploaded?.length!==1 || item?.success!==true ||
      item.duration!==credentials.duration || (credentials.duration!=='permanent' && !Number.isFinite(Date.parse(item.expires_at)))) {
      throw providerError(502,'POD_UPLOAD_MINI_TOOLS_RESULT');
    }
    try {
      const url = new URL(validateImageUrl(item.url));
      if (url.protocol!=='https:' || url.port || url.search || url.hash || !url.hostname.endsWith('.mini-tools.uk')) throw new Error();
      return url.href;
    } catch {
      throw providerError(502,'POD_UPLOAD_MINI_TOOLS_RESULT');
    }
  }

  return {check,upload};
}
