import {descriptionImageUrls} from './miaoshou-description-images.mjs';
import {miaoshouId} from './dist/miaoshou-policy.js';
import {createHash} from 'node:crypto';
import {serializeMiaoshou} from './miaoshou-client.mjs';
import {builtinMiaoshouCategoryName} from './miaoshou-category-names.mjs';
import {readMiaoshouCategoryName} from './dist/miaoshou-editor-read-model.js';
const own=(value,key)=>Object.hasOwn(value,key);
function canonical(value){
  if(Array.isArray(value))return value.map(canonical);
  if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])]));
  return value;
}
/** Bind the complete verified original, including its opaque concurrency token,
 * claims and unknown product fields. Response object key order is immaterial. */
export function miaoshouEditRevision(detail){
  if(!detail||typeof detail.ossMd5!=='string'||!detail.ossMd5||!Array.isArray(detail.claimToShopIds)||!detail.shopCollectItemInfo||typeof detail.shopCollectItemInfo!=='object')throw Object.assign(new Error('商品原件版本无效，请重新读取。'),{code:'MIAOSHOU_EDIT_INVALID',status:400});
  return createHash('sha256').update(serializeMiaoshou(canonical({ossMd5:detail.ossMd5,claimToShopIds:detail.claimToShopIds,shopCollectItemInfo:detail.shopCollectItemInfo}))).digest('hex');
}
function productView(info,target,categoryId){
  const product={detailId:String(target.detailId??info.detailId),shopId:target.shopId,categoryId};
  for(const [source,destination]of [['title','title'],['notes','description'],['mainImgVideoUrl','videoUrl'],['deliveryOptionSetType','deliveryMode'],['categoryName','categoryName'],['shopName','shopName']])if(own(info,source)&&typeof info[source]==='string')product[destination]=info[source];
  if(typeof info.oriTitle==='string'&&info.oriTitle.trim())product.sourceTitle=Array.from(info.oriTitle.trim()).slice(0,255).join('');
  if(own(info,'imgUrls')&&Array.isArray(info.imgUrls))product.mainImages=structuredClone(info.imgUrls);
  if(info.sizeChartType==='image'&&typeof info.sizeChart==='string')product.sizeChartUrl=info.sizeChart;
  if(typeof info.categoryPath==='string'||Array.isArray(info.categoryPath)&&info.categoryPath.every(v=>typeof v==='string'))product.categoryPath=structuredClone(info.categoryPath);
  if(!readMiaoshouCategoryName(product)){const category=builtinMiaoshouCategoryName(categoryId);if(category){product.categoryName=category.name;product.categoryPath=category.path;}}
  const numeric=value=>(typeof value==='number'||typeof value==='string'&&value.trim()!==''&&/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/u.test(value))&&Number.isFinite(Number(value))?Number(value):undefined;
  if(own(info,'weight')){const value=numeric(info.weight);if(value!==undefined)product.weightGrams=value*1000;}
  for(const [source,destination]of [['packageLength','length'],['packageWidth','width'],['packageHeight','height']])if(own(info,source)){const value=numeric(info[source]);if(value!==undefined)(product.packageDimensionsCm??={})[destination]=value;}
  if([true,1,'1'].includes(info.isCodOpen))product.codEnabled=true;
  else if([false,0,'0'].includes(info.isCodOpen))product.codEnabled=false;
  return product;
}
export const MIAOSHOU_EDIT_OPTION_GROUPS=Object.freeze(['metadata','warehouses','manufacturers','responsiblePersons']);
export const MIAOSHOU_WAREHOUSE_SHOPS_PER_REQUEST=20;
export const MIAOSHOU_WAREHOUSES_PER_SHOP=10000;

export function usableMiaoshouWarehouse(row){
  const status=String(row?.warehouseEffectStatus??'').trim().toLowerCase();
  return !['false','0','ineffective','inactive','disabled','invalid','expired','不可用','停用','失效'].includes(status);
}

export function normalizeMiaoshouWarehouseShop(data,shop){
  try{
    const matches=Array.isArray(data?.shopWarehouseList)?data.shopWarehouseList.filter(row=>String(row?.shopId??'')===shop.id):[];
    if(matches.length!==1)return;
    const [source]=matches;
    if(!Array.isArray(source.warehouseList)||source.warehouseList.length>MIAOSHOU_WAREHOUSES_PER_SHOP||
      source.platform&&String(source.platform).toLowerCase()!=='tiktok'||
      source.site&&shop.siteCode&&String(source.site).toUpperCase()!==String(shop.siteCode).toUpperCase())return;
    if(miaoshouId(source.shopId)!==shop.id)return;
    const seen=new Set();
    return source.warehouseList.map(row=>{
      const warehouseId=miaoshouId(row?.warehouseId),name=row?.warehouseName;
      if(seen.has(warehouseId)||row.shopId!=null&&row.shopId!==''&&miaoshouId(row.shopId)!==shop.id||
        typeof name!=='string'||!name.trim()||name.length>4096||name.includes('\u0000'))throw invalidOptions();
      seen.add(warehouseId);
      const result={warehouseId,warehouseName:name.trim()};
      for(const key of ['warehouseSubType','warehouseEffectStatus','isDefault']){
        const value=row[key];
        if(value==null)continue;
        if(key==='isDefault'&&(typeof value==='boolean'||['true','false'].includes(value)))result[key]=value===true||value==='true'?'1':'0';
        else if(typeof value==='boolean'||Number.isSafeInteger(value))result[key]=String(value);
        else if(typeof value==='string'&&value.length<=160&&!value.includes('\u0000'))result[key]=value;
        else throw invalidOptions();
      }
      return result;
    });
  }catch{return undefined;}
}

const invalidOptions=()=>Object.assign(new Error('编辑选项参数无效。'),{code:'MIAOSHOU_EDIT_INVALID',status:400});
export const MIAOSHOU_CATEGORY_UNASSIGNED='妙手尚未返回有效的商品类目，请在妙手补齐类目后重新加载商品。';
function optionNeeds(needs){if(!Array.isArray(needs)||needs.some(key=>!MIAOSHOU_EDIT_OPTION_GROUPS.includes(key)))throw invalidOptions();return [...new Set(needs)];}
function optionRequest(key,shopId,categoryId){return {metadata:['categoryMetadata',{cid:BigInt(categoryId),shopIds:[BigInt(shopId)]}],warehouses:['warehouses',{shopIds:[BigInt(shopId)]}],manufacturers:['manufacturers',{shopId:BigInt(shopId),refresh:0}],responsiblePersons:['responsiblePersons',{shopId:BigInt(shopId),refresh:0}]}[key];}
function optionValue(key,data,shopId){
  const value=key==='metadata'?data?.categoryMetadata:key==='warehouses'?data?.shopWarehouseList?.find(row=>String(row.shopId)===shopId)?.warehouseList:key==='manufacturers'?data?.manufacturerList:data?.responsiblePersonList;
  if(key==='metadata'?(!value||typeof value!=='object'||Array.isArray(value)):!Array.isArray(value))throw Object.assign(new Error('字段选项格式不完整。'),{code:'REMOTE_FORMAT'});
  return structuredClone(value);
}
const optionLabels={metadata:'类目属性',warehouses:'店铺仓库',manufacturers:'制造商',responsiblePersons:'负责人'};
function optionFailure(key,error){
  const raw=String(error?.code??''),reasonCode=/^[A-Za-z][A-Za-z0-9_]{0,79}$/u.test(raw)?raw:'MIAOSHOU_OPTION_UNAVAILABLE';
  const limited=/RateLimit$/u.test(reasonCode)||reasonCode==='REMOTE_RATE_LIMIT';
  const reasons={REMOTE_TIMEOUT:'妙手读取超时，请稍后重试。',REMOTE_CONNECTION:'妙手连接暂时失败，请稍后重试。',REMOTE_FORMAT:'妙手返回的选项格式不完整，请重新加载。',appNotFound:'妙手应用不存在或未启用。',appNoPermission:'妙手应用没有该接口权限。',signMissing:'妙手请求签名缺失。',signInvalid:'妙手请求签名校验失败。',signExpired:'妙手请求已过期，请校准主机时间。',ipNotInWhitelist:'当前主机出口 IP 不在妙手白名单中。',routeNotFound:'妙手接口路径不存在。'};
  const httpStatus=Number.isInteger(error?.httpStatus)&&error.httpStatus>=100&&error.httpStatus<=599?error.httpStatus:undefined;
  const reason=limited?'妙手接口达到频率限制，请稍后重试。':reasons[reasonCode]||'妙手暂未返回有效选项，请重新加载。';
  return Object.assign(new Error('读取'+optionLabels[key]+'失败：'+reason),{code:'MIAOSHOU_EDIT_CONTEXT',status:502,data:{optionGroup:key,reasonCode,...(httpStatus?{httpStatus}:{})}});
}
/** Bound the whole queued read as well as each network attempt. A slow option
 * must not keep the shared Miaoshou request queue occupied for several minutes. */
async function readOption({client,key,shop,category,guard,signal}){
  const deadline=AbortSignal.timeout(35000),reading=signal?AbortSignal.any([signal,deadline]):deadline;
  const active=async()=>{reading.throwIfAborted();await guard();reading.throwIfAborted();};
  let onAbort;
  const cancelled=new Promise((_,reject)=>{onAbort=()=>reject(reading.reason);reading.addEventListener('abort',onAbort,{once:true});if(reading.aborted)onAbort();});
  void cancelled.catch(()=>{});
  try{
    await active();
    const [operation,payload]=optionRequest(key,shop,category);
    const data=await Promise.race([client.call(operation,payload,{guard:active,signal:reading,timeoutMs:15000,maxRetries:1}),cancelled]);
    await active();return optionValue(key,data,shop);
  }catch(error){
    await guard();
    if(deadline.aborted&&!signal?.aborted)throw Object.assign(new Error('妙手读取超时，请稍后重试。'),{code:'REMOTE_TIMEOUT'});
    throw error;
  }finally{reading.removeEventListener('abort',onAbort);}
}
export async function loadMiaoshouEditOptions({client,shopId,categoryId,guard=async()=>{},needs=MIAOSHOU_EDIT_OPTION_GROUPS,partial=false}){
  const result={errors:{}},shop=miaoshouId(shopId),category=categoryId===''?'':miaoshouId(categoryId);
  for(const key of optionNeeds(needs)){
    if(key==='metadata'&&!category){result.errors.metadata=MIAOSHOU_CATEGORY_UNASSIGNED;continue;}
    try{result[key]=await readOption({client,key,shop,category,guard});}
    catch(error){await guard();const failure=optionFailure(key,error);if(!partial)throw failure;result.errors[key]=failure.message;}
  }
  return result;
}
/** A service-local, success-only cache for display options. Saves bypass it. */
export function createMiaoshouEditOptionsCache({client,now=Date.now,ttlMs=5*60*1000,maxEntries=128}={}){
  if(typeof client?.call!=='function'||typeof now!=='function'||!Number.isFinite(ttlMs)||ttlMs<0||!Number.isSafeInteger(maxEntries)||maxEntries<1)throw invalidOptions();
  const cache=new Map(),pending=new Map();let generation=0;
  const changed=()=>Object.assign(new Error('妙手连接已变化，请重新读取编辑选项。'),{code:'CONTEXT_CHANGED',status:409});
  return {
    clear(){generation++;cache.clear();for(const entry of pending.values())entry.controller.abort(changed());pending.clear();},
    async load({contextId,accountScope,shopId,categoryId,needs=MIAOSHOU_EDIT_OPTION_GROUPS,guard=async()=>{}}={}){
      if(typeof contextId!=='string'||!contextId||typeof accountScope!=='string'||!/^[a-f0-9]{64}$/u.test(accountScope)||typeof guard!=='function')throw invalidOptions();
      const groups=optionNeeds(needs),shop=miaoshouId(shopId),category=categoryId===''?'':miaoshouId(categoryId),version=generation,result={errors:{}};
      const active=async()=>{await guard();if(version!==generation)throw changed();};
      await active();for(const [key,entry]of cache)if(entry.expires<=now())cache.delete(key);
      await Promise.all(groups.map(async key=>{
        if(key==='metadata'&&!category){result.errors.metadata=MIAOSHOU_CATEGORY_UNASSIGNED;return;}
        try{
          await active();const cacheKey=JSON.stringify([contextId,accountScope,shop,key,key==='metadata'?category:'']);const saved=cache.get(cacheKey);
          if(saved&&saved.expires>now()){cache.delete(cacheKey);cache.set(cacheKey,saved);await active();result[key]=structuredClone(saved.value);return;}
          let entry=pending.get(cacheKey);
          if(!entry){
            if(pending.size>=maxEntries)throw new Error('编辑选项正在读取，请稍后重试。');
            const controller=new AbortController();
            const promise=(async()=>{const value=await readOption({client,key,shop,category,guard:active,signal:controller.signal});await active();cache.set(cacheKey,{value:structuredClone(value),expires:now()+ttlMs});while(cache.size>maxEntries)cache.delete(cache.keys().next().value);return value;})();
            entry={promise,controller};pending.set(cacheKey,entry);const release=()=>{if(pending.get(cacheKey)===entry)pending.delete(cacheKey);};void promise.then(release,release);
          }
          const value=await entry.promise;await active();result[key]=structuredClone(value);
        }catch(error){await active();result.errors[key]=optionFailure(key,error).message;}
      }));
      await active();return result;
    }
  };
}
export async function loadMiaoshouEditContext({info,target,detail,client,guard=async()=>{},needs=MIAOSHOU_EDIT_OPTION_GROUPS,partial=false,allowMissingCategory=false}){
  let categoryId;
  try{categoryId=miaoshouId(info.cid);}catch(error){if(!allowMissingCategory)throw error;categoryId='';}
  const context={shopId:target.shopId,categoryId,...(categoryId?{}:{categoryNotice:MIAOSHOU_CATEGORY_UNASSIGNED}),descriptionImages:descriptionImageUrls(info.notes),info:structuredClone({detailId:String(info.detailId),brandId:info.brandId,brandName:info.brandName,skuPropertyList:info.skuPropertyList||[],skuMap:info.skuMap||{},productAttributes:info.productAttributes||[],productCertifications:info.productCertifications||[],manufacturerIds:info.manufacturerIds||[],responsiblePersonIds:info.responsiblePersonIds||[]}),errors:{}};
  context.product=productView(info,target,context.categoryId);
  if(detail!==undefined)context.revision=miaoshouEditRevision(detail);
  return Object.assign(context,await loadMiaoshouEditOptions({client,shopId:target.shopId,categoryId:context.categoryId,guard,needs,partial}));
}
