import {mkdir,open,readFile,rename,unlink} from 'node:fs/promises';
import {resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {validateMiaoshouMockupTemplateIds} from './dist/miaoshou-mockup-template-binding.js';

const empty=()=>({revision:0,templateIds:[]});
const storageError=()=>Object.assign(new Error('店铺模板匹配读取或保存失败，请检查主机目录后重试。'),{status:503,code:'MIAOSHOU_MOCKUP_BINDING_STORAGE'});
const conflict=message=>Object.assign(new Error(message),{status:409,code:'MIAOSHOU_MOCKUP_BINDING_CONFLICT'});

export function createMiaoshouMockupTemplateBindings({root}={}){
  const folder=root?resolve(root,'mockup-template-bindings'):null;
  const memory=new Map(),pending=new Map();
  let closed=false;
  function keyOf({accountScope,shopId}){
    if(closed)throw storageError();
    if(typeof accountScope!=='string'||!(/^[a-f0-9]{64}$/u.test(accountScope))||typeof shopId!=='string'||!(/^[1-9][0-9]{0,24}$/u.test(shopId)))throw new Error('店铺模板匹配的账号或店铺无效。');
    return accountScope+'-'+shopId;
  }
  async function read(key){
    if(!folder)return structuredClone(memory.get(key)||empty());
    try{
      const raw=await readFile(resolve(folder,key+'.json'),'utf8');
      if(raw.length>1024*1024)throw storageError();
      const {version,revision,templateIds}=JSON.parse(raw);
      if(version!==1||!Number.isSafeInteger(revision)||revision<0)throw storageError();
      return {revision,templateIds:validateMiaoshouMockupTemplateIds(templateIds)};
    }catch(error){
      if(error.code==='ENOENT')return empty();
      throw storageError();
    }
  }
  async function save(input,{guard=async()=>{}}={}){
    const key=keyOf(input),templateIds=validateMiaoshouMockupTemplateIds(input.templateIds);
    if(!Number.isSafeInteger(input.revision)||input.revision<0)throw new Error('店铺模板匹配的版本无效。');
    const previous=pending.get(key)||Promise.resolve();
    const write=previous.then(async()=>{
      const path=folder?resolve(folder,key+'.json'):null;
      let lock,temp;
      try{
        if(path){
          await mkdir(folder,{recursive:true});
          try{lock=await open(path+'.lock','wx');}
          catch(error){if(error.code==='EEXIST')throw conflict('此店铺的模板匹配正在保存，请稍后重试。');throw error;}
        }
        await guard();
        const current=await read(key);
        if(current.revision!==input.revision||current.revision===Number.MAX_SAFE_INTEGER)throw conflict('店铺的模板匹配已更新，请刷新后重新选择。');
        const value={revision:current.revision+1,templateIds};
        if(path){
          temp=path+'.'+randomUUID()+'.tmp';
          const file=await open(temp,'wx');
          try{await file.writeFile(JSON.stringify({version:1,...value}));await file.sync();}finally{await file.close();}
          await guard();
          await rename(temp,path);
          temp=null;
        }else{await guard();memory.set(key,structuredClone(value));}
        return value;
      }catch(error){
        if(error.status)throw error;
        throw storageError();
      }finally{
        if(temp)await unlink(temp).catch(()=>{});
        if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}
      }
    });
    const settled=write.catch(()=>{});
    pending.set(key,settled);
    void settled.then(()=>{if(pending.get(key)===settled)pending.delete(key);});
    return write;
  }
  return {async list(input){return read(keyOf(input));},save,async close(){closed=true;await Promise.all([...pending.values()]);}};
}
