import {createHash} from 'node:crypto';
import {validateAdsPowerEndpoint} from './adspower-settings.mjs';

const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const fail=(code,message,status=503)=>Object.assign(new Error(message),{code,status});
const validId=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/u.test(value);
const text=value=>typeof value==='string'||typeof value==='number'?String(value).slice(0,255):'';
const environment=value=>({id:text(value.profile_id||value.user_id||value.id),no:text(value.profile_no||value.serial_number||value.no),name:text(value.name||value.profile_name),group:text(value.group_name||value.group_id),platform:text(value.platform||value.domain_name)});
const unsupported=(status,result)=>[404,405].includes(status)||result?.code!==0&&/^(?:api\s*(?:is\s*)?(?:not\s*(?:found|support(?:ed)?)|unsupported)|(?:unsupported|unknown)\s*(?:api|endpoint|route)|(?:endpoint|route)\s*not\s*found)/iu.test(String(result?.msg||result?.message||'').trim());
function connectionData(data){
  if(!data||typeof data!=='object')return null;
  const ws={};
  if(typeof data.ws?.puppeteer==='string'){let url;try{url=new URL(data.ws.puppeteer);}catch{}if(url&&['ws:','wss:'].includes(url.protocol)&&['127.0.0.1','localhost','[::1]'].includes(url.hostname)&&!url.username&&!url.password)ws.puppeteer=url.href;}
  if(typeof data.ws?.selenium==='string'&&/^(?:127\.0\.0\.1|localhost):[0-9]{1,5}$/u.test(data.ws.selenium))ws.selenium=data.ws.selenium;
  const debug_port=/^[0-9]{1,5}$/u.test(String(data.debug_port||''))?String(data.debug_port):'';
  if(!ws.puppeteer&&!ws.selenium)return null;
  return {ws,debug_port,...(typeof data.webdriver==='string'?{webdriver:data.webdriver}:{})};
}
/** Serialized Local API access. V1 fallback occurs only for an explicitly absent V2 route. */
export function createAdsPowerClient({settings,fetchImpl=fetch,now=Date.now,sleep=delay,minInterval=1000}={}){
  if(!settings?.getConnectionConfig)throw new Error('AdsPower 设置服务未连接。');
  let queue=Promise.resolve(),lastRequest=-Infinity,catalog=new Map(),catalogAt=-Infinity,closed=false,catalogScope='';
  const serial=operation=>{const next=queue.then(operation,operation);queue=next.catch(()=>{});return next;};
  async function request(path,{method='GET',body}={},snapshot){return serial(async()=>{
    if(closed)throw fail('ADS_UNAVAILABLE','AdsPower 连接已关闭。');
    const config=snapshot||await settings.getConnectionConfig(),base=validateAdsPowerEndpoint(config.endpoint),wait=Math.max(0,Math.max(1000,minInterval)-(now()-lastRequest));if(wait)await sleep(wait);lastRequest=now();if(closed)throw fail('ADS_UNAVAILABLE','AdsPower 连接已关闭。');
    let response;try{response=await fetchImpl(base+path,{method,headers:{Accept:'application/json',...(config.apiKey?{Authorization:'Bearer '+config.apiKey}:{}),...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(30000)});}catch{throw fail('ADS_UNAVAILABLE','无法连接本机 AdsPower，请启动 AdsPower 并开启 Local API。');}
    if(closed)throw fail('ADS_UNAVAILABLE','AdsPower 连接已关闭。');
    let bytes=0,chunks=[];try{for await(const chunk of response.body){bytes+=chunk.length;if(bytes>2*1024*1024)throw new Error();chunks.push(chunk);}let result;try{result=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{if(![401,403,404,405].includes(response.status))throw new Error();result=null;}return {response,result};}catch{throw fail('ADS_RESPONSE','AdsPower 返回内容无效，请检查 Local API 版本。');}
  });}
  function checked({response,result}){
    if(result?.code===0&&response.ok)return result.data;
    const message=String(result?.msg||result?.message||'');
    if(response.status===401||response.status===403||/api.?key|unauth|forbidden/iu.test(message))throw fail('ADS_KEY_REQUIRED','AdsPower 需要有效的 API Key，请在主机配置中填写。',401);
    if(response.status===429||/rate|too many|frequency/iu.test(message))throw fail('ADS_RATE_LIMIT','AdsPower 请求频率受限，请稍后重试。',429);
    throw fail('ADS_REQUEST','AdsPower 操作未完成，请检查环境状态和 Local API。');
  }
  async function versioned(v2,v1,snapshot){const result=await request(v2.path,v2,snapshot);return checked(unsupported(result.response.status,result.result)?await request(v1.path,v1,snapshot):result);}
  async function status(){checked(await request('/status'));return {available:true};}
  const scope=config=>createHash('sha256').update(JSON.stringify([config.endpoint,config.apiKey])).digest('hex');
  async function listEnvironments(snapshot){
    snapshot=snapshot||await settings.getConnectionConfig();
    const result=[],seen=new Set();
    for(let page=1;page<=50;page++){
      const data=await versioned({path:'/api/v2/browser-profile/list',method:'POST',body:{page:String(page),limit:'100'}},{path:`/api/v1/user/list?page=${page}&page_size=100`},snapshot);
      if(!Array.isArray(data?.list))throw fail('ADS_RESPONSE','AdsPower 环境列表格式无效。');
      for(const raw of data.list){const item=environment(raw);if(!validId(item.id))throw fail('ADS_RESPONSE','AdsPower 环境编号无效。');if(!seen.has(item.id)){seen.add(item.id);result.push(item);}}
      if(data.list.length<100){catalog=new Map(result.map(item=>[item.id,item]));catalogAt=now();catalogScope=scope(snapshot);return result;}
    }
    throw fail('ADS_LIST_LIMIT','AdsPower 环境过多，请按分组精简后重试。');
  }
  async function connectEnvironment(id){
    if(!validId(id))throw fail('ADS_ENVIRONMENT','请选择有效的 AdsPower 环境。',400);
    const snapshot=await settings.getConnectionConfig();
    if(catalogScope!==scope(snapshot)||!catalog.has(id)||now()-catalogAt>60000)await listEnvironments(snapshot);const item=catalog.get(id);if(!item)throw fail('ADS_ENVIRONMENT','所选 AdsPower 环境已不存在，请重新读取。',404);
    const data=await versioned({path:'/api/v2/browser-profile/active?profile_id='+encodeURIComponent(id)},{path:'/api/v1/browser/active?user_id='+encodeURIComponent(id)},snapshot);
    let connection=connectionData(data);
    if(!connection){const started=await versioned({path:'/api/v2/browser-profile/start',method:'POST',body:{profile_id:id,headless:'0',last_opened_tabs:'1',proxy_detection:'0'}},{path:'/api/v1/browser/start?user_id='+encodeURIComponent(id)+'&headless=0&open_tabs=1&ip_tab=0'},snapshot);connection=connectionData(started);}
    if(!connection)throw fail('ADS_CONNECTION','AdsPower 已响应，但没有可用的本机浏览器连接，请检查环境状态。');
    return {environment:{...item},connection};
  }
  function invalidateCatalog(){catalog.clear();catalogAt=-Infinity;catalogScope='';}
  function close(){closed=true;invalidateCatalog();}
  return {status,listEnvironments,connectEnvironment,invalidateCatalog,close};
}
