const flag=v=>v===true||v===1||v==='1'||v==='true';
const fail=message=>{throw Object.assign(new Error(message),{code:'MIAOSHOU_EDIT_INVALID',status:400});};
function index(rows,key,label){
  if(!Array.isArray(rows))fail('未读取到'+label+'选项。');const map=new Map();
  for(const row of rows){const raw=row?.[key];if(raw===undefined||raw===null||typeof raw==='number'&&!Number.isSafeInteger(raw))continue;const id=String(raw);if(!id.trim())continue;if(map.has(id))fail(label+'编号重复，无法确认真实选项。');map.set(id,row);}return map;
}
/** Fresh official metadata determines every selected ID/name. No name-to-ID mapping. */
export function compileMiaoshouAttributeUpdates(attributes,metadata){
  const defs=index(metadata?.categoryProductAttrList,'attrId','商品属性');
  return attributes.map(a=>{
    const def=defs.get(a.id);if(!def)fail('属性不属于当前商品类目。');
    if(a.clear===true){if(['isRequired','required','isMandatory'].some(key=>flag(def[key])))fail('必填属性不能清空。');return {attributeId:a.id,attributeName:String(def.name||''),attributeNameAlias:String(def.attributeNameAlias||''),attributeValues:[]};}
    if(a.values.length>1&&!flag(def.isMultipleSelected))fail('该属性只允许单选。');const options=index(def.values??[],'id','属性值');
    const values=a.values.map(v=>{
      if(v.id){const option=options.get(v.id);if(!option)fail('属性值不在当前后台选项中。');if(typeof option.name!=='string'||!option.name.trim())fail('属性值名称未能确认，请重新读取后台选项。');return {valueId:String(option.id),valueName:option.name};}
      if(!flag(def.isCustomized))fail('该属性不允许自定义值。');if(def.valueDataFormat&&Object.keys(def.valueDataFormat).length)fail('该自定义属性有专用格式，请在后台填写。');return {valueName:v.name};
    });return {attributeId:a.id,attributeName:String(def.name||''),attributeNameAlias:String(def.attributeNameAlias||''),attributeValues:values};
  });
}
/** Check the merged final state too: an unchanged old value can depend on a cleared field. */
export function validateMiaoshouAttributeDependencies(attributes,certifications,metadata){
  const defs=index(metadata?.categoryProductAttrList,'attrId','商品属性');
  for(const attribute of attributes){const def=defs.get(String(attribute.attributeId));if(!def)continue;
    for(const value of attribute.attributeValues??[]){if(value.valueId===undefined)continue;
      for(const [key,rows,idKey,valueKey]of [['valueIdAndRequiredAttrIdsMap',attributes,'attributeId','attributeValues'],['valueIdAndRequiredCertificationIdsMap',certifications,'id','files']]){
        const required=def[key]?.[String(value.valueId)]??[];if(!Array.isArray(required))fail('属性关联规则无法确认，请在后台填写。');
        for(const id of required){const match=rows.find(row=>String(row[idKey])===String(id));if(!match||!Array.isArray(match[valueKey])||!match[valueKey].length)fail('所选或保留的属性还有必填关联属性或认证，请一并填写。');}
      }
    }
  }
}
