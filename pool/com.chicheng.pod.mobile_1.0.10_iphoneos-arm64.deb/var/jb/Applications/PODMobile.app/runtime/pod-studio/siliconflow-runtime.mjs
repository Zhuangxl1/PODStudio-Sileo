import {randomUUID} from 'node:crypto';
import {EventEmitter} from 'node:events';
import {PassThrough, Writable} from 'node:stream';
import {StringDecoder} from 'node:string_decoder';
import {createMiaoshouImageReader} from './miaoshou-image.mjs';

const API = 'https://api.siliconflow.cn/v1/';
const MODEL_TTL_MS = 5 * 60_000;
const MODEL_TIMEOUT_MS = 12_000;
const TURN_TIMEOUT_MS = 10 * 60_000;
const IMAGE_LIMIT = 25 * 1024 * 1024;
const INPUT_IMAGE_LIMIT = 64 * 1024 * 1024;
const LINE_LIMIT = Math.ceil(INPUT_IMAGE_LIMIT / 3) * 4 + 1024 * 1024;
const JSON_LIMIT = 1024 * 1024;
const DATA_IMAGE = /^data:image\/(?:png|jpeg|webp);base64,/u;
const PNG_SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
const JPEG_SIGNATURE = Buffer.from([255, 216, 255]);
const MODELS = new Map([
  ['Qwen/Qwen-Image-Edit-2509', 3],
  ['Qwen/Qwen-Image-Edit', 1],
  ['Qwen/Qwen-Image', 0],
]);

const MESSAGES = Object.freeze({
  missingKey: '请在设置中配置硅基流动 API Key。',
  auth: '硅基流动 API Key 无效，请检查设置。',
  denied: '硅基流动拒绝了请求，请核对 API Key 和模型权限。',
  quota: '硅基流动余额或可用额度不足，请核对账户。',
  rate: '硅基流动请求过于频繁，请稍后手动重试。',
  busy: '硅基流动服务暂时繁忙，请稍后手动重试。',
  timeout: '硅基流动请求超时，尚未收到结果，请核对后手动重试。',
  network: '硅基流动连接失败，请检查主机网络后手动重试。',
  request: '硅基流动未接受图片请求，请核对指令和图片。',
  catalogue: '硅基流动未返回可用的图像模型，请刷新模型列表。',
  model: '硅基流动当前模型不可用，请选择列表中的图像模型。',
  effort: '硅基流动图像模型无需设置推理强度。',
  needsImage: '此硅基流动编辑模型需要参考图片。纯文字生成请选 Qwen/Qwen-Image。',
  textOnly: '此硅基流动模型只支持文字生成。上传参考图后请选择图像编辑模型。',
  tooManyImages: '参考图超过所选硅基流动模型支持的数量，请减少图片或改用支持多图的编辑模型。',
  invalidImage: '请提供有效的 PNG、JPG 或 WebP 参考图。',
  imageLimit: '硅基流动参考图超过上传大小限制。',
  response: '硅基流动未返回可用的生成图片。',
  download: '无法读取硅基流动返回的图片，请核对任务结果后手动重试。',
  thread: '会话不属于当前硅基流动连接。',
  running: '此硅基流动会话还有图像任务正在运行。',
  turn: '任务不属于当前硅基流动会话。',
  unsupported: '当前硅基流动连接仅支持图片生成和编辑。',
});

class SiliconFlowFailure extends Error {
  constructor(kind) {
    super(MESSAGES[kind]);
    this.kind = kind;
  }
}

export const isSiliconFlowImageModel = model => MODELS.has(model);

export function siliconFlowPublicError(error) {
  const kind = error?.siliconFlowError;
  return typeof kind === 'string' && Object.hasOwn(MESSAGES, kind) ? MESSAGES[kind] : null;
}

function errorPayload(error, fallback) {
  const kind = error instanceof SiliconFlowFailure ? error.kind : fallback;
  return {code: -32000, message: MESSAGES[kind], siliconFlowError: kind};
}

function httpFailure(status) {
  if (status === 401) return 'auth';
  if (status === 403) return 'denied';
  if (status === 402) return 'quota';
  if (status === 429) return 'rate';
  if (status === 408 || status === 504) return 'timeout';
  if (status >= 500) return 'busy';
  return 'request';
}

function hasImageSignature(bytes) {
  return bytes.subarray(0, 8).equals(PNG_SIGNATURE) || bytes.subarray(0, 3).equals(JPEG_SIGNATURE) ||
    bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
}

async function boundedJson(response, signal, invalid) {
  if (!response.body || Number(response.headers.get('content-length')) > JSON_LIMIT) {
    await response.body?.cancel().catch(() => {});
    throw new SiliconFlowFailure(invalid);
  }
  const reader = response.body.getReader();
  const chunks = [];
  let length = 0;
  let complete = false;
  try {
    for (;;) {
      signal.throwIfAborted();
      const {value, done} = await reader.read();
      if (done) {
        complete = true;
        break;
      }
      length += value.byteLength;
      if (length > JSON_LIMIT) throw new SiliconFlowFailure(invalid);
      chunks.push(value);
    }
    signal.throwIfAborted();
    return JSON.parse(Buffer.concat(chunks, length).toString('utf8'));
  } catch (error) {
    if (signal.aborted) throw signal.reason;
    if (error instanceof SiliconFlowFailure) throw error;
    throw new SiliconFlowFailure(invalid);
  } finally {
    if (!complete) await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

function createClient({apiKey, imageModel = '', fetchImpl = globalThis.fetch, imageReaderOptions} = {}) {
  const readImage = createMiaoshouImageReader(imageReaderOptions);
  let modelRequest = null;
  let catalogue = null;
  let expiresAt = 0;

  async function request(path, {signal, body, invalid}) {
    if (typeof apiKey !== 'string' || !/^[\x21-\x7e]{1,4096}$/u.test(apiKey)) throw new SiliconFlowFailure('missingKey');
    let response;
    try {
      response = await fetchImpl(new URL(path, API).href, {
        method: body ? 'POST' : 'GET',
        redirect: 'error',
        signal,
        headers: {Authorization: 'Bearer ' + apiKey, Accept: 'application/json', ...(body ? {'Content-Type': 'application/json'} : {})},
        ...(body ? {body: JSON.stringify(body)} : {}),
      });
    } catch (error) {
      if (signal.aborted) throw signal.reason;
      throw new SiliconFlowFailure('network');
    }
    if (!response.ok) {
      await response.body?.cancel().catch(() => {});
      throw new SiliconFlowFailure(httpFailure(response.status));
    }
    return boundedJson(response, signal, invalid);
  }

  async function listModels() {
    if (catalogue && Date.now() < expiresAt) return catalogue;
    if (modelRequest) return modelRequest;
    const signal = AbortSignal.timeout(MODEL_TIMEOUT_MS);
    modelRequest = (async () => {
      try {
        const result = await request('models?type=image', {signal, invalid: 'catalogue'});
        if (!Array.isArray(result?.data)) throw new SiliconFlowFailure('catalogue');
        const listed = new Set(result.data.map(row => row?.id));
        const supported = [...MODELS.keys()].filter(id => listed.has(id));
        if (!supported.length) throw new SiliconFlowFailure('catalogue');
        const preferred = supported.includes(imageModel) ? imageModel : supported[0];
        catalogue = supported.map(id => ({
          id, model: id, displayName: id, hidden: false, isDefault: id === preferred,
          inputModalities: MODELS.get(id) ? ['text', 'image'] : ['text'],
          supportedReasoningEfforts: [{reasoningEffort: 'none', description: '图像模型无需推理强度'}],
          defaultReasoningEffort: 'none',
        }));
        expiresAt = Date.now() + MODEL_TTL_MS;
        return catalogue;
      } catch (error) {
        if (signal.aborted) throw new SiliconFlowFailure('timeout');
        throw error;
      } finally {
        modelRequest = null;
      }
    })();
    return modelRequest;
  }

  async function generate(body, signal) {
    const result = await request('images/generations', {signal, body, invalid: 'response'});
    const address = result?.images?.[0]?.url;
    if (typeof address !== 'string' || !address || address.length > 8192) throw new SiliconFlowFailure('response');
    try {
      const url = new URL(address);
      if (url.hash) throw new SiliconFlowFailure('download');
      const image = await readImage(url.href, {signal});
      signal.throwIfAborted();
      if (!Buffer.isBuffer(image?.bytes) || image.bytes.length > IMAGE_LIMIT || !hasImageSignature(image.bytes)) {
        throw new SiliconFlowFailure('download');
      }
      return image.bytes.toString('base64');
    } catch (error) {
      if (signal.aborted) throw signal.reason;
      throw new SiliconFlowFailure('download');
    }
  }

  return {listModels, generate};
}

function imageBody(model, input) {
  const first = input?.[0];
  if (!Array.isArray(input) || first?.type !== 'text' || typeof first.text !== 'string' || !first.text.trim() || first.text.length > 120_000) {
    throw new SiliconFlowFailure('request');
  }
  const maxImages = MODELS.get(model);
  const count = input.length - 1;
  if (maxImages && !count) throw new SiliconFlowFailure('needsImage');
  if (!maxImages && count) throw new SiliconFlowFailure('textOnly');
  if (count > maxImages) throw new SiliconFlowFailure('tooManyImages');
  const body = {model, prompt: first.text};
  if (!count) body.image_size = '1328x1328';
  let totalBytes = 0;
  for (let i = 1; i <= count; i++) {
    const item = input[i];
    const prefix = item?.type === 'image' && typeof item.url === 'string' && item.url.match(DATA_IMAGE)?.[0];
    if (!prefix) throw new SiliconFlowFailure('invalidImage');
    const data = item.url.slice(prefix.length);
    if (!data.length || data.length % 4 !== 0) throw new SiliconFlowFailure('invalidImage');
    const bytes = data.length / 4 * 3 - (data.endsWith('==') ? 2 : data.endsWith('=') ? 1 : 0);
    totalBytes += bytes;
    if (bytes > IMAGE_LIMIT || totalBytes > INPUT_IMAGE_LIMIT) throw new SiliconFlowFailure('imageLimit');
    if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(data)) throw new SiliconFlowFailure('invalidImage');
    body[i === 1 ? 'image' : 'image' + i] = item.url;
  }
  return body;
}

export function createImageApiRuntime(client, {
  turnTimeoutMs = TURN_TIMEOUT_MS,
  runtimeName = 'pod-siliconflow',
  buildImageBody = imageBody,
  mapError = errorPayload,
} = {}) {
  const child = new EventEmitter();
  child.stdout = new PassThrough();
  child.stderr = new PassThrough();
  child.killed = false;
  const threads = new Map();
  const output = message => {
    if (!child.killed) child.stdout.write(JSON.stringify(message) + '\n');
  };
  const notify = (method, params) => output({method, params});
  const reply = (id, result) => output({id, result});
  const reject = (id, error) => output({id, error: mapError(error, 'request')});

  function finish(thread, job, status, error) {
    if (thread.job !== job) return;
    thread.job = null;
    notify('turn/completed', {
      threadId: thread.id,
      turn: {id: job.id, status, ...(error ? {error: mapError(error, 'response')} : {})},
    });
  }

  async function generate(thread, job, body) {
    if (child.killed || thread.job !== job) return;
    const timeout = AbortSignal.timeout(turnTimeoutMs);
    const signal = AbortSignal.any([job.controller.signal, timeout]);
    const onTimeout = () => finish(thread, job, 'failed', new SiliconFlowFailure('timeout'));
    timeout.addEventListener('abort', onTimeout, {once: true});
    const scope = {threadId: thread.id, turnId: job.id};
    notify('turn/started', {...scope, turn: {id: job.id, status: 'inProgress'}});
    notify('item/started', {...scope, item: {id: job.itemId, type: 'imageGeneration', status: 'inProgress'}});
    try {
      const result = await client.generate(body, signal);
      if (thread.job !== job || child.killed) return;
      signal.throwIfAborted();
      notify('item/completed', {...scope, item: {id: job.itemId, type: 'imageGeneration', status: 'completed', result}});
      finish(thread, job, 'completed');
    } catch (error) {
      if (thread.job !== job || child.killed) return;
      finish(thread, job, 'failed', signal.aborted ? new SiliconFlowFailure('timeout') : error);
    } finally {
      timeout.removeEventListener('abort', onTimeout);
    }
  }

  const threadResult = thread => ({
    thread: {id: thread.id, status: {type: thread.job ? 'active' : 'idle'}},
    model: thread.model,
    reasoningEffort: 'none',
    approvalPolicy: 'on-request',
    activePermissionProfile: {id: thread.permission},
  });

  async function dispatch({id, method, params = {}}) {
    if (id === undefined || typeof method !== 'string' || child.killed) return;
    try {
      switch (method) {
        case 'initialize': return reply(id, {userAgent: runtimeName});
        case 'config/read': return reply(id, {config: {}});
        case 'modelProvider/capabilities/read': return reply(id, {imageGeneration: true, imageOnly: true});
        case 'account/read':
          await client.listModels();
          return reply(id, {account: null, requiresOpenaiAuth: false});
        case 'model/list': {
          const models = await client.listModels();
          const limit = Number.isInteger(params.limit) ? Math.min(100, Math.max(1, params.limit)) : 100;
          const offset = params.cursor == null ? 0 : Number(/^sf-models-(\d{1,2})$/u.exec(params.cursor)?.[1]);
          if (!Number.isInteger(offset) || offset >= models.length) throw new SiliconFlowFailure('request');
          const data = models.slice(offset, offset + limit);
          return reply(id, {data, nextCursor: offset + data.length < models.length ? 'sf-models-' + (offset + data.length) : null});
        }
        case 'thread/start': {
          const models = await client.listModels();
          if (child.killed) return;
          const selected = params.model ?? models.find(model => model.isDefault)?.id;
          if (!models.some(model => model.id === selected)) throw new SiliconFlowFailure('model');
          if (params.config?.model_reasoning_effort !== undefined && params.config.model_reasoning_effort !== 'none') {
            throw new SiliconFlowFailure('effort');
          }
          const thread = {id: randomUUID(), model: selected, permission: params.permissions, job: null, lastTurnId: null};
          threads.set(thread.id, thread);
          return reply(id, threadResult(thread));
        }
        case 'thread/resume': {
          const thread = threads.get(params.threadId);
          if (!thread || params.permissions !== thread.permission) throw new SiliconFlowFailure('thread');
          return reply(id, threadResult(thread));
        }
        case 'turn/start': {
          const thread = threads.get(params.threadId);
          if (!thread || params.permissions !== thread.permission) throw new SiliconFlowFailure('thread');
          if (thread.job) throw new SiliconFlowFailure('running');
          if (params.effort !== undefined && params.effort !== 'none') throw new SiliconFlowFailure('effort');
          const model = params.model ?? thread.model;
          const models = await client.listModels();
          if (child.killed) return;
          if (thread.job) throw new SiliconFlowFailure('running');
          if (!models.some(item => item.id === model)) throw new SiliconFlowFailure('model');
          const body = buildImageBody(model, params.input);
          const job = {id: randomUUID(), itemId: randomUUID(), controller: new AbortController()};
          thread.model = model;
          thread.job = job;
          thread.lastTurnId = job.id;
          reply(id, {turn: {id: job.id, status: 'inProgress'}});
          setImmediate(() => { void generate(thread, job, body); });
          return;
        }
        case 'turn/interrupt': {
          const thread = threads.get(params.threadId);
          if (!thread || !params.turnId || thread.lastTurnId !== params.turnId) throw new SiliconFlowFailure('turn');
          reply(id, {});
          if (thread.job?.id === params.turnId) {
            const job = thread.job;
            job.controller.abort();
            finish(thread, job, 'interrupted');
          }
          return;
        }
        default: throw new SiliconFlowFailure('unsupported');
      }
    } catch (error) {
      reject(id, error);
    }
  }

  const decoder = new StringDecoder('utf8');
  let parts = [];
  let length = 0;
  child.stdin = new Writable({write(chunk, _encoding, done) {
    const text = decoder.write(chunk);
    let start = 0;
    try {
      while (start < text.length) {
        const newline = text.indexOf('\n', start);
        const end = newline < 0 ? text.length : newline;
        length += end - start;
        if (length > LINE_LIMIT) throw new SiliconFlowFailure('request');
        if (end > start) parts.push(text.slice(start, end));
        if (newline < 0) break;
        const line = parts.join('');
        parts = [];
        length = 0;
        start = newline + 1;
        if (line.trim()) void dispatch(JSON.parse(line));
      }
      done();
    } catch (error) {
      done(new SiliconFlowFailure('request'));
    }
  }});
  child.kill = () => {
    if (child.killed) return false;
    child.killed = true;
    for (const thread of threads.values()) thread.job?.controller.abort();
    threads.clear();
    parts = [];
    child.stdin.destroy();
    child.stdout.end();
    child.stderr.end();
    setImmediate(() => {
      child.emit('exit', null, 'SIGTERM');
      child.emit('close', null, 'SIGTERM');
    });
    return true;
  };
  return child;
}

export function createSiliconFlowRuntime(options) {
  return createImageApiRuntime(createClient(options), options);
}

export function createSiliconFlowSpawn(options) {
  const client = createClient(options);
  return () => createImageApiRuntime(client, options);
}
