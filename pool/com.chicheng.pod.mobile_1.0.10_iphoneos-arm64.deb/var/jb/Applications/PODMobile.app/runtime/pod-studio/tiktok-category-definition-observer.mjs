import {createHash} from 'node:crypto';
import {projectCategoryDefinition,projectCompositionPropertyStructure} from './tiktok-category-definition.mjs';

const ORIGIN='https://seller.us.tiktokshopglobalselling.com';
const PATH_HASH='d796912ebc77a546509f75d5f4e8236a229bb0436c88a359503ab109eac027ef';
const MAX_BODY=2*1024*1024,MAX_TRACKED=8,MAX_READS=4,READ_TIMEOUT=10000;
const safeId=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,160}$/u.test(value);
const requestId=value=>typeof value==='string'&&value.length>0&&value.length<=256&&!/[\u0000-\u001f\u007f]/u.test(value);
const failed=(reason,limitDiagnostics)=>({accepted:false,complete:false,reason,...(limitDiagnostics?{limitDiagnostics:{...limitDiagnostics}}:{})});
const limitStages=new Set(['property_value_count','total_value_count','response_body_characters','response_body_bytes','response_encoded_bytes','body_read_count']);
function safeLimitDiagnostics(value,readCount){
  if(!limitStages.has(value?.limitStage))return undefined;
  const count=value=>Number.isSafeInteger(value)&&value>=0?value:null;
  return {limitStage:value.limitStage,observedCount:count(value.observedCount),maxPerPropertyCount:count(value.maxPerPropertyCount),readCount:count(readCount)};
}
const localizedFailures=new Set(['localized_scope_unverified','localized_request_unverified','localized_response_unavailable','localized_response_limit','localized_response_invalid','localized_response_unverified','localized_values_limit','localized_timeout','localized_read_failed']);

function requestScope(raw){
  if(typeof raw!=='string'||raw.length>16384)return null;
  let url;try{url=new URL(raw);}catch{return null;}
  if(url.origin!==ORIGIN||url.username||url.password||url.hash||createHash('sha256').update(url.pathname).digest('hex')!==PATH_HASH)return null;
  if(url.searchParams.getAll('category_id').length!==1||!safeId(url.searchParams.get('category_id'))||url.searchParams.getAll('locale').length!==1||url.searchParams.get('locale')!=='zh-CN'||url.searchParams.getAll('language').length!==1||url.searchParams.get('language')!=='zh-CN')return {invalid:true};
  return {categoryId:url.searchParams.get('category_id')};
}

function localizedUrl(raw){
  // Replacing only the two semantic query components preserves every opaque
  // component byte-for-byte, including signed escaping/order/empty segments.
  const url=new URL(raw),parts=url.search.slice(1).split('&');
  url.search=parts.map(part=>{const equal=part.indexOf('='),key=equal<0?part:part.slice(0,equal);let decoded;try{decoded=decodeURIComponent(key.replace(/\+/gu,' '));}catch{return part;}return ['locale','language'].includes(decoded)?key+'=en-US':part;}).join('&');
  return url.href;
}

// Optional diagnostics examine only property/value row structure, never values
// or arbitrary nested objects. Counts describe the bounded sample honestly.
function responseStructure(response,categoryId){
  const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
  const own=(value,key)=>{if(!object(value))return undefined;const descriptor=Object.getOwnPropertyDescriptor(value,key);return descriptor&&Object.hasOwn(descriptor,'value')?descriptor.value:undefined;};
  const properties=own(own(response,'data'),'product_properties');
  if(own(response,'code')!==0||!Array.isArray(properties))return null;
  const limits={propertyRows:200,valueRows:20000,keys:64,keysPerRow:64};
  const group=()=>({declaredCount:0,declaredCountComplete:true,sampledCount:0,objectRowCount:0,nonObjectRowCount:0,filteredKeyCount:0,omittedKeyCount:0,truncated:false,keyTypes:Object.create(null)});
  const output={kind:'category-definition-response-structure',version:1,complete:false,limits,propertyRows:group(),valueRows:group(),sampled:false,truncated:false};
  const credentialShape=/gh[pousr]_|github_pat_|(?:^|[_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[_-])(?:jwt|basic|bearer)(?:$|[_-])/iu;
  const safeKey=key=>typeof key==='string'&&/^[A-Za-z_][A-Za-z0-9_]{0,63}$/u.test(key)&&!['__proto__','prototype','constructor'].includes(key)&&!credentialShape.test(key)&&!/token|cookie|auth|secret|password|passwd|credential|session|bearer|csrf|signature|api_?key|access_?key|private_?key|refresh|headers?|(?:^|_)(?:url|uri|email)(?:$|_)|[0-9]{6,}|[a-f0-9]{24,}/iu.test(key);
  const type=value=>value===null?'null':Array.isArray(value)?'array':object(value)?'object':['string','number','boolean'].includes(typeof value)?typeof value:null;
  const scan=(row,target)=>{
    target.sampledCount++;if(!object(row)){target.nonObjectRowCount++;return;}target.objectRowCount++;
    const keys=Object.keys(row);if(keys.length>limits.keysPerRow){target.omittedKeyCount+=keys.length-limits.keysPerRow;target.truncated=true;}
    for(const key of keys.slice(0,limits.keysPerRow)){
      if(!safeKey(key)){target.filteredKeyCount++;continue;}
      const descriptor=Object.getOwnPropertyDescriptor(row,key),kind=descriptor&&Object.hasOwn(descriptor,'value')?type(descriptor.value):null;if(!kind){target.filteredKeyCount++;continue;}
      if(!Object.hasOwn(target.keyTypes,key)){if(Object.keys(target.keyTypes).length>=limits.keys){target.omittedKeyCount++;target.truncated=true;continue;}target.keyTypes[key]={types:[],rowCount:0};}
      const entry=target.keyTypes[key];entry.rowCount++;if(!entry.types.includes(kind)){entry.types.push(kind);entry.types.sort();}
    }
  };
  output.propertyRows.declaredCount=properties.length;
  if(properties.length>limits.propertyRows){output.propertyRows.truncated=true;output.valueRows.declaredCountComplete=false;}
  for(const property of properties.slice(0,limits.propertyRows)){
    scan(property,output.propertyRows);const values=own(property,'values');if(!Array.isArray(values))continue;
    output.valueRows.declaredCount+=values.length;
    const remaining=Math.max(0,limits.valueRows-output.valueRows.sampledCount);if(values.length>remaining)output.valueRows.truncated=true;
    for(let index=0;index<Math.min(values.length,remaining);index++)scan(values[index],output.valueRows);
  }
  output.sampled=output.propertyRows.sampledCount!==output.propertyRows.declaredCount||!output.valueRows.declaredCountComplete||output.valueRows.sampledCount!==output.valueRows.declaredCount;
  output.truncated=output.propertyRows.truncated||output.valueRows.truncated;
  output.compositionStructure=projectCompositionPropertyStructure({categoryId,response});
  return output;
}

/** The driver must dispatch ONLY its owned session's network events. send is
 * already bound to that same session. No enable, HTTP, retry or target action.
 */
export function createCategoryDefinitionObserver({send,onResponseStructure,readLocalized}={}){
  if(typeof send!=='function')throw new TypeError('CATEGORY_OBSERVER_SEND_REQUIRED');
  let command=send,current=null,closed=false,lastLocalizedDiagnostics=null;
  const active=scope=>!closed&&current===scope;
  const notify=scope=>{for(const wake of scope.waiters)wake();scope.waiters.clear();};
  const invalidateLocalized=scope=>{const token=scope.localized;if(!token)return;token.failure='localized_scope_changed';token.diagnostics.stage='invalidated';token.diagnostics.scopeCurrent=false;token.diagnostics.scopeChanged=true;token.url='';token.cancel?.();scope.localized=null;};
  const dispose=scope=>{if(!scope)return;invalidateLocalized(scope);for(const cancel of scope.cancel)cancel();scope.cancel.clear();for(const entry of scope.requests.values())entry.url='';scope.requests.clear();scope.pending.clear();scope.categories.clear();if(scope.latest)scope.latest.url='';scope.latest=null;notify(scope);};
  const reject=(scope,reason,limitDiagnostics)=>{if(!scope.failure){scope.failure=reason;scope.limitDiagnostics=safeLimitDiagnostics(limitDiagnostics,scope.reads);}invalidateLocalized(scope);for(const entry of scope.requests.values())entry.url='';scope.requests.clear();if(scope.latest)scope.latest.url='';scope.latest=null;for(const cancel of scope.cancel)cancel();notify(scope);};
  const settle=(scope,entry,reason,projection)=>{
    if(!active(scope)||scope.failure||entry.done)return;
    entry.done=true;entry.failure=reason;entry.projection=scope.latest===entry?projection:undefined;
    if(reason||scope.latest!==entry)entry.url='';
    if(scope.requests.get(entry.id)===entry)scope.requests.delete(entry.id);notify(scope);
  };

  async function capture(scope,entry){
    let timer,cancel;
    const outcome=await new Promise(resolve=>{
      cancel=()=>resolve({stopped:true});scope.cancel.add(cancel);timer=setTimeout(()=>resolve({timedOut:true}),READ_TIMEOUT);
      Promise.resolve().then(()=>active(scope)&&!scope.failure&&!entry.done?command('Network.getResponseBody',{requestId:entry.id}):undefined).then(result=>resolve({result}),()=>resolve({commandFailed:true}));
    });
    clearTimeout(timer);scope.cancel.delete(cancel);
    if(!active(scope)||scope.failure||entry.done||outcome.stopped)return;
    if(outcome.timedOut){settle(scope,entry,'category_body_timeout');return;}
    if(outcome.commandFailed){settle(scope,entry,'category_body_unavailable');return;}
    try{
      const result=outcome.result;if(typeof result?.body!=='string'||!result.body.length||typeof result.base64Encoded!=='boolean'){settle(scope,entry,'category_body_unavailable');return;}
      if(result.body.length>(result.base64Encoded?Math.ceil(MAX_BODY/3)*4:MAX_BODY)){reject(scope,'category_response_limit',{limitStage:'response_body_characters',observedCount:result.body.length});return;}
      if(result.base64Encoded&&(result.body.length%4!==0||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/u.test(result.body))){settle(scope,entry,'category_response_invalid');return;}
      const bytes=Buffer.from(result.body,result.base64Encoded?'base64':'utf8');if(bytes.length>MAX_BODY){reject(scope,'category_response_limit',{limitStage:'response_body_bytes',observedCount:bytes.length});return;}
      let response;try{response=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{settle(scope,entry,'category_response_invalid');return;}
      const projection=projectCategoryDefinition({categoryId:entry.categoryId,response});
      if(typeof onResponseStructure==='function')try{const structure=responseStructure(response,entry.categoryId);if(structure&&active(scope)&&!scope.failure&&!entry.done){const limitDiagnostics=safeLimitDiagnostics(projection.limitDiagnostics,scope.reads);Promise.resolve(onResponseStructure({...structure,...(limitDiagnostics?{limitDiagnostics}:{})})).catch(()=>{});}}catch{ /* Optional shape diagnostics cannot affect projection. */ }
      if(!active(scope)||scope.failure||entry.done)return;
      if(projection.reason==='category_values_limit'){reject(scope,'category_response_limit',projection.limitDiagnostics);return;}
      if(projection.accepted!==true||projection.responseComplete!==true||projection.propertyRowsComplete!==true||projection.truncated===true||projection.categoryId!==entry.categoryId||projection.endpointPathHash!==PATH_HASH||!Array.isArray(projection.properties)||!projection.properties.length){settle(scope,entry,'category_response_unverified');return;}
      settle(scope,entry,null,projection);
    }catch{settle(scope,entry,'category_response_invalid');}
  }

  return {
    begin(){if(closed)return false;dispose(current);lastLocalizedDiagnostics=null;current={requests:new Map(),pending:new Set(),cancel:new Set(),waiters:new Set(),categories:new Set(),latest:null,localized:null,localizedAttempted:false,sequence:0,reads:0,failure:null,session:undefined};return true;},
    observe(message){
      const scope=current;if(!active(scope)||!scope||scope.failure)return;
      const params=message?.params,id=params?.requestId;if(!requestId(id))return;
      const session=message.sessionId===undefined?null:typeof message.sessionId==='string'&&message.sessionId.length<=256?message.sessionId:undefined;if(session===undefined||scope.session!==undefined&&scope.session!==session)return;
      const token=scope.localized;
      if(message.method==='Network.requestWillBeSent'&&token&&(params.request?.url===token.url||id===token.requestId)){
        if(token.failure||token.requestId||params.request?.method!=='GET'||params.redirectResponse!==undefined||scope.requests.has(id)){reject(scope,'category_request_unverified');return;}
        token.requestId=id;token.diagnostics.requestObserved=true;token.diagnostics.stage='request_observed';return;
      }
      if(token&&id===token.requestId){
        if(token.failure)return;
        if(message.method==='Network.responseReceived'){
          const response=params.response;
          token.diagnostics.stage='response_observed';token.diagnostics.responseObserved=true;token.diagnostics.responseScopeVerified=response?.url===token.url;token.diagnostics.resourceTypeVerified=['XHR','Fetch'].includes(params.type);token.diagnostics.httpStatusVerified=Number.isInteger(response?.status)&&response.status>=200&&response.status<300;token.diagnostics.jsonMimeVerified=/^application\/(?:[A-Za-z0-9.-]+\+)?json(?:;|$)/iu.test(response?.mimeType||'');
          if(response?.url!==token.url){reject(scope,'category_response_unverified');return;}
          if(!['XHR','Fetch'].includes(params.type)||!Number.isInteger(response.status)||response.status<200||response.status>=300||!/^application\/(?:[A-Za-z0-9.-]+\+)?json(?:;|$)/iu.test(response.mimeType||'')){token.failure='localized_response_unverified';token.signal?.();return;}
          token.responseVerified=true;
        }else if(message.method==='Network.loadingFailed'){token.diagnostics.stage='loading_failed';token.failure='localized_response_unavailable';token.signal?.();}
        else if(message.method==='Network.loadingFinished'){
          token.diagnostics.stage='loading_finished';token.diagnostics.loadingFinishedObserved=true;token.diagnostics.encodedSizeVerified=Number.isFinite(params.encodedDataLength)&&params.encodedDataLength>=0&&params.encodedDataLength<=MAX_BODY;
          if(!token.responseVerified||!Number.isFinite(params.encodedDataLength)||params.encodedDataLength<0||params.encodedDataLength>MAX_BODY)token.failure='localized_response_unverified';
          else token.finished=true;token.diagnostics.loadingFinishedVerified=token.finished;token.signal?.();
        }
        return;
      }
      if(message.method==='Network.requestWillBeSent'){
        const context=params.request?.method==='GET'?requestScope(params.request.url):null;
        if(scope.requests.has(id)){reject(scope,'category_request_reused');return;}
        if(!context)return;if(context.invalid){reject(scope,'category_request_unverified');return;}
        if(params.redirectResponse!==undefined){reject(scope,'category_request_redirected');return;}
        if(scope.session===undefined)scope.session=session;
        scope.categories.add(context.categoryId);if(scope.categories.size!==1){reject(scope,'category_scope_ambiguous');return;}
        if(scope.requests.size>=MAX_TRACKED){reject(scope,'category_request_limit');return;}
        invalidateLocalized(scope);
        const entry={id,url:params.request.url,categoryId:context.categoryId,sequence:++scope.sequence,eligible:false,fetching:false,done:false,failure:null,projection:undefined};
        if(scope.latest){scope.latest.projection=undefined;scope.latest.url='';}
        scope.requests.set(id,entry);scope.latest=entry;notify(scope);
      }else if(message.method==='Network.responseReceived'){
        const entry=scope.requests.get(id);if(!entry)return;
        const response=params.response,context=requestScope(response?.url);
        if(!context||context.invalid||context.categoryId!==entry.categoryId){reject(scope,'category_response_unverified');return;}
        if(!['XHR','Fetch'].includes(params.type)||!Number.isInteger(response?.status)||response.status<200||response.status>=300||!/^application\/(?:[A-Za-z0-9.-]+\+)?json(?:;|$)/iu.test(response.mimeType||'')){settle(scope,entry,'category_response_unverified');return;}
        entry.eligible=true;
      }else if(message.method==='Network.loadingFailed'){
        const entry=scope.requests.get(id);if(entry)settle(scope,entry,'category_response_unavailable');
      }else if(message.method==='Network.loadingFinished'){
        const entry=scope.requests.get(id);if(!entry||entry.fetching)return;
        if(!entry.eligible){settle(scope,entry,'category_response_unverified');return;}
        if(!Number.isFinite(params.encodedDataLength)||params.encodedDataLength<0||params.encodedDataLength>MAX_BODY){reject(scope,'category_response_limit',{limitStage:'response_encoded_bytes',observedCount:params.encodedDataLength});return;}
        if(scope.reads>=MAX_READS){reject(scope,'category_response_limit',{limitStage:'body_read_count',observedCount:scope.reads+1});return;}
        scope.reads++;entry.fetching=true;
        const pending=capture(scope,entry).finally(()=>{scope.pending.delete(pending);if(scope.requests.get(id)===entry)scope.requests.delete(id);});scope.pending.add(pending);
      }
    },
    async read(){
      const scope=current;if(closed)return failed('category_observer_closed');if(!scope)return failed('category_scope_not_started');if(scope.failure)return failed(scope.failure,scope.limitDiagnostics);
      let expired=false,wake,timer;
      try{
        // Only the last matching natural request can establish this scope. A
        // newer request wakes readers immediately; old body promises may finish
        // independently and cannot restore a superseded result.
        while(true){
          if(!active(scope))return failed(closed?'category_observer_closed':'category_scope_changed');if(scope.failure)return failed(scope.failure,scope.limitDiagnostics);
          const entry=scope.latest;if(scope.categories.size!==1||!entry)return failed('category_response_unavailable');
          if(entry.done)return entry.projection?structuredClone(entry.projection):failed(entry.failure||'category_response_unverified');
          if(!entry.fetching||expired)return failed('category_response_pending');
          if(timer===undefined)timer=setTimeout(()=>{expired=true;wake?.();},READ_TIMEOUT);
          await new Promise(resolve=>{wake=resolve;scope.waiters.add(resolve);});scope.waiters.delete(wake);wake=undefined;
        }
      }finally{clearTimeout(timer);if(wake)scope.waiters.delete(wake);}
    },
    async readLocalizedCategoryDefinition(locale){
      const scope=current;if(closed)return failed('localized_observer_closed');if(!scope||scope.failure)return failed('localized_scope_unverified');
      if(locale!=='en-US')return failed('localized_locale_unsupported');if(typeof readLocalized!=='function')return failed('localized_reader_unavailable');
      if(scope.localizedAttempted)return failed('localized_already_attempted');
      const natural=scope.latest;if(!natural?.done||natural.failure||!natural.projection||!natural.url)return failed('localized_natural_definition_unavailable');
      const diagnostics={stage:'armed',requestObserved:false,responseObserved:false,responseScopeVerified:null,resourceTypeVerified:null,httpStatusVerified:null,jsonMimeVerified:null,loadingFinishedObserved:false,loadingFinishedVerified:null,encodedSizeVerified:null,runtimeReturned:false,runtimeAccepted:null,projectionVerified:null,scopeCurrent:true,scopeChanged:false,deadlineExpired:false};
      const token={url:localizedUrl(natural.url),requestId:null,responseVerified:false,finished:false,failure:null,result:null,diagnostics};scope.localizedAttempted=true;scope.localized=token;lastLocalizedDiagnostics=diagnostics;
      const isCurrent=()=>active(scope)&&!scope.failure&&scope.latest===natural&&scope.localized===token&&!token.failure;
      let timer;
      try{
        const result=await new Promise(resolve=>{
          token.cancel=()=>resolve(failed('localized_scope_changed'));
          token.signal=()=>{if(token.failure)resolve(failed(token.failure));else if(token.result&&token.requestId&&token.responseVerified&&token.finished){diagnostics.stage='complete';resolve(token.result);}};
          timer=setTimeout(()=>{diagnostics.stage='deadline';diagnostics.deadlineExpired=true;token.failure='localized_read_timeout';token.signal();},READ_TIMEOUT);
          Promise.resolve().then(()=>isCurrent()?readLocalized({url:token.url,categoryId:natural.categoryId,isCurrent}):failed('localized_scope_changed')).then(value=>{
            diagnostics.runtimeReturned=true;diagnostics.runtimeAccepted=value?.accepted===true;
            if(!isCurrent()){token.cancel?.();return;}
            diagnostics.stage='runtime_returned';
            if(value?.accepted!==true){diagnostics.stage='runtime_rejected';token.failure=localizedFailures.has(value?.reason)?value.reason:'localized_response_unverified';token.signal?.();return;}
            if(value.source!=='controlled-seller-category-definition'||value.complete!==false||value.responseComplete!==true||value.propertyRowsComplete!==true||value.categoryId!==natural.categoryId||value.endpointPathHash!==PATH_HASH||value.locale!=='en-US'||value.language!=='en-US'||!Array.isArray(value.properties)||!value.properties.length||value.truncated===true){diagnostics.stage='projection_rejected';diagnostics.projectionVerified=false;token.failure='localized_response_unverified';token.signal?.();return;}
            diagnostics.projectionVerified=true;if(!token.finished)diagnostics.stage='waiting_loading_finished';
            token.result=structuredClone(value);token.signal?.();
          },()=>{diagnostics.stage='runtime_failed';token.failure='localized_evaluation_failed';token.signal?.();}).catch(()=>{diagnostics.stage='projection_rejected';diagnostics.projectionVerified=false;token.failure='localized_response_unverified';token.signal?.();});
        });
        if(!active(scope)||scope.failure||scope.latest!==natural||scope.localized!==token)return failed('localized_scope_changed');
        return result;
      }finally{clearTimeout(timer);token.cancel=undefined;token.signal=undefined;token.result=null;}
    },
    localizedDiagnostics(){return lastLocalizedDiagnostics?structuredClone(lastLocalizedDiagnostics):null;},
    close(){if(closed)return;closed=true;dispose(current);current=null;command=null;onResponseStructure=undefined;readLocalized=undefined;lastLocalizedDiagnostics=null;},
  };
}
