import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('./dist/', import.meta.url));
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.webp':'image/webp','.svg':'image/svg+xml','.json':'application/json'};
export function createDesignerServer(){return http.createServer(async (req,res) => {
  try {
    if(req.url==='/__pod/designer-status'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({app:'pod-designer',version:1}));}
    const path = resolve(root, '.' + decodeURIComponent(new URL(req.url,'http://localhost').pathname));
    if (path !== resolve(root) && !path.startsWith(resolve(root)+sep)) { res.writeHead(403); return res.end(); }
    const file = (await stat(path)).isDirectory() ? resolve(path,'index.html') : path;
    const data = await readFile(file);
    res.writeHead(200, {'Content-Type':types[extname(file)] || 'application/octet-stream','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    res.end(data);
  } catch { res.writeHead(404); res.end('Not found'); }
});}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))createDesignerServer().listen(4173,'127.0.0.1',() => console.log('Local: http://127.0.0.1:4173'));
