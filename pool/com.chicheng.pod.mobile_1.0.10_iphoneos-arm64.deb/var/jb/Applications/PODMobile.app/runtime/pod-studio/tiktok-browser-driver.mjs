import { realpath, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { isAbsolute, relative, sep } from 'node:path';
import { createCategoryDefinitionObserver } from './tiktok-category-definition-observer.mjs';
import { projectCategoryDefinition } from './tiktok-category-definition.mjs';
import { readLocalizedCategoryDefinitionInPage, normalizeLocalizedCategoryDefinitionResult } from './tiktok-category-localized-definition.mjs';

const SELLER_HOSTS = new Set(['seller.us.tiktokshopglobalselling.com', 'seller-us.tiktok.com', 'seller.tiktokglobalshop.com', 'seller.tiktokshop.com']);
export function assertSellerUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || !SELLER_HOSTS.has(url.hostname) || url.username || url.password) throw new Error('仅支持 TikTok Shop 官方商家页面。');
  return url.href;
}
export function assertLoopbackWebSocket(value) {
  const url = new URL(value);
  if (!['ws:', 'wss:'].includes(url.protocol) || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)
    || url.username || url.password || url.search || url.hash || !/^\/devtools\/browser\/[A-Za-z0-9._-]+$/u.test(url.pathname)) throw new Error('浏览器调试连接必须是本机 AdsPower 浏览器端点。');
  return url.href;
}
export async function validateSpoolFiles(root, files) {
  if (!isAbsolute(root || '') || !Array.isArray(files) || !files.length) throw new Error('需要受控上传目录和文件。');
  const resolvedRoot = await realpath(root), info = await stat(resolvedRoot);
  if (!info.isDirectory()) throw new Error('上传目录不存在。');
  return Promise.all(files.map(async value => {
    if (typeof value !== 'string' || !isAbsolute(value)) throw new Error('上传文件必须来自受控目录。');
    const resolved = await realpath(value), rel = relative(resolvedRoot, resolved);
    if (!rel || rel === '..' || rel.startsWith('..' + sep) || isAbsolute(rel) || !(await stat(resolved)).isFile()) throw new Error('禁止上传受控目录之外的文件。');
    return resolved;
  }));
}

/** A transport, not a general browser scripting API. Its callers use the fixed DOM operations below. */
export class TikTokCdpTransport {
  constructor(socket, { timeoutMs = 15000 } = {}) {
    this.socket = socket; this.timeoutMs = timeoutMs; this.nextId = 0; this.pending = new Map(); this.closed = false; this.dialogObservers = new Map(); this.timedOut = new Map(); this.lateObservers = new Map(); this.categoryObservers = new Map();
    socket.addEventListener('message', event => {
      let message; try { message = JSON.parse(typeof event.data === 'string' ? event.data : String(event.data)); } catch { return; }
      if (['Network.requestWillBeSent', 'Network.responseReceived', 'Network.loadingFinished', 'Network.loadingFailed'].includes(message.method)) {
        try { this.categoryObservers.get(message.sessionId)?.(message); } catch { /* Passive capture cannot dispatch page actions. */ }
        return;
      }
      if (message.method === 'Page.javascriptDialogOpening') {
        const observer = this.dialogObservers.get(message.sessionId); if (!observer) return;
        const params = message.params || {}; let officialUrl = false;
        try { assertSellerUrl(params.url); officialUrl = true; } catch { /* No URL or dialog text is retained. */ }
        observer({ type: ['alert', 'confirm', 'prompt', 'beforeunload'].includes(params.type) ? params.type : '', officialUrl, hasBrowserHandler: typeof params.hasBrowserHandler === 'boolean' ? params.hasBrowserHandler : null });
        return;
      }
      const waiting = this.pending.get(message.id);
      if (!waiting) {
        const late = this.timedOut.get(message.id); if (late) {
          this.timedOut.delete(message.id);
          this.lateObservers.get(late.sessionId)?.({ method: ['Runtime.evaluate', 'Page.captureScreenshot', 'Target.getTargetInfo'].includes(late.method) ? late.method : 'other', elapsedMs: Date.now() - late.started });
        }
        return;
      }
      this.pending.delete(message.id); clearTimeout(waiting.timer);
      if (message.error) waiting.reject(new Error(message.error.message || '浏览器操作失败。')); else waiting.resolve(message.result || {});
    });
    const fail = () => { this.closed = true; for (const item of this.pending.values()) { clearTimeout(item.timer); item.reject(new Error('浏览器连接已断开。')); } this.pending.clear(); this.dialogObservers.clear(); this.timedOut.clear(); this.lateObservers.clear(); this.categoryObservers.clear(); };
    socket.addEventListener('close', fail); socket.addEventListener('error', fail);
  }
  send(method, params = {}, sessionId, { timeoutMs } = {}) {
    if (this.closed) return Promise.reject(new Error('浏览器连接已断开。'));
    return new Promise((resolve, reject) => {
      const id = ++this.nextId, started = Date.now(), budget = Number.isFinite(timeoutMs) && timeoutMs > 0 && timeoutMs <= 60000 ? timeoutMs : this.timeoutMs;
      const timer = setTimeout(() => { this.pending.delete(id); this.timedOut.set(id, { method, started, sessionId }); if (this.timedOut.size > 30) this.timedOut.delete(this.timedOut.keys().next().value); reject(new Error('浏览器操作超时。')); }, budget);
      this.pending.set(id, { resolve, reject, timer });
      try { this.socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) })); }
      catch (error) { clearTimeout(timer); this.pending.delete(id); reject(error); }
    });
  }
  observeJavascriptDialogs(sessionId, observer) { this.dialogObservers.set(sessionId, observer); return () => this.dialogObservers.delete(sessionId); }
  observeLateResponses(sessionId, observer) { this.lateObservers.set(sessionId, observer); return () => this.lateObservers.delete(sessionId); }
  observeCategoryDefinitions(sessionId, observer) { this.categoryObservers.set(sessionId, observer); return () => this.categoryObservers.delete(sessionId); }
  close() { if (!this.closed) this.socket.close(); }
}

// This function executes inside the dedicated seller tab. It never accesses cookies,
// storage, framework internals, network requests, or non-rendered application state.
export function visibleOptionListBusyEvidence(root, painted) {
  const evidence = { ariaBusyCount: 0, progressbarCount: 0, activeSpinnerCount: 0, loadingTextCount: 0, inactiveSpinnerCount: 0, staticWrapperCount: 0, scanComplete: true };
  evidence.ariaBusyCount = [root, ...root.querySelectorAll('[aria-busy="true"]')].filter(node => node.getAttribute('aria-busy') === 'true' && painted(node)).length;
  evidence.progressbarCount = [...root.querySelectorAll('[role="progressbar"]')].filter(painted).length;
  const icons = [...root.querySelectorAll('.core-spin-icon,.core-spin-dot,.core-icon-loading,.pulse-loading-icon,.pulse-loading-spinner,[data-icon="IconLoading"],[data-icon="Loading"]')].filter(painted);
  for (const icon of icons) {
    const active = [icon, ...icon.querySelectorAll('*')].some(node => {
      const css = getComputedStyle(node); return painted(node) && String(css.animationName || '').split(',').some(name => name.trim() && name.trim() !== 'none') && css.animationPlayState !== 'paused';
    });
    if (active) evidence.activeSpinnerCount++; else evidence.inactiveSpinnerCount++;
  }
  evidence.staticWrapperCount = [...root.querySelectorAll('.core-spin,.pulse-loading')].filter(painted).length;
  const walker = document.createTreeWalker(root, 4); let node, scanned = 0;
  while ((node = walker.nextNode())) {
    if (++scanned > 20000) { evidence.scanComplete = false; break; }
    const text = String(node.nodeValue || '').replace(/\s+/gu, ' ').trim(), parent = node.parentElement;
    if (!text || !parent || parent.closest('[role="option"],[role="treeitem"],[role="menuitem"],li.core-select-option,input,textarea,[contenteditable="true"]') || !painted(parent)) continue;
    if (/^(?:加载中|正在加载|Loading)[.…。]*$/iu.test(text)) evidence.loadingTextCount++;
  }
  return evidence;
}

// Pairing reads only the visible basic-information fields on the explicit seller
// profile page. It never reads contact cards or unmasks the protected shop ID.
export function visibleSellerProfile() {
  const norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  const current = new URL(location.href);
  const official = current.origin === 'https://seller.us.tiktokshopglobalselling.com'
    && current.pathname === '/profile/seller-profile-v2' && current.searchParams.getAll('shop_region').length === 1
    && current.searchParams.get('shop_region') === 'US';
  const visible = element => {
    if (!element || element.closest('[hidden],[aria-hidden="true"]')) return false;
    const rect = element.getBoundingClientRect(); if (!(rect.width > 0 && rect.height > 0)) return false;
    for (let node = element; node; node = node.parentElement) {
      const style = getComputedStyle(node);
      if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) return false;
    }
    return true;
  };
  const labels = { shopName: /^(?:店铺名称|Shop name|Store name)$/iu,
    mainCategory: /^(?:主营类目|Main category|Primary category|Main business category)$/iu,
    shopId: /^(?:店铺\s*ID|Shop ID|店铺代码|Shop code)$/iu };
  const all = official ? [...document.querySelectorAll('div,span,p,dt,dd,label,h1,h2,h3,h4')].filter(visible) : [];
  const ownText=element=>norm([...(element.childNodes||element.children||[])].filter(node=>node.nodeType===3||node.tagName==='#TEXT'||node.tagName==='#text').map(node=>node.nodeValue??node.textContent??'').join(' '));
  const anchors = all.filter(element => Object.values(labels).some(pattern => pattern.test(ownText(element))));
  const values = {};
  for (const [key, pattern] of Object.entries(labels)) {
    const found = new Set();
    for (const label of anchors.filter(element => pattern.test(ownText(element)))) {
      for (let owner = label.parentElement, depth = 0; owner && depth < 4; owner = owner.parentElement, depth++) {
        if (['BODY','HTML'].includes(owner.tagName)) break;
        const owned = anchors.filter(item => owner.contains(item));
        if (owned.length !== 1) break;
        const parts = [];
        const walker = document.createTreeWalker(owner, 4); let node;
        while ((node = walker.nextNode())) {
          const parent = node.parentElement, text = norm(node.nodeValue);
          if (!text || !visible(parent) || label.contains(parent) || parent.closest('button,a,input,textarea,script,style,[role="button"]')) continue;
          if (/^(?:更改|修改|编辑|Change|Edit)$/iu.test(text)) continue;
          parts.push(text);
        }
        const value = norm(parts.join(' '));
        if (value && value.length <= 160 && !/^(?:[-—–.·…\s]+|暂无(?:数据)?|未设置|未填写|加载中[.。…]*|请选择.*|Loading[.。…]*|N\/A|Not set|No data)$/iu.test(value) && !Object.values(labels).some(other => other.test(value))) { found.add(value); break; }
      }
    }
    values[key] = found.size === 1 ? [...found][0] : '';
  }
  const rawId = values.shopId || '', usableId = /^[A-Za-z0-9_-]{3,80}$/u.test(rawId);
  const idLabels = anchors.filter(element => labels.shopId.test(ownText(element))).map(element => ownText(element));
  return { url: location.href, title: document.title, profileSource: 'seller-profile', profileComplete: official && !!values.shopName && !!values.mainCategory,
    identity: { shopName: values.shopName || '', shopId: usableId ? rawId : '', idKind: usableId ? idLabels.some(label => /code|代码/iu.test(label)) ? 'shop_code' : 'shop_id' : '', region: official ? 'US' : '', regionSource: official ? 'seller-url-market' : '' },
    mainCategory: values.mainCategory ? { label: values.mainCategory, path: [values.mainCategory], source: 'seller-profile' } : null };
}

export function visibleSellerDom(censusReader, listBusyReader = visibleOptionListBusyEvidence, omitValues = false) {
  const norm = text => String(text || '').replace(/\s+/gu, ' ').trim();
  const visibleCache = new WeakMap(), styleCache = new WeakMap(), rectCache = new WeakMap();
  const identityKey=Symbol.for('pod-observed-seller-controls-v1');
  if(!globalThis[identityKey])Object.defineProperty(globalThis,identityKey,{value:{nodes:new WeakMap(),next:1},configurable:true});
  const controlIdentities=globalThis[identityKey],instanceFor=element=>{if(!controlIdentities.nodes.has(element))controlIdentities.nodes.set(element,'control-'+controlIdentities.next++);return controlIdentities.nodes.get(element);};
  if(!controlIdentities.generation)controlIdentities.generation=String(Date.now())+'-'+Math.random().toString(36).slice(2);
  const styleFor = element => { if (!styleCache.has(element)) { const style = getComputedStyle(element); styleCache.set(element, { display: style.display, visibility: style.visibility, opacity: style.opacity, overflowY: style.overflowY }); } return styleCache.get(element); };
  const rectFor = element => { if (!rectCache.has(element)) rectCache.set(element, element.getBoundingClientRect()); return rectCache.get(element); };
  const visible = element => {
    if (!element) return false;
    if (visibleCache.has(element)) return visibleCache.get(element);
    if (element.closest('[hidden],[aria-hidden="true"]')) { visibleCache.set(element, false); return false; }
    const rect = rectFor(element);
    if (!(rect.width > 0 && rect.height > 0)) { visibleCache.set(element, false); return false; }
    for (let node = element; node; node = node.parentElement) {
      const style = styleFor(node);
      if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) { visibleCache.set(element, false); return false; }
    }
    visibleCache.set(element, true); return true;
  };
  const ancestorIdCache = new Map();
  const selector = element => {
    if (element.id) return '#' + CSS.escape(element.id);
    const parts = []; for (let node = element; node && node !== document.documentElement; node = node.parentElement) {
      if (node !== element && node.id) {
        if (!ancestorIdCache.has(node.id)) { const anchor = '#' + CSS.escape(node.id); ancestorIdCache.set(node.id, document.querySelectorAll(anchor).length === 1 ? anchor : ''); }
        const anchor = ancestorIdCache.get(node.id); if (anchor) return [anchor, ...parts].join('>');
      }
      const index = [...node.parentElement.children].filter(child => child.tagName === node.tagName).indexOf(node) + 1;
      parts.unshift(node.tagName.toLowerCase() + ':nth-of-type(' + index + ')');
    } return 'html>' + parts.join('>');
  };
  const formLabelCache = new WeakMap();
  const formLabelFor = element => {
    if (formLabelCache.has(element)) return formLabelCache.get(element);
    if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(element.tagName) && !element.isContentEditable && !['combobox', 'textbox'].includes(element.getAttribute('role')) && !element.matches?.('.core-select,.pulse-select,.p-cascader-select-view,.arco-select,.ant-select')) { formLabelCache.set(element, null); return null; }
    for (let parent = element.parentElement, depth = 0; parent && depth < 12; parent = parent.parentElement, depth++) {
      const labels = [...parent.querySelectorAll('[class*="_formLabel_"]')].filter(visible);
      if (labels.length !== 1) continue;
      const roots = [...new Set([...parent.querySelectorAll('input,textarea,select,[contenteditable="true"],[role="combobox"],.core-select,.pulse-select,.p-cascader-select-view')].map(canonicalControl))].filter(visible);
      if (roots.length === 1 && roots[0] === canonicalControl(element)) { formLabelCache.set(element, labels[0]); return labels[0]; }
    }
    formLabelCache.set(element, null); return null;
  };
  const labelFor = element => {
    const ids = (element.getAttribute('aria-labelledby') || '').split(/\s+/u).filter(Boolean);
    const explicit = ids.map(id => document.getElementById(id)).filter(visible).map(item => item.innerText).join(' ')
      || element.getAttribute('aria-label') || [...(element.labels || [])].filter(visible).map(item => item.innerText).join(' ');
    if (explicit) return norm(explicit);
    const actualFormLabel = formLabelFor(element), actualTitle = actualFormLabel?.querySelector('[class*="_title_"]');
    if (actualFormLabel) return norm((actualTitle && visible(actualTitle) ? actualTitle : actualFormLabel).innerText).replace(/^\*\s*/u, '');
    const item = element.closest('[class*="FormItem"],[class*="form-item"],[class*="formItem"],[data-testid*="form-item"],fieldset');
    return norm(item?.querySelector('label,[class*="label"],legend')?.innerText || element.getAttribute('placeholder') || element.getAttribute('title') || '');
  };
  const attributeCardCache = new WeakMap();
  const attributeCardKind = card => {
    if (!card) return '';
    if (attributeCardCache.has(card)) return attributeCardCache.get(card);
    const headings = [...card.querySelectorAll('p.text-head-s.text-neutral-text3')].filter(visible).filter(item => item.closest('div.bg-neutral-bg2.rounded-8') === card)
      .map(item => norm(item.innerText)).filter(value => /^(关键属性|可选属性|选填|Key attributes|Optional attributes)$/iu.test(value));
    const kind = headings.length === 1 ? /可选|选填|Optional/iu.test(headings[0]) ? '可选属性' : '关键属性' : '';
    attributeCardCache.set(card, kind); return kind;
  };
  const sectionFor = element => {
    for (let card = element.closest('div.bg-neutral-bg2.rounded-8'); card; card = card.parentElement?.closest('div.bg-neutral-bg2.rounded-8')) {
      const kind = attributeCardKind(card); if (kind) return kind;
    }
    const section = element.closest('section,[class*="Card"],[class*="card"],fieldset');
    return norm(section?.querySelector('h1,h2,h3,h4,legend,[class*="title"]')?.innerText || '');
  };
  const shopNameSelector = '[data-testid*="shop-name"],[data-tid*="shop-name"],[aria-label="Shop name"],[aria-label="店铺名称"],[class*="shop-name"],[class*="shopName"],[class*="ShopName"],[class*="shop_name"]';
  const shopTriggerElements = new Set();
  const shopNames = [...document.querySelectorAll(shopNameSelector)].filter(visible);
  for (const element of shopNames) {
    const target = element.closest('button,[role="button"],[tabindex]');
    if (target && norm(target.innerText).length <= 100) shopTriggerElements.add(target);
    else for (let node = element, depth = 0; node && depth < 4; node = node.parentElement, depth++) {
      if (getComputedStyle(node).cursor === 'pointer' && norm(node.innerText) && norm(node.innerText).length <= 100) { shopTriggerElements.add(node); break; }
    }
  }
  // The observed seller header shows the current shop as an avatar + name capsule.
  // Open only its bounded, visibly clickable top-right container; this is a read-only menu.
  const viewportWidth = document.documentElement?.clientWidth || globalThis.innerWidth || 0;
  for (const avatar of [...document.querySelectorAll('[class*="avatar"],[class*="Avatar"],header img,[role="banner"] img')].filter(visible)) {
    for (let node = avatar.parentElement, depth = 0; node && depth < 4; node = node.parentElement, depth++) {
      const rect = node.getBoundingClientRect?.(), name = norm(node.innerText);
      if (viewportWidth && rect && rect.x >= viewportWidth * .5 && rect.y >= 0 && rect.y < 100 && rect.width < 400 && name && name.length <= 100
        && (node.tagName === 'BUTTON' || node.getAttribute('role') === 'button' || getComputedStyle(node).cursor === 'pointer')) { shopTriggerElements.add(node); break; }
    }
  }
  for (const element of [...shopTriggerElements]) if ([...shopTriggerElements].some(other => other !== element && other.contains?.(element))) shopTriggerElements.delete(element);
  const popupSelector = '[role="listbox"],[role="menu"],[class*="select-popup"],[class*="select-dropdown"],[class*="SelectPopup"],[class*="SelectDropdown"]';
  const compositeSelector = '.arco-select,.arco-select-view,.ant-select,.core-select,.pulse-select,.p-cascader-select-view,[role="combobox"]:not(input)';
  const canonicalControl = element => {
    const coreOption = element.closest('li[role="option"].core-select-option');
    if (coreOption && coreOption.closest('.core-select-popup') && (element === coreOption || element.matches?.('span.pulse-select-option-label-single') && !element.getAttribute('role') && !element.hasAttribute?.('tabindex') && !element.isContentEditable)) return coreOption;
    if (element.closest(popupSelector)) return element;
    if (element.tagName === 'INPUT' || element.getAttribute('role') === 'combobox' || element.matches?.('.arco-select,.arco-select-view,.ant-select,.core-select,.pulse-select,.p-cascader-select-view')) {
      return element.closest('.arco-select,.ant-select,.core-select,.pulse-select,.p-cascader-select-view') || element.closest(compositeSelector) || element;
    }
    return element;
  };
  const all = [...new Set([...document.querySelectorAll('input,textarea,select,.arco-select,.arco-select-view,.ant-select,.core-select,.pulse-select,.p-cascader-select-view,[role="combobox"],[contenteditable="true"],button,[role="button"],[role="option"],[role="treeitem"],[role="menuitem"],[class*="cascader-option"],[class*="cascader-menu-item"],[class*="select-option"],[class*="modal-close"],[class*="ModalClose"],a[href]'), ...shopTriggerElements].map(canonicalControl))].filter(visible)
    .filter(element => !(element.tagName === 'INPUT' && element.closest(popupSelector)))
    .filter(element => element.getAttribute('type') !== 'password' && !/password|one-time-code/u.test(element.getAttribute('autocomplete') || '') && !/验证码|verification code|API.?key|access.?token|密钥/iu.test(labelFor(element)));
  const controls = all.map((element, index) => {
    const selectRoot = element.closest(compositeSelector), composite = !!selectRoot && selectRoot === element;
    const helpers = composite ? [element, ...element.querySelectorAll('input,[role="combobox"]')].filter(visible) : [element];
    const tag = element.tagName.toLowerCase(), role = composite ? 'combobox' : element.getAttribute('role') || (tag === 'select' ? 'combobox' : tag === 'button' || shopTriggerElements.has(element) || /modal-close|ModalClose/u.test(element.className || '') ? 'button' : /cascader-option|cascader-menu-item|select-option/u.test(element.className || '') ? 'option' : element.isContentEditable ? 'textbox' : '');
    const rect = rectFor(element), label = labelFor(element) || helpers.map(labelFor).find(Boolean) || '';
    let fieldX = rect.x, fieldY = rect.y;
    for (let ancestor = element.parentElement; ancestor; ancestor = ancestor.parentElement) { fieldX += ancestor.scrollLeft || 0; fieldY += ancestor.scrollTop || 0; }
    const selectionNodes=selectRoot?[...selectRoot.querySelectorAll('[class*="select-view-value"],[class*="select-selection-item"],[class*="SelectValue"],[class*="select-tag"],[class*="tag-content"]')].filter(visible):[];
    // A tag wrapper and its text child describe one selection, not two.
    const selectionLabels=selectionNodes.filter(item=>!selectionNodes.some(child=>child!==item&&item.contains?.(child))).map(item=>norm(item.innerText)).filter(Boolean);
    return { ref: String(index), selector: selector(element), instanceId:instanceFor(element), tag, role, type: element.getAttribute('type') || '', label,
      name: element.getAttribute('name') || '', text: norm(element.innerText), section: sectionFor(element), value: omitValues ? '' : 'value' in element ? String(element.value || '') : element.isContentEditable ? element.innerText : element.getAttribute('data-value') || '',
      uiHints: { placeholder: norm(element.getAttribute('placeholder') || ''), className: String(element.className || '').slice(0, 180) },
      selectedValues: omitValues ? [] : tag === 'select' ? [...element.selectedOptions].map(option => option.value) : selectionLabels,
      required: helpers.some(item => item.required === true || item.getAttribute('aria-required') === 'true') || /^\*/u.test(label) || /^\s*\*/u.test(formLabelFor(element)?.innerText || '')
        || !!element.closest('[class*="required"]'),
      multiple: helpers.some(item => item.multiple === true || item.getAttribute('aria-multiselectable') === 'true') || composite && /(?:^|\s)(?:arco-select(?:-view)?|ant-select|core-select|pulse-select)-multiple(?:\s|$)/u.test(element.className || ''),
      disabled: helpers.some(item => item.disabled === true || item.getAttribute('aria-disabled') === 'true') || composite && /(?:^|\s)(?:arco-select|ant-select|core-select|pulse-select)-disabled(?:\s|$)/u.test(element.className || ''),
      readOnly: helpers.some(item => item.readOnly === true || item.getAttribute('aria-readonly') === 'true'),
      listIds: [...new Set(helpers.flatMap(item => ((item.getAttribute('aria-controls') || '') + ' ' + (item.getAttribute('aria-owns') || '')).split(/\s+/u).filter(Boolean)))],
      posInSet: Number(element.getAttribute('aria-posinset')) || null, setSize: Number(element.getAttribute('aria-setsize')) || null,
      expanded: element.getAttribute('aria-expanded'), checked: element.checked === true || element.getAttribute('aria-checked') === 'true',
      href: tag === 'a' ? element.href : undefined, x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, fieldPosition: { x: fieldX, y: fieldY },
      uploadImageCount: [...(element.closest('[class*="upload"],[class*="Upload"],[data-testid*="upload"]') || element.parentElement).querySelectorAll('img,video')].filter(visible).length,
      options: !omitValues && tag === 'select' ? [...element.options].filter(option => !option.hidden && !option.disabled).map(option => ({ value: option.value, label: norm(option.label || option.textContent) })) : undefined };
  });
  // This independent root count deliberately precedes any label/editable filter.
  // Repeated field-row structure is not yet verified from the observed page, so
  // these groups remain incomplete until their row census is established.
  const attributeGroups = censusReader === false ? [] : typeof censusReader === 'function' ? censusReader(controls) : [...document.querySelectorAll('div.bg-neutral-bg2.rounded-8')].filter(visible).map(card => {
    const kind = attributeCardKind(card); if (!kind) return null;
    const candidates = [...new Set([...card.querySelectorAll('input,textarea,select,[role="combobox"],[role="textbox"],[contenteditable="true"],.core-select,.pulse-select')].map(canonicalControl))].filter(visible);
    const normalised = candidates.map(element => controls.find(item => item.selector === selector(element)));
    return { groupId: kind === '关键属性' ? 'attribute-key' : 'attribute-optional', kind, expanded: true, scanComplete: false, truncated: candidates.length > 700,
      candidateFieldCount: null, candidateControlCount: candidates.length, labelledControlCount: normalised.filter(item => item?.label).length,
      normalisedControlCount: normalised.filter(Boolean).length, missingLabelCount: normalised.filter(item => !item?.label).length,
      unknownControlCount: normalised.filter(item => !item).length, unresolvedCount: Math.max(1, normalised.filter(item => !item?.label).length), fieldRowsVerified: false };
  }).filter(Boolean);
  // Read rendered text nodes only; body.innerText can include text from opacity-zero
  // application containers, which is not acceptable shop identity evidence.
  const textParts = [], attributeGroupHeadings = new Set(), attributeGroupTotals = {}; let textLength = 0;
  if (document.body) {
    const walker = document.createTreeWalker(document.body, 4); let node;
    while ((node = walker.nextNode()) && textLength < 120000) {
      const parent = node.parentElement;
      const value = String(node.nodeValue || '').trim(); if (!value) continue;
      if (!parent || parent.closest('script,style,template,noscript,input,textarea,[contenteditable="true"]') || !visible(parent)) continue;
      const groupName = norm(value).match(/^(关键属性|可选属性|选填|Key attributes|Optional attributes)(?:\s*[（(]\s*\d+\s*[）)])?$/iu)?.[1];
      if (groupName) {
        const name = /可选|选填|Optional/iu.test(groupName) ? '可选属性' : '关键属性'; attributeGroupHeadings.add(name);
        for (const candidate of [norm(value), norm(parent.innerText)]) {
          const total = candidate.match(/^(?:关键属性|可选属性|选填|Key attributes|Optional attributes)\s*[（(]\s*(\d+)\s*[）)]$/iu)?.[1];
          if (total !== undefined) attributeGroupTotals[name] = Number(total);
        }
      }
      textParts.push(value.slice(0, 120000 - textLength)); textLength += value.length;
    }
  }
  const rawText = textParts.join('\n'), text = norm(rawText);
  const identity = { shopId: '', shopName: '', region: '', idKind: '' };
  for (const element of shopNames) {
    const name = norm(element.innerText || element.getAttribute('aria-label')); if (name && !['Shop name', '店铺名称'].includes(name)) { identity.shopName = name; break; }
  }
  const capsuleNames = [...new Set([...shopTriggerElements].map(element => norm(element.innerText)).filter(name => name && name.length <= 100))];
  if (!identity.shopName && capsuleNames.length === 1) identity.shopName = capsuleNames[0];
  const shopIds = [...new Set([...text.matchAll(/(?:Shop\s*ID|店铺\s*ID|店铺编号)\s*[:：#]?\s*([A-Za-z0-9_-]{4,80})/giu)].map(match => match[1]))];
  const shopCodes = [...new Set([...text.matchAll(/(?:Shop\s*Code|店铺代码|店铺编码|店铺代号)\s*[:：#]?\s*([A-Za-z0-9_-]{3,80})/giu)].map(match => match[1]))];
  const nameMatch = rawText.match(/(?:Shop\s*name|店铺名称)\s*[:：]\s*([^\n]{1,100})/iu);
  if (shopIds.length === 1) { identity.shopId = shopIds[0]; identity.idKind = 'shop_id'; }
  else if (!shopIds.length && shopCodes.length === 1) { identity.shopId = shopCodes[0]; identity.idKind = 'shop_code'; }
  if (!identity.shopName && nameMatch) identity.shopName = norm(nameMatch[1].split(/Shop\s*(?:ID|Code)|店铺\s*ID|店铺代码|店铺编码|地区|Region/iu)[0]);
  const regionMatch = text.match(/(?:Shop\s*(?:region|market)|店铺地区|店铺市场|销售国家|地区|Region)\s*[:：]\s*(美国|United States|US|英国|United Kingdom|UK|GB)(?=\s|$|[，,;；])/iu);
  if (regionMatch) identity.region = /美国|United States|US/iu.test(regionMatch[1]) ? 'US' : 'GB';
  const currentUrl = new URL(location.href), marketValues = currentUrl.searchParams.getAll('shop_region');
  const marketParameter = currentUrl.protocol === 'https:' && currentUrl.hostname === 'seller.us.tiktokshopglobalselling.com' && marketValues.length === 1 && marketValues[0] === 'US' ? 'US' : '';
  if (marketParameter) { identity.region = 'US'; identity.regionSource = 'seller-url-market'; }
  const alertElements = [...document.querySelectorAll('[role="alert"],[class*="error"],[class*="Error"],[class*="message-success"],[class*="MessageSuccess"],[class*="toast"]')].filter(visible).filter(element => norm(element.innerText));
  const alertEvidence = alertElements.slice(0, 100).map(element => ({ instanceId: 'alert-' + instanceFor(element), text: norm(element.innerText),
    isLeaf: !alertElements.some(other => other !== element && element.contains(other)) }));
  const alerts = alertEvidence.map(item => item.text), alertEvidenceComplete = alertElements.length <= 100;
  const scrollables = [...document.querySelectorAll('main,section,div,article,[class*="scroll"],[class*="Scroll"],[role="listbox"],[role="tree"],[role="menu"],[class*="virtual"],[class*="Virtual"],[class*="select-popup"],[class*="cascader"]')]
    .filter(element => /auto|scroll/u.test(styleFor(element).overflowY || '')).filter(visible).filter(element => element.scrollHeight > element.clientHeight + 2)
    .map(element => ({ selector: selector(element), top: element.scrollTop, height: element.clientHeight, scrollHeight: element.scrollHeight,
      kind: element.closest('[role="listbox"],[role="tree"],[role="menu"],[class*="virtual"],[class*="Virtual"],[class*="select-popup"],[class*="cascader"]') ? 'popup' : 'page' }));
  const pageScroll = document.scrollingElement;
  if (pageScroll && pageScroll.scrollHeight > pageScroll.clientHeight + 2) scrollables.push({ selector: ':root', kind: 'page', top: pageScroll.scrollTop, height: pageScroll.clientHeight, scrollHeight: pageScroll.scrollHeight });
  const listRootSelector = '[role="listbox"],[role="menu"],[class*="select-popup"],[class*="select-dropdown"],[class*="SelectPopup"],[class*="SelectDropdown"]';
  const listRoots = [...document.querySelectorAll(listRootSelector)].filter(visible).filter(element => !element.parentElement?.closest(listRootSelector));
  const optionLists = listRoots.map(root => {
    const scrolling = [root, ...root.querySelectorAll('*')].filter(visible).filter(element => element.scrollHeight > element.clientHeight + 2 && /auto|scroll/u.test(getComputedStyle(element).overflowY || ''))
      .sort((left, right) => (right.scrollHeight - right.clientHeight) - (left.scrollHeight - left.clientHeight));
    const pane = scrolling[0] || root, rootText = norm(root.innerText), optionRefs = controls.filter(item => ['option', 'treeitem', 'menuitem'].includes(item.role)
      && root.contains(document.querySelector(item.selector))).map(item => item.ref);
    const sizes = controls.filter(item => optionRefs.includes(item.ref)).map(item => item.setSize).filter(value => Number.isInteger(value) && value > 0);
    const explicitCount = Number(root.getAttribute('aria-setsize') || root.getAttribute('aria-rowcount')) || null;
    const countText = rootText.match(/(?:共|Total[:：]?)\s*(\d+)\s*(?:项|个|条|results?|options?)/iu)?.[1];
    const totalCount = explicitCount || (sizes.length && new Set(sizes).size === 1 ? sizes[0] : null) || (countText ? Number(countText) : null);
    const busyEvidence = listBusyReader(root, visible), busy = !busyEvidence.scanComplete || ['ariaBusyCount', 'progressbarCount', 'activeSpinnerCount', 'loadingTextCount'].some(key => busyEvidence[key] > 0);
    const moreButtons = controls.filter(item => item.role === 'button' && !item.disabled && root.contains(document.querySelector(item.selector)) && /^(加载更多|Load more|Show more results)$/iu.test(norm(item.label || item.text)));
    const relatedListIds = [...new Set(controls.filter(item => item.role === 'combobox').flatMap(item => item.listIds || []).filter(id => {
      const target = document.getElementById(id);
      return target && document.querySelectorAll('#' + CSS.escape(id)).length === 1 && (target === root || root.contains(target) && target.matches('[role="listbox"],[role="menu"],[class*="select-popup"],[class*="select-dropdown"]'));
    }))];
    const customBinding=globalThis[Symbol.for('pod-custom-select-popup-owners-v1')]?.owners?.get(root);
    const customOwner=customBinding?.document===document&&customBinding.href===location.href&&customBinding.owner?.isConnected&&controlIdentities.nodes.get(customBinding.owner)===customBinding.ownerInstanceId?customBinding:null;
    const result = { id: root.id || '', selector: selector(pane), containerSelector: selector(root), popupInstanceId: instanceFor(root), optionRefs, top: pane.scrollTop || 0, height: pane.clientHeight || 0, scrollHeight: pane.scrollHeight || 0,
      ...(customOwner?{customOwnerInstanceId:customOwner.ownerInstanceId,customPopupInstanceId:instanceFor(root)}:{}),
      relatedListIds,
      countConflict: new Set([...sizes, ...(explicitCount > 0 ? [explicitCount] : []), ...(Number(countText) > 0 ? [Number(countText)] : [])]).size > 1,
      totalCount, busy, busyEvidence, virtual: !!root.querySelector('[class*="virtual"],[class*="Virtual"]') || sizes.length > 0, moreControlCount: moreButtons.length, moreRef: moreButtons.length === 1 ? moreButtons[0].ref : null };
    if (result.scrollHeight > result.height + 2 && !scrollables.some(item => item.selector === result.selector)) scrollables.push({ selector: result.selector, kind: 'popup', top: result.top, height: result.height, scrollHeight: result.scrollHeight });
    return result;
  });
  const categoryPopupRoots = [...document.querySelectorAll('.core-cascader-popup')].filter(visible);
  const categoryBusy = categoryPopupRoots.some(root => root.getAttribute('aria-busy') === 'true' || [...root.querySelectorAll('[aria-busy="true"],[role="progressbar"],[class*="loading"],[class*="Loading"],[class*="spin"],[class*="Spin"]')].some(visible));
  const categoryColumns = categoryPopupRoots.flatMap(root => [...root.querySelectorAll('.core-cascader-list-column')].filter(visible).map((column, level) => {
    const pane = column.querySelector('.core-cascader-list-wrapper') || column;
    const optionRefs = controls.filter(item => ['option', 'menuitem', 'treeitem'].includes(item.role) && column.contains(document.querySelector(item.selector))).map(item => item.ref);
    for (const item of controls) if (optionRefs.includes(item.ref)) item.categoryLevel = level;
    const result = { level, selector: selector(pane), popupSelector: selector(root), popupInstanceId: instanceFor(root), columnInstanceId: instanceFor(column), optionRefs, top: pane.scrollTop || 0, height: pane.clientHeight || 0, scrollHeight: pane.scrollHeight || 0, busy: categoryBusy };
    if (result.scrollHeight > result.height + 2 && !scrollables.some(item => item.selector === result.selector)) scrollables.push({ ...result, kind: 'popup' });
    return result;
  }));
  const knownActivityProgress = element => {
    try {
    // One observed seller-header campaign ring is a static activity metric,
    // not product loading. Unknown progressbars and all aria-busy remain busy.
    if (element.tagName !== 'DIV' || element.getAttribute('role') !== 'progressbar' || String(element.className || '').trim() !== 'island-arco-progress-circle-wrapper') return false;
    if (element.closest('form,main,[role="dialog"],[aria-modal="true"],[role="combobox"],[role="textbox"],[class*="modal"],[class*="Modal"]')) return false;
    let reachedDocumentRoot = false;
    for (let current = element, depth = 0; current && depth < 32; current = current.parentElement, depth++) {
      const classes = String(current.className || '');
      if (classes.length > 2000 || /loading|spinner|(?:^|[\s_-])spin(?:$|[\s_-])|modal/iu.test(classes)) return false;
      if (['BODY', 'HTML'].includes(current.tagName)) { reachedDocumentRoot = true; break; }
    }
    if (!reachedDocumentRoot) return false;
    const box = rectFor(element);
    if (![box.y, box.width, box.height].every(Number.isFinite) || box.y < 0 || box.y > 100 || box.width <= 0 || box.width > 64 || box.height <= 0 || box.height > 64) return false;
    for (let ancestor = element.parentElement, depth = 0; ancestor && depth < 4; ancestor = ancestor.parentElement, depth++) {
      if (['BODY', 'HTML', 'MAIN', 'FORM'].includes(ancestor.tagName)) break;
      const bounds = rectFor(ancestor);
      if (![bounds.y, bounds.width, bounds.height].every(Number.isFinite) || bounds.y < 0 || bounds.y > 100 || bounds.width <= 0 || bounds.width > 1000 || bounds.height <= 0 || bounds.height > 100) continue;
      let count = 0, cleanTree = true; const queue = [ancestor];
      while (queue.length) {
        const current = queue.shift(); if (++count > 80) { cleanTree = false; break; }
        const role = current.getAttribute('role'), classes = String(current.className || '');
        if (['FORM', 'INPUT', 'TEXTAREA', 'SELECT', 'DIALOG'].includes(current.tagName) || ['dialog', 'combobox', 'textbox', 'searchbox', 'spinbutton', 'listbox'].includes(role)
          || current.isContentEditable === true || current.hasAttribute('contenteditable') && current.getAttribute('contenteditable') !== 'false'
          || current.getAttribute('aria-modal') === 'true' || current.getAttribute('aria-busy') === 'true' || role === 'progressbar' && current !== element
          || /loading|spinner|(?:^|[\s_-])spin(?:$|[\s_-])|modal/iu.test(classes)) { cleanTree = false; break; }
        if (queue.length + current.children.length + count > 80) { cleanTree = false; break; }
        queue.push(...current.children);
      }
      if (!cleanTree) continue;
      const activityText = norm(ancestor.innerText);
      // The seller header now rotates GMV and LIVE campaign cards in the same
      // observed activity ring. Keep these outside every product/loading scope.
      const header = element.closest('header,[role="banner"]'), headerBox = header && rectFor(header);
      const inSellerHeader = headerBox && headerBox.y >= 0 && headerBox.y <= 10 && headerBox.height >= 32 && headerBox.height <= 100 && headerBox.width >= 200;
      const counter = '(?:[0-9]{1,3}\\s*\\/\\s*[1-9][0-9]{0,2}\\s*)?';
      const campaignAmount = '[1-9][0-9,]{0,12}(?:\\.[0-9]{1,2})?';
      const currentHeaderCampaign = inSellerHeader && (
        new RegExp('^' + counter + 'GMV达到(?:💲|\\$)' + campaignAmount + '\\s+\\$' + campaignAmount + '$', 'u').test(activityText)
        || new RegExp('^' + counter + 'Click the link for BFCM Auction LIVE incentives \\$' + campaignAmount + '$', 'u').test(activityText));
      if (activityText.length <= 180 && (/潜力排位赛/u.test(activityText) || /^(?:0\s*\/\s*1\s*)?开通商家钱包\s*\$\s*50(?:\.00)?$/u.test(activityText) || currentHeaderCampaign) && visible(ancestor)) return true;
    }
    return false;
    } catch { return false; }
  };
  const visibleBusyElements = [...document.querySelectorAll('[aria-busy="true"],[role="progressbar"]')].filter(visible);
  const activityProgress = visibleBusyElements.filter(element => element.getAttribute('aria-busy') !== 'true' && knownActivityProgress(element));
  const ignoredKnownActivityProgressCount = activityProgress.length === 1 ? 1 : 0;
  const busy = categoryBusy || visibleBusyElements.length > ignoredKnownActivityProgressCount;
  const visibleModals=[...document.querySelectorAll('[role="dialog"],[aria-modal="true"],.core-modal,.arco-modal,.ant-modal')].filter(visible);
  const modalCount=visibleModals.filter(element=>!visibleModals.some(parent=>parent!==element&&parent.contains(element))).length;
  const knownGuides = [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],[class*="modal"],[class*="Modal"]')].filter(visible)
    .filter(element => /上传图片即可生成草稿|Upload images? to (?:generate|create) (?:a )?draft/iu.test(norm(element.innerText)));
  const guidanceDialogs = knownGuides.filter(element => !knownGuides.some(other => other !== element && other.contains(element)))
    .map(element => ({ kind: 'image-to-draft', closeRefs: controls.filter(item => item.role === 'button' && !item.disabled && element.contains(document.querySelector(item.selector))
      && (/^(关闭|取消|暂不|跳过|Close|Cancel|Not now|Maybe later|Skip)$/iu.test(norm(item.label || item.text)) || /modal-close|ModalClose/u.test(document.querySelector(item.selector)?.className || ''))).map(item => item.ref) }));
  const shopTriggers = controls.filter(item => [...shopTriggerElements].some(element => selector(element) === item.selector)).map(item => item.ref);
  const shopMenuRoots = [...document.querySelectorAll('[role="menu"],[class*="popover"],[class*="Popover"],[class*="dropdown"],[class*="Dropdown"],[class*="tooltip"],[class*="Tooltip"]')].filter(visible);
  const shopMenuShells = shopMenuRoots.filter(element => {
    const rect = element.getBoundingClientRect();
    return controls.filter(item => shopTriggers.includes(item.ref)).some(item => rect.x + rect.width >= item.bounds.x - 300 && rect.x <= item.bounds.x + item.bounds.width + 50 && rect.y >= item.bounds.y - 30 && rect.y <= item.bounds.y + item.bounds.height + 300);
  }).slice(0, 10).map(element => {
    const rect = element.getBoundingClientRect(), text = norm(element.innerText);
    return { tag: element.tagName.toLowerCase(), role: element.getAttribute('role') || '', className: String(element.className || '').slice(0, 180),
      bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, containsShopName: capsuleNames.some(name => text.includes(name)), hasIdentityMarker: /Shop\s*(?:ID|Code|information|settings)|店铺\s*ID|店铺(?:代码|编码|信息|设置)|切换店铺|Switch shop/iu.test(text), hasVisibleChildren: [...element.children].some(visible) };
  });
  const shopIdentityMenuVisible = shopMenuRoots
    .some(element => {
      const value = norm(element.innerText);
      return capsuleNames.some(name => value.includes(name)) && /Shop\s*(?:ID|Code|information|settings)|店铺\s*ID|店铺(?:代码|编码|信息|设置)|切换店铺|Switch shop/iu.test(value);
    }) || controls.some(item => shopTriggers.includes(item.ref) && item.expanded === 'true');
  const tables = [...document.querySelectorAll('table,[role="table"],[role="grid"]')].filter(visible).map(table => {
    const tableSelector='table,[role="table"],[role="grid"]',rowSelector='tr,[role="row"]',spanIssues=[],issueKeys=new Set(),maxColumns=256,maxRows=5000,maxCells=100000;
    const issue=(reason,row,column)=>{const key=reason+':'+row+':'+column;if(!issueKeys.has(key)&&spanIssues.length<100){issueKeys.add(key);spanIssues.push({reason,row,column});}};
    const ownCells=row=>[...row.querySelectorAll('th,td,[role="columnheader"],[role="cell"],[role="gridcell"]')].filter(visible).filter(cell=>cell.closest(rowSelector)===row&&cell.closest(tableSelector)===table);
    let physicalRows=[...table.querySelectorAll(rowSelector)].filter(visible).filter(row=>row.closest(tableSelector)===table);
    if(physicalRows.length>maxRows){issue('row-limit',maxRows,0);physicalRows=physicalRows.slice(0,maxRows);}
    const cellsFor=new Map(physicalRows.map(row=>[row,ownCells(row)]));
    const isHeader=row=>!!row.closest('thead')||cellsFor.get(row).some(cell=>cell.getAttribute('role')==='columnheader')||cellsFor.get(row).length>0&&cellsFor.get(row).every(cell=>cell.tagName==='TH'&&cell.getAttribute('scope')!=='row');
    const headerRows=physicalRows.filter(isHeader),bodyRows=physicalRows.filter(row=>!isHeader(row)&&!row.closest('tfoot'));
    const expand=(sourceRows,expectedWidth)=>{
      const grid=sourceRows.map(()=>[]);let assigned=0;
      const groupFor=row=>row.closest('thead,tbody,tfoot,[role="rowgroup"]')||table;
      const span=(cell,axis,row,column,remaining)=>{
        const native=cell.getAttribute(axis+'span'),aria=cell.getAttribute('aria-'+axis+'span'),raw=native??aria;
        if(raw===null)return 1;
        if(!/^\d+$/u.test(raw)||!Number.isSafeInteger(Number(raw))||Number(raw)<1&&!(axis==='row'&&native!==null&&Number(raw)===0)){issue('invalid-'+axis+'span',row,column);return null;}
        if(native!==null&&aria!==null&&(!/^\d+$/u.test(aria)||Number(native)!==Number(aria))){issue('conflicting-'+axis+'span',row,column);return null;}
        const value=Number(raw)===0?remaining:Number(raw),limit=axis==='row'?remaining:maxColumns;
        if(value>limit){issue(axis+'span-overflow',row,column);return null;}return value;
      };
      for(let ri=0;ri<sourceRows.length;ri++){
        const row=sourceRows[ri],group=groupFor(row);let remaining=1;while(ri+remaining<sourceRows.length&&groupFor(sourceRows[ri+remaining])===group)remaining++;
        let column=0;
        for(const cell of cellsFor.get(row)){
          while(grid[ri][column])column++;
          const index=cell.getAttribute('aria-colindex');
          if(index!==null){if(!/^[1-9]\d*$/u.test(index)||!Number.isSafeInteger(Number(index))){issue('invalid-colindex',ri,column);continue;}column=Number(index)-1;}
          const rowSpan=span(cell,'row',ri,column,remaining),colSpan=span(cell,'col',ri,column,maxColumns);if(rowSpan===null||colSpan===null)continue;
          if(column+colSpan>maxColumns||expectedWidth!==undefined&&column+colSpan>expectedWidth){issue('column-overflow',ri,column);continue;}
          if(assigned+rowSpan*colSpan>maxCells){issue('cell-limit',ri,column);continue;}
          let overlaps=false;for(let y=ri;y<ri+rowSpan;y++)for(let x=column;x<column+colSpan;x++)if(grid[y][x])overlaps=true;
          if(overlaps){issue('overlapping-span',ri,column);column+=colSpan;continue;}
          const observed={text:norm(cell.innerText),controls:[...cell.querySelectorAll('input,textarea,select,[role="combobox"]')].filter(visible).filter(element=>element.closest('th,td,[role="columnheader"],[role="cell"],[role="gridcell"]')===cell).map(element=>controls.find(item=>item.selector===selector(element))?.ref).filter(ref=>ref!==undefined)};
          for(let y=ri;y<ri+rowSpan;y++)for(let x=column;x<column+colSpan;x++)grid[y][x]=observed;
          assigned+=rowSpan*colSpan;column+=colSpan;
        }
      }
      const width=expectedWidth??Math.max(0,...grid.map(row=>row.length));
      return grid.map((row,ri)=>Array.from({length:width},(_,column)=>{if(row[column])return row[column];issue('incomplete-grid',ri,column);return {text:'',controls:[]};}));
    };
    const headerGrid=expand(headerRows),headers=headerGrid.at(-1)?.map(cell=>cell.text)||[];
    const rows=expand(bodyRows,headers.length||undefined).map(cells=>({cells}));
    return { headers, rows, spanIssues };
  });
  const specificationLabel=value=>norm(value).replace(/^\*\s*/u,'').replace(/\s*[:：]\s*$/u,'');
  const specificationKind=value=>/^(?:颜色|Color|Colour)$/iu.test(specificationLabel(value))?'color':/^(?:尺码|尺寸|Size|Specification)$/iu.test(specificationLabel(value))?'size':/^(?:款式|风格|样式|类型|Style|Type)$/iu.test(specificationLabel(value))?'style':'';
  const specificationNameMatches=(left,right)=>{const a=specificationLabel(left),b=specificationLabel(right),kind=specificationKind(a);return a===b||['color','size'].includes(kind)&&kind===specificationKind(b);};
  const nameLabel=value=>/^(?:规格名称|变体名称|Variation name|Specification name)$/iu.test(specificationLabel(value));
  const salesHeading=value=>/^(?:销售属性|销售信息|销售规格|商品规格|变体|Sales information|Sales specifications|Variations|Product variations|Specifications)$/iu.test(norm(value));
  const attributeHeading=value=>/^(?:商品属性|关键属性|可选属性|Product attributes|Key attributes|Optional attributes)$/iu.test(norm(value));
  const skuField=value=>/^(?:价格|售价|销售价格|库存|库存量|数量|商家SKU|商家\s*SKU|SKU|Seller SKU|Merchant SKU|Price|Sale price|Stock|Inventory|Quantity|GTIN|EAN|UPC|重量|Weight)$/iu.test(specificationLabel(value));
  const groupSelector='fieldset,[role="group"],[class*="sku"],[class*="Sku"],[class*="sale"],[class*="Sale"],[class*="variation"],[class*="Variation"],[class*="form-item"],[class*="FormItem"],[class*="formItem"]';
  const namedControls=controls.filter(control=>nameLabel(control.label)&&(['input','textarea','select'].includes(control.tag)||control.role==='combobox'));
  const specificationElements=new Map(controls.map((control,index)=>[control.ref,all[index]])),nameElements=new Set(namedControls.map(control=>specificationElements.get(control.ref)));
  const labelledGroup=(root,anchor)=>{
    if(root.tagName==='FIELDSET'&&anchor.tagName==='LEGEND'&&anchor.parentElement===root)return true;
    const ids=(root.getAttribute('aria-labelledby')||'').split(/\s+/u).filter(Boolean);
    return root.getAttribute('role')==='group'&&!!anchor.id&&ids.includes(anchor.id);
  };
  const anchors=[...document.querySelectorAll('label,legend,h3,h4,[class*="label"],[class*="Label"],[class*="_title_"]')].filter(visible).filter(element=>{
    const name=specificationLabel(element.innerText);return name&&name.length<=80&&(specificationKind(name)||nameLabel(name)||labelledGroup(element.parentElement,element));
  });
  for(const control of namedControls){const element=document.querySelector(control.selector);if(element&&!anchors.includes(element))anchors.push(element);}
  const specRoots=new Map(),specificationGroups=[],specificationScopeIssues=[],rejectedScopes=new Set();
  const rejectScope=(root,reason)=>{const key=instanceFor(root)+':'+reason;if(!rejectedScopes.has(key)){rejectedScopes.add(key);specificationScopeIssues.push({reason});}};
  const directNameCache=new WeakMap(),directNamesFor=root=>{if(!directNameCache.has(root))directNameCache.set(root,[...new Set(anchors.filter(other=>root.contains(other)&&!nameElements.has(other)&&!nameLabel(other.innerText)).map(other=>specificationLabel(other.innerText)).filter(Boolean))]);return directNameCache.get(root);};
  for(const anchor of anchors.slice(0,100)){
    let start=anchor.parentElement;
    // A name's inner form row is not a separate dimension when one explicit
    // enclosing group owns both its name and its option editor.
    for(let owner=start,depth=0;owner&&depth<9;owner=owner.parentElement,depth++){
      if(!owner.matches?.('fieldset,[role="group"],[class*="sku"],[class*="Sku"],[class*="sale"],[class*="Sale"],[class*="variation"],[class*="Variation"]'))continue;
      if(directNamesFor(owner).length<=1&&namedControls.filter(control=>owner.contains(specificationElements.get(control.ref))).length<=1)start=owner;
      break;
    }
    for(let root=start,depth=0;root&&depth<9;root=root.parentElement,depth++){
      if(!root.matches?.(groupSelector)||!visible(root)||root.closest('table,[role="table"],[role="grid"]'))continue;
      const hasSalesClass=root.matches?.('[class*="sku"],[class*="Sku"],[class*="sale"],[class*="Sale"],[class*="variation"],[class*="Variation"]');
      let hasSalesHeading=false,attributes=false;
      for(let section=root,level=0;section&&level<5&&!['BODY','HTML','FORM'].includes(section.tagName);section=section.parentElement,level++){
        const titles=[...section.querySelectorAll('h1,h2,h3,h4,legend,[class*="_title_"]')].filter(visible).map(element=>norm(element.innerText));
        if(titles.some(attributeHeading)){attributes=true;break;}
        if(titles.some(salesHeading)){hasSalesHeading=true;break;}
      }
      if(attributes||!hasSalesClass&&!hasSalesHeading)continue;
      const actual=controls.filter(control=>root.contains(specificationElements.get(control.ref)));
      const inputs=actual.filter(control=>['input','textarea','select'].includes(control.tag)||control.role==='combobox');
      if(!inputs.length||inputs.length>50)continue;
      const directNames=directNamesFor(root);
      // Never merge neighbouring dimension containers into one writable scope.
      if(directNames.length>1){rejectScope(root,'ambiguous-name');break;}
      const selectorValue=selector(root);if(document.querySelectorAll(selectorValue).length!==1){rejectScope(root,'duplicate-selector');break;}
      if(!specRoots.has(selectorValue))specRoots.set(selectorValue,{root,actual,directName:directNames[0]||''});break;
    }
  }
  const scopes=[...specRoots.values()];
  for(const {root,actual,directName}of scopes){
    if(scopes.some(other=>other.root!==root&&(root.contains(other.root)||other.root.contains(root)))){rejectScope(root,'overlapping-groups');continue;}
    const nameFields=actual.filter(control=>namedControls.includes(control)||control.role==='combobox'&&directName&&specificationKind(directName)&&specificationKind(control.value||control.text)===specificationKind(directName));
    if(nameFields.length>1){rejectScope(root,'ambiguous-name-control');continue;}
    const nameControl=nameFields[0],nameElement=nameControl?document.querySelector(nameControl.selector):null,nameRef=nameControl?.ref??null;
    let selectedNameLabels=[];
    if(nameControl&&!omitValues){
      if(nameControl.tag==='select')selectedNameLabels=[...nameElement.selectedOptions].map(option=>norm(option.label||option.textContent));
      else selectedNameLabels=nameControl.selectedValues?.length?nameControl.selectedValues:[nameControl.value||nameControl.text];
    }
    selectedNameLabels=selectedNameLabels.map(specificationLabel).filter(value=>value&&!/^(?:请选择.*|选择规格.*|Select(?: a)? (?:variation|specification).*|Choose.*)$/iu.test(value));
    if(selectedNameLabels.length>1||directName&&selectedNameLabels.length&&!specificationNameMatches(directName,selectedNameLabels[0])){rejectScope(root,'conflicting-name');continue;}
    const name=selectedNameLabels[0]||directName,kind=specificationKind(name);
    const valueControls=actual.filter(control=>control.ref!==nameRef&&!control.disabled&&!skuField(control.label)&&!nameLabel(control.label)&&(['input','select'].includes(control.tag)||control.role==='combobox')&&!['file','hidden','password','checkbox','radio','button','submit','number'].includes(control.type));
    const addRefs=actual.filter(control=>control.role==='button'&&!control.disabled&&/^(?:\+\s*)?(?:添加(?:规格值|选项|颜色|尺码|款式)?|Add(?: (?:value|option|color|colour|size|style))?)$/iu.test(norm(control.label||control.text))).filter(control=>{const element=document.querySelector(control.selector);return element?.tagName!=='BUTTON'||!element.form||element.type==='button';}).map(control=>control.ref);
    const tokenNodes=omitValues?[]:[...root.querySelectorAll('[class*="tag-content"],[class*="TagContent"],[class*="chip"],[class*="Chip"],[class*="select-view-value"],[class*="select-selection-item"]')].filter(visible).filter(element=>!nameElement?.contains(element));
    // One chip can appear through both its control and a nested tag wrapper.
    // Deduplicate that DOM identity, never equal labels on two actual chips.
    const valueElements=valueControls.map(control=>specificationElements.get(control.ref));
    const tokens=tokenNodes.filter(element=>!tokenNodes.some(child=>child!==element&&element.contains(child))&&!valueElements.some(owner=>owner?.contains(element))).map(element=>norm(element.innerText)).filter(Boolean);
    const values=omitValues?[]:[...tokens,...valueControls.flatMap(control=>control.tag==='select'?[...document.querySelector(control.selector).selectedOptions].map(option=>norm(option.label||option.textContent)):control.selectedValues?.length?control.selectedValues:control.value?[control.value]:[])];
    specificationGroups.push({groupId:'specification-'+instanceFor(root),kind,name,nameRef,nameInputEditable:!!nameControl&&nameLabel(nameControl.label)&&['input','textarea'].includes(nameControl.tag)&&!nameControl.disabled&&!nameControl.readOnly&&['','text','search'].includes(nameControl.type),valueRefs:valueControls.map(control=>control.ref),addRefs,values,
      textEntryRefs:valueControls.filter(control=>{const element=document.querySelector(control.selector),inputs=element?.tagName==='INPUT'?[element]:[...(element?.querySelectorAll('input')||[])].filter(visible);return inputs.length===1&&!inputs[0].disabled&&!inputs[0].readOnly&&['','text','search'].includes(inputs[0].getAttribute('type')||'');}).map(control=>control.ref)});
  }
  const specificationAddRefs=controls.filter(control=>control.role==='button'&&!control.disabled&&/^(?:\+\s*)?(?:添加规格|添加变体|Add variation|Add specification)$/iu.test(norm(control.label||control.text))).filter(control=>{const element=document.querySelector(control.selector);return element?.tagName!=='BUTTON'||!element.form||element.type==='button';}).map(control=>control.ref);
  return { url: location.href, documentGeneration: controlIdentities.generation, title: document.title, text, identity, marketParameter, controls, alerts, alertEvidence, alertEvidenceComplete, scrollables, optionLists, categoryColumns, categoryPopupCount: categoryPopupRoots.length, categoryBusy, attributeGroups, attributeGroupHeadings: [...attributeGroupHeadings], attributeGroupTotals, busy, ignoredKnownActivityProgressCount, modalCount, guidanceDialogs, shopTriggers, shopIdentityMenuVisible, shopMenuShells, specificationGroups, specificationScopeIssues, specificationAddRefs, tables };
}

// The observed attribute grid's direct children form the candidate universe.
// Popup-only portal branches are excluded by their complete known topology.
// Observe only an already open attribute list. This is window metadata, never
// evidence that the complete option universe or an API property was identified.
export function fillObservedSpecificationInput(selector,value){
  const matches=document.querySelectorAll(selector);if(matches.length!==1)throw Error('销售规格控件不唯一。');
  const root=matches[0],painted=element=>{const r=element.getBoundingClientRect(),style=getComputedStyle(element);return r.width>0&&r.height>0&&style.display!=='none'&&style.visibility!=='hidden'&&!element.closest('[hidden],[aria-hidden="true"]');};
  const candidates=(root.tagName==='INPUT'?[root]:[...root.querySelectorAll('input')]).filter(painted).filter(element=>!element.disabled&&!element.readOnly&&['','text','search'].includes(element.getAttribute('type')||''));
  if(candidates.length!==1)throw Error('销售规格没有唯一可输入控件。');
  const input=candidates[0];input.focus();Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,String(value));
  for(const type of ['input','change'])input.dispatchEvent(new Event(type,{bubbles:true}));input.blur();return true;
}

export function visiblePublicProductFormStructure() {
  const result = { accepted: false, kind: 'product-form-structure', complete: false, structureOnly: true, labelScanComplete: false, titleAnchors: [], imageAnchors: [], uploadRoots: [], descendantCensuses: [], mediaSamples: [],
    counts: { examinedTextNodes: 0, examinedElementNodes: 0, emittedNodes: 0, titleAnchors: 0, brandAnchors: 0, imageAnchors: 0, imageFieldAnchors: 0, uploadActionAnchors: 0, uploadRoots: 0, standaloneNativeInputCount: 0, compositeDescendantInputCount: 0, descendantCensusScannedNodes: 0, descendantCensusTruncatedCount: 0, truncatedCount: 0 }, truncated: false, reason: 'PAGE_UNVERIFIED' };
  const started = Date.now(), limit = () => Date.now() - started >= 700 || result.counts.emittedNodes >= 1200;
  const truncate = () => { result.truncated = true; result.counts.truncatedCount++; };
  const locationBefore = location.href;
  const official = () => { try { const url = new URL(location.href); return url.origin === 'https://seller.us.tiktokshopglobalselling.com' && url.pathname === '/product/create' && !url.username && !url.password && !url.hash && url.searchParams.getAll('shop_region').length === 1 && url.searchParams.get('shop_region') === 'US'; } catch { return false; } };
  if (!official() || !document.body || !document.createTreeWalker) return result;
  const classes = element => { const value = String(element.getAttribute?.('class') || ''); if (value.length > 2000) truncate(); return value.slice(0, 2000).split(/\s+/u); };
  const has = (element, value) => classes(element).includes(value);
  const tag = element => String(element.tagName || '').toLowerCase();
  const rects = new WeakMap(), styles = new WeakMap();
  const rectFor = element => { if (!rects.has(element)) rects.set(element, element.getBoundingClientRect()); return rects.get(element); };
  const styleFor = element => { if (!styles.has(element)) { const css = getComputedStyle(element); styles.set(element, { display: css.display, visibility: css.visibility, opacity: css.opacity, backgroundContainsUrl: /url\s*\(/iu.test(css.backgroundImage || '') }); } return styles.get(element); };
  const painted = element => {
    if (!element || element.isConnected === false) return false;
    const box = rectFor(element); if (!(box.width > 0 && box.height > 0)) return false;
    for (let node = element, depth = 0; node; node = node.parentElement, depth++) {
      if (limit() || depth >= 64) { truncate(); return false; }
      if (node.hasAttribute?.('hidden') || node.getAttribute?.('aria-hidden') === 'true' || node.hasAttribute?.('inert')) return false;
      const css = styleFor(node); if (css.display === 'none' || ['hidden', 'collapse'].includes(css.visibility) || Number(css.opacity) === 0) return false;
    } return true;
  };
  const classKind = element => {
    const names = classes(element);
    if (names.includes('pulse-upload-type_picture-card')) return 'upload-picture-card';
    if (names.includes('pulse-upload-type_large')) return 'upload-large';
    if (names.includes('pulse-upload')) return 'upload';
    if (names.some(name => /^_formLabel_/u.test(name))) return 'form-label';
    if (names.some(name => /^_title_/u.test(name))) return 'form-title';
    if (names.includes('ProseMirror')) return 'prosemirror';
    if (names.includes('core-select')) return 'core-select';
    if (names.includes('pulse-select')) return 'pulse-select';
    if (names.includes('core-input')) return 'core-input';
    return 'other';
  };
  const nativeInputKind = element => {
    if (!['input', 'textarea'].includes(tag(element)) || !painted(element)) return '';
    for (let parent = element, depth = 0; parent; parent = parent.parentElement, depth++) {
      if (limit() || depth >= 64) { truncate(); return ''; }
      if (has(parent, 'core-select') || has(parent, 'pulse-select') || parent.getAttribute?.('role') === 'combobox') return 'composite';
    } return 'standalone';
  };
  const nodeInfo = element => {
    if (limit()) { truncate(); return null; }
    result.counts.emittedNodes++;
    const actualTag = tag(element), actualRole = element.getAttribute?.('role') || '', actualType = element.getAttribute?.('type') || '', rect = rectFor(element);
    return { tag: ['div', 'span', 'p', 'label', 'input', 'textarea', 'select', 'button', 'img', 'video', 'canvas', 'svg', 'image', 'ul', 'ol', 'li', 'section', 'fieldset', 'legend', 'form', 'body'].includes(actualTag) ? actualTag : 'other',
      role: ['', 'textbox', 'combobox', 'button', 'group', 'list', 'listitem', 'img', 'spinbutton', 'progressbar'].includes(actualRole) ? actualRole || 'none' : 'other',
      type: ['', 'text', 'search', 'number', 'file', 'hidden', 'password', 'checkbox', 'radio', 'button', 'submit'].includes(actualType) ? actualType || 'none' : 'other', classKind: classKind(element),
      contentEditableAttribute: element.getAttribute?.('contenteditable') === 'true', contentEditable: element.isContentEditable === true,
      disabled: element.disabled === true || element.getAttribute?.('aria-disabled') === 'true', readOnly: element.readOnly === true || element.hasAttribute?.('readonly') === true,
      hidden: element.hasAttribute?.('hidden') === true, ariaHidden: element.getAttribute?.('aria-hidden') === 'true', painted: painted(element), emptyTile: has(element, 'pulse-upload-empty'),
      bounds: Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, Number.isFinite(rect[key]) ? Math.max(-10000000, Math.min(10000000, Math.round(rect[key] * 100) / 100)) : null])) };
  };
  const anchors = [], uploads = [], known = new Map();
  const labelKind = text => { const value = String(text || '').replace(/\s+/gu, ' ').trim().replace(/^\*\s*/u, '').replace(/[:：]$/u, '').trim(); return /^(商品名称|产品名称|Product name|Product title)$/iu.test(value) ? 'title' : /^(品牌|Brand)$/iu.test(value) ? 'brand' : /^(图片|Images?)$/iu.test(value) ? 'image-field' : /^(上传主图|Upload main image)$/iu.test(value) ? 'upload-action' : ''; };
  const texts = document.createTreeWalker(document.body, 4); let textNode; result.labelScanComplete = true;
  while ((textNode = texts.nextNode())) {
    if (++result.counts.examinedTextNodes > 4000 || limit()) { result.labelScanComplete = false; truncate(); break; }
    const parent = textNode.parentElement;
    if (!parent || parent.closest?.('input,textarea,select,[contenteditable],script,style')) continue;
    const kind = labelKind(textNode.nodeValue); if (!kind || !painted(parent)) continue;
    if (known.has(parent)) continue; known.set(parent, kind);
    if (kind === 'title' || kind === 'brand') result.counts[kind + 'Anchors']++;
    else { result.counts.imageAnchors++; result.counts[kind === 'image-field' ? 'imageFieldAnchors' : 'uploadActionAnchors']++; }
    if (kind !== 'brand') { if (anchors.filter(item => kind === 'title' ? item.kind === kind : item.kind !== 'title').length >= 20) { truncate(); continue; } anchors.push({ element: parent, kind }); }
  }
  if (limit()) { result.labelScanComplete = false; truncate(); }
  const elements = document.createTreeWalker(document.body, 1); let element;
  while ((element = elements.nextNode())) {
    if (++result.counts.examinedElementNodes > 4000 || limit()) { truncate(); break; }
    if (has(element, 'pulse-upload')) { result.counts.uploadRoots++; if (uploads.length < 12) uploads.push(element); else truncate(); }
    const inputKind = nativeInputKind(element); if (inputKind === 'standalone') result.counts.standaloneNativeInputCount++; if (inputKind === 'composite') result.counts.compositeDescendantInputCount++;
  }
  const tree = root => {
    const queue = [{ element: root, parentIndex: null, depth: 0 }], nodes = [], counts = { inputs: 0, textareas: 0, contentEditables: 0, fileInputs: 0, images: 0, videos: 0, canvases: 0, svgImages: 0, uploadTiles: 0, emptyTiles: 0, titleLabels: 0, brandLabels: 0, imageLabels: 0, imageFieldLabels: 0, uploadActionLabels: 0, standaloneNativeInputCount: 0, compositeDescendantInputCount: 0 };
    const truncationsBefore = result.counts.truncatedCount;
    let locallyTruncated = false;
    while (queue.length && nodes.length < 24 && !limit()) {
      const current = queue.shift(), item = nodeInfo(current.element); if (!item) break;
      const index = nodes.length, children = current.element.children || [];
      nodes.push({ parentIndex: current.parentIndex, depth: current.depth, childCount: Math.min(100000, children.length), ...item });
      if (item.tag === 'input') counts.inputs++; if (item.tag === 'textarea') counts.textareas++; if (item.contentEditableAttribute) counts.contentEditables++;
      if (item.tag === 'input' && item.type === 'file') counts.fileInputs++; if (item.tag === 'img') counts.images++; if (item.tag === 'video') counts.videos++;
      if (item.tag === 'canvas') counts.canvases++; if (item.tag === 'image') counts.svgImages++; if (['upload', 'upload-picture-card', 'upload-large'].includes(item.classKind)) counts.uploadTiles++; if (item.emptyTile) counts.emptyTiles++;
      const kind = known.get(current.element); if (kind === 'title' || kind === 'brand') counts[kind + 'Labels']++; else if (kind) { counts.imageLabels++; counts[kind === 'image-field' ? 'imageFieldLabels' : 'uploadActionLabels']++; }
      const inputKind = nativeInputKind(current.element); if (inputKind === 'standalone') counts.standaloneNativeInputCount++; if (inputKind === 'composite') counts.compositeDescendantInputCount++;
      if (current.depth < 3) { for (let i = 0; i < Math.min(children.length, 24); i++) queue.push({ element: children[i], parentIndex: index, depth: current.depth + 1 }); if (children.length > 24) { locallyTruncated = true; truncate(); } }
      else if (children.length) { locallyTruncated = true; truncate(); }
    }
    const truncated = locallyTruncated || queue.length > 0 || result.counts.truncatedCount !== truncationsBefore; if (queue.length) truncate();
    return { nodes, counts, truncated };
  };
  const censusCache = new WeakMap(), mediaSampleCache = new WeakMap();
  const mediaNode = element => {
    if (limit()) { truncate(); return null; }
    try {
      const rawClass = element.getAttribute('class'), childCount = element.children.length, actualTag = tag(element);
      if (rawClass !== null && typeof rawClass !== 'string' || !Number.isSafeInteger(childCount) || childCount < 0 || childCount > 100000) { truncate(); return null; }
      const classFiltered = !!rawClass && (rawClass.length > 180 || /[\x00-\x1f\x7f]|(?:https?|wss?|data|blob|file):|[A-Z][A-Z0-9+.-]*:\/\/|password|passwd|token|secret|cookie|credential|authorization|API.?key|验证码|密钥|@|\b\d{7,}\b|gh[pousr]_|github_pat_|(?:^|[\s_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[\s_-])(?:jwt|basic|bearer)(?:$|[\s_-])/iu.test(rawClass));
      const value = { tag: ['img', 'div', 'span', 'p', 'section', 'li', 'ul', 'button', 'a', 'figure', 'picture', 'body'].includes(actualTag) ? actualTag : 'other', className: classFiltered ? '' : rawClass || '', classFiltered, childCount, painted: painted(element) };
      result.counts.emittedNodes++; return value;
    } catch { truncate(); return null; }
  };
  const mediaSample = element => {
    if (mediaSampleCache.has(element)) return mediaSampleCache.get(element);
    if (result.mediaSamples.length >= 12 || limit()) return null;
    const before = result.counts.truncatedCount, node = mediaNode(element); if (!node) return null;
    const parents = []; let parent = element.parentElement;
    for (let depth = 0; parent && depth < 4; depth++, parent = parent.parentElement) { const item = mediaNode(parent); if (!item) break; parents.push(item); }
    const index = result.mediaSamples.length;
    result.mediaSamples.push({ node, parents, parentLimitReached: parents.length === 4 && !!parent, truncated: result.counts.truncatedCount !== before });
    mediaSampleCache.set(element, index); return index;
  };
  const descendantCensus = root => {
    if (censusCache.has(root)) return censusCache.get(root);
    if (result.descendantCensuses.length >= 120) { truncate(); return null; }
    const index = result.descendantCensuses.length, counts = { inputs: 0, textareas: 0, contentEditableRoots: 0, nativeSelects: 0, knownSelectRoots: 0, standaloneNativeInputCount: 0, compositeDescendantInputCount: 0,
      fileInputs: 0, fileInputsWithFiles: 0, fileInputsWithoutFiles: 0, images: 0, imageSrcNonempty: 0, imageSrcEmpty: 0, paintedImages: 0, imageNaturalSizePositive: 0, imageCurrentSrcNonempty: 0, imageSrcsetNonempty: 0,
      sourceElements: 0, sourceSrcNonempty: 0, sourceSrcsetNonempty: 0, videos: 0, canvases: 0, svgImages: 0, uploadRoots: 0, pictureCardRoots: 0, largeUploadRoots: 0, emptyTiles: 0, backgroundUrlNodes: 0, titleLabels: 0, brandLabels: 0, imageFieldLabels: 0, uploadActionLabels: 0 };
    const census = { countsComplete: false, truncated: false, labelsComplete: result.labelScanComplete, scannedNodes: 0, maxRelativeDepth: 0, controlSamplesTruncated: false, mediaSamplesTruncated: false, counts, nativeControls: [], mediaSamples: [] };
    censusCache.set(root, index); result.descendantCensuses.push(census);
    const queue = [{ element: root, depth: 0 }]; let scanCut = false;
    while (queue.length && census.scannedNodes < 400 && result.counts.descendantCensusScannedNodes < 4000 && !limit()) {
      const current = queue.shift(), element = current.element, actualTag = tag(element), children = element.children || [], truncationsBefore = result.counts.truncatedCount, names = classes(element);
      census.scannedNodes++; result.counts.descendantCensusScannedNodes++; census.maxRelativeDepth = Math.max(census.maxRelativeDepth, current.depth);
      if (actualTag === 'input') counts.inputs++; if (actualTag === 'textarea') counts.textareas++; if (actualTag === 'select') counts.nativeSelects++;
      const contentEditableRoot = element.getAttribute?.('contenteditable') === 'true'; if (contentEditableRoot) counts.contentEditableRoots++;
      if (names.includes('core-select') || names.includes('pulse-select') || !['input', 'textarea'].includes(actualTag) && element.getAttribute?.('role') === 'combobox') counts.knownSelectRoots++;
      const inputKind = nativeInputKind(element); if (inputKind === 'standalone') counts.standaloneNativeInputCount++; if (inputKind === 'composite') counts.compositeDescendantInputCount++;
      if (actualTag === 'input' && element.getAttribute?.('type') === 'file') {
        counts.fileInputs++;
        try {
          const files = element.files, length = files && typeof files === 'object' ? files.length : null;
          if (!Number.isSafeInteger(length) || length < 0) scanCut = true;
          else if (length > 0) counts.fileInputsWithFiles++; else counts.fileInputsWithoutFiles++;
        } catch { scanCut = true; }
      }
      if (actualTag === 'img') counts.images++; if (actualTag === 'video') counts.videos++; if (actualTag === 'canvas') counts.canvases++; if (actualTag === 'image') counts.svgImages++;
      if (actualTag === 'img') {
        const sampleIndex = mediaSample(element);
        if (sampleIndex === null) census.mediaSamplesTruncated = true;
        else { census.mediaSamples.push({ index: sampleIndex, relativeDepth: current.depth }); if (result.mediaSamples[sampleIndex].truncated) census.mediaSamplesTruncated = true; }
      }
      if (actualTag === 'img' || actualTag === 'source') {
        if (actualTag === 'source') counts.sourceElements++;
        try {
          const src = element.getAttribute('src'), srcset = element.getAttribute('srcset');
          if (src !== null && typeof src !== 'string' || srcset !== null && typeof srcset !== 'string') scanCut = true;
          else if (actualTag === 'source') { if (src?.length) counts.sourceSrcNonempty++; if (srcset?.length) counts.sourceSrcsetNonempty++; }
          else {
            const currentSrc = element.currentSrc, naturalWidth = element.naturalWidth, naturalHeight = element.naturalHeight;
            if (typeof currentSrc !== 'string' || !Number.isFinite(naturalWidth) || naturalWidth < 0 || !Number.isFinite(naturalHeight) || naturalHeight < 0) scanCut = true;
            else {
              if (src?.length) counts.imageSrcNonempty++; else counts.imageSrcEmpty++;
              if (srcset?.length) counts.imageSrcsetNonempty++; if (currentSrc.length) counts.imageCurrentSrcNonempty++;
              if (naturalWidth > 0 && naturalHeight > 0) counts.imageNaturalSizePositive++;
              if (painted(element)) counts.paintedImages++;
            }
          }
        } catch { scanCut = true; }
      }
      if (names.includes('pulse-upload')) counts.uploadRoots++; if (names.includes('pulse-upload-type_picture-card')) counts.pictureCardRoots++; if (names.includes('pulse-upload-type_large')) counts.largeUploadRoots++; if (names.includes('pulse-upload-empty')) counts.emptyTiles++;
      if (styleFor(element).backgroundContainsUrl) counts.backgroundUrlNodes++;
      const kind = known.get(element); if (kind === 'title' || kind === 'brand') counts[kind + 'Labels']++; else if (kind) counts[kind === 'image-field' ? 'imageFieldLabels' : 'uploadActionLabels']++;
      if (['input', 'textarea', 'select'].includes(actualTag) || contentEditableRoot) {
        if (census.nativeControls.length < 12) { const item = nodeInfo(element); if (item) census.nativeControls.push({ relativeDepth: current.depth, nativeInputKind: ['input', 'textarea'].includes(actualTag) ? inputKind || 'unverified' : 'not-native', ...item }); else scanCut = true; }
        else census.controlSamplesTruncated = true;
      }
      if (current.depth < 20) {
        const queued = Math.min(children.length, Math.max(0, 400 - queue.length));
        for (let i = 0; i < queued; i++) queue.push({ element: children[i], depth: current.depth + 1 });
        if (children.length > queued) scanCut = true;
      } else if (children.length) scanCut = true;
      if (limit()) scanCut = true;
      if (result.counts.truncatedCount !== truncationsBefore) scanCut = true;
    }
    census.truncated = scanCut || queue.length > 0 || !census.labelsComplete; census.countsComplete = !census.truncated;
    if (census.truncated) { result.counts.descendantCensusTruncatedCount++; truncate(); }
    if (census.controlSamplesTruncated) truncate();
    if (census.mediaSamplesTruncated) truncate();
    return index;
  };
  const entry = (root, kind, depthLimit) => {
    const node = nodeInfo(root); if (!node) return null;
    const ancestors = []; let branch = root;
    for (let parent = root.parentElement, depth = 1; parent && depth <= depthLimit && !limit(); parent = parent.parentElement, depth++) {
      const parentNode = nodeInfo(parent); if (!parentNode) break;
      const children = parent.children || []; let branchIndex = -1; for (let i = 0; i < children.length; i++) { if (children[i] === branch) { branchIndex = i; break; } if (i >= 4000 || limit()) { truncate(); break; } }
      ancestors.push({ depth, node: parentNode, branchIndex: branchIndex >= 0 ? Math.min(branchIndex, 100000) : null, childCount: Math.min(100000, children.length), ...tree(parent), descendantCensusIndex: descendantCensus(parent) });
      branch = parent; if (parent === document.body) break;
    }
    if (ancestors.length === depthLimit && branch !== document.body && branch.parentElement) truncate();
    if (limit()) truncate(); return { labelKind: kind, node, ancestors };
  };
  for (const anchor of anchors) { if (limit()) { truncate(); break; } const item = entry(anchor.element, anchor.kind, 10); if (item) (anchor.kind === 'title' ? result.titleAnchors : result.imageAnchors).push(item); }
  for (const root of uploads) { if (limit()) { truncate(); break; } const item = entry(root, 'upload-root', 5); if (item) result.uploadRoots.push(item); }
  if (!official() || location.href !== locationBefore) return { ...result, accepted: false, titleAnchors: [], imageAnchors: [], uploadRoots: [], descendantCensuses: [], mediaSamples: [], reason: 'PAGE_UNVERIFIED' };
  return { ...result, accepted: true, reason: result.truncated ? 'SCAN_LIMIT' : 'STRUCTURE_OBSERVED' };
}

export function normalizePublicProductFormStructure(raw) {
  const empty = reason => ({ accepted: false, kind: 'product-form-structure', complete: false, structureOnly: true, labelScanComplete: false, titleAnchors: [], imageAnchors: [], uploadRoots: [], descendantCensuses: [], mediaSamples: [], counts: { examinedTextNodes: 0, examinedElementNodes: 0, emittedNodes: 0, titleAnchors: 0, brandAnchors: 0, imageAnchors: 0, imageFieldAnchors: 0, uploadActionAnchors: 0, uploadRoots: 0, standaloneNativeInputCount: 0, compositeDescendantInputCount: 0, descendantCensusScannedNodes: 0, descendantCensusTruncatedCount: 0, truncatedCount: 0 }, truncated: false, reason });
  const object = value => value && typeof value === 'object' && !Array.isArray(value), count = (value, max = 100000) => Number.isSafeInteger(value) && value >= 0 && value <= max;
  if (!object(raw) || raw.kind !== 'product-form-structure' || raw.complete !== false || raw.structureOnly !== true || !['PAGE_UNVERIFIED', 'STRUCTURE_OBSERVED', 'SCAN_LIMIT'].includes(raw.reason)) return empty('OBSERVATION_FAILED');
  if (raw.accepted !== true) return empty(raw.reason);
  if (!['STRUCTURE_OBSERVED', 'SCAN_LIMIT'].includes(raw.reason) || typeof raw.truncated !== 'boolean' || typeof raw.labelScanComplete !== 'boolean' || !object(raw.counts) || !Array.isArray(raw.descendantCensuses) || raw.descendantCensuses.length > 120 || !Array.isArray(raw.mediaSamples) || raw.mediaSamples.length > 12) return empty('OBSERVATION_FAILED');
  const counts = {}; for (const [key, max] of Object.entries({ examinedTextNodes: 4001, examinedElementNodes: 4001, emittedNodes: 1200, titleAnchors: 4000, brandAnchors: 4000, imageAnchors: 4000, imageFieldAnchors: 4000, uploadActionAnchors: 4000, uploadRoots: 4000, standaloneNativeInputCount: 4000, compositeDescendantInputCount: 4000, descendantCensusScannedNodes: 4000, descendantCensusTruncatedCount: 120, truncatedCount: 100000 })) { if (!count(raw.counts[key], max)) return empty('OBSERVATION_FAILED'); counts[key] = raw.counts[key]; }
  let emitted = 0;
  const node = value => {
    if (!object(value) || ++emitted > 1200) throw Error();
    const result = {};
    for (const [key, allowed] of Object.entries({ tag: ['div', 'span', 'p', 'label', 'input', 'textarea', 'select', 'button', 'img', 'video', 'canvas', 'svg', 'image', 'ul', 'ol', 'li', 'section', 'fieldset', 'legend', 'form', 'body', 'other'], role: ['none', 'textbox', 'combobox', 'button', 'group', 'list', 'listitem', 'img', 'spinbutton', 'progressbar', 'other'], type: ['none', 'text', 'search', 'number', 'file', 'hidden', 'password', 'checkbox', 'radio', 'button', 'submit', 'other'], classKind: ['upload-picture-card', 'upload-large', 'upload', 'form-label', 'form-title', 'prosemirror', 'core-select', 'pulse-select', 'core-input', 'other'] })) { if (!allowed.includes(value[key])) throw Error(); result[key] = value[key]; }
    for (const key of ['contentEditableAttribute', 'contentEditable', 'disabled', 'readOnly', 'hidden', 'ariaHidden', 'painted', 'emptyTile']) { if (typeof value[key] !== 'boolean') throw Error(); result[key] = value[key]; }
    if (!object(value.bounds)) throw Error(); result.bounds = {}; for (const key of ['x', 'y', 'width', 'height']) { if (value.bounds[key] !== null && (!Number.isFinite(value.bounds[key]) || Math.abs(value.bounds[key]) > 10000000)) throw Error(); result.bounds[key] = value.bounds[key]; }
    return result;
  };
  const entries = (values, kinds, maximum, depthLimit) => {
    if (!Array.isArray(values) || values.length > maximum) throw Error();
    return values.map(value => {
      if (!object(value) || !kinds.includes(value.labelKind) || !Array.isArray(value.ancestors) || value.ancestors.length > depthLimit) throw Error();
      return { labelKind: value.labelKind, node: node(value.node), ancestors: value.ancestors.map((ancestor, index) => {
        if (!object(ancestor) || ancestor.depth !== index + 1 || !count(ancestor.childCount) || ancestor.branchIndex !== null && (!count(ancestor.branchIndex) || ancestor.branchIndex >= ancestor.childCount) || !Array.isArray(ancestor.nodes) || ancestor.nodes.length > 24 || typeof ancestor.truncated !== 'boolean' || !object(ancestor.counts)) throw Error();
        if (ancestor.descendantCensusIndex !== null && (!count(ancestor.descendantCensusIndex, 119) || ancestor.descendantCensusIndex >= raw.descendantCensuses.length)) throw Error();
        const treeCounts = {}; for (const key of ['inputs', 'textareas', 'contentEditables', 'fileInputs', 'images', 'videos', 'canvases', 'svgImages', 'uploadTiles', 'emptyTiles', 'titleLabels', 'brandLabels', 'imageLabels', 'imageFieldLabels', 'uploadActionLabels', 'standaloneNativeInputCount', 'compositeDescendantInputCount']) { if (!count(ancestor.counts[key], 24)) throw Error(); treeCounts[key] = ancestor.counts[key]; }
        return { depth: ancestor.depth, node: node(ancestor.node), branchIndex: ancestor.branchIndex, childCount: ancestor.childCount, nodes: ancestor.nodes.map((item, position) => {
          if (!count(item.depth, 3) || !count(item.childCount) || item.parentIndex !== null && (!count(item.parentIndex, 23) || item.parentIndex >= position)) throw Error();
          return { parentIndex: item.parentIndex, depth: item.depth, childCount: item.childCount, ...node(item) };
        }), counts: treeCounts, truncated: ancestor.truncated, descendantCensusIndex: ancestor.descendantCensusIndex };
      }) };
    });
  };
  try {
    const titleAnchors = entries(raw.titleAnchors, ['title'], 20, 10), imageAnchors = entries(raw.imageAnchors, ['image-field', 'upload-action'], 20, 10), uploadRoots = entries(raw.uploadRoots, ['upload-root'], 12, 5);
    const mediaNode = value => {
      if (!object(value) || ++emitted > 1200 || !['img', 'div', 'span', 'p', 'section', 'li', 'ul', 'button', 'a', 'figure', 'picture', 'body', 'other'].includes(value.tag) || typeof value.className !== 'string' || value.className.length > 180
        || /[\x00-\x1f\x7f]|(?:https?|wss?|data|blob|file):|[A-Z][A-Z0-9+.-]*:\/\/|password|passwd|token|secret|cookie|credential|authorization|API.?key|验证码|密钥|@|\b\d{7,}\b|gh[pousr]_|github_pat_|(?:^|[\s_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[\s_-])(?:jwt|basic|bearer)(?:$|[\s_-])/iu.test(value.className) || typeof value.classFiltered !== 'boolean' || value.classFiltered && value.className !== '' || !count(value.childCount) || typeof value.painted !== 'boolean') throw Error();
      return { tag: value.tag, className: value.className, classFiltered: value.classFiltered, childCount: value.childCount, painted: value.painted };
    };
    const mediaSamples = raw.mediaSamples.map(sample => {
      if (!object(sample) || sample.node?.tag !== 'img' || !Array.isArray(sample.parents) || sample.parents.length > 4 || typeof sample.parentLimitReached !== 'boolean' || sample.parentLimitReached && sample.parents.length !== 4 || typeof sample.truncated !== 'boolean') throw Error();
      return { node: mediaNode(sample.node), parents: sample.parents.map(mediaNode), parentLimitReached: sample.parentLimitReached, truncated: sample.truncated };
    });
    const descendantCensuses = raw.descendantCensuses.map(census => {
      if (!object(census) || typeof census.countsComplete !== 'boolean' || typeof census.truncated !== 'boolean' || census.countsComplete === census.truncated || typeof census.labelsComplete !== 'boolean' || census.countsComplete && !census.labelsComplete || !count(census.scannedNodes, 400) || !count(census.maxRelativeDepth, 20) || typeof census.controlSamplesTruncated !== 'boolean' || !object(census.counts) || !Array.isArray(census.nativeControls) || census.nativeControls.length > 12 || census.controlSamplesTruncated && census.nativeControls.length !== 12) throw Error();
      const values = {}; for (const key of ['inputs', 'textareas', 'contentEditableRoots', 'nativeSelects', 'knownSelectRoots', 'standaloneNativeInputCount', 'compositeDescendantInputCount', 'fileInputs', 'fileInputsWithFiles', 'fileInputsWithoutFiles', 'images', 'imageSrcNonempty', 'imageSrcEmpty', 'paintedImages', 'imageNaturalSizePositive', 'imageCurrentSrcNonempty', 'imageSrcsetNonempty', 'sourceElements', 'sourceSrcNonempty', 'sourceSrcsetNonempty', 'videos', 'canvases', 'svgImages', 'uploadRoots', 'pictureCardRoots', 'largeUploadRoots', 'emptyTiles', 'backgroundUrlNodes', 'titleLabels', 'brandLabels', 'imageFieldLabels', 'uploadActionLabels']) { if (!count(census.counts[key], census.scannedNodes)) throw Error(); values[key] = census.counts[key]; }
      if (values.fileInputsWithFiles + values.fileInputsWithoutFiles > values.fileInputs || census.countsComplete && values.fileInputsWithFiles + values.fileInputsWithoutFiles !== values.fileInputs) throw Error();
      if (values.imageSrcNonempty + values.imageSrcEmpty > values.images || census.countsComplete && values.imageSrcNonempty + values.imageSrcEmpty !== values.images
        || ['paintedImages', 'imageNaturalSizePositive', 'imageCurrentSrcNonempty', 'imageSrcsetNonempty'].some(key => values[key] > values.images)
        || ['sourceSrcNonempty', 'sourceSrcsetNonempty'].some(key => values[key] > values.sourceElements)) throw Error();
      if (typeof census.mediaSamplesTruncated !== 'boolean' || !Array.isArray(census.mediaSamples) || census.mediaSamples.length > 12 || census.mediaSamples.length > values.images || new Set(census.mediaSamples.map(sample => sample.index)).size !== census.mediaSamples.length || !census.mediaSamplesTruncated && census.mediaSamples.length !== values.images) throw Error();
      const samples = census.mediaSamples.map(sample => { if (!count(sample.index, 11) || sample.index >= mediaSamples.length || !count(sample.relativeDepth, 20) || mediaSamples[sample.index].truncated && !census.mediaSamplesTruncated) throw Error(); return { index: sample.index, relativeDepth: sample.relativeDepth }; });
      return { countsComplete: census.countsComplete, truncated: census.truncated, labelsComplete: census.labelsComplete, scannedNodes: census.scannedNodes, maxRelativeDepth: census.maxRelativeDepth, controlSamplesTruncated: census.controlSamplesTruncated, mediaSamplesTruncated: census.mediaSamplesTruncated, mediaSamples: samples, counts: values, nativeControls: census.nativeControls.map(control => { if (!count(control.relativeDepth, 20) || !['input', 'textarea', 'select'].includes(control.tag) && control.contentEditableAttribute !== true || !['standalone', 'composite', 'not-native', 'unverified'].includes(control.nativeInputKind)) throw Error(); return { relativeDepth: control.relativeDepth, nativeInputKind: control.nativeInputKind, ...node(control) }; }) };
    });
    if (emitted !== counts.emittedNodes || counts.descendantCensusScannedNodes !== descendantCensuses.reduce((sum, census) => sum + census.scannedNodes, 0) || counts.descendantCensusTruncatedCount !== descendantCensuses.filter(census => census.truncated).length || counts.imageAnchors !== counts.imageFieldAnchors + counts.uploadActionAnchors || raw.truncated !== (raw.reason === 'SCAN_LIMIT') || !raw.truncated && (counts.truncatedCount !== 0 || !raw.labelScanComplete || descendantCensuses.some(census => census.truncated || census.controlSamplesTruncated || census.mediaSamplesTruncated))) return empty('OBSERVATION_FAILED');
    return { accepted: true, kind: raw.kind, complete: false, structureOnly: true, labelScanComplete: raw.labelScanComplete, titleAnchors, imageAnchors, uploadRoots, descendantCensuses, mediaSamples, counts, truncated: raw.truncated, reason: raw.reason };
  } catch { return empty('OBSERVATION_FAILED'); }
}

/** Dormant QA: category-only public layout; no input values or page prose. */
export function visibleQaCategoryNavigation(selector, expected) {
  const failed = reason => ({ accepted: false, reason, structureOnly: true, complete: false });
  try {
    const url = new URL(location.href);
    if (url.origin !== 'https://seller.us.tiktokshopglobalselling.com' || url.username || url.password || url.pathname !== '/product/create' || url.hash || url.searchParams.getAll('shop_region').length !== 1 || url.searchParams.get('shop_region') !== 'US') return failed('PAGE_UNVERIFIED');
    const started = performance.now(), norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
    const budget = () => { if (performance.now() - started > 700) throw Error(); };
    const nodes = document.querySelectorAll(selector), popups = [...document.querySelectorAll('.core-cascader-popup')];
    if (nodes.length !== 1 || popups.length > 8 || nodes[0].tagName.toLowerCase() !== expected?.tag || norm(nodes[0].innerText) !== expected.text) return failed('TARGET_UNVERIFIED');
    const target = nodes[0], popup = target.closest('.core-cascader-popup');
    if (!popup || !target.matches('li.core-cascader-list-item') || !['menuitem', 'option', 'treeitem'].includes(target.getAttribute('role'))) return failed('TARGET_UNVERIFIED');
    const modals = [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],.core-modal')];
    if (modals.length > 40) return failed('SCAN_LIMIT');
    for (const modal of modals) { budget(); const box = modal.getBoundingClientRect(); let painted = box.width > 0 && box.height > 0, depth = 0; for (let current = modal; current; current = current.parentElement) { budget(); if (++depth > 80) throw Error(); const style = getComputedStyle(current); if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) painted = false; } if (painted) return failed('MODAL_PRESENT'); }
    const kind = value => [['运动与户外', 'root'], ['运动服饰', 'second'], ['运动T恤', 'next'], ['女士运动帽衫', 'leaf']].find(([text]) => norm(value) === text)?.[1] || 'other';
    const metadata = node => {
      budget(); const box = node.getBoundingClientRect(), css = getComputedStyle(node), rawClass = typeof node.className === 'string' ? node.className : '';
      const classFiltered = rawClass.length > 180 || /[\x00-\x1f\x7f]|(?:https?|wss?|data|blob|file):|[A-Z][A-Z0-9+.-]*:\/\/|password|passwd|token|secret|cookie|credential|authorization|API.?key|验证码|密钥|@|\b\d{7,}\b|gh[pousr]_|github_pat_|(?:^|[\s_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[\s_-])(?:jwt|basic|bearer)(?:$|[\s_-])/iu.test(rawClass);
      let painted = box.width > 0 && box.height > 0, depth = 0;
      for (let current = node; current; current = current.parentElement) { budget(); if (++depth > 80) throw Error(); const style = getComputedStyle(current); if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) painted = false; }
      const ariaHidden = !!node.closest('[aria-hidden="true"]'), hidden = !!node.closest('[hidden],[inert]'), expanded = node.getAttribute('aria-expanded');
      return { tag: ['DIV', 'LI', 'UL', 'SPAN'].includes(node.tagName) ? node.tagName.toLowerCase() : 'other', role: ['menuitem', 'option', 'treeitem', 'menu', 'listbox'].includes(node.getAttribute('role')) ? node.getAttribute('role') : 'none',
        className: classFiltered ? '' : rawClass, classFiltered, painted, canonicalVisible: painted && !ariaHidden && !hidden, ariaHidden, hidden,
        active: /(?:^|\s)core-cascader-list-item-active(?:\s|$)/u.test(rawClass), disabled: node.hasAttribute('disabled') || node.getAttribute('aria-disabled') === 'true' || /(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(rawClass),
        ariaExpanded: expanded === 'true' ? true : expanded === 'false' ? false : null, hasTabindex: node.hasAttribute('tabindex'), childCount: Math.min(1500, node.children.length),
        display: ['none', 'block', 'flex', 'inline', 'inline-block', 'grid'].includes(css.display) ? css.display : 'other', visibility: ['visible', 'hidden', 'collapse'].includes(css.visibility) ? css.visibility : 'other', pointerEvents: ['auto', 'none'].includes(css.pointerEvents) ? css.pointerEvents : 'other',
        bounds: Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, Number.isFinite(box[key]) && Math.abs(box[key]) <= 10000000 ? Math.round(box[key] * 100) / 100 : null])) };
    };
    const columns = [...popup.querySelectorAll('.core-cascader-list-column')]; if (columns.length > 8) return failed('SCAN_LIMIT');
    let scanned = 0;
    const output = columns.map((column, index) => {
      const rows = [...column.querySelectorAll('li.core-cascader-list-item')]; scanned += rows.length; if (scanned > 200) throw Error();
      const pathRows = rows.filter(row => kind(row.innerText) !== 'other' || /(?:^|\s)core-cascader-list-item-active(?:\s|$)/u.test(row.className || '')).slice(0, 8).map(row => ({ labelKind: kind(row.innerText), ...metadata(row) }));
      return { index, rawRowCount: rows.length, targetColumn: column.contains(target), ...metadata(column), pathRows };
    });
    budget(); return { accepted: true, reason: 'OBSERVED', structureOnly: true, complete: false, rawPopupCount: popups.length, rawColumnCount: columns.length,
      canonicalVisibleColumnCount: output.filter(column => column.canonicalVisible).length, target: { labelKind: kind(target.innerText), ...metadata(target) }, columns: output };
  } catch { return failed('SCAN_LIMIT'); }
}

/** This returned remote object owns only our passive counters, never app state. */
export function beginQaCategoryEventsInPage(selector, expected, structureReader) {
  const structure = structureReader(selector, expected);
  if (!structure.accepted) return { accepted: false };
  const target = document.querySelector(selector), generation = performance.timeOrigin;
  const types = ['click', 'mouseover', 'mouseenter', 'mousemove', 'mousedown', 'mouseup', 'pointerover', 'pointermove', 'pointerdown', 'pointerup'];
  const counts = Object.fromEntries(types.map(type => [type, { trusted: 0, synthetic: 0 }])); let closed = false, truncated = false;
  const handler = event => { if (closed || !target.contains(event.target) || !types.includes(event.type)) return; const key = event.isTrusted === true ? 'trusted' : 'synthetic'; if (counts[event.type][key] >= 1000) truncated = true; else counts[event.type][key]++; };
  for (const type of types) target.addEventListener(type, handler, { capture: true, passive: true });
  return { accepted: true, read(finish) {
    if (finish === true && !closed) { for (const type of types) target.removeEventListener(type, handler, { capture: true }); closed = true; }
    const targetConnected = target.isConnected === true, observedTargetSame = document.querySelector(selector) === target, sameTarget = observedTargetSame && targetConnected, documentUnchanged = performance.timeOrigin === generation;
    return { accepted: sameTarget && documentUnchanged, reason: sameTarget && documentUnchanged ? 'OBSERVED' : 'TARGET_CHANGED', sameTarget, targetConnected, observedTargetSame, documentUnchanged, closed, truncated,
      counts: Object.fromEntries(types.map(type => [type, { ...counts[type] }])), structure: sameTarget && documentUnchanged ? structureReader(selector, expected) : null };
  } };
}

export function safeQaCategoryObservation(raw) {
  const failure = reason => ({ accepted: false, reason, structureOnly: true, complete: false, ...Object.fromEntries(['targetConnected', 'observedTargetSame', 'documentUnchanged'].filter(key => typeof raw?.[key] === 'boolean').map(key => [key, raw[key]])) });
  if (raw?.accepted !== true || raw.sameTarget !== true || raw.documentUnchanged !== true || raw.structure?.accepted !== true) return failure(['TARGET_CHANGED', 'TARGET_UNVERIFIED', 'PAGE_UNVERIFIED', 'SCAN_LIMIT', 'MODAL_PRESENT'].includes(raw?.reason) ? raw.reason : 'OBSERVATION_UNVERIFIED');
  const number = (value, max = 10000000) => Number.isFinite(value) && value >= -10000000 && value <= max ? value : null;
  const node = value => {
    if (!value || typeof value !== 'object') throw Error();
    const classFiltered = value.classFiltered === true || typeof value.className !== 'string' || value.className.length > 180 || /[\x00-\x1f\x7f]|(?:https?|wss?|data|blob|file):|[A-Z][A-Z0-9+.-]*:\/\/|password|passwd|token|secret|cookie|credential|authorization|API.?key|验证码|密钥|@|\b\d{7,}\b|gh[pousr]_|github_pat_|(?:^|[\s_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[\s_-])(?:jwt|basic|bearer)(?:$|[\s_-])/iu.test(value.className);
    const result = { tag: ['div', 'li', 'ul', 'span'].includes(value.tag) ? value.tag : 'other', role: ['none', 'menuitem', 'option', 'treeitem', 'menu', 'listbox'].includes(value.role) ? value.role : 'other', className: classFiltered ? '' : value.className, classFiltered };
    for (const key of ['painted', 'canonicalVisible', 'ariaHidden', 'hidden', 'active', 'disabled', 'hasTabindex']) result[key] = typeof value[key] === 'boolean' ? value[key] : null;
    result.ariaExpanded = typeof value.ariaExpanded === 'boolean' ? value.ariaExpanded : null; result.childCount = Number.isSafeInteger(value.childCount) && value.childCount >= 0 && value.childCount <= 1500 ? value.childCount : null;
    for (const [key, allowed] of [['display', ['none', 'block', 'flex', 'inline', 'inline-block', 'grid']], ['visibility', ['visible', 'hidden', 'collapse']], ['pointerEvents', ['auto', 'none']]]) result[key] = allowed.includes(value[key]) ? value[key] : 'other';
    result.bounds = Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, number(value.bounds?.[key])]));
    if (value.labelKind !== undefined) result.labelKind = ['root', 'second', 'next', 'leaf'].includes(value.labelKind) ? value.labelKind : 'other'; return result;
  };
  try {
    const structure = raw.structure;
    if (!Array.isArray(structure.columns) || structure.columns.length > 8) throw Error();
    const columns = structure.columns.map(column => ({ ...node(column), index: Number.isSafeInteger(column.index) && column.index >= 0 && column.index < 8 ? column.index : null,
      targetColumn: column.targetColumn === true, rawRowCount: Number.isSafeInteger(column.rawRowCount) && column.rawRowCount >= 0 && column.rawRowCount <= 200 ? column.rawRowCount : null,
      pathRows: (Array.isArray(column.pathRows) ? column.pathRows : []).slice(0, 8).map(node) }));
    const counts = {}; for (const type of ['click', 'mouseover', 'mouseenter', 'mousemove', 'mousedown', 'mouseup', 'pointerover', 'pointermove', 'pointerdown', 'pointerup']) {
      counts[type] = {}; for (const key of ['trusted', 'synthetic']) { const count = raw.counts?.[type]?.[key]; if (!Number.isSafeInteger(count) || count < 0 || count > 1000) throw Error(); counts[type][key] = count; }
    }
    return { accepted: true, reason: 'OBSERVED', structureOnly: true, complete: false, sameTarget: true, targetConnected: raw.targetConnected === true, observedTargetSame: raw.observedTargetSame === true, documentUnchanged: true, closed: raw.closed === true, truncated: raw.truncated === true, counts,
      structure: { rawPopupCount: number(structure.rawPopupCount, 8), rawColumnCount: number(structure.rawColumnCount, 8), canonicalVisibleColumnCount: number(structure.canonicalVisibleColumnCount, 8), target: node(structure.target), columns } };
  } catch { return failure('OBSERVATION_UNVERIFIED'); }
}

/** A local draft capability observation only. No value/defaultValue/selection reads. */
export function visiblePublicInputCensus(selector, expected) {
  const result = { accepted: false, complete: false, localDraftOnly: true, commitVerified: false, fieldRowCount: 0, ownerCount: 0, nativeInputCount: 0, writableInputCount: 0,
    unknownControlCount: 0, missingLabelCount: 0, disabledControlCount: 0, readOnlyControlCount: 0, scanComplete: false, ownerRevalidated: false, fieldAssociationVerified: false, truncated: false, nativeInput: null, reason: 'FIELD_UNVERIFIED' };
  const stop = reason => ({ ...result, accepted: false, reason });
  try {
    const url = new URL(location.href), started = performance.now(), marker = Symbol('limit'); let scanned = 0;
    const budget = () => { if (++scanned > 2000 || performance.now() - started > 900) { result.truncated = true; throw marker; } };
    if (url.origin !== 'https://seller.us.tiktokshopglobalselling.com' || url.pathname !== '/product/create' || url.username || url.password || url.hash || url.searchParams.getAll('shop_region').length !== 1 || url.searchParams.get('shop_region') !== 'US') return stop('PAGE_UNVERIFIED');
    const labels = ['制造商', '制造商地址', '制造商地址（省份）', '制造商地址（城市）', '制造商邮政编码', '制造商邮箱'];
    if (!labels.includes(expected?.label) || expected.section !== '可选属性' || !['div', 'span'].includes(expected.tag) || typeof expected.multiple !== 'boolean' || typeof expected.required !== 'boolean') return stop('FIELD_UNVERIFIED');
    const styles = new WeakMap(), boxes = new WeakMap();
    const style = node => { budget(); if (!styles.has(node)) styles.set(node, getComputedStyle(node)); return styles.get(node); };
    const painted = node => { budget(); if (!node || node.isConnected === false || node.closest('[hidden],[aria-hidden="true"],[inert]')) return false;
      if (!boxes.has(node)) boxes.set(node, node.getBoundingClientRect()); const box = boxes.get(node); if (!(box.width > 0 && box.height > 0)) return false;
      for (let current = node, depth = 0; current; current = current.parentElement) { if (++depth > 80) { result.truncated = true; throw marker; } const css = style(current); if (css.display === 'none' || ['hidden', 'collapse'].includes(css.visibility) || Number(css.opacity) === 0) return false; } return true; };
    const list = (node, css, max = 500) => { budget(); const nodes = [...node.querySelectorAll(css)]; if (nodes.length > max) { result.truncated = true; throw marker; } return nodes; };
    const norm = text => String(text || '').replace(/\s+/gu, ' ').trim().replace(/^\*\s*/u, '');
    if (list(document, '[role="dialog"],[aria-modal="true"],.core-modal', 40).some(painted)) return stop('MODAL_PRESENT');
    const owners = list(document, selector); if (owners.length !== 1) return stop('FIELD_UNVERIFIED'); const owner = owners[0];
    if (owner.tagName.toLowerCase() !== expected.tag || owner.getAttribute('role') !== 'combobox' || !owner.matches('.core-select,.pulse-select') || !painted(owner)) return stop('FIELD_UNVERIFIED');
    const popupSelector = '[role="listbox"],[role="menu"],.core-select-popup,.pulse-select-popup';
    if (owner.closest(popupSelector) || owner.getAttribute('aria-expanded') === 'true' || /(?:^|\s)(?:core-select|pulse-select)-open(?:\s|$)/u.test(String(owner.className || '')) || list(document, popupSelector, 40).some(painted)) return stop('POPUP_PRESENT');
    const cardSelector = 'div.bg-neutral-bg2.rounded-8', cardKinds = new WeakMap(), cardKind = card => {
      if (cardKinds.has(card)) return cardKinds.get(card);
      const headings = list(card, 'p.text-head-s.text-neutral-text3', 30).filter(node => node.closest(cardSelector) === card && painted(node)).map(node => norm(node.innerText)).filter(text => ['关键属性', '可选属性', '选填', 'Key attributes', 'Optional attributes'].includes(text));
      const kind = headings.length === 1 ? ['可选属性', '选填', 'Optional attributes'].includes(headings[0]) ? 'optional' : 'key' : ''; cardKinds.set(card, kind); return kind;
    };
    const cardOwner = node => { let depth = 0; for (let card = node.closest(cardSelector); card; card = card.parentElement?.closest(cardSelector)) { budget(); if (++depth > 12) { result.truncated = true; throw marker; } if (cardKind(card)) return card; } return null; };
    const cards = list(document, cardSelector, 40).filter(card => painted(card) && cardKind(card) === 'optional');
    if (cards.length !== 1 || cardOwner(owner) !== cards[0]) return stop('FIELD_UNVERIFIED'); const card = cards[0];
    const grids = list(card, 'div.relative.grid.grid-cols-3', 10).filter(node => cardOwner(node) === card); if (grids.length !== 1) return stop('ROW_UNVERIFIED');
    const grid = grids[0], rows = [...grid.children]; if (rows.length > 700) { result.truncated = true; return stop('SCAN_LIMIT'); }
    const labelNodes = row => list(row, '[class*="_formLabel_"]', 20).filter(node => !node.closest(popupSelector) && painted(node));
    const labelText = node => { if (list(node, 'input,textarea,select,[contenteditable]', 10).length) return ''; const titles = list(node, '[class*="_title_"]', 5).filter(painted); const title = titles.length === 1 ? titles[0] : titles.length ? null : node; if (!title) return ''; const text = title.innerText; return typeof text === 'string' && text.length <= 180 ? norm(text) : ''; };
    const matching = rows.filter(row => labelNodes(row).some(node => labelText(node) === expected.label)); result.fieldRowCount = matching.length;
    if (matching.length !== 1) return stop('ROW_UNVERIFIED'); const row = matching[0], rowLabels = labelNodes(row), slots = list(row, 'span[class*="_form_"]', 10).filter(node => !node.closest(popupSelector));
    if (row.tagName !== 'DIV' || row.children.length !== 1 || !row.contains(owner) || slots.length !== 1 || !slots[0].contains(owner)) return stop('ROW_UNVERIFIED');
    result.missingLabelCount = rowLabels.length === 1 && labelText(rowLabels[0]) === expected.label ? 0 : 1;
    const roots = [...new Set(list(row, '.core-select,.pulse-select,input,textarea,select,[role="combobox"],[role="textbox"],[contenteditable]').map(node => node.closest('.core-select,.pulse-select') || node))]; result.ownerCount = roots.length;
    const nodes = [row, ...list(row, '*')], inputs = nodes.filter(node => node.tagName === 'INPUT'); result.nativeInputCount = inputs.length;
    for (const node of nodes) {
      budget(); const role = node.getAttribute('role'), tag = node.tagName, native = tag === 'INPUT';
      if (['TEXTAREA', 'SELECT', 'BUTTON', 'A'].includes(tag) || node.isContentEditable === true || node.hasAttribute('contenteditable') && node.getAttribute('contenteditable') !== 'false'
        || role && !['none', 'presentation', 'img', 'group'].includes(role) && !(node === owner && role === 'combobox') && !(native && ['textbox', 'searchbox', 'combobox'].includes(role))
        || node !== owner && !native && node.hasAttribute('tabindex')) result.unknownControlCount++;
      if (node.disabled === true || node.hasAttribute('disabled') || node.getAttribute('aria-disabled') === 'true' || /(?:^|\s)(?:core-select|pulse-select|core-input)-disabled(?:\s|$)/u.test(String(node.className || ''))) result.disabledControlCount++;
      if (node.readOnly === true || node.hasAttribute('readonly')) result.readOnlyControlCount++;
    }
    if (roots.length !== 1 || roots[0] !== owner || inputs.length !== 1 || !owner.contains(inputs[0])) return stop('INPUT_UNVERIFIED');
    const entry = inputs[0], type = entry.getAttribute('type') || 'text', hidden = !painted(entry), disabled = entry.disabled === true || !!entry.closest('[disabled],[inert],[aria-disabled="true"]'), readOnly = entry.readOnly === true || entry.hasAttribute('readonly');
    const multiple = owner.getAttribute('aria-multiselectable') === 'true' || entry.multiple === true || /(?:^|\s)(?:core-select|pulse-select)-multiple(?:\s|$)/u.test(String(owner.className || ''));
    const required = owner.getAttribute('aria-required') === 'true' || entry.required === true || entry.getAttribute('aria-required') === 'true' || /^\s*\*/u.test(rowLabels[0]?.innerText || '') || !!owner.closest('[class*="required"]');
    if (multiple !== expected.multiple || required !== expected.required) return stop('FIELD_UNVERIFIED');
    result.writableInputCount = ['text', 'search'].includes(type) && !hidden && !disabled && !readOnly ? 1 : 0;
    result.nativeInput = { tag: 'input', type: ['text', 'search'].includes(type) ? type : 'other', painted: !hidden, hidden, disabled, readOnly };
    result.ownerTag = owner.tagName.toLowerCase(); result.ownerRole = 'combobox'; result.scanComplete = true;
    if (result.unknownControlCount || result.missingLabelCount || result.disabledControlCount || result.readOnlyControlCount || result.writableInputCount !== 1) return stop('INPUT_UNVERIFIED');
    const nativePath = []; let current = entry;
    while (current && current !== owner && nativePath.length < 20) { budget(); const index = [...current.parentElement.children].indexOf(current); if (index < 0 || index >= 500) return stop('INPUT_UNVERIFIED'); nativePath.unshift(index); current = current.parentElement; }
    if (current !== owner || !nativePath.length) return stop('INPUT_UNVERIFIED');
    budget(); return { ...result, accepted: true, ownerRevalidated: true, fieldAssociationVerified: true, fieldRowIndex: rows.indexOf(row), nativePath, reason: 'OBSERVED_LOCAL_DRAFT_INPUT' };
  } catch { return stop(result.truncated ? 'SCAN_LIMIT' : 'OBSERVATION_FAILED'); }
}

export function normalizePublicInputCensus(raw) {
  const empty = reason => ({ accepted: false, complete: false, localDraftOnly: true, commitVerified: false, reason });
  const reasons = ['FIELD_UNVERIFIED', 'PAGE_UNVERIFIED', 'MODAL_PRESENT', 'POPUP_PRESENT', 'ROW_UNVERIFIED', 'INPUT_UNVERIFIED', 'SCAN_LIMIT', 'OBSERVATION_FAILED', 'OBSERVED_LOCAL_DRAFT_INPUT'];
  if (raw?.accepted !== true) return empty(reasons.includes(raw?.reason) ? raw.reason : 'OBSERVATION_FAILED');
  if (raw.complete !== false || raw.localDraftOnly !== true || raw.commitVerified !== false || !['div', 'span'].includes(raw.ownerTag) || raw.ownerRole !== 'combobox' || raw.truncated !== false
    || !['scanComplete', 'ownerRevalidated', 'fieldAssociationVerified'].every(key => raw[key] === true) || !['fieldRowCount', 'ownerCount', 'nativeInputCount', 'writableInputCount'].every(key => raw[key] === 1)
    || !['unknownControlCount', 'missingLabelCount', 'disabledControlCount', 'readOnlyControlCount'].every(key => raw[key] === 0)
    || raw.nativeInput?.tag !== 'input' || !['text', 'search'].includes(raw.nativeInput.type) || raw.nativeInput.painted !== true || !['hidden', 'disabled', 'readOnly'].every(key => raw.nativeInput[key] === false)
    || !Number.isSafeInteger(raw.fieldRowIndex) || raw.fieldRowIndex < 0 || raw.fieldRowIndex >= 700 || !Array.isArray(raw.nativePath) || raw.nativePath.length < 1 || raw.nativePath.length > 20 || raw.nativePath.some(index => !Number.isSafeInteger(index) || index < 0 || index >= 500) || raw.reason !== 'OBSERVED_LOCAL_DRAFT_INPUT') return empty('OBSERVATION_FAILED');
  return { accepted: true, complete: false, localDraftOnly: true, commitVerified: false, ownerTag: raw.ownerTag, ownerRole: 'combobox', scanComplete: true, ownerRevalidated: true, fieldAssociationVerified: true, truncated: false,
    fieldRowCount: 1, ownerCount: 1, nativeInputCount: 1, writableInputCount: 1, unknownControlCount: 0, missingLabelCount: 0, disabledControlCount: 0, readOnlyControlCount: 0,
    nativeInput: { tag: 'input', type: raw.nativeInput.type, painted: true, hidden: false, disabled: false, readOnly: false }, reason: 'OBSERVED_LOCAL_DRAFT_INPUT' };
}

export function visiblePublicOptionIdentity(selector, expected, listProof, rowProofs) {
  const result = { accepted: false, mountedOnly: true, complete: false, associationVerified: false,
    mountedRowCount: 0, capturedRowCount: 0, filteredAttributeCount: 0, rows: [], reason: 'FIELD_UNVERIFIED' };
  const stop = reason => ({ ...result, accepted: false, capturedRowCount: 0, rows: [], reason });
  const norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  const painted = element => {
    if (!element || element.isConnected === false || element.closest('[hidden],[aria-hidden="true"],[inert]')) return false;
    const box = element.getBoundingClientRect(); if (!(box.width > 0 && box.height > 0)) return false;
    for (let current = element; current; current = current.parentElement) {
      const css = getComputedStyle(current);
      if (css.display === 'none' || ['hidden', 'collapse'].includes(css.visibility) || Number(css.opacity) === 0) return false;
    }
    return true;
  };
  const unique = value => { const nodes = typeof value === 'string' && value ? document.querySelectorAll(value) : []; return nodes.length === 1 ? nodes[0] : null; };
  const idNode = id => typeof id === 'string' && id.length > 0 && id.length <= 160 ? unique('#' + CSS.escape(id)) : null;
  const publicText = value => typeof value === 'string' && value.length > 0 && value.length <= 1024 && !/[\u0000-\u001f\u007f]|(?:https?|wss?):\/\//iu.test(value);
  const numeric = value => typeof value === 'string' && /^\d{1,160}$/u.test(value);
  const url = new URL(location.href);
  if (url.origin !== 'https://seller.us.tiktokshopglobalselling.com' || url.pathname !== '/product/create' || url.hash || url.searchParams.getAll('shop_region').length !== 1 || url.searchParams.get('shop_region') !== 'US') return stop('PAGE_UNVERIFIED');
  const modals = document.querySelectorAll('[role="dialog"],[aria-modal="true"],.core-modal');
  if (modals.length > 40 || [...modals].some(painted)) return stop('MODAL_PRESENT');
  const owner = unique(selector);
  if (!owner || !painted(owner) || owner.tagName.toLowerCase() !== expected?.tag || !owner.matches('.core-select,.pulse-select')
    || owner.getAttribute('aria-disabled') === 'true' || owner.hasAttribute('disabled') || !['关键属性', '可选属性'].includes(expected.section)
    || typeof expected.multiple !== 'boolean') return stop('FIELD_UNVERIFIED');
  const ownerHelpers = [owner, ...owner.querySelectorAll('input,[role="combobox"]')];
  if (ownerHelpers.length > 11 || ownerHelpers.some(node => node.hasAttribute('disabled') || node.getAttribute('aria-disabled') === 'true')
    || /(?:^|\s)(?:core-select|pulse-select)-disabled(?:\s|$)/u.test(owner.className || '')) return stop('FIELD_UNVERIFIED');
  const multiple = ownerHelpers.some(node => node.hasAttribute('multiple') || node.getAttribute('aria-multiselectable') === 'true')
    || /(?:^|\s)(?:core-select|pulse-select)-multiple(?:\s|$)/u.test(owner.className || '');
  if (multiple !== expected.multiple) return stop('FIELD_UNVERIFIED');
  let fieldLabel = '';
  for (const helper of ownerHelpers) {
    const ids = (helper.getAttribute('aria-labelledby') || '').split(/\s+/u).filter(Boolean);
    if (ids.length > 10) return stop('FIELD_UNVERIFIED');
    const names = ids.map(idNode).filter(painted).map(node => norm(node.innerText));
    fieldLabel = norm(names.join(' ') || helper.getAttribute('aria-label')); if (fieldLabel) break;
  }
  if (!fieldLabel) for (let parent = owner.parentElement, depth = 0; parent && depth < 7; parent = parent.parentElement, depth++) {
    const labels = [...parent.querySelectorAll('[class*="_formLabel_"]')].filter(painted);
    const roots = [...parent.querySelectorAll('.core-select,.pulse-select')].filter(painted);
    if (labels.length === 1 && roots.length === 1 && roots[0] === owner) {
      const title = labels[0].querySelector('[class*="_title_"]');
      fieldLabel = norm((title && painted(title) ? title : labels[0]).innerText).replace(/^\*\s*/u, ''); break;
    }
  }
  if (!fieldLabel || fieldLabel !== expected.label) return stop('FIELD_UNVERIFIED');
  let card = owner.closest('div.bg-neutral-bg2.rounded-8'), kind = '';
  for (; card; card = card.parentElement?.closest('div.bg-neutral-bg2.rounded-8')) {
    const headings = [...card.querySelectorAll('p.text-head-s.text-neutral-text3')].filter(node => painted(node) && node.closest('div.bg-neutral-bg2.rounded-8') === card)
      .map(node => norm(node.innerText)).filter(value => /^(关键属性|可选属性|选填|Key attributes|Optional attributes)$/iu.test(value));
    if (headings.length === 1) { kind = /可选|选填|Optional/iu.test(headings[0]) ? '可选属性' : '关键属性'; break; }
    if (headings.length > 1) return stop('FIELD_UNVERIFIED');
  }
  if (kind !== expected.section) return stop('FIELD_UNVERIFIED');
  const popupCandidates = document.querySelectorAll('.core-select-popup.pulse-select-popup');
  if (popupCandidates.length > 20) return stop('SCAN_LIMIT');
  const popups = [...popupCandidates].filter(painted), popup = unique(listProof?.containerSelector);
  if (popups.length !== 1 || popup !== popups[0]) return stop('POPUP_NOT_UNIQUE');
  const lists = [popup, ...popup.querySelectorAll('[role="listbox"]')].filter(node => node.getAttribute('role') === 'listbox' && painted(node));
  if (lists.length !== 1) return stop('LISTBOX_NOT_UNIQUE');
  const list = lists[0], pane = unique(listProof?.selector);
  if (!pane || !(pane === popup || popup.contains(pane))) return stop('ASSOCIATION_UNVERIFIED');
  const rawOwners = document.querySelectorAll('.core-select,.pulse-select');
  if (rawOwners.length > 300) return stop('SCAN_LIMIT');
  const linked = [...new Set([...rawOwners])].filter(node => !popup.contains(node) && painted(node)).filter(node => {
    const helpers = node.querySelectorAll('input,[role="combobox"]'); if (helpers.length > 10) return false;
    return [node, ...helpers].some(helper => {
      const ids = ((helper.getAttribute('aria-controls') || '') + ' ' + (helper.getAttribute('aria-owns') || '')).split(/\s+/u).filter(Boolean);
      return ids.length <= 10 && ids.some(id => { const target = idNode(id); return target === list || target === popup; });
    });
  });
  if (linked.length !== 1 || linked[0] !== owner || !(listProof?.relatedListIds || []).some(id => idNode(id) === list || idNode(id) === popup)) return stop('ASSOCIATION_UNVERIFIED');
  const helpers = [owner, ...owner.querySelectorAll('input,[role="combobox"]')];
  if (!owner.classList.contains('core-select-open') && !helpers.some(node => node.getAttribute('aria-expanded') === 'true')) return stop('FIELD_NOT_OPEN');
  result.associationVerified = true;
  const rawRows = list.querySelectorAll('[role="option"]');
  if (rawRows.length > 32 || !Array.isArray(rowProofs) || rowProofs.length > 32) return stop('ROW_LIMIT');
  const rows = [...rawRows].filter(painted); result.mountedRowCount = rows.length;
  if (!rows.length || rows.length !== rowProofs.length || new Set(rows).size !== rows.length) return stop('ROWS_UNVERIFIED');
  const observedRows = rowProofs.map(proof => unique(proof.selector));
  if (new Set(observedRows).size !== rows.length || rows.some((row, index) => row !== observedRows[index] || !row.matches('li.core-select-option[role="option"]') || row.querySelector('[role="option"]'))) return stop('ROWS_UNVERIFIED');
  for (let index = 0; index < rows.length; index++) {
    const row = rows[index], label = norm(row.innerText);
    if (!publicText(label) || label !== rowProofs[index].text) return stop('LABEL_UNVERIFIED');
    const item = { label, id: null, valueAttribute: null, dataValue: null, dataId: null, ariaPosInSet: null, ariaSetSize: null };
    for (const [attribute, key] of [['id', 'id'], ['value', 'valueAttribute'], ['data-value', 'dataValue'], ['data-id', 'dataId']]) {
      const value = row.getAttribute(attribute); if (value === null) continue;
      if (numeric(value) || ['value', 'data-value'].includes(attribute) && value === label) item[key] = value;
      else result.filteredAttributeCount++;
    }
    for (const [attribute, key] of [['aria-posinset', 'ariaPosInSet'], ['aria-setsize', 'ariaSetSize']]) {
      const value = row.getAttribute(attribute); if (value === null) continue;
      if (/^[1-9]\d{0,8}$/u.test(value)) item[key] = Number(value); else result.filteredAttributeCount++;
    }
    result.rows.push(item);
  }
  return { ...result, accepted: true, capturedRowCount: result.rows.length, reason: result.filteredAttributeCount ? 'OBSERVED_WITH_FILTERED_ATTRIBUTES' : 'OBSERVED' };
}

/** Fixed read-only proof of one completely mounted Core option flow. The caller
 * still has to observe both scroll boundaries repeatedly and recheck identity. */
export function visiblePublicOptionListCensus(selector, expected, listProof) {
  const result = { accepted: false, complete: false, mountedOnly: true, coverageKind: 'complete-mounted-list',
    popupCount: 0, innerListboxCount: 0, scrollPaneCount: 0, ownerCount: 0, associationVerified: false,
    paneIdentityVerifiable: false, ownerRevalidated: false, rowCount: 0, normalisedOptionCount: 0, selectableOptionCount: 0,
    disabledRowCount: 0, missingLabelCount: 0, duplicateLabelCount: 0, unknownChildCount: 0, unknownOptionControlCount: 0,
    moreControlCount: 0, virtualMarker: false, ariaHidden: false, busy: false, countConflict: false, positionsComplete: false, emptyQueryVerified: false,
    finiteGeometry: false, flowVerified: false, completeMounted: false, atTop: false, atBottom: false, truncated: false,
    coverageGapCount: 0, coverageOverlapCount: 0, declaredTotal: null, scrollTop: null, clientHeight: null, scrollHeight: null,
    paddingTop: null, paddingBottom: null, firstContentOffset: null, lastContentOffset: null, options: [], orderedLabels: [],
    observationStage: 'field', unknownChildren: [], unknownChildrenTruncated: false, flowGeometrySamples: [], reason: 'FIELD_UNVERIFIED' };
  const stop = reason => ({ ...result, accepted: false, options: [], orderedLabels: [], reason });
  const norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  const basicCredential = value => {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    for (const match of value.matchAll(/\bBasic\s+([^\s,;]+)/giu)) {
      const encoded = match[1]; if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded)) continue;
      const bare = encoded.replace(/=+$/u, ''), remainder = bare.length % 4, padding = encoded.length - bare.length;
      if (remainder === 1 || padding && (encoded.length % 4 !== 0 || padding !== (4 - remainder) % 4)) continue;
      let buffer = 0, bits = 0, colon = false;
      for (const character of bare) { buffer = buffer * 64 + alphabet.indexOf(character); bits += 6; if (bits >= 8) { bits -= 8; if (Math.floor(buffer / 2 ** bits) === 58) colon = true; buffer %= 2 ** bits; } }
      if (buffer === 0 && colon) return true;
    }
    return false;
  };
  const safeLabel = value => typeof value === 'string' && value.length > 0 && value.length <= 1024
    && !/[\u0000-\u001f\u007f]|(?:https?|wss?):\/\/|\bBearer\s+\S+|\b(?:password|passwd|cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret)\s*[:=]|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_|\b(?:sk|rk)[-_][A-Za-z0-9]{12,}|eyJ[A-Za-z0-9_-]{12,}\./iu.test(value) && !basicCredential(value);
  const started = performance.now(), styles = new WeakMap(), boxes = new WeakMap(); let nodeCount = 0;
  const budget = () => { if (performance.now() - started > 1000) { result.truncated = true; throw Error('CENSUS_SCAN_LIMIT'); } };
  const style = node => { budget(); if (!styles.has(node)) styles.set(node, getComputedStyle(node)); return styles.get(node); };
  const rect = node => { budget(); if (!boxes.has(node)) boxes.set(node, node.getBoundingClientRect()); return boxes.get(node); };
  const painted = node => {
    budget(); if (!node || node.isConnected === false || node.closest('[hidden],[aria-hidden="true"],[inert]')) return false;
    const box = rect(node); if (!(box.width > 0 && box.height > 0)) return false;
    let depth = 0;
    for (let current = node; current; current = current.parentElement) { if (++depth > 80) { result.truncated = true; throw Error('CENSUS_SCAN_LIMIT'); } const css = style(current); if (css.display === 'none' || ['hidden', 'collapse'].includes(css.visibility) || Number(css.opacity) === 0) return false; }
    return true;
  };
  const query = (node, value, cap = 2000) => { budget(); const found = [...node.querySelectorAll(value)]; budget(); if (found.length > cap) { result.truncated = true; throw Error('CENSUS_SCAN_LIMIT'); } return found; };
  const unique = value => { const found = typeof value === 'string' && value.length > 0 && value.length <= 4096 ? query(document, value, 2000) : []; return found.length === 1 ? found[0] : null; };
  const idNode = id => typeof id === 'string' && id.length > 0 && id.length <= 160 ? unique('#' + CSS.escape(id)) : null;
  let unknownDescendantCount = 0;
  const unknownNodeInfo = (node, classifyText = false) => {
      const actualTag = String(node.tagName || '').toLowerCase(), actualRole = node.getAttribute('role') || '', rawClass = typeof node.className === 'string' ? node.className : '';
      const classFiltered = !!rawClass && (rawClass.length > 180 || /[\x00-\x1f\x7f]|(?:https?|wss?|data|blob|file):|[A-Z][A-Z0-9+.-]*:\/\/|password|passwd|token|secret|cookie|credential|authorization|API.?key|验证码|密钥|@|\b\d{7,}\b|gh[pousr]_|github_pat_|(?:^|[\s_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[\s_-])(?:jwt|basic|bearer)(?:$|[\s_-])/iu.test(rawClass));
      const rawText = node.innerText, textLength = typeof rawText === 'string' ? rawText.length : null;
      const info = { tag: ['div', 'span', 'ul', 'ol', 'li', 'input', 'svg', 'path', 'label', 'button', 'p', 'i', 'section'].includes(actualTag) ? actualTag : 'other',
        role: ['', 'listbox', 'option', 'separator', 'button', 'searchbox', 'checkbox', 'radio', 'presentation', 'img', 'none', 'combobox'].includes(actualRole) ? actualRole || 'none' : 'other',
        className: classFiltered ? '' : rawClass, classFiltered, childCount: Number.isSafeInteger(node.children.length) && node.children.length <= 2000 ? node.children.length : null,
        textLength: textLength !== null && textLength <= 1000000 ? textLength : null, hasTabindex: node.hasAttribute('tabindex') };
      if (classifyText) info.knownTextKind = [['创建', 'create-cn'], ['添加', 'add-cn'], ['Create', 'create-en'], ['Add', 'add-en']].find(([text]) => norm(rawText) === text)?.[1] || 'unknown';
      return info;
  };
  const rememberUnknown = (node, relation, cause) => {
    if (result.unknownChildren.length >= 8) { result.unknownChildrenTruncated = true; return; }
    let currentInfo;
    try {
      const footer = relation === 'root' && cause === 'unknown-child' && node.tagName === 'DIV' && node.className === 'pulse-select-extra';
      const info = { relation, cause, ...unknownNodeInfo(node, footer) }; currentInfo = info; result.unknownChildren.push(info);
      if (footer) {
        info.descendants = []; info.descendantsTruncated = false;
        const queue = [...node.children].map(child => ({ child, relativeDepth: 1, parentIndex: null }));
        while (queue.length && unknownDescendantCount < 16) {
          budget(); const { child, relativeDepth, parentIndex } = queue.shift(), index = info.descendants.length;
          unknownDescendantCount++; info.descendants.push({ relativeDepth, parentIndex, ...unknownNodeInfo(child, true) });
          if (relativeDepth < 6) for (const next of child.children) queue.push({ child: next, relativeDepth: relativeDepth + 1, parentIndex: index });
          else if (child.children.length) info.descendantsTruncated = true;
        }
        if (queue.length) info.descendantsTruncated = true;
      }
    } catch { if (currentInfo?.descendants) currentInfo.descendantsTruncated = true; result.unknownChildrenTruncated = true; }
  };
  try {
    const url = new URL(location.href);
    if (url.origin !== 'https://seller.us.tiktokshopglobalselling.com' || url.username || url.password || url.pathname !== '/product/create' || url.hash || url.searchParams.getAll('shop_region').length !== 1 || url.searchParams.get('shop_region') !== 'US') return stop('PAGE_UNVERIFIED');
    if (query(document, '[role="dialog"],[aria-modal="true"],.core-modal', 40).some(painted)) return stop('MODAL_PRESENT');
    const owner = unique(selector);
    if (!owner || !painted(owner) || owner.tagName.toLowerCase() !== expected?.tag || !owner.matches('.core-select,.pulse-select')
      || !['关键属性', '可选属性'].includes(expected.section) || typeof expected.multiple !== 'boolean') return stop('FIELD_UNVERIFIED');
    const helpers = [owner, ...query(owner, 'input,[role="combobox"]', 10)];
    if (helpers.some(node => node.hasAttribute('disabled') || node.getAttribute('aria-disabled') === 'true') || /(?:^|\s)(?:core-select|pulse-select)-disabled(?:\s|$)/u.test(owner.className || '')) return stop('FIELD_UNVERIFIED');
    const multiple = helpers.some(node => node.hasAttribute('multiple') || node.getAttribute('aria-multiselectable') === 'true') || /(?:^|\s)(?:core-select|pulse-select)-multiple(?:\s|$)/u.test(owner.className || '');
    if (multiple !== expected.multiple) return stop('FIELD_UNVERIFIED');
    let label = '';
    for (const helper of helpers) { const ids = (helper.getAttribute('aria-labelledby') || '').split(/\s+/u).filter(Boolean); if (ids.length > 10) return stop('FIELD_UNVERIFIED'); label = norm(ids.map(idNode).filter(painted).map(node => norm(node.innerText)).join(' ') || helper.getAttribute('aria-label')); if (label) break; }
    if (!label) for (let parent = owner.parentElement, depth = 0; parent && depth < 7; parent = parent.parentElement, depth++) {
      const labels = query(parent, '[class*="_formLabel_"]').filter(painted), roots = query(parent, '.core-select,.pulse-select').filter(painted);
      if (labels.length === 1 && roots.length === 1 && roots[0] === owner) { const title = labels[0].querySelector('[class*="_title_"]'); label = norm((title && painted(title) ? title : labels[0]).innerText).replace(/^\*\s*/u, ''); break; }
    }
    if (!label || label !== expected.label) return stop('FIELD_UNVERIFIED');
    let card = owner.closest('div.bg-neutral-bg2.rounded-8'), kind = '';
    for (let depth = 0; card && depth < 12; depth++, card = card.parentElement?.closest('div.bg-neutral-bg2.rounded-8')) {
      const headings = query(card, 'p.text-head-s.text-neutral-text3').filter(node => painted(node) && node.closest('div.bg-neutral-bg2.rounded-8') === card).map(node => norm(node.innerText)).filter(text => /^(关键属性|可选属性|选填|Key attributes|Optional attributes)$/iu.test(text));
      if (headings.length === 1) { kind = /可选|选填|Optional/iu.test(headings[0]) ? '可选属性' : '关键属性'; break; } if (headings.length > 1) return stop('FIELD_UNVERIFIED');
    }
    if (kind !== expected.section) return stop('FIELD_UNVERIFIED');
    result.observationStage = 'popup-tree';
    const popups = query(document, '.core-select-popup.pulse-select-popup', 20).filter(painted); result.popupCount = popups.length;
    const root = unique(listProof?.containerSelector); if (popups.length !== 1 || root !== popups[0]) return stop('POPUP_NOT_UNIQUE');
    const descendants = [], stack = [root];
    while (stack.length) { budget(); if (++nodeCount > 2000) { result.truncated = true; return stop('SCAN_LIMIT'); } const node = stack.pop(); descendants.push(node); if (node.children.length + stack.length + nodeCount > 2000) { result.truncated = true; return stop('SCAN_LIMIT'); } for (let index = node.children.length - 1; index >= 0; index--) stack.push(node.children[index]); }
    const lists = descendants.filter(node => node.getAttribute('role') === 'listbox' && painted(node)); result.innerListboxCount = lists.length;
    if (lists.length !== 1) return stop('LISTBOX_NOT_UNIQUE'); const inner = lists[0];
    const panes = descendants.filter(node => painted(node) && /^(?:auto|scroll)$/u.test(style(node).overflowY) && node.scrollHeight > node.clientHeight + 2);
    const pane = panes.length === 0 ? inner : panes.length === 1 ? panes[0] : null;
    result.scrollPaneCount = pane ? 1 : panes.length;
    if (!pane || pane !== unique(listProof?.selector) || !(pane === inner || inner.contains(pane) || pane.contains(inner))) return stop('ASSOCIATION_UNVERIFIED');
    result.paneIdentityVerifiable = !!inner.id && idNode(inner.id) === inner && (pane === inner || !!pane.id && idNode(pane.id) === pane);
    result.observationStage = 'association';
    const ownerNodes = query(document, '.core-select,.pulse-select', 300).filter(node => !root.contains(node) && painted(node));
    const linked = ownerNodes.filter(node => [node, ...query(node, 'input,[role="combobox"]', 10)].some(helper => {
      const ids = ((helper.getAttribute('aria-controls') || '') + ' ' + (helper.getAttribute('aria-owns') || '')).split(/\s+/u).filter(Boolean);
      if (ids.length > 10) return false; return ids.some(id => { const target = idNode(id); return target === inner || target === root; });
    }));
    result.ownerCount = linked.length; result.associationVerified = linked.length === 1 && linked[0] === owner && (listProof?.relatedListIds || []).some(id => idNode(id) === inner || idNode(id) === root);
    if (!result.associationVerified || !result.paneIdentityVerifiable) return stop('ASSOCIATION_UNVERIFIED');
    if (!owner.classList.contains('core-select-open') && !helpers.some(node => node.getAttribute('aria-expanded') === 'true')) return stop('FIELD_NOT_OPEN');
    result.ownerRevalidated = true; result.ariaHidden = !!root.closest('[aria-hidden="true"]') || !!inner.closest('[aria-hidden="true"]');
    result.observationStage = 'query';
    const inputType = node => String(node.getAttribute('type') || 'text').toLowerCase();
    const isTextInput = node => node.tagName === 'INPUT' && ['text', 'search'].includes(inputType(node));
    // Only the current string's emptiness is observed. Never retain, serialize,
    // hash or inspect its content; option/checkbox/tag values are not queried.
    const emptyInput = node => { try { return node.value === ''; } catch { return false; } };
    const ownerInputs = query(owner, 'input'), ownerTextInputs = ownerInputs.filter(isTextInput);
    const editors = [owner, ...query(owner, 'textarea,[contenteditable],[role="textbox"],[role="searchbox"]'), ...descendants];
    if (ownerTextInputs.length !== 1 || ownerInputs.some(node => !['text', 'search', 'hidden', 'checkbox', 'radio'].includes(inputType(node)))
      || editors.some(node => node.tagName === 'TEXTAREA' || node.isContentEditable || node.hasAttribute('contenteditable') && node.getAttribute('contenteditable') !== 'false' || ['textbox', 'searchbox'].includes(node.getAttribute('role')) && !isTextInput(node))
      || descendants.some(node => node.tagName === 'INPUT' && !['text', 'search', 'hidden', 'checkbox', 'radio'].includes(inputType(node)))
      || ![...ownerTextInputs, ...descendants.filter(isTextInput)].every(emptyInput)) return stop('QUERY_UNVERIFIED');
    result.emptyQueryVerified = true;
    result.observationStage = 'loading';
    for (const node of descendants) {
      budget(); if (/virtual/iu.test(String(node.className || '')) || node.hasAttribute('data-virtualized')) result.virtualMarker = true;
      if (!painted(node)) continue;
      if (node.getAttribute('aria-busy') === 'true' || node.getAttribute('role') === 'progressbar') result.busy = true;
      if (node.matches('.core-spin-icon,.core-spin-dot,.core-icon-loading,.pulse-loading-icon,.pulse-loading-spinner,[data-icon="IconLoading"],[data-icon="Loading"]')) {
        if ([node, ...query(node, '*')].some(icon => { const css = style(icon); return painted(icon) && String(css.animationName || '').split(',').some(name => name.trim() && name.trim() !== 'none') && css.animationPlayState !== 'paused'; })) result.busy = true;
      }
      if ((node.tagName === 'BUTTON' || node.getAttribute('role') === 'button') && /^(?:加载更多|Load more|Show more results)$/iu.test(norm(node.innerText))) result.moreControlCount++;
      if (!node.closest('[role="option"],li.core-select-option,input,textarea,[contenteditable="true"]')) for (const child of node.childNodes) if (child.nodeType === 3 && /^(?:加载中|正在加载|Loading)[.…。]*$/iu.test(norm(child.nodeValue))) result.busy = true;
    }
    result.observationStage = 'row-tree';
    let host = inner; const wrappers = [inner];
    for (let depth = 0; depth < 8; depth++) { if (host.children.length === 1 && ['DIV', 'UL'].includes(host.children[0].tagName) && host.children[0].getAttribute('role') !== 'option') { host = host.children[0]; wrappers.push(host); } else break; }
    const rows = [...host.children]; result.rowCount = rows.length;
    if (rows.length > 1000) { result.truncated = true; return stop('ROW_LIMIT'); }
    const rowSet = new Set(rows);
    result.unknownChildCount = rows.filter(node => !node.matches('li.core-select-option[role="option"]')).length;
    for (const row of rows) if (!row.matches('li.core-select-option[role="option"]')) rememberUnknown(row, 'host', 'unknown-row');
    const path = new Set([...wrappers, ...rows]);
    const knownAddFooter = footer => {
      if (footer.tagName !== 'DIV' || footer.className !== 'pulse-select-extra' || footer.children.length !== 2 || !['添加', 'Add'].includes(norm(footer.innerText)) || !painted(footer)) return false;
      const [divider, content] = footer.children;
      if (divider.tagName !== 'DIV' || divider.getAttribute('role') !== 'separator' || !divider.classList.contains('core-divider') || !divider.classList.contains('pulse-divider') || divider.children.length || norm(divider.innerText)
        || content.tagName !== 'DIV' || content.className !== 'pulse-select-extra-content' || content.children.length !== 1) return false;
      const wrapper = content.children[0];
      if (wrapper.tagName !== 'DIV' || norm(wrapper.className) !== 'px-8 py-4 relative w-full' || wrapper.children.length !== 2) return false;
      const nodes = [], pending = [{ node: footer, depth: 0 }];
      while (pending.length) { budget(); const current = pending.pop(); if (nodes.length >= 128 || current.depth > 10) return false; nodes.push(current.node); for (const child of current.node.children) pending.push({ node: child, depth: current.depth + 1 }); }
      const inputs = nodes.filter(isTextInput), commandText = norm(footer.innerText);
      const commands = nodes.filter(node => (node.tagName === 'BUTTON' && node.getAttribute('type') === 'button' || ['DIV', 'SPAN'].includes(node.tagName) && node.getAttribute('role') === 'button') && norm(node.innerText) === commandText);
      if (inputs.length !== 1 || commands.length !== 1) return false;
      const input = inputs[0], command = commands[0];
      if (!wrapper.contains(input) || !wrapper.contains(command) || input.contains(command) || command.contains(input) || !painted(input) || !painted(command)
        || input.disabled === true || input.hasAttribute('disabled') || input.readOnly === true || input.hasAttribute('readonly') || input.getAttribute('aria-disabled') === 'true'
        || input.getAttribute('role') && !['textbox', 'searchbox'].includes(input.getAttribute('role')) || input.hasAttribute('list') || !emptyInput(input)) return false;
      if (command.getAttribute('role') && command.getAttribute('role') !== 'button') return false;
      for (const node of nodes) {
        if (!painted(node) || node.isContentEditable || node.hasAttribute('contenteditable') && node.getAttribute('contenteditable') !== 'false') return false;
        if (node === input || node === command) continue;
        const tag = String(node.tagName).toUpperCase(), role = node.getAttribute('role');
        if (!['DIV', 'SPAN', 'SVG', 'PATH', 'G', 'LINE', 'POLYLINE', 'CIRCLE'].includes(tag) || node.hasAttribute('tabindex')
          || role && !['none', 'presentation', 'img'].includes(role) && node !== divider) return false;
      }
      return true;
    };
    for (const node of descendants) {
      if (node === root || path.has(node)) for (const child of node.childNodes) if (child.nodeType === 3 && norm(child.nodeValue)) { result.unknownChildCount++; rememberUnknown(node, node === root ? 'root' : rowSet.has(node) || node === host ? 'host' : 'wrapper', 'direct-text'); }
      if (node === root || wrappers.includes(node)) for (const child of node.children) {
        if (path.has(child)) continue;
        if (node === root && child.classList.contains('pulse-select-extra') && knownAddFooter(child)) continue;
        // The observed Core extra footer contains its search input. It must be
        // outside the listbox and may expose no options or actionable command.
        if (node === root && child.classList.contains('pulse-select-extra') && !child.hasAttribute('tabindex') && !child.isContentEditable && !child.getAttribute('role') && [null, 'false'].includes(child.getAttribute('contenteditable')) && !query(child, '[role="option"],li.core-select-option,button,[role="button"],[contenteditable="true"],a').length && !norm(child.innerText)
          && query(child, '*').every(item => ['DIV', 'SPAN', 'INPUT'].includes(item.tagName)
            && !item.isContentEditable && [null, 'false'].includes(item.getAttribute('contenteditable')) && (item.tagName === 'INPUT' || !item.hasAttribute('tabindex'))
            && (!item.getAttribute('role') || item.getAttribute('role') === 'searchbox' || item.tagName === 'DIV' && item.getAttribute('role') === 'separator' && item.classList.contains('core-divider') && item.classList.contains('pulse-divider') && item.children.length === 0 && !item.hasAttribute('tabindex'))
            && (item.tagName !== 'INPUT' || ['text', 'search', null].includes(item.getAttribute('type'))))) continue;
        result.unknownChildCount++; rememberUnknown(child, node === root ? 'root' : node === host ? 'host' : 'wrapper', 'unknown-child');
      }
    }
    if (!rows.length || result.unknownChildCount) return stop('ROWS_UNVERIFIED');
    result.observationStage = 'option-controls';
    const canonical = new Set();
    for (const node of descendants.filter(node => node.getAttribute('role') === 'option' || /(?:^|\s)[^\s]*select-option[^\s]*(?:\s|$)/u.test(String(node.className || '')))) {
      const row = node.closest('li.core-select-option[role="option"]');
      if (rowSet.has(row) && (node === row || node.tagName === 'SPAN' && node.classList.contains('pulse-select-option-label-single') && !node.hasAttribute('role') && !node.hasAttribute('tabindex') && !node.isContentEditable)) canonical.add(row); else result.unknownOptionControlCount++;
    }
    result.normalisedOptionCount = canonical.size;
    result.observationStage = 'geometry';
    const number = value => typeof value === 'number' ? value : typeof value === 'string' && /^-?(?:\d+(?:\.\d+)?|\.\d+)(?:px)?$/u.test(value) ? Number.parseFloat(value) : NaN;
    const css = style(pane), box = rect(pane), top = pane.scrollTop, height = pane.clientHeight, extent = pane.scrollHeight, border = pane.clientTop;
    result.finiteGeometry = [top, height, extent, border, box.top, box.height].every(Number.isFinite) && top >= -1 && height > 0 && extent >= height - 1 && top <= extent - height + 2;
    Object.assign(result, { scrollTop: top, clientHeight: height, scrollHeight: extent, paddingTop: number(css.paddingTop), paddingBottom: number(css.paddingBottom), atTop: top <= 1, atBottom: top >= extent - height - 2 });
    const parentCss = style(host), flowMargins = rows.map(row => [number(style(row).marginTop), number(style(row).marginBottom)]);
    const marginFlow = parentCss.display === 'flex' && parentCss.flexDirection === 'column' && parentCss.rowGap === 'normal' && rows.every(row => row.parentElement === host)
      && flowMargins.every((pair, index) => pair.every(Number.isFinite) && Math.abs(pair[0]) <= .01 && Math.abs(pair[1] - (index === rows.length - 1 ? 0 : 2)) <= .01);
    result.flowLayout = marginFlow ? 'flex-column-margin-2' : 'zero-margin-contiguous';
    result.flowParent = { display: parentCss.display === 'flex' ? 'flex' : 'other', flexDirection: parentCss.flexDirection === 'column' ? 'column' : 'other', rowGapKind: parentCss.rowGap === 'normal' ? 'normal' : 'other', commonRowParentVerified: rows.every(row => row.parentElement === host) };
    result.flowVerified = [pane, host, ...wrappers, ...rows].every(node => ['static', 'relative'].includes(style(node).position) && (!style(node).transform || style(node).transform === 'none'))
      && (marginFlow || flowMargins.every(pair => pair.every(Number.isFinite) && pair.every(value => Math.abs(value) <= .5)));
    const origin = box.top + border - top, flowRows = [], labels = new Set(), totals = new Set(), positions = new Set(); let cursor = result.paddingTop, invalidAria = false;
    // Native coordinates prove cross-scroll layout stability separately from
    // the complete, precise rect coverage which is still checked every frame.
    const nativeLayout = { scanComplete: true, reason: 'OBSERVED', rowCount: rows.length, capturedRowCount: 0, sameOffsetParent: true, offsetParentKind: 'unknown', ancestorKinds: [], rows: [], parentPath: [], hostBox: null, paneBox: null };
    let nativeParent, nativeParentSeen = false;
    const nativeNumber = value => typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= 10000000;
    const nativeKind = node => node === host ? 'row-host' : node === pane ? 'scroll-pane' : node === inner ? 'listbox' : node === root ? 'popup' : node === document.body ? 'body' : node === document.documentElement ? 'document' : node?.contains?.(root) ? 'popup-ancestor' : node ? 'other' : 'none';
    const nativeRow = row => {
      if (!nativeLayout.scanComplete) return;
      if (performance.now() - started > 1000) { nativeLayout.scanComplete = false; nativeLayout.reason = 'BUDGET'; return; }
      try {
        const parent = row.offsetParent, offsetTop = row.offsetTop, offsetHeight = row.offsetHeight, offsetWidth = row.offsetWidth;
        if (![offsetTop, offsetHeight, offsetWidth].every(value => nativeNumber(value) && Number.isInteger(value)) || offsetHeight <= 0 || offsetWidth <= 0) { nativeLayout.scanComplete = false; nativeLayout.reason = 'NONFINITE'; return; }
        if (!nativeParentSeen) { nativeParent = parent; nativeParentSeen = true; }
        if (!parent || typeof parent !== 'object') { nativeLayout.scanComplete = false; nativeLayout.sameOffsetParent = false; nativeLayout.reason = 'NO_OFFSET_PARENT'; return; }
        if (parent !== nativeParent) { nativeLayout.sameOffsetParent = false; nativeLayout.reason = 'MIXED_OFFSET_PARENTS'; }
        nativeLayout.rows.push([offsetTop, offsetHeight, offsetWidth]); nativeLayout.capturedRowCount++;
      } catch { nativeLayout.scanComplete = false; nativeLayout.reason = 'READ_FAILED'; }
    };
    const sampleIndices = new Set([0, 1, Math.floor(rows.length / 2) - 1, Math.floor(rows.length / 2), rows.length - 2, rows.length - 1].filter(index => index >= 0 && index < rows.length));
    const flowNumber = value => Number.isFinite(value) && Math.abs(value) <= 10000000 ? Math.round(value * 1000) / 1000 : null;
    for (let index = 0; index < rows.length; index++) {
      budget(); const row = rows[index], rowBox = rect(row), rowCss = style(row), labelNodes = query(row, 'span.pulse-select-option-label-single').filter(painted);
      const label = labelNodes.length === 1 ? norm(labelNodes[0].innerText) : '';
      if (!safeLabel(label) || norm(row.innerText) !== label) result.missingLabelCount++;
      if (labels.has(label)) result.duplicateLabelCount++; labels.add(label);
      const disabled = row.hasAttribute('disabled') || row.getAttribute('aria-disabled') === 'true' || /(?:^|\s)(?:core-select-option|pulse-select-option)-disabled(?:\s|$)/u.test(String(row.className || '')) || query(row, 'input').some(node => node.disabled === true || node.hasAttribute('disabled'));
      if (disabled) result.disabledRowCount++; else result.selectableOptionCount++;
      if (query(row, 'button,a,textarea,[role="button"],[contenteditable="true"]').length) result.unknownOptionControlCount++;
      for (const child of query(row, 'input,[role],[tabindex]')) {
        if (child.tagName === 'INPUT' && ['checkbox', 'radio'].includes(child.getAttribute('type')) && !child.isContentEditable) continue;
        if (['img', 'presentation', 'none'].includes(child.getAttribute('role')) && !child.hasAttribute('tabindex') && !child.isContentEditable) continue;
        result.unknownOptionControlCount++;
      }
      const start = rowBox.top - origin, end = start + rowBox.height;
      if (sampleIndices.has(index)) {
        const parentCss = style(row.parentElement), gap = number(parentCss.rowGap);
        result.flowGeometrySamples.push({ index, start: flowNumber(start), end: flowNumber(end), height: flowNumber(rowBox.height), marginTop: flowNumber(number(rowCss.marginTop)), marginBottom: flowNumber(number(rowCss.marginBottom)), prevEndDelta: flowNumber(start - cursor),
          parentDisplay: ['block', 'flex', 'inline-flex', 'grid', 'inline-grid', 'contents', 'flow-root', 'list-item'].includes(parentCss.display) ? parentCss.display : 'other',
          parentFlexDirection: ['row', 'row-reverse', 'column', 'column-reverse'].includes(parentCss.flexDirection) ? parentCss.flexDirection : 'other', parentRowGap: flowNumber(gap), parentRowGapKind: parentCss.rowGap === 'normal' ? 'normal' : Number.isFinite(gap) ? 'numeric' : 'unknown' });
      }
      if (![start, end, rowBox.width, rowBox.height, number(rowCss.marginTop), number(rowCss.marginBottom)].every(Number.isFinite) || rowBox.height <= 0 || rowBox.width <= 0 || !painted(row)) result.finiteGeometry = false;
      const expectedStart = cursor + (marginFlow ? flowMargins[index][0] + (index ? flowMargins[index - 1][1] : 0) : 0), gapTolerance = marginFlow ? .25 : 1.5;
      if (start > expectedStart + gapTolerance) result.coverageGapCount++; if (start < expectedStart - gapTolerance) result.coverageOverlapCount++;
      if (index === 0) result.firstContentOffset = start; result.lastContentOffset = end; cursor = end;
      const posRaw = row.getAttribute('aria-posinset'), totalRaw = row.getAttribute('aria-setsize');
      const pos = posRaw === null ? null : /^[1-9]\d{0,8}$/u.test(posRaw) ? Number(posRaw) : NaN, total = totalRaw === null ? null : /^[1-9]\d{0,8}$/u.test(totalRaw) ? Number(totalRaw) : NaN;
      if (pos !== null && !Number.isFinite(pos) || total !== null && !Number.isFinite(total)) invalidAria = true;
      if (total !== null && Number.isFinite(total)) totals.add(total); if (pos !== null && Number.isFinite(pos)) positions.add(pos);
      flowRows.push([Math.round(start * 1000) / 1000, Math.round(end * 1000) / 1000, Math.round(rowBox.width * 1000) / 1000]);
      nativeRow(row);
      result.options.push({ value: label, label }); result.orderedLabels.push(label);
    }
    try {
      nativeLayout.offsetParentKind = nativeKind(nativeParent);
      nativeLayout.parentTag = ['div', 'span'].includes(String(nativeParent?.tagName || '').toLowerCase()) ? nativeParent.tagName.toLowerCase() : 'other';
      nativeLayout.parentPosition = nativeParent ? getComputedStyle(nativeParent).position : 'unknown';
      nativeLayout.parentContainsPopup = !!nativeParent && nativeParent !== root && nativeParent.contains(root);
      nativeLayout.parentContainsHost = !!nativeParent?.contains(host); nativeLayout.parentContainsPane = !!nativeParent?.contains(pane);
      nativeLayout.hostOffsetParentSame = host.offsetParent === nativeParent; nativeLayout.paneOffsetParentSame = pane.offsetParent === nativeParent;
      const nativeBox = node => Object.fromEntries(['offsetTop', 'offsetHeight', 'offsetWidth', 'clientTop', 'clientHeight', 'clientWidth', 'scrollHeight', 'scrollWidth'].map(key => [key, node[key]]));
      nativeLayout.hostBox = nativeBox(host); nativeLayout.paneBox = nativeBox(pane);
      let pathNode = nativeParent;
      for (let depth = 0; pathNode && pathNode !== document.body && depth < 80; depth++) {
        const parent = pathNode.parentElement, index = parent ? [...parent.children].indexOf(pathNode) : -1;
        if (!parent || index < 0 || parent.children.length > 2000) break;
        nativeLayout.parentPath.unshift(index); pathNode = parent;
      }
      nativeLayout.parentPathVerified = pathNode === document.body && nativeLayout.parentPath.length > 0;
      for (let node = nativeParent, depth = 0; node && depth < 6; node = node.parentElement, depth++) {
        if (performance.now() - started > 1000) { nativeLayout.scanComplete = false; nativeLayout.reason = 'BUDGET'; break; }
        const tag = String(node.tagName || '').toLowerCase(), position = getComputedStyle(node).position;
        nativeLayout.ancestorKinds.push({ tag: ['div', 'span', 'ul', 'ol', 'li', 'section', 'article', 'main', 'body', 'html'].includes(tag) ? tag : 'other', kind: nativeKind(node), position: ['static', 'relative', 'absolute', 'fixed', 'sticky'].includes(position) ? position : 'unknown' });
        if (node === document.body || node === document.documentElement) break;
      }
    } catch { nativeLayout.scanComplete = false; nativeLayout.reason = 'READ_FAILED'; }
    result.nativeLayoutObservation = nativeLayout;
    for (const node of [inner, root]) for (const name of ['aria-setsize', 'aria-rowcount']) if (node.hasAttribute(name)) { const raw = node.getAttribute(name); if (/^[1-9]\d{0,8}$/u.test(raw)) totals.add(Number(raw)); else invalidAria = true; }
    result.countConflict = totals.size > 1 || invalidAria; result.declaredTotal = totals.size === 1 ? [...totals][0] : null;
    result.positionsComplete = !invalidAria && (!positions.size || positions.size === rows.length && rows.every((row, index) => row.getAttribute('aria-posinset') === String(index + 1)));
    if (!Number.isFinite(result.paddingTop) || !Number.isFinite(result.paddingBottom) || result.paddingTop < 0 || result.paddingBottom < 0) result.finiteGeometry = false;
    if (Math.abs(cursor - (extent - result.paddingBottom)) > 1.5) result.coverageGapCount++;
    result.completeMounted = result.finiteGeometry && result.flowVerified && !result.virtualMarker && !result.ariaHidden && !result.coverageGapCount && !result.coverageOverlapCount;
    budget();
    if (!result.completeMounted || !result.positionsComplete || result.countConflict || result.declaredTotal !== null && result.declaredTotal !== rows.length || result.busy || result.moreControlCount || result.disabledRowCount || result.missingLabelCount || result.duplicateLabelCount || result.unknownOptionControlCount || canonical.size !== rows.length) return stop('MOUNTED_PROOF_INCOMPLETE');
    const validNativeBox = value => value && Object.values(value).every(item => nativeNumber(item) && Number.isInteger(item) && item >= 0) && value.offsetHeight > 0 && value.offsetWidth > 0
      && value.clientHeight > 0 && value.clientWidth > 0 && value.offsetHeight >= value.clientHeight && value.offsetWidth >= value.clientWidth && value.scrollHeight >= value.clientHeight && value.scrollWidth >= value.clientWidth;
    const nativeVerified = nativeLayout.scanComplete && nativeLayout.reason === 'OBSERVED' && nativeLayout.sameOffsetParent && nativeLayout.capturedRowCount === rows.length
      && nativeLayout.offsetParentKind === 'popup-ancestor' && ['div', 'span'].includes(nativeLayout.parentTag) && ['absolute', 'relative'].includes(nativeLayout.parentPosition)
      && ['parentContainsPopup', 'parentContainsHost', 'parentContainsPane', 'hostOffsetParentSame', 'paneOffsetParentSame', 'parentPathVerified'].every(key => nativeLayout[key] === true)
      && validNativeBox(nativeLayout.hostBox) && validNativeBox(nativeLayout.paneBox) && nativeLayout.paneBox.clientHeight === height && nativeLayout.paneBox.scrollHeight === extent
      && nativeLayout.rows.every((values, index) => Math.abs(values[0] - nativeLayout.paneBox.offsetTop - nativeLayout.paneBox.clientTop - flowRows[index][0]) <= 1.5
        && Math.abs(values[1] - (flowRows[index][1] - flowRows[index][0])) <= 1 && Math.abs(values[2] - flowRows[index][2]) <= 1);
    if (!nativeVerified) return stop('NATIVE_LAYOUT_UNVERIFIED');
    // These private identity strings are consumed solely by the host hasher.
    const identityParts = [selector, listProof.containerSelector, listProof.selector, inner.id, pane.id || inner.id,
      helpers.map(node => [node.getAttribute('aria-controls') || '', node.getAttribute('aria-owns') || ''])];
    budget();
    result.observationStage = 'complete';
    return { ...result, accepted: true, flowRows, flowMargins, identityParts, reason: 'OBSERVED_COMPLETE_MOUNTED_LIST' };
  } catch (error) { return stop(result.truncated || error?.message === 'CENSUS_SCAN_LIMIT' ? 'SCAN_LIMIT' : 'OBSERVATION_FAILED'); }
}

export function normalizePublicOptionListCensus(raw) {
  const empty = reason => ({ accepted: false, complete: false, mountedOnly: true, coverageKind: 'complete-mounted-list', options: [], orderedLabels: [], reason });
  const reasons = ['PAGE_UNVERIFIED', 'MODAL_PRESENT', 'FIELD_UNVERIFIED', 'SCAN_LIMIT', 'POPUP_NOT_UNIQUE', 'LISTBOX_NOT_UNIQUE', 'ASSOCIATION_UNVERIFIED', 'FIELD_NOT_OPEN', 'ROW_LIMIT', 'ROWS_UNVERIFIED', 'QUERY_UNVERIFIED', 'MOUNTED_PROOF_INCOMPLETE', 'NATIVE_LAYOUT_UNVERIFIED', 'OBSERVED_COMPLETE_MOUNTED_LIST'];
  if (!raw || !reasons.includes(raw.reason)) return empty('OBSERVATION_FAILED');
  if (raw.accepted !== true) return empty(raw.reason);
  const count = raw.rowCount, result = { ...empty(raw.reason), accepted: true };
  if (raw.reason !== 'OBSERVED_COMPLETE_MOUNTED_LIST' || raw.complete !== false || raw.mountedOnly !== true || raw.coverageKind !== 'complete-mounted-list' || !Number.isSafeInteger(count) || count < 1 || count > 1000) return empty('OBSERVATION_FAILED');
  for (const key of ['popupCount', 'innerListboxCount', 'scrollPaneCount', 'ownerCount']) { if (raw[key] !== 1) return empty('OBSERVATION_FAILED'); result[key] = 1; }
  for (const key of ['associationVerified', 'paneIdentityVerifiable', 'ownerRevalidated', 'positionsComplete', 'finiteGeometry', 'flowVerified', 'completeMounted', 'emptyQueryVerified']) { if (raw[key] !== true) return empty('OBSERVATION_FAILED'); result[key] = true; }
  for (const key of ['virtualMarker', 'ariaHidden', 'busy', 'countConflict', 'truncated']) { if (raw[key] !== false) return empty('OBSERVATION_FAILED'); result[key] = false; }
  for (const key of ['rowCount', 'normalisedOptionCount', 'selectableOptionCount']) { if (raw[key] !== count) return empty('OBSERVATION_FAILED'); result[key] = count; }
  for (const key of ['disabledRowCount', 'missingLabelCount', 'duplicateLabelCount', 'unknownChildCount', 'unknownOptionControlCount', 'moreControlCount', 'coverageGapCount', 'coverageOverlapCount']) { if (raw[key] !== 0) return empty('OBSERVATION_FAILED'); result[key] = 0; }
  for (const key of ['scrollTop', 'clientHeight', 'scrollHeight', 'paddingTop', 'paddingBottom', 'firstContentOffset', 'lastContentOffset']) { if (!Number.isFinite(raw[key]) || raw[key] < -1 || raw[key] > 10000000) return empty('OBSERVATION_FAILED'); result[key] = raw[key]; }
  if (raw.clientHeight <= 0 || raw.scrollHeight < raw.clientHeight - 1 || raw.scrollTop > raw.scrollHeight - raw.clientHeight + 2 || raw.paddingTop < 0 || raw.paddingBottom < 0 || Math.abs(raw.firstContentOffset - raw.paddingTop) > 1.5 || Math.abs(raw.lastContentOffset - (raw.scrollHeight - raw.paddingBottom)) > 1.5) return empty('OBSERVATION_FAILED');
  if (typeof raw.atTop !== 'boolean' || raw.atTop !== (raw.scrollTop <= 1) || typeof raw.atBottom !== 'boolean' || raw.atBottom !== (raw.scrollTop >= raw.scrollHeight - raw.clientHeight - 2) || raw.declaredTotal !== null && raw.declaredTotal !== count) return empty('OBSERVATION_FAILED');
  Object.assign(result, { atTop: raw.atTop, atBottom: raw.atBottom, declaredTotal: raw.declaredTotal });
  // Reuse the standalone catalogue label filter, including its canonical Basic
  // payload decoder. The synthetic row exists only in memory and proves no API relation.
  if (!Array.isArray(raw.orderedLabels) || !Array.isArray(raw.options) || raw.orderedLabels.length !== count || raw.options.length !== count || new Set(raw.orderedLabels).size !== count
    || raw.orderedLabels.some(value => typeof value !== 'string' || value !== value.replace(/\s+/gu, ' ').trim() || /gh[pousr]_[A-Za-z0-9]{20,}|github_pat_|\b(?:sk|rk)[-_][A-Za-z0-9]{12,}|eyJ[A-Za-z0-9_-]{12,}\./iu.test(value))) return empty('OBSERVATION_FAILED');
  const projected = projectCategoryDefinition({ categoryId: 'label-validation', response: { code: 0, data: { product_properties: [{ id: 'labels', name: 'labels', values: raw.orderedLabels.map((name, index) => ({ id: String(index), name })) }] } } });
  if (projected.accepted !== true || projected.properties?.[0]?.valid !== true || projected.properties[0].values.length !== count || raw.options.some((option, index) => option?.label !== raw.orderedLabels[index] || option.value !== option.label)) return empty('OBSERVATION_FAILED');
  if (!Array.isArray(raw.flowRows) || raw.flowRows.length !== count || !Array.isArray(raw.identityParts) || raw.identityParts.length !== 6 || raw.identityParts.slice(0, 5).some(value => typeof value !== 'string' || !value.length || value.length > 4096) || !Array.isArray(raw.identityParts[5]) || raw.identityParts[5].length < 1 || raw.identityParts[5].length > 11 || raw.identityParts[5].some(pair => !Array.isArray(pair) || pair.length !== 2 || pair.some(value => typeof value !== 'string' || value.length > 2048))) return empty('OBSERVATION_FAILED');
  if (!['zero-margin-contiguous', 'flex-column-margin-2'].includes(raw.flowLayout) || !Array.isArray(raw.flowMargins) || raw.flowMargins.length !== count || raw.flowMargins.some(pair => !Array.isArray(pair) || pair.length !== 2 || pair.some(value => !Number.isFinite(value) || Math.abs(value) > 10000000))) return empty('OBSERVATION_FAILED');
  const marginFlow = raw.flowLayout === 'flex-column-margin-2';
  if (marginFlow ? raw.flowParent?.display !== 'flex' || raw.flowParent.flexDirection !== 'column' || raw.flowParent.rowGapKind !== 'normal' || raw.flowParent.commonRowParentVerified !== true || raw.flowMargins.some((pair, index) => Math.abs(pair[0]) > .01 || Math.abs(pair[1] - (index === count - 1 ? 0 : 2)) > .01)
    : raw.flowMargins.some(pair => pair.some(value => Math.abs(value) > .5))) return empty('OBSERVATION_FAILED');
  let end = raw.paddingTop;
  for (let index = 0; index < raw.flowRows.length; index++) {
    const pair = raw.flowRows[index], expectedStart = end + (marginFlow ? raw.flowMargins[index][0] + (index ? raw.flowMargins[index - 1][1] : 0) : 0);
    if (!Array.isArray(pair) || pair.length !== 3 || pair.some(value => !Number.isFinite(value) || Math.abs(value) > 10000000) || pair[1] <= pair[0] || pair[2] <= 0 || Math.abs(pair[0] - expectedStart) > (marginFlow ? .25 : 1.5)) return empty('OBSERVATION_FAILED'); end = pair[1];
  }
  if (Math.abs(raw.flowRows[0][0] - raw.firstContentOffset) > .002 || Math.abs(end - raw.lastContentOffset) > .002) return empty('OBSERVATION_FAILED');
  const native = raw.nativeLayoutObservation, boxKeys = ['offsetTop', 'offsetHeight', 'offsetWidth', 'clientTop', 'clientHeight', 'clientWidth', 'scrollHeight', 'scrollWidth'];
  const nativeNumber = value => Number.isSafeInteger(value) && value >= 0 && value <= 10000000;
  const nativeBox = value => value && boxKeys.every(key => nativeNumber(value[key])) && value.offsetHeight > 0 && value.offsetWidth > 0 && value.clientHeight > 0 && value.clientWidth > 0
    && value.offsetHeight >= value.clientHeight && value.offsetWidth >= value.clientWidth && value.scrollHeight >= value.clientHeight && value.scrollWidth >= value.clientWidth ? Object.fromEntries(boxKeys.map(key => [key, value[key]])) : null;
  const hostBox = nativeBox(native?.hostBox), paneBox = nativeBox(native?.paneBox);
  if (!native || native.scanComplete !== true || native.reason !== 'OBSERVED' || native.sameOffsetParent !== true || native.rowCount !== count || native.capturedRowCount !== count
    || native.offsetParentKind !== 'popup-ancestor' || !['div', 'span'].includes(native.parentTag) || !['absolute', 'relative'].includes(native.parentPosition)
    || ['parentContainsPopup', 'parentContainsHost', 'parentContainsPane', 'hostOffsetParentSame', 'paneOffsetParentSame', 'parentPathVerified'].some(key => native[key] !== true)
    || !Array.isArray(native.parentPath) || native.parentPath.length < 1 || native.parentPath.length > 80 || native.parentPath.some(index => !Number.isSafeInteger(index) || index < 0 || index >= 2000)
    || !hostBox || !paneBox || paneBox.clientHeight !== raw.clientHeight || paneBox.scrollHeight !== raw.scrollHeight
    || !Array.isArray(native.rows) || native.rows.length !== count || native.rows.some(values => !Array.isArray(values) || values.length !== 3 || values.some(value => !nativeNumber(value)) || values[1] <= 0 || values[2] <= 0)) return empty('NATIVE_LAYOUT_UNVERIFIED');
  for (let index = 0; index < count; index++) {
    const values = native.rows[index], rect = raw.flowRows[index], previous = native.rows[index - 1], expectedGap = marginFlow && previous ? raw.flowMargins[index][0] + raw.flowMargins[index - 1][1] : 0;
    // offsetTop/Height are integer-rounded. The precise rect flow above remains
    // mandatory; this never replaces its per-gap and first/last coverage checks.
    if (Math.abs(values[0] - paneBox.offsetTop - paneBox.clientTop - rect[0]) > 1.5 || Math.abs(values[1] - (rect[1] - rect[0])) > 1 || Math.abs(values[2] - rect[2]) > 1
      || previous && (values[0] <= previous[0] || Math.abs(values[0] - previous[0] - previous[1] - expectedGap) > 1.5)) return empty('NATIVE_LAYOUT_UNVERIFIED');
  }
  if (Math.abs(native.rows[0][0] - hostBox.offsetTop) > 1.5 || Math.abs(native.rows.at(-1)[0] + native.rows.at(-1)[1] - hostBox.offsetTop - hostBox.offsetHeight) > 1.5) return empty('NATIVE_LAYOUT_UNVERIFIED');
  const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
  result.options = raw.orderedLabels.map(label => ({ value: label, label })); result.orderedLabels = [...raw.orderedLabels];
  result.schemaFingerprint = digest([result.orderedLabels, count, raw.normalisedOptionCount, raw.selectableOptionCount, raw.declaredTotal]);
  result.geometryFingerprint = digest([raw.clientHeight, raw.scrollHeight, raw.paddingTop, raw.paddingBottom,
    { rows: native.rows, hostBox, paneBox, parentPath: native.parentPath, parentTag: native.parentTag, parentPosition: native.parentPosition }, raw.flowLayout, raw.flowMargins, marginFlow ? raw.flowParent : null]);
  result.associationFingerprint = digest(raw.identityParts);
  return result;
}

function safePublicOptionIdentity(raw) {
  const empty = reason => ({ accepted: false, mountedOnly: true, complete: false, associationVerified: false, mountedRowCount: 0, capturedRowCount: 0, filteredAttributeCount: 0, rows: [], reason });
  const reasons = ['PAGE_UNVERIFIED', 'MODAL_PRESENT', 'FIELD_UNVERIFIED', 'SCAN_LIMIT', 'POPUP_NOT_UNIQUE', 'LISTBOX_NOT_UNIQUE', 'ASSOCIATION_UNVERIFIED', 'FIELD_NOT_OPEN', 'ROW_LIMIT', 'ROWS_UNVERIFIED', 'LABEL_UNVERIFIED', 'OBSERVED', 'OBSERVED_WITH_FILTERED_ATTRIBUTES'];
  if (!raw || !reasons.includes(raw.reason)) return empty('OBSERVATION_FAILED');
  if (raw.accepted !== true) return empty(raw.reason);
  if (!['OBSERVED', 'OBSERVED_WITH_FILTERED_ATTRIBUTES'].includes(raw.reason) || raw.associationVerified !== true || !Array.isArray(raw.rows) || raw.rows.length < 1 || raw.rows.length > 32
    || raw.mountedRowCount !== raw.rows.length || raw.capturedRowCount !== raw.rows.length || !Number.isSafeInteger(raw.filteredAttributeCount) || raw.filteredAttributeCount < 0 || raw.filteredAttributeCount > 192) return empty('OBSERVATION_FAILED');
  const rows = [];
  for (const row of raw.rows) {
    if (typeof row?.label !== 'string' || !row.label.length || row.label.length > 1024 || /[\u0000-\u001f\u007f]|(?:https?|wss?):\/\//iu.test(row.label)) return empty('OBSERVATION_FAILED');
    const item = { label: row.label };
    for (const key of ['id', 'valueAttribute', 'dataValue', 'dataId']) {
      const value = row[key]; if (value !== null && !(typeof value === 'string' && (/^\d{1,160}$/u.test(value) || ['valueAttribute', 'dataValue'].includes(key) && value === row.label))) return empty('OBSERVATION_FAILED');
      item[key] = value;
    }
    for (const key of ['ariaPosInSet', 'ariaSetSize']) { const value = row[key]; if (value !== null && (!Number.isSafeInteger(value) || value < 1 || value > 999999999)) return empty('OBSERVATION_FAILED'); item[key] = value; }
    rows.push(item);
  }
  return { ...empty(raw.reason), accepted: true, associationVerified: true, mountedRowCount: rows.length, capturedRowCount: rows.length, filteredAttributeCount: raw.filteredAttributeCount, rows };
}

export function visibleAttributeCensus(controls = []) {
  const norm = value => String(value || '').replace(/\s+/gu, ' ').trim(), cardSelector = 'div.bg-neutral-bg2.rounded-8';
  const popupSelector = '[role="listbox"],[role="menu"],[class*="select-popup"],[class*="select-dropdown"]';
  const visible = element => {
    if (!element || element.closest('[hidden],[aria-hidden="true"]')) return false;
    const rect = element.getBoundingClientRect(); if (!(rect.width > 0 && rect.height > 0)) return false;
    for (let parent = element; parent; parent = parent.parentElement) { const style = getComputedStyle(parent); if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) return false; }
    return true;
  };
  const kindCache = new WeakMap(), kindFor = card => {
    if (kindCache.has(card)) return kindCache.get(card);
    const headings = [...card.querySelectorAll('p.text-head-s.text-neutral-text3')].filter(visible).filter(item => item.closest(cardSelector) === card).map(item => norm(item.innerText)).filter(text => /^(关键属性|可选属性|选填|Key attributes|Optional attributes)$/iu.test(text));
    const kind = headings.length === 1 ? /可选|选填|Optional/iu.test(headings[0]) ? '可选属性' : '关键属性' : ''; kindCache.set(card, kind); return kind;
  };
  const owner = element => { for (let card = element.closest(cardSelector); card; card = card.parentElement?.closest(cardSelector)) if (kindFor(card)) return card; return null; };
  const rootsIn = element => [...new Set([...element.querySelectorAll('input,textarea,select,[role="combobox"],[role="textbox"],[contenteditable="true"],.core-select,.pulse-select')]
    .filter(node => !node.closest(popupSelector)).map(node => node.closest('.core-select,.pulse-select') || node))].filter(visible);
  const controlNodes = controls.map(item => ({ item, node: document.querySelector(item.selector) }));
  return [...document.querySelectorAll(cardSelector)].filter(visible).map(card => {
    const kind = kindFor(card); if (!kind) return null;
    const grids = [...card.querySelectorAll('div.relative.grid.grid-cols-2,div.relative.grid.grid-cols-3')].filter(grid => owner(grid) === card), rawRows = grids.flatMap(grid => [...grid.children]);
    const excluded = row => {
      const children = [...row.children], trigger = children[0], popup = trigger?.children?.[0];
      return children.length === 1 && trigger?.tagName === 'SPAN' && trigger.matches('.core-trigger') && trigger.children.length === 1
        && popup?.matches('.core-select-popup.pulse-select-popup') && !!popup.querySelector('[role="listbox"]')
        && !row.querySelector('span[class*="_form_"],[class*="_formLabel_"],.core-select,.pulse-select,[role="combobox"]');
    };
    const rows = rawRows.filter(row => !excluded(row)), cardRoots = rootsIn(card).filter(node => owner(node) === card), allNodes = new Set(), unresolved = new Set();
    let missingLabelCount = 0, unknownControlCount = 0, labelledControlCount = 0, normalisedControlCount = 0, candidateControlCount = 0, verified = grids.length > 0 && rows.length > 0;
    const truncated = rawRows.length > 700 || cardRoots.length > 700 || grids.length > 10;
    for (const [index, row] of rows.slice(0, 700).entries()) {
      const roots = rootsIn(row).filter(node => owner(node) === card), slots = [...row.querySelectorAll('span[class*="_form_"]')].filter(node => !node.closest(popupSelector)), labels = [...row.querySelectorAll('[class*="_formLabel_"]')].filter(node => !node.closest(popupSelector));
      const matched = roots.map(node => controlNodes.find(entry => entry.node === node)?.item);
      candidateControlCount += roots.length; roots.forEach(node => allNodes.add(node)); normalisedControlCount += matched.filter(Boolean).length; labelledControlCount += matched.filter(item => item && norm(item.label)).length;
      const shape = row.tagName === 'DIV' && row.children.length === 1 && slots.length === 1 && labels.length === 1;
      verified = verified && shape;
      const missing = roots.length > 0 && matched.some(item => !item || !norm(item.label));
      const unknown = !shape || roots.length !== 1 || matched.length !== 1 || !matched[0] || !slots[0]?.contains(roots[0]);
      if (missing) missingLabelCount++; if (unknown) unknownControlCount++;
      if (missing || unknown) unresolved.add(index);
    }
    const outside = cardRoots.filter(node => !allNodes.has(node)); candidateControlCount += outside.length; unknownControlCount += outside.length;
    for (const [index] of outside.entries()) unresolved.add('outside-' + index);
    if (!rows.length || truncated || grids.some(grid => grids.some(other => other !== grid && other.contains(grid))) || card.querySelector('[class*="virtual"],[class*="Virtual"]')) { verified = false; unresolved.add('structure'); }
    return { groupId: kind === '关键属性' ? 'attribute-key' : 'attribute-optional', kind, expanded: true, fieldRowsVerified: verified && !truncated,
      scanComplete: verified && !truncated && !unresolved.size && candidateControlCount === rows.length, truncated,
      rawChildCount: rawRows.length, excludedPopupRowCount: rawRows.length - rows.length, candidateFieldCount: rows.length, candidateControlCount, labelledControlCount, normalisedControlCount, missingLabelCount, unknownControlCount, unresolvedCount: unresolved.size };
  }).filter(Boolean);
}

export function visibleShopPopoverState() {
  const roots = [...document.querySelectorAll('[class*="ub-popover-"]')].filter(element => /(?:^|\s)ub-popover-[\w-]+(?:\s|$)/u.test(String(element.getAttribute('class') || '')));
  const candidates = roots.slice(0, 20).map(element => {
    const rect = element.getBoundingClientRect(), style = getComputedStyle(element);
    let cssVisible = !element.closest('[hidden]');
    for (let parent = element; cssVisible && parent; parent = parent.parentElement) {
      const value = getComputedStyle(parent); cssVisible = value.display !== 'none' && !['hidden', 'collapse'].includes(value.visibility) && Number(value.opacity) !== 0;
    }
    const positiveChildRectCount = [...(element.children || [])].slice(0, 20).filter(child => { const box = child.getBoundingClientRect(); return box.width > 0 && box.height > 0; }).length;
    return { tag: element.tagName.toLowerCase(), role: element.getAttribute('role') || '', className: String(element.getAttribute('class') || '').slice(0, 180),
      bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, display: style.display, visibility: style.visibility, opacity: style.opacity,
      ariaHidden: element.getAttribute('aria-hidden') || '', nearestAriaHidden: !!element.closest('[aria-hidden="true"]'), hidden: !!element.closest('[hidden]'),
      positiveChildRectCount, painted: cssVisible && (rect.width > 0 && rect.height > 0 || positiveChildRectCount > 0) };
  });
  return { rawCount: roots.length, paintedCount: candidates.filter(item => item.painted).length, truncated: roots.length > 20, candidates };
}

// Opt-in QA experiment: run both unchanged collectors in one synchronous page
// evaluation. A failed/missing collector result must never become an empty menu.
export function visibleSellerDomWithShopPopover(domReader, popoverReader, censusReader, listBusyReader) {
  const state = domReader(censusReader, listBusyReader), popover = popoverReader();
  if (!state || typeof state !== 'object' || Array.isArray(state) || !popover || typeof popover !== 'object' || Array.isArray(popover)) throw new Error('POD_QA_COMBINED_SNAPSHOT_INVALID');
  state.shopPopoverState = popover;
  return state;
}

export function visibleSellerSecurity() {
  const visible = element => {
    if (!element || element.closest('[hidden]')) return false;
    const rect = element.getBoundingClientRect(); if (!(rect.width > 0 && rect.height > 0)) return false;
    for (let parent = element; parent; parent = parent.parentElement) { const style = getComputedStyle(parent); if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) return false; }
    return true;
  };
  const verification = /请完成(?:下列|以下)验证(?:后|以)继续|按住左边按钮拖动完成上方拼图|拖动滑块完成拼图|请完成人机验证|Verify (?:you are human|to continue)|Complete (?:the |this )?(?:security )?verification to continue|Drag the slider to (?:complete|fit)/iu;
  let detected = false, iframeCount = 0;
  if (document.body) {
    const walker = document.createTreeWalker(document.body, 4); let node, count = 0;
    while ((node = walker.nextNode()) && count++ < 5000) {
      const parent = node.parentElement;
      if (!parent || parent.closest('script,style,template,noscript,input,textarea,[contenteditable="true"]') || !visible(parent)) continue;
      if (verification.test(String(node.nodeValue || ''))) { detected = true; break; }
    }
  }
  for (const frame of [...document.querySelectorAll('iframe')].slice(0, 60)) {
    if (!visible(frame)) continue;
    let source = ''; try { const value = new URL(frame.getAttribute('src') || '', location.href); source = value.hostname + value.pathname; } catch { /* No source is needed for title/class detection. */ }
    if (/captcha|recaptcha|hcaptcha|security.challenge|verification.challenge|人机验证|安全验证|拼图验证/iu.test([frame.getAttribute('title'), frame.getAttribute('class'), frame.getAttribute('aria-label'), source].join(' '))) iframeCount++;
  }
  return { detected: detected || iframeCount > 0, kind: detected ? 'visible-verification' : iframeCount ? 'captcha-frame' : '', iframeCount };
}

// Private, fixed-label structure observation only. It is not a field/census proof.
// The caller embeds this in its existing failure inspection, not a new read.
export function visibleComplianceFieldStructureDiagnostic(deadline = Date.now() + 120) {
  const started = Date.now(), end = Math.min(Number.isFinite(deadline) ? deadline : started, started + 120);
  const labels = ['有机织物', '其他危险品或有害物质'], kinds = ['organic-fabric', 'other-dangerous-materials'];
  const result = { version: 1, structureOnly: true, complete: false, reason: 'OBSERVED_STRUCTURE_ONLY', scanComplete: false, truncated: false,
    examinedTextNodes: 0, examinedElements: 0, headingEvidence: { semantic: 0, knownTitleClass: 0, navigation: 0, exactTextOnly: 0 },
    fields: labels.map((label, index) => ({ labelKind: kinds[index], anchorCount: 0, anchors: [] })), sectionHeadingAnchors: [] };
  const cut = () => { result.truncated = true; result.reason = 'SCAN_LIMIT'; };
  const expired = () => { if (Date.now() >= end) { cut(); return true; } return false; };
  const norm = value => typeof value === 'string' && value.length <= 256 ? value.replace(/\s+/gu, ' ').trim() : '';
  const seen = new WeakSet(), nodeCache = new WeakMap(), paintCache = new WeakMap(), censusCache = new WeakMap(); let structureIndex = 0;
  const touch = element => { if (!element || expired()) return false; if (!seen.has(element)) { if (result.examinedElements >= 800) { cut(); return false; } seen.add(element); result.examinedElements++; } return true; };
  const tagOf = element => { const tag = String(element?.tagName || '').toLowerCase(); return ['div', 'span', 'label', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section', 'article', 'fieldset', 'legend', 'input', 'textarea', 'select', 'button', 'a', 'nav', 'ul', 'li', 'svg', 'path'].includes(tag) ? tag : 'other'; };
  const roleOf = element => { const role = element.getAttribute('role'); return ['combobox', 'textbox', 'searchbox', 'button', 'checkbox', 'radio', 'heading', 'tab', 'group', 'listbox', 'option', 'menu', 'menuitem', 'dialog'].includes(role) ? role : role ? 'other' : 'none'; };
  const classKinds = element => {
    const value = element.getAttribute('class'); if (typeof value !== 'string' || value.length > 2048) return [];
    const tokens = value.split(/\s+/u), out = [];
    for (const token of ['core-select', 'pulse-select', 'core-input', 'pulse-input', 'grid', 'grid-cols-2', 'grid-cols-3', 'bg-neutral-bg2', 'rounded-8', 'text-head-s', 'text-neutral-text3']) if (tokens.includes(token)) out.push(token);
    if (tokens.some(token => /^_formLabel_[a-z0-9_]+$/iu.test(token))) out.push('form-label');
    if (tokens.some(token => /^_form_[a-z0-9_]+$/iu.test(token))) out.push('form-slot');
    if (tokens.some(token => /^_title_[a-z0-9_]+$/iu.test(token))) out.push('form-title');
    return out;
  };
  const painted = element => {
    if (paintCache.has(element)) return paintCache.get(element);
    let visible = true, depth = 0;
    for (let current = element; current; current = current.parentElement) {
      if (++depth > 40 || !touch(current)) { cut(); visible = false; break; }
      const style = getComputedStyle(current);
      if (current.hasAttribute('hidden') || current.getAttribute('aria-hidden') === 'true' || style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) { visible = false; break; }
    }
    const rect = element.getBoundingClientRect(); visible = visible && Number.isFinite(rect.width) && Number.isFinite(rect.height) && rect.width > 0 && rect.height > 0;
    paintCache.set(element, visible); return visible;
  };
  const info = element => {
    if (nodeCache.has(element)) return nodeCache.get(element);
    if (!touch(element)) return null;
    const rect = element.getBoundingClientRect(), box = {};
    for (const key of ['x', 'y', 'width', 'height']) box[key] = Number.isFinite(rect[key]) && Math.abs(rect[key]) <= 1e7 ? rect[key] : null;
    const node = { structureIndex: structureIndex++, tag: tagOf(element), role: roleOf(element), classKinds: classKinds(element), childCount: Math.min(element.children?.length || 0, 10000), painted: painted(element),
      hidden: element.hasAttribute('hidden') || element.getAttribute('aria-hidden') === 'true', hasTabindex: element.hasAttribute('tabindex'), contentEditable: element.isContentEditable === true,
      multiple: element.multiple === true || element.getAttribute('aria-multiselectable') === 'true' || /(?:^|\s)(?:core|pulse)-select-multiple(?:\s|$)/u.test(String(element.getAttribute('class') || '').slice(0, 2048)),
      required: element.required === true || element.getAttribute('aria-required') === 'true', disabled: element.disabled === true || element.getAttribute('aria-disabled') === 'true', readOnly: element.readOnly === true || element.getAttribute('aria-readonly') === 'true', bounds: box };
    nodeCache.set(element, node); return node;
  };
  const anchors = [], headings = [];
  try {
    if (location.protocol !== 'https:' || location.hostname !== 'seller.us.tiktokshopglobalselling.com' || !/^\/product\/create\/?$/u.test(location.pathname) || !document.body || !document.createTreeWalker) { result.reason = 'PAGE_UNVERIFIED'; return result; }
    const walker = document.createTreeWalker(document.body, 4); let text, textComplete = false;
    while (!expired()) {
      text = walker.nextNode(); if (!text) { textComplete = true; break; }
      if (result.examinedTextNodes >= 4000) { cut(); break; } result.examinedTextNodes++;
      const label = norm(text.nodeValue), element = text.parentElement;
      if (!element || !labels.includes(label) && !['商品合规', 'Product compliance'].includes(label)) continue;
      if (element.closest('input,textarea,select,option,script,style,template,noscript,[contenteditable]:not([contenteditable="false"]),[role="combobox"],[role="textbox"],[role="searchbox"],[role="option"],[role="listbox"],[role="menuitem"]') || !painted(element)) continue;
      if (labels.includes(label)) { if (!anchors.some(anchor => anchor.element === element && anchor.label === label)) anchors.push({ element, label }); }
      else if (!headings.some(heading => heading.element === element)) {
        const navigation = !!element.closest('nav,a,button,[role="tab"]'), semanticRoot = element.closest('h1,h2,h3,h4,h5,h6,[role="heading"]'), semantic = !navigation && !!semanticRoot;
        const knownTitleClass = !navigation && !semantic && classKinds(element).some(kind => ['form-title', 'text-head-s'].includes(kind));
        const kind = navigation ? 'navigation' : semantic ? 'semantic' : knownTitleClass ? 'knownTitleClass' : 'exactTextOnly'; headings.push({ element, kind, semanticRoot: semantic ? semanticRoot : null }); result.headingEvidence[kind]++;
      }
    }
    const census = root => {
      if (censusCache.has(root)) return censusCache.get(root);
      const queue = [{ element: root, parentIndex: null, depth: 0 }], tree = [], controls = [], controlRoots = new Set(); let truncated = false;
      while (queue.length && !expired()) {
        if (tree.length >= 80) { truncated = true; break; }
        const current = queue.shift(), metadata = info(current.element); if (!metadata) { truncated = true; break; }
        const index = tree.length; tree.push({ ...metadata, parentIndex: current.parentIndex, depth: current.depth });
        if (current.element.matches('input,textarea,select,[role="combobox"],[role="textbox"],[role="searchbox"],.core-select,.pulse-select')) {
          const owner = current.element.closest('.core-select,.pulse-select') || current.element;
          if (root.contains(owner) && !controlRoots.has(owner)) { controlRoots.add(owner); const value = info(owner); if (value && controls.length < 12) controls.push(value); else if (value) truncated = true; }
        }
        const children = current.element.children || [];
        if (current.depth >= 12 && children.length) truncated = true;
        else for (const child of children) { if (queue.length >= 80) { truncated = true; break; } queue.push({ element: child, parentIndex: index, depth: current.depth + 1 }); }
      }
      if (queue.length || expired()) truncated = true;
      const value = { scanComplete: !truncated, truncated, examinedNodeCount: tree.length, canonicalControlCount: controlRoots.size, controls, structureTree: tree };
      censusCache.set(root, value); return value;
    };
    for (let fieldIndex = 0; fieldIndex < labels.length; fieldIndex++) {
      const field = result.fields[fieldIndex], matches = anchors.filter(anchor => anchor.label === labels[fieldIndex]); field.anchorCount = matches.length;
      if (matches.length > 2) cut();
      for (const anchor of matches.slice(0, 2)) {
        const ancestors = []; let root = anchor.element, depth = 0, rowCaptured = false, interrupted = false;
        for (; root && root !== document.body && root !== document.documentElement && depth < 16 && !expired(); root = root.parentElement, depth++) {
          const metadata = info(root); if (!metadata) { interrupted = true; break; }
          const headingEvidence = { semantic: 0, knownTitleClass: 0, navigation: 0, exactTextOnly: 0 };
          for (const heading of headings) if (root.contains(heading.element)) headingEvidence[heading.kind]++;
          const observed = census(root), exactFieldLabelCount = anchors.filter(item => root.contains(item.element)).length;
          const rowCandidate = !rowCaptured && observed.scanComplete && observed.canonicalControlCount === 1 && exactFieldLabelCount === 1;
          if (rowCandidate) rowCaptured = true;
          ancestors.push({ ...metadata, relativeDepth: depth, exactFieldLabelCount, headingEvidence, ...observed, rowCandidate,
            structureTree: rowCandidate ? observed.structureTree : [] });
          if (['section', 'article', 'fieldset'].includes(tagOf(root)) || depth > 0 && ['form', 'main'].includes(String(root.tagName).toLowerCase())) break;
        }
        const truncated = interrupted || expired() || !!root && root !== document.body && root !== document.documentElement && depth >= 16;
        if (truncated) cut(); field.anchors.push({ ancestors, truncated });
      }
    }
    const semanticHeadings = [...new Set(headings.filter(item => item.kind === 'semantic').map(item => item.semanticRoot))];
    for (const semanticRoot of semanticHeadings.slice(0, 2)) {
      const ancestors = []; let root = semanticRoot, depth = 0, interrupted = false;
      for (; root && root !== document.body && root !== document.documentElement && depth < 10 && !expired(); root = root.parentElement, depth++) {
        const metadata = info(root); if (!metadata) { interrupted = true; break; }
        ancestors.push({ ...metadata, relativeDepth: depth,
          organicAnchorCount: anchors.filter(item => item.label === labels[0] && root.contains(item.element)).length,
          otherDangerousAnchorCount: anchors.filter(item => item.label === labels[1] && root.contains(item.element)).length,
          semanticHeadingCount: semanticHeadings.filter(item => root.contains(item)).length,
          navigationHeadingCount: headings.filter(item => item.kind === 'navigation' && root.contains(item.element)).length });
        if (['section', 'article', 'fieldset'].includes(tagOf(root))) break;
      }
      const truncated = interrupted || expired() || !!root && root !== document.body && root !== document.documentElement && depth >= 10;
      if (truncated) cut(); result.sectionHeadingAnchors.push({ headingKind: 'semantic', ancestors, truncated });
    }
    if (semanticHeadings.length > 2) cut();
    result.scanComplete = textComplete && !result.truncated;
    return result;
  } catch { result.reason = 'OBSERVATION_FAILED'; result.scanComplete = false; result.truncated = true; return result; }
}

export function normalizeComplianceFieldStructureDiagnostic(raw) {
  const count = value => Number.isInteger(value) && value >= 0 && value <= 10000 ? value : null;
  const heading = value => Object.fromEntries(['semantic', 'knownTitleClass', 'navigation', 'exactTextOnly'].map(key => [key, count(value?.[key])]));
  const tags = new Set(['div', 'span', 'label', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section', 'article', 'fieldset', 'legend', 'input', 'textarea', 'select', 'button', 'a', 'nav', 'ul', 'li', 'svg', 'path', 'other']);
  const roles = new Set(['combobox', 'textbox', 'searchbox', 'button', 'checkbox', 'radio', 'heading', 'tab', 'group', 'listbox', 'option', 'menu', 'menuitem', 'dialog', 'other', 'none']);
  const classes = new Set(['core-select', 'pulse-select', 'core-input', 'pulse-input', 'grid', 'grid-cols-2', 'grid-cols-3', 'bg-neutral-bg2', 'rounded-8', 'text-head-s', 'text-neutral-text3', 'form-label', 'form-slot', 'form-title']);
  const node = value => {
    if (!value || !tags.has(value.tag) || !roles.has(value.role)) return null;
    const result = { structureIndex: Number.isSafeInteger(value.structureIndex) && value.structureIndex >= 0 && value.structureIndex < 800 ? value.structureIndex : null,
      tag: value.tag, role: value.role, classKinds: [...new Set(Array.isArray(value.classKinds) ? value.classKinds.filter(item => classes.has(item)).slice(0, 16) : [])], childCount: count(value.childCount), bounds: {} };
    for (const key of ['painted', 'hidden', 'hasTabindex', 'contentEditable', 'multiple', 'required', 'disabled', 'readOnly']) result[key] = typeof value[key] === 'boolean' ? value[key] : null;
    for (const key of ['x', 'y', 'width', 'height']) result.bounds[key] = Number.isFinite(value.bounds?.[key]) && Math.abs(value.bounds[key]) <= 1e7 ? value.bounds[key] : null;
    return result;
  };
  const result = { version: 1, structureOnly: true, complete: false, reason: ['OBSERVED_STRUCTURE_ONLY', 'SCAN_LIMIT', 'PAGE_UNVERIFIED', 'OBSERVATION_FAILED'].includes(raw?.reason) ? raw.reason : 'OBSERVATION_FAILED',
    scanComplete: raw?.scanComplete === true, truncated: raw?.truncated !== false, examinedTextNodes: count(raw?.examinedTextNodes), examinedElements: count(raw?.examinedElements), headingEvidence: heading(raw?.headingEvidence), fields: [], sectionHeadingAnchors: [] };
  for (const labelKind of ['organic-fabric', 'other-dangerous-materials']) {
    const fields = Array.isArray(raw?.fields) ? raw.fields.filter(field => field?.labelKind === labelKind) : [], source = fields.length === 1 ? fields[0] : null;
    const field = { labelKind, anchorCount: count(source?.anchorCount), anchors: [] };
    for (const anchor of (Array.isArray(source?.anchors) ? source.anchors : []).slice(0, 2)) {
      const ancestors = [];
      for (const value of (Array.isArray(anchor?.ancestors) ? anchor.ancestors : []).slice(0, 16)) {
        const metadata = node(value); if (!metadata) continue;
        const structureTree = (Array.isArray(value.structureTree) ? value.structureTree : []).slice(0, 80).flatMap((entry, index) => { const item = node(entry); return item ? [{ ...item, parentIndex: entry.parentIndex === null ? null : Number.isInteger(entry.parentIndex) && entry.parentIndex >= 0 && entry.parentIndex < index ? entry.parentIndex : null, depth: Number.isInteger(entry.depth) && entry.depth >= 0 && entry.depth <= 12 ? entry.depth : null }] : []; });
        ancestors.push({ ...metadata, relativeDepth: Number.isInteger(value.relativeDepth) && value.relativeDepth >= 0 && value.relativeDepth < 16 ? value.relativeDepth : null,
          exactFieldLabelCount: count(value.exactFieldLabelCount), headingEvidence: heading(value.headingEvidence), scanComplete: value.scanComplete === true, truncated: value.truncated !== false, rowCandidate: value.rowCandidate === true,
          examinedNodeCount: count(value.examinedNodeCount), canonicalControlCount: count(value.canonicalControlCount), controls: (Array.isArray(value.controls) ? value.controls : []).slice(0, 12).map(node).filter(Boolean), structureTree });
      }
      field.anchors.push({ ancestors, truncated: anchor?.truncated !== false });
    }
    result.fields.push(field);
  }
  for (const value of (Array.isArray(raw?.sectionHeadingAnchors) ? raw.sectionHeadingAnchors : []).slice(0, 2)) {
    if (value?.headingKind !== 'semantic') continue;
    const ancestors = [];
    for (const entry of (Array.isArray(value.ancestors) ? value.ancestors : []).slice(0, 10)) {
      const metadata = node(entry); if (!metadata) continue;
      ancestors.push({ ...metadata, relativeDepth: Number.isInteger(entry.relativeDepth) && entry.relativeDepth >= 0 && entry.relativeDepth < 10 ? entry.relativeDepth : null,
        organicAnchorCount: count(entry.organicAnchorCount), otherDangerousAnchorCount: count(entry.otherDangerousAnchorCount), semanticHeadingCount: count(entry.semanticHeadingCount), navigationHeadingCount: count(entry.navigationHeadingCount) });
    }
    result.sectionHeadingAnchors.push({ headingKind: 'semantic', ancestors, truncated: value.truncated !== false });
  }
  return result;
}

// Optional, once-per-failure structure inspection. No input values or general body
// text are returned; bounds and time limits keep this out of the normal hot path.
export function visibleSellerStructure(complianceReader) {
  const started = Date.now(), expired = () => Date.now() - started >= 700;
  const complianceFieldStructure = typeof complianceReader === 'function' ? complianceReader(started + 120) : null;
  const norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  const visibleCache = new WeakMap();
  const visible = element => {
    if (!element) return false;
    if (visibleCache.has(element)) return visibleCache.get(element);
    let result = !element.closest('[hidden],[aria-hidden="true"]');
    if (result) {
      const rect = element.getBoundingClientRect(); result = rect.width > 0 && rect.height > 0;
      for (let parent = element; result && parent; parent = parent.parentElement) {
        const style = getComputedStyle(parent); result = style.display !== 'none' && !['hidden', 'collapse'].includes(style.visibility) && Number(style.opacity) !== 0;
      }
    }
    visibleCache.set(element, result); return result;
  };
  const nodeInfo = element => ({ tag: element.tagName?.toLowerCase() || '', role: element.getAttribute?.('role') || '', className: String(element.getAttribute?.('class') || element.className || '').slice(0, 180) });
  const fixed = /^(?:\*\s*)?(?:商品名称|产品名称|类目|商品类目|产品类目|商品分类|品牌|属性|商品属性|关键属性|可选属性|选填|Product name|Product title|Category|Product category|Brand|Attributes|Key attributes|Optional attributes)\s*[:：]?$/iu;
  const publicLabelAnchors = [], visibleSelectStructure = [], controlStructure = [], categoryMenuStructure = [], loadingStructure = [], attributeControlStructure = [], attributeGroupStructure = [], guidanceStructure = [], rawCategoryAnchors = [];
  const rawMenuNode = element => {
    const rect = element.getBoundingClientRect(), style = getComputedStyle(element), nearestAria = element.closest('[aria-hidden="true"]'), nearestHidden = element.closest('[hidden]');
    const positiveChildRectCount = [...(element.children || [])].slice(0, 200).filter(child => { const box = child.getBoundingClientRect(); return box.width > 0 && box.height > 0; }).length;
    const accepted = visible(element), rejectReason = accepted ? '' : nearestHidden ? 'hidden-attribute' : nearestAria ? 'aria-hidden' : !(rect.width > 0 && rect.height > 0) ? 'zero-rectangle' : style.display === 'none' ? 'display-none' : ['hidden', 'collapse'].includes(style.visibility) ? 'visibility-hidden' : Number(style.opacity) === 0 ? 'opacity-zero' : 'ancestor-style';
    return { ...nodeInfo(element), bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }, display: style.display, visibility: style.visibility, opacity: style.opacity,
      ariaHidden: element.getAttribute('aria-hidden') || '', nearestAriaHidden: !!nearestAria, hidden: element.hasAttribute?.('hidden') === true, nearestHidden: !!nearestHidden, positiveChildRectCount, visibleAccepted: accepted, rejectReason };
  };
  const corePopups = [...document.querySelectorAll('.core-cascader-popup')], coreColumns = [...document.querySelectorAll('.core-cascader-list-column')], menuItems = [...document.querySelectorAll('[role="menuitem"]')], broadMenus = [...document.querySelectorAll('[class*="cascader"],[class*="Cascader"],[role="menu"],[role="menuitem"]')];
  const rawMenuCensus = { counts: { corePopup: corePopups.length, coreColumn: coreColumns.length, menuitem: menuItems.length, broad: broadMenus.length },
    candidates: [...new Set([...corePopups, ...coreColumns, ...broadMenus])].slice(0, 20).map(rawMenuNode) };
  const frames = [...document.querySelectorAll('iframe')], frameStructure = frames.slice(0, 20).map(element => {
    let officialHost = false, sameOrigin = false;
    try { const value = element.getAttribute('src'); if (value) { const source = new URL(value, location.href); officialHost = source.protocol === 'https:' && ['seller.us.tiktokshopglobalselling.com', 'seller-us.tiktok.com', 'seller.tiktokglobalshop.com', 'seller.tiktokshop.com'].includes(source.hostname); sameOrigin = source.origin === location.origin; } } catch { /* Only the booleans are diagnostic output. */ }
    return { ...nodeInfo(element), officialHost, sameOrigin };
  });
  const shadowRootHosts = []; let examinedElements = 0, shadowRootHostCount = 0, shadowScanTruncated = false;
  if (document.body && document.createTreeWalker) {
    const walker = document.createTreeWalker(document.body, 1); let element;
    while ((element = walker.nextNode())) {
      if (++examinedElements > 4000 || expired()) { shadowScanTruncated = true; break; }
      if (element.shadowRoot) { shadowRootHostCount++; if (shadowRootHosts.length < 20) shadowRootHosts.push(nodeInfo(element)); }
    }
  }
  const surfaceCensus = { iframeCount: frames.length, frameStructure, shadowRootHostCount, shadowRootHosts, examinedElements: Math.min(examinedElements, 4000), shadowScanTruncated };
  let examined = 0;
  if (document.body) {
    const walker = document.createTreeWalker(document.body, 4); let textNode;
    while (!expired() && examined++ < 4000 && (textNode = walker.nextNode())) {
      if (textNode.parentElement?.closest('input,textarea,[contenteditable="true"]')) continue;
      const label = norm(textNode.nodeValue);
      if (['所有类目', '家居用品'].includes(label) && !textNode.parentElement?.closest('script,style,template,noscript') && rawCategoryAnchors.length < 20) {
        const ancestors = []; for (let element = textNode.parentElement, depth = 0; element && depth < 6; element = element.parentElement, depth++) ancestors.push(rawMenuNode(element));
        rawCategoryAnchors.push({ label, ancestors });
      }
      if (!fixed.test(label) || !visible(textNode.parentElement)) continue;
      const ancestors = [];
      for (let element = textNode.parentElement, depth = 0; element && depth < 6 && !expired(); element = element.parentElement, depth++) {
        const descendantControls = [...element.querySelectorAll('input,select,[role="combobox"],.core-select,.pulse-select,[class*="cascader"],[class*="Cascader"]')].slice(0, 12).filter(visible).map(nodeInfo);
        ancestors.push({ ...nodeInfo(element), descendantControls });
      }
      publicLabelAnchors.push({ label, ancestors }); if (publicLabelAnchors.length >= 60) break;
    }
  }
  for (const element of [...document.querySelectorAll('[class*="core-select"],[class*="pulse-select"],[class*="cascader"],[class*="Cascader"]')].slice(0, 80)) {
    if (expired()) break; if (visible(element)) visibleSelectStructure.push(nodeInfo(element));
  }
  for (const element of [...document.querySelectorAll('[class*="cascader"],[class*="Cascader"],[role="treeitem"],[role="menuitem"],[role="option"]')].slice(0, 180)) {
    if (expired()) break;
    if (!visible(element) || element.closest('input,textarea,[contenteditable="true"]') || element.querySelector('input,textarea,[contenteditable="true"]')) continue;
    const label = norm(element.innerText);
    if (label && label.length <= 160) categoryMenuStructure.push({ ...nodeInfo(element), label });
  }
  for (const element of [...document.querySelectorAll('[aria-busy="true"],[role="progressbar"],[class*="loading"],[class*="Loading"],[class*="spin"],[class*="Spin"]')].slice(0, 80)) {
    if (expired()) break; if (!visible(element)) continue;
    const rect = element.getBoundingClientRect();
    loadingStructure.push({ ...nodeInfo(element), bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } });
  }
  for (const card of [...document.querySelectorAll('div.bg-neutral-bg2.rounded-8')].slice(0, 20)) {
    if (expired()) break; if (!visible(card)) continue;
    const heading = [...card.querySelectorAll('p.text-head-s.text-neutral-text3')].filter(visible).filter(item => item.closest('div.bg-neutral-bg2.rounded-8') === card).map(item => norm(item.innerText)).find(value => /^(关键属性|可选属性|选填|Key attributes|Optional attributes)$/iu.test(value));
    if (!heading) continue;
    const kind = /可选|选填|Optional/iu.test(heading) ? '可选属性' : '关键属性';
    const grids = [...card.querySelectorAll('div.relative.grid.grid-cols-2,div.relative.grid.grid-cols-3')].slice(0, 10);
    attributeGroupStructure.push({ kind, heading, ...nodeInfo(card), grids: grids.map(grid => {
      const rows = [...grid.children];
      return { ...nodeInfo(grid), directChildCount: rows.length, truncated: rows.length > 100, rows: rows.slice(0, 100).map(row => {
        const queue = [{ element: row, parentIndex: null, depth: 0 }], structureTree = [];
        while (queue.length && structureTree.length < 35) {
          const current = queue.shift(), index = structureTree.length, children = [...(current.element.children || [])];
          structureTree.push({ ...nodeInfo(current.element), parentIndex: current.parentIndex, depth: current.depth, childCount: children.length });
          if (current.depth < 5) for (const child of children) queue.push({ element: child, parentIndex: index, depth: current.depth + 1 });
        }
        return { ...nodeInfo(row), childCount: row.children.length, knownSelectCount: row.querySelectorAll('.core-select,.pulse-select').length,
          nativeControlCount: row.querySelectorAll('input,textarea,select,[contenteditable="true"]').length, formSlotCount: row.querySelectorAll('span[class*="_form_"]').length, structureTree, treeTruncated: queue.length > 0 };
      }) };
    }) });
    const roots = [...new Set([...card.querySelectorAll('input,textarea,select,[role="combobox"],[role="textbox"],[contenteditable="true"],.core-select,.pulse-select')].map(element => element.closest('.core-select,.pulse-select') || element))].filter(visible);
    for (const element of roots.slice(0, 80)) {
      if (expired()) break;
      const ancestors = [];
      for (let parent = element.parentElement, depth = 0; parent && parent !== card && depth < 6; parent = parent.parentElement, depth++) ancestors.push(nodeInfo(parent));
      attributeControlStructure.push({ kind, ...nodeInfo(element), ancestors });
    }
  }
  for (const modal of [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],[class*="modal"],[class*="Modal"]')].slice(0, 80)) {
    if (expired() || guidanceStructure.length >= 10) break;
    if (!visible(modal) || !/上传图片即可生成草稿|Upload images? to (?:generate|create) (?:a )?draft/iu.test(norm(modal.innerText))) continue;
    const bounds = element => { const rect = element.getBoundingClientRect(); return { x: rect.x, y: rect.y, width: rect.width, height: rect.height }; };
    const closeCandidates = [...modal.querySelectorAll('button,[role="button"],[class*="close"],[class*="Close"]')].slice(0, 60).filter(visible).filter(element => /close|Close/u.test(String(element.className || '')) || /^(关闭|取消|Close|Cancel)$/iu.test(norm(element.getAttribute('aria-label') || element.getAttribute('title') || element.innerText)))
      .map(element => ({ ...nodeInfo(element), bounds: bounds(element) }));
    const cornerCandidates = [];
    const cornerNode = element => ({ ...nodeInfo(element), ariaLabel: norm(element.getAttribute('aria-label')).slice(0, 180), title: norm(element.getAttribute('title')).slice(0, 180),
      ariaHidden: element.getAttribute('aria-hidden') || '', dataIcon: norm(element.getAttribute('data-icon')).slice(0, 180), cursor: getComputedStyle(element).cursor, bounds: bounds(element) });
    const renderedDecoration = element => {
      if (element.closest('[hidden]')) return false;
      const rect = element.getBoundingClientRect(); if (!(rect.width > 0 && rect.height > 0)) return false;
      for (let parent = element; parent; parent = parent.parentElement) { const style = getComputedStyle(parent); if (style.display === 'none' || ['hidden', 'collapse'].includes(style.visibility) || Number(style.opacity) === 0) return false; }
      return true;
    };
    const allGuideNodes = [...modal.querySelectorAll('*')];
    const guideNodes = [...new Set([...modal.querySelectorAll('svg,path,use,[data-icon],button,[role="button"],[class*="close"],[class*="Close"]'), ...allGuideNodes])].slice(0, 1800);
    const filterCounts = { examined: 0, notRendered: 0, input: 0, tooLarge: 0, accepted: 0 };
    for (const element of guideNodes) {
      if (expired() || cornerCandidates.length >= 60) break;
      filterCounts.examined++;
      if (!renderedDecoration(element)) { filterCounts.notRendered++; continue; }
      if (element.closest('input,textarea,[contenteditable="true"]')) { filterCounts.input++; continue; }
      const rect = element.getBoundingClientRect();
      if (rect.width > 100 || rect.height > 100) { filterCounts.tooLarge++; continue; }
      const parents = [];
      for (let parent = element.parentElement, depth = 0; parent && parent !== modal && depth < 3; parent = parent.parentElement, depth++) parents.push(cornerNode(parent));
      cornerCandidates.push({ ...cornerNode(element), parents });
      filterCounts.accepted++;
    }
    const structureTree = [], queue = [{ element: modal, parentIndex: null, depth: 0 }];
    while (queue.length && structureTree.length < 300 && !expired()) {
      const { element, parentIndex, depth } = queue.shift(), style = getComputedStyle(element), index = structureTree.length;
      const children = [...(element.children || [])];
      structureTree.push({ ...nodeInfo(element), parentIndex, depth, childCount: children.length, bounds: bounds(element),
        display: style.display, visibility: style.visibility, opacity: style.opacity, hidden: element.hasAttribute?.('hidden') === true, ariaHidden: element.getAttribute('aria-hidden') || '',
        shadowRootPresent: !!element.shadowRoot, iframePresent: element.tagName?.toLowerCase() === 'iframe', dataIcon: element.getAttribute('data-icon') || '' });
      if (depth < 12) for (const child of children) queue.push({ element: child, parentIndex: index, depth: depth + 1 });
    }
    guidanceStructure.push({ ...nodeInfo(modal), bounds: bounds(modal), closeCandidates, cornerCandidates, descendantNodeCount: allGuideNodes.length,
      filterCounts, structureTree, treeTruncated: queue.length > 0 || expired() });
  }
  for (const element of [...document.querySelectorAll('input,textarea,select,[role="combobox"],[contenteditable="true"],.core-select,.pulse-select')].slice(0, 80)) {
    if (expired()) break; if (!visible(element) || element.getAttribute('type') === 'password') continue;
    const formLabels = [];
    for (let parent = element.parentElement, depth = 0; parent && depth < 6 && !expired(); parent = parent.parentElement, depth++) {
      for (const candidate of [...parent.querySelectorAll('label,[class*="label"],[class*="Label"]')].slice(0, 8)) {
        if (expired()) break;
        if (candidate.closest('input,textarea,[contenteditable="true"]') || candidate.querySelector?.('input,textarea,[contenteditable="true"]')) continue;
        const label = norm(candidate.textContent || candidate.innerText);
        if (fixed.test(label) && visible(candidate) && !formLabels.includes(label)) formLabels.push(label);
        if (formLabels.length >= 4) break;
      }
      if (formLabels.length >= 4) break;
    }
    controlStructure.push({ ...nodeInfo(element), placeholder: norm(element.getAttribute('placeholder')).slice(0, 180), formLabels });
  }
  return { guidanceProbeVersion: 6, rawMenuCensus, rawCategoryAnchors, surfaceCensus, publicLabelAnchors, visibleSelectStructure, controlStructure, categoryMenuStructure, loadingStructure, attributeControlStructure, attributeGroupStructure, guidanceStructure, structureMetrics: { elapsedMs: Date.now() - started, examinedTextNodes: Math.min(examined, 4000), truncated: expired() || examined > 4000 }, ...(complianceFieldStructure ? { complianceFieldStructure } : {}) };
}

export function visibleKnownGuideClose(selector, expected = {}) {
  if (location.protocol !== 'https:' || !['seller.us.tiktokshopglobalselling.com', 'seller-us.tiktok.com', 'seller.tiktokglobalshop.com', 'seller.tiktokshop.com'].includes(location.hostname)) throw new Error('POD_GUIDE_CLOSE_STALE');
  const element = document.querySelector(selector), norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  if (!element || element.tagName.toLowerCase() !== expected.tag || String(element.className || '').slice(0, 180) !== String(expected.className || '')) throw new Error('POD_GUIDE_CLOSE_STALE');
  const rendered = current => {
    const box = current.getBoundingClientRect(); if (!(box.width > 0 && box.height > 0) || current.isConnected === false || current.closest('[hidden],[inert]')) return false;
    for (let parent = current; parent; parent = parent.parentElement) { const css = getComputedStyle(parent); if (css.display === 'none' || css.visibility !== 'visible' || Number(css.opacity) === 0) return false; }
    return true;
  };
  const safeClose = current => {
    const label = norm(current.getAttribute('aria-label') || current.getAttribute('title') || current.innerText);
    return !current.disabled && current.getAttribute('aria-disabled') !== 'true' && !(current.form && ['submit', 'reset'].includes(current.type || 'submit'))
      && /modal-close|ModalClose/u.test(String(current.className || '')) && !/生成|发布|提交|Generate|Publish|Submit/iu.test(label) && rendered(current);
  };
  const rect = element.getBoundingClientRect(), label = norm(element.getAttribute('aria-label') || element.getAttribute('title') || element.innerText);
  const closeIntent = /modal-close|ModalClose/u.test(String(element.className || '')) || /^(关闭|取消|暂不|跳过|Close|Cancel|Not now|Maybe later|Skip)$/iu.test(label);
  if (!closeIntent || /生成|发布|提交|Generate|Publish|Submit/iu.test(label) || !(rect.width > 0 && rect.height > 0)) throw new Error('POD_GUIDE_CLOSE_STALE');
  let owner;
  for (let parent = element.parentElement, depth = 0; parent && parent !== document.body && parent !== document.documentElement && depth < 8; parent = parent.parentElement, depth++) {
    if (parent.matches('[role="dialog"],[aria-modal="true"],[class*="modal"],[class*="Modal"]') && /上传图片即可生成草稿|Upload images? to (?:generate|create) (?:a )?draft/iu.test(norm(parent.innerText))) { owner = parent; break; }
  }
  if (!owner || !safeClose(element)) throw new Error('POD_GUIDE_CLOSE_STALE');
  const modals = [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],.core-modal-wrapper,.core-modal,.arco-modal-wrapper,.ant-modal-wrap')].filter(rendered);
  if (modals.some(current => (current.getAttribute('role') === 'dialog' || current.getAttribute('aria-modal') === 'true') && !/上传图片即可生成草稿|Upload images? to (?:generate|create) (?:a )?draft/iu.test(norm(current.innerText)))) throw new Error('POD_GUIDE_CLOSE_STALE');
  const outer = modals.filter(current => !modals.some(other => other !== current && other.contains(current)));
  if (outer.length !== 1 || !outer[0].contains(element) || !/上传图片即可生成草稿|Upload images? to (?:generate|create) (?:a )?draft/iu.test(norm(outer[0].innerText))) throw new Error('POD_GUIDE_CLOSE_STALE');
  const closes = [...outer[0].querySelectorAll('[class*="modal-close"],[class*="ModalClose"]')].filter(safeClose);
  const clusters = closes.filter(current => !closes.some(other => other !== current && other.contains(current)));
  if (clusters.length !== 1 || clusters[0] !== element && !clusters[0].contains(element) && !element.contains(clusters[0])) throw new Error('POD_GUIDE_CLOSE_STALE');
  const safeClass = value => { const text = String(value || '').slice(0, 180); return /token|secret|password|cookie|https?:|wss?:|@|\b\d{7,}\b/iu.test(text) ? '' : text; };
  return { verified: true, target: { tag: element.tagName.toLowerCase(), className: safeClass(element.className), bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } },
    guideScope: { tag: owner.tagName.toLowerCase(), className: safeClass(owner.className) } };
}

export function clickKnownGuideClose(selector, expected, verify = visibleKnownGuideClose) {
  const check = verify(selector, expected), element = document.querySelector(selector);
  // The observed image-to-draft X can first open its own hide-method prompt.
  // Only its reversible "temporarily close" action is allowed here; the
  // seven-day preference and all generation / submission actions stay excluded.
  const norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  const rendered = current => {
    if (!current || current.isConnected === false || current.closest('[hidden],[inert]')) return false;
    const box = current.getBoundingClientRect(); if (!(box.width > 0 && box.height > 0)) return false;
    for (let parent = current; parent; parent = parent.parentElement) { const style = getComputedStyle(parent); if (style.display === 'none' || style.visibility !== 'visible' || Number(style.opacity) === 0) return false; }
    return true;
  };
  // The observed prompt is a sibling portal of .core-modal-focus-lock, inside
  // this same verified Core dialog. Searching the focus lock misses it entirely.
  const scope = element.closest('.core-modal[role="dialog"]');
  const mountedPopovers = scope ? [...scope.querySelectorAll('.core-popover-content')] : [], popovers = mountedPopovers.filter(rendered);
  if (!popovers.length && mountedPopovers.length) {
    // Real captures show the known prompt mounted under an opacity-zero trigger
    // until a read-only screenshot advances its paint. Do not toggle X again.
    const popup = mountedPopovers[0];
    if (mountedPopovers.length !== 1 || popup.tagName !== 'DIV' || popup.getAttribute('role') !== 'tooltip'
      || popup.querySelectorAll('[class*="_closePromptContent_"]').length !== 1 || !scope.contains(popup)) throw new Error('POD_GUIDE_CLOSE_STALE');
    return { ...check, action: 'prompt-pending' };
  }
  if (popovers.length) {
    if (popovers.length !== 1) throw new Error('POD_GUIDE_CLOSE_STALE');
    const popup = popovers[0], contents = [...popup.querySelectorAll('[class*="_closePromptContent_"]')].filter(rendered);
    if (popup.tagName !== 'DIV' || popup.getAttribute('role') !== 'tooltip' || contents.length !== 1 || !scope.contains(popup)) throw new Error('POD_GUIDE_CLOSE_STALE');
    const content = contents[0], titles = [...content.querySelectorAll('[class*="_closePromptTitle_"]')].filter(rendered), actions = [...content.querySelectorAll('[class*="_closePromptActions_"]')].filter(rendered);
    if (content.tagName !== 'DIV' || content.children.length !== 2 || titles.length !== 1 || actions.length !== 1
      || !['隐藏此发品方式?', '隐藏此发品方式？'].includes(norm(titles[0].innerText)) || !content.contains(titles[0]) || !content.contains(actions[0])) throw new Error('POD_GUIDE_CLOSE_STALE');
    const buttons = [...actions[0].querySelectorAll('button')].filter(rendered), closes = buttons.filter(button => norm(button.innerText) === '暂时关闭');
    if (buttons.length !== 2 || closes.length !== 1 || !buttons.some(button => /^隐藏\s*7\s*天$/u.test(norm(button.innerText)))) throw new Error('POD_GUIDE_CLOSE_STALE');
    const close = closes[0], expectedClass = 'core-btn core-btn-secondary core-btn-size-small core-btn-shape-square pulse-button pulse-button-size-small';
    if (close.tagName !== 'BUTTON' || norm(close.className) !== expectedClass || close.disabled || close.getAttribute('aria-disabled') === 'true'
      || close.form && ['submit', 'reset'].includes(close.type || 'submit') || !close.closest('[class*="_closePromptActions_"]') || !rendered(close)) throw new Error('POD_GUIDE_CLOSE_STALE');
    close.click();
    return { ...check, action: 'temporary-close' };
  }
  element.click();
  return { ...check, action: 'guide-x' };
}

export function visiblePointerTarget(selector, expected = {}) {
  const element = document.querySelector(selector); if (!element) return { target: null, tagMatched: false, textMatched: false };
  const rect = element.getBoundingClientRect(), text = String(element.innerText || '').replace(/\s+/gu, ' ').trim(), className = String(element.className || '').slice(0, 180);
  return { target: { tag: element.tagName.toLowerCase(), className: /token|secret|password|cookie|https?:|wss?:|@|\b\d{7,}\b/iu.test(className) ? '' : className,
    bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } }, tagMatched: element.tagName.toLowerCase() === expected.tag,
    textMatched: !expected.text || text === expected.text,
    instanceMatched: !expected.instanceId || globalThis[Symbol.for('pod-observed-seller-controls-v1')]?.nodes?.get(element) === expected.instanceId };
}

// Recovery never prefers an old selector or a row position. A replacement must
// be the sole semantic match in the same document, shop and category scope.
export function findRecoveredSellerControl(before, after, observed, { confirmAfterAction = false } = {}) {
  const norm = value => String(value ?? '').replace(/\s+/gu, ' ').trim();
  const stale = () => Object.assign(new Error('页面控件无法在原店铺与类目中重新唯一确认。'), { code: 'SELLER_CONTROL_STALE', dispatchState: 'not_dispatched' });
  const safe = state => state?.securityChallenge?.detected === false && state.busy === false && state.categoryBusy === false
    && state.shopIdentityMenuVisible === false && Array.isArray(state.guidanceDialogs) && !state.guidanceDialogs.length
    && state.modalCount === 0 && !(state.unknownModalCount > 0) && !(state.unknownModals || []).length;
  if (!safe(before) || !safe(after) || !norm(before.documentGeneration) || before.documentGeneration !== after.documentGeneration || before.url !== after.url) throw stale();
  assertSellerUrl(after.url);
  if (!norm(before.identity?.shopName) || !norm(before.identity?.region)
    || ['shopName', 'region', 'shopId', 'idKind'].some(key => norm(before.identity?.[key]) !== norm(after.identity?.[key]))) throw stale();
  const categories = state => (state.controls || []).filter(item => /^(商品类目|产品类目|类目|Product category|Category)$/iu.test(norm(item.label)))
    .map(item => [item.label, item.value, item.text, item.selectedValues || []]);
  if (categories(before).length !== 1 || JSON.stringify(categories(before)) !== JSON.stringify(categories(after))) throw stale();
  const option = ['option', 'menuitem', 'treeitem'].includes(observed.role);
  const field = ['input', 'textarea', 'select'].includes(observed.tag) || ['combobox', 'textbox'].includes(observed.role);
  if (!option && (!field || !norm(observed.label)) || observed.disabled || observed.readOnly || observed.type === 'file' || observed.tag === 'button') throw stale();
  // A unique Price/Stock/SKU label is not a SKU tuple. Table cells require the
  // RPA matrix's exact dimension/value proof; generic semantic recovery cannot
  // safely follow a reordered or virtualized row, even when only one is visible.
  const tableRefs = state => new Set((state.tables || []).flatMap(table => (table.rows || []).flatMap(row => (row.cells || []).flatMap(cell => cell.controls || []))));
  if (tableRefs(before).has(observed.ref)) throw stale();
  // Only an acknowledged field mutation may request post-action confirmation.
  // The caller must still verify its exact expected value on the returned node.
  if (confirmAfterAction && option) throw stale();
  const keys = ['tag', 'role', 'type', 'label', 'section', 'name', 'multiple', 'required', 'readOnly', 'categoryLevel', ...(!confirmAfterAction ? ['text','value','checked'] : [])];
  let candidates = (after.controls || []).filter(item => !item.disabled && !item.readOnly
    && keys.every(key => (item[key] ?? '') === (observed[key] ?? ''))
    && (confirmAfterAction || JSON.stringify(item.selectedValues || []) === JSON.stringify(observed.selectedValues || [])));
  if (candidates.some(item => tableRefs(after).has(item.ref))) throw stale();
  if (option) {
    const membership = (state, item) => [...(state.optionLists || []), ...(state.categoryColumns || [])].filter(list => list.optionRefs?.includes(item.ref));
    const owners = membership(before, observed);
    if (owners.length !== 1 || owners[0].busy !== false || !owners[0].popupInstanceId) throw stale();
    candidates = candidates.filter(item => {
      const current = membership(after, item);
      return current.length === 1 && current[0].busy === false && current[0].popupInstanceId === owners[0].popupInstanceId
        && (current[0].columnInstanceId || '') === (owners[0].columnInstanceId || '');
    });
  } else if ((before.optionLists || []).length || (after.optionLists || []).length || (before.categoryColumns || []).length || (after.categoryColumns || []).length) throw stale();
  if (candidates.length > 1) throw Object.assign(new Error('页面出现多个同名同类型控件，未执行点击。'), { code: 'SELLER_CONTROL_AMBIGUOUS', dispatchState: 'not_dispatched' });
  if (candidates.length !== 1 || !candidates[0].instanceId) throw stale();
  return candidates[0];
}

export function clickObservedShopMenu(selector, expected = {}) {
  const element = document.querySelector(selector), norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  if (!element || element.tagName.toLowerCase() !== expected.tag || !expected.text || /^(?:提交审核|生成发品|发布|Publish|Submit for review|Generate)$/iu.test(expected.text) || norm(element.innerText) !== expected.text || !/(?:^|\s)ub-triggerContent-[\w-]+(?:\s|$)/u.test(String(element.className || ''))) throw new Error('POD_SHOP_TRIGGER_STALE');
  const rect = element.getBoundingClientRect(), viewport = document.documentElement.clientWidth || globalThis.innerWidth || 0;
  if (!(rect.width > 0 && rect.width <= 480 && rect.height > 0 && rect.height <= 130 && rect.x >= viewport * .55 && rect.x + rect.width <= viewport + 2 && rect.y >= 0 && rect.y <= 130)) throw new Error('POD_SHOP_TRIGGER_STALE');
  for (let parent = element; parent; parent = parent.parentElement) { const style = getComputedStyle(parent); if (style.display === 'none' || style.visibility !== 'visible' || Number(style.opacity) === 0) throw new Error('POD_SHOP_TRIGGER_STALE'); }
  const hit = document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2);
  if (!hit || hit !== element && !element.contains(hit)) throw new Error('POD_CONTROL_OBSCURED');
  element.click();
  return { tag: element.tagName.toLowerCase(), className: String(element.className || '').slice(0, 180), bounds: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } };
}

export function clickReadSellerControl(selector, expected = {}) {
  if (location.protocol !== 'https:' || !['seller.us.tiktokshopglobalselling.com', 'seller-us.tiktok.com', 'seller.tiktokglobalshop.com', 'seller.tiktokshop.com'].includes(location.hostname)) throw new Error('POD_READ_CONTROL_STALE');
  const element = document.querySelector(selector), norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  if (!element || element.tagName.toLowerCase() !== expected.tag || expected.text && norm(element.innerText) !== expected.text) throw new Error('POD_READ_CONTROL_STALE');
  if (expected.kind === 'category-option') {
    const rendered = current => {
      const box = current.getBoundingClientRect(); if (!(box.width > 0 && box.height > 0) || current.isConnected === false || current.closest('[hidden]')) return false;
      for (let parent = current; parent; parent = parent.parentElement) { const css = getComputedStyle(parent); if (css.display === 'none' || css.visibility !== 'visible' || Number(css.opacity) === 0) return false; }
      return true;
    };
    if (!expected.text || !Number.isInteger(expected.categoryLevel) || expected.categoryLevel < 0 || !element.matches('li.core-cascader-list-item') || !['menuitem', 'treeitem', 'option'].includes(element.getAttribute('role')) || !rendered(element)) throw new Error('POD_READ_CONTROL_STALE');
    const modals = [...document.querySelectorAll('[role="dialog"],[aria-modal="true"],.core-modal-wrapper,.core-modal,.arco-modal-wrapper,.ant-modal-wrap')].filter(rendered);
    if (modals.length) throw new Error('POD_READ_MODAL_BLOCKED');
    const roots = [...document.querySelectorAll('.core-cascader-popup')].filter(rendered), root = roots[0];
    if (roots.length !== 1 || element.closest('.core-cascader-popup') !== root) throw new Error('POD_READ_CONTROL_STALE');
    const columns = [...root.querySelectorAll('.core-cascader-list-column')].filter(rendered), column = element.closest('.core-cascader-list-column');
    if (columns[expected.categoryLevel] !== column) throw new Error('POD_READ_CONTROL_STALE');
    const enabled = current => !current.disabled && current.getAttribute('aria-disabled') !== 'true' && !/(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(String(current.className || ''));
    const matches = [...column.querySelectorAll('li.core-cascader-list-item')].filter(current => rendered(current) && norm(current.innerText) === expected.text);
    if (matches.length !== 1 || matches[0] !== element || !enabled(element)) throw new Error('POD_READ_CONTROL_STALE');
    const labels = [...element.querySelectorAll('.core-cascader-list-item-label')].filter(current => rendered(current) && norm(current.innerText) === expected.text);
    if (labels.length !== 1 || labels[0].querySelector('button,a,input,textarea,select,[role="button"]')) throw new Error('POD_READ_CONTROL_STALE');
    const label = labels[0], leaves = [...label.querySelectorAll('div,span')].filter(current => rendered(current) && norm(current.innerText) === expected.text && ![...current.querySelectorAll('div,span')].some(child => rendered(child) && norm(child.innerText) === expected.text));
    if (leaves.length > 1) throw new Error('POD_READ_CONTROL_STALE');
    const target = leaves[0] || label, bounds = target.getBoundingClientRect(); target.click();
    return { kind: expected.kind, tag: element.tagName.toLowerCase(), semanticCategoryOption: true, categoryLevel: expected.categoryLevel, defaultActionGuarded: false,
      activationTarget: { tag: target.tagName.toLowerCase(), className: String(target.getAttribute?.('class') || target.className || '').slice(0, 180), bounds: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height } } };
  }
  let allowed = false;
  if (expected.kind === 'category-trigger') allowed = element.tagName === 'DIV' && element.matches('.p-cascader-select-view');
  if (expected.kind === 'attribute-trigger') {
    let kind = '';
    for (let card = element.closest('div.bg-neutral-bg2.rounded-8'); card; card = card.parentElement?.closest('div.bg-neutral-bg2.rounded-8')) {
      const titles = [...card.querySelectorAll('p.text-head-s.text-neutral-text3')].filter(item => item.closest('div.bg-neutral-bg2.rounded-8') === card).map(item => norm(item.innerText)).filter(text => /^(关键属性|可选属性|选填|Key attributes|Optional attributes)$/iu.test(text));
      if (titles.length === 1) { kind = /可选|选填|Optional/iu.test(titles[0]) ? '可选属性' : '关键属性'; break; }
    }
    allowed = element.tagName === 'DIV' && element.matches('.core-select,.pulse-select') && kind === expected.section && ['关键属性', '可选属性'].includes(expected.section);
  }
  if (expected.kind === 'attribute-option') allowed = element.matches('[role="option"],[class*="select-option"]') && !!element.closest('[role="listbox"],[class*="select-popup"],[class*="select-dropdown"]');
  if (expected.kind === 'show-optional') allowed = element.tagName === 'BUTTON' && norm(element.innerText) === '显示选填属性';
  if (!allowed || element.disabled || element.getAttribute('aria-disabled') === 'true') throw new Error('POD_READ_CONTROL_STALE');
  const rect = element.getBoundingClientRect(), hit = document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2);
  if (!(rect.width > 0 && rect.height > 0) || !hit || hit !== element && !element.contains(hit)) throw new Error('POD_CONTROL_OBSCURED');
  for (let parent = element; parent; parent = parent.parentElement) { const style = getComputedStyle(parent); if (style.display === 'none' || style.visibility !== 'visible' || Number(style.opacity) === 0) throw new Error('POD_READ_CONTROL_STALE'); }
  let target = element;
  const bounds = target.getBoundingClientRect(), defaultActionGuarded = expected.kind === 'show-optional' && !!element.form && ['submit', 'reset'].includes(element.type || element.getAttribute('type') || 'submit');
  const preventDefault = event => event.preventDefault();
  if (defaultActionGuarded) element.addEventListener('click', preventDefault, { capture: true });
  try { target.click(); } finally { if (defaultActionGuarded) element.removeEventListener('click', preventDefault, { capture: true }); }
  return { kind: expected.kind, tag: element.tagName.toLowerCase(), defaultActionGuarded, activationTarget: { tag: target.tagName.toLowerCase(), className: String(target.getAttribute?.('class') || target.className || '').slice(0, 180), bounds: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height } } };
}

export function visibleReadExpanderButton(selector) {
  const element = document.querySelector(selector), norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  if (!element || element.tagName !== 'BUTTON' || norm(element.innerText) !== '显示选填属性') throw new Error('POD_READ_CONTROL_STALE');
  const attribute = element.getAttribute('type');
  return { type: ['button', 'submit', 'reset'].includes(element.type) ? element.type : 'unknown', typeAttribute: attribute === null ? 'absent' : ['button', 'submit', 'reset'].includes(attribute) ? attribute : 'other', hasForm: !!element.form };
}

export async function visibleControlPoint(selector, diagnosticOnly = false, visibleIntersection = false) {
  const element = document.querySelector(selector); if (!element && !diagnosticOnly) throw new Error('POD_CONTROL_STALE');
  const read = () => {
    const rect = element?.getBoundingClientRect(); let point = rect ? { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 } : null;
    let hit = point ? document.elementFromPoint(point.x, point.y) : null;
    const viewport = { width: document.documentElement?.clientWidth || globalThis.innerWidth || 0, height: document.documentElement?.clientHeight || globalThis.innerHeight || 0 };
    let contained = !!element && !!hit && (hit === element || element.contains(hit));
    if (visibleIntersection && !contained && rect && viewport.width > 0 && viewport.height > 0) {
      const left = Math.max(2, rect.x + 2), right = Math.min(viewport.width - 2, rect.x + rect.width - 2), top = Math.max(2, rect.y + 2), bottom = Math.min(viewport.height - 2, rect.y + rect.height - 2);
      if (right > left && bottom > top) for (const [fx, fy] of [[.25, .5], [.75, .5], [.5, .25], [.5, .75]]) {
        const candidate = { x: left + (right - left) * fx, y: top + (bottom - top) * fy }, candidateHit = document.elementFromPoint(candidate.x, candidate.y);
        if (candidateHit && (candidateHit === element || element.contains(candidateHit))) { point = candidate; hit = candidateHit; contained = true; break; }
      }
    }
    return { rect, point, hit, viewport, contained };
  };
  if (diagnosticOnly) {
    const state = read(), node = value => {
      const className = String(value?.className || '').slice(0, 180);
      return value ? { tag: String(value.tagName || '').toLowerCase(), className: /token|secret|password|cookie|https?:|wss?:|@|\b\d{7,}\b/iu.test(className) ? '' : className } : null;
    };
    return { target: node(element), rect: state.rect ? Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, Math.round(state.rect[key] * 100) / 100])) : null,
      hit: node(state.hit), viewport: state.viewport, contained: state.contained };
  }
  // Leave an already hittable portal option in place. A fixed footer can cover
  // an in-viewport field, so center only a target that currently fails the hit
  // check, then wait for its popup and geometry to settle before any input.
  const initial = read();
  if (!initial.contained || initial.rect.width <= 0 || initial.rect.height <= 0) element.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
  const frame = () => new Promise(resolve => {
    const timer = setTimeout(resolve, 50);
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => { clearTimeout(timer); resolve(); });
  });
  let previous = '', stable = 0;
  for (let attempt = 0; attempt < 24; attempt++) {
    await frame();
    if (element.isConnected === false || document.querySelector(selector) !== element) throw new Error('POD_CONTROL_STALE');
    const state = read(), rect = state.rect;
    const shape = JSON.stringify([rect.x, rect.y, rect.width, rect.height, state.point]);
    stable = state.contained && rect.width > 0 && rect.height > 0 ? shape === previous ? stable + 1 : 1 : 0; previous = shape;
    if (stable >= 3) return state.point;
  }
  throw new Error('POD_CONTROL_OBSCURED');
}

// One synchronous sample for the category read chain. Host-side polling owns the
// deadline; page rAF/timers cannot keep this Runtime.evaluate pending.
export function visibleCategoryControlPoint(selector, expected, visibleIntersection = false, allowScroll = false) {
  if (location.protocol !== 'https:' || !['seller.us.tiktokshopglobalselling.com', 'seller-us.tiktok.com', 'seller.tiktokglobalshop.com', 'seller.tiktokshop.com'].includes(location.hostname)) throw new Error('POD_READ_CONTROL_STALE');
  const element = document.querySelector(selector), norm = value => String(value || '').replace(/\s+/gu, ' ').trim();
  if (!element || element.isConnected === false || element.tagName.toLowerCase() !== expected.tag || expected.text && norm(element.innerText) !== norm(expected.text)) throw new Error('POD_READ_CONTROL_STALE');
  let pane = null, column = null, popup = null; const scrollableAncestors = [], clippingAncestors = [];
  if (expected.kind === 'category-option') {
    column = element.closest('.core-cascader-list-column'); popup = element.closest('.core-cascader-popup');
    pane = column?.querySelector('.core-cascader-list-wrapper');
    if (!element.matches('li.core-cascader-list-item') || !['menuitem', 'option', 'treeitem'].includes(element.getAttribute('role')) || !popup || !pane?.contains(element)) throw new Error('POD_READ_CONTROL_STALE');
    let reachedPopup = false;
    for (let current = element.parentElement, depth = 0; current && depth < 16; current = current.parentElement, depth++) {
      const css = getComputedStyle(current);
      if (/^(?:auto|scroll|hidden|clip)$/u.test(css.overflowY)) clippingAncestors.push(current);
      if (/^(?:auto|scroll)$/u.test(css.overflowY) && Number.isFinite(current.scrollHeight) && Number.isFinite(current.clientHeight) && current.clientHeight > 0 && current.scrollHeight > current.clientHeight + 2) scrollableAncestors.push(current);
      if (current === popup) { reachedPopup = true; break; }
    }
    if (!reachedPopup) throw new Error('POD_READ_CONTROL_STALE');
    if (scrollableAncestors.length) pane = scrollableAncestors[0];
  } else if (expected.kind !== 'category-trigger' || !element.matches('.p-cascader-select-view')) throw new Error('POD_READ_CONTROL_STALE');
  const node = value => {
    const className = String(value?.className || '').slice(0, 180);
    return value ? { tag: String(value.tagName || '').toLowerCase(), className: /token|secret|password|cookie|https?:|wss?:|@|\b\d{7,}\b/iu.test(className) ? '' : className } : null;
  };
  const read = () => {
    const rect = element.getBoundingClientRect(), paneRect = pane?.getBoundingClientRect(), viewport = { width: document.documentElement?.clientWidth || globalThis.innerWidth || 0, height: document.documentElement?.clientHeight || globalThis.innerHeight || 0 };
    const clip = { left: 2, top: 2, right: viewport.width - 2, bottom: viewport.height - 2 };
    if (paneRect) { clip.left = Math.max(clip.left, paneRect.x); clip.right = Math.min(clip.right, paneRect.x + paneRect.width); clip.top = Math.max(clip.top, paneRect.y + (pane.clientTop || 0)); clip.bottom = Math.min(clip.bottom, paneRect.y + (pane.clientTop || 0) + pane.clientHeight); }
    for (const current of clippingAncestors) {
      const box = current.getBoundingClientRect(), top = box.y + (current.clientTop || 0), height = current.clientHeight;
      if (![top, height].every(Number.isFinite) || height <= 0) throw new Error('POD_READ_CONTROL_STALE');
      clip.top = Math.max(clip.top, top); clip.bottom = Math.min(clip.bottom, top + height);
    }
    const inClip = point => point.x >= clip.left && point.x <= clip.right && point.y >= clip.top && point.y <= clip.bottom && clip.right > clip.left && clip.bottom > clip.top;
    let point = { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 }, hit = inClip(point) ? document.elementFromPoint(point.x, point.y) : null;
    let contained = !!hit && (hit === element || element.contains(hit));
    if (!contained && visibleIntersection) {
      const left = Math.max(clip.left, rect.x + 2), right = Math.min(clip.right, rect.x + rect.width - 2),
        top = Math.max(clip.top, rect.y + 2), bottom = Math.min(clip.bottom, rect.y + rect.height - 2);
      if (right > left && bottom > top) for (const [fx, fy] of [[.25, .5], [.75, .5], [.5, .25], [.5, .75]]) {
        const candidate = { x: left + (right - left) * fx, y: top + (bottom - top) * fy }, candidateHit = document.elementFromPoint(candidate.x, candidate.y);
        if (candidateHit && (candidateHit === element || element.contains(candidateHit))) { point = candidate; hit = candidateHit; contained = true; break; }
      }
    }
    return { rect, paneRect, clip, point, hit, viewport, contained: contained && rect.width > 0 && rect.height > 0 };
  };
  const state = read(); let scrollAction = 'none';
  if (!state.contained && allowScroll) {
    if (pane && scrollableAncestors.length) {
      const { paneRect, rect } = state, current = pane.scrollTop, height = pane.clientHeight, extent = pane.scrollHeight;
      if (![current, height, extent, paneRect.y, rect.y, rect.height].every(Number.isFinite) || height <= 0 || extent < height - 2) throw new Error('POD_READ_CONTROL_STALE');
      // A popup can extend below the browser viewport while its row still lies
      // inside the UL. Center within the actually visible clip, not the full UL.
      const top = state.clip.top, bottom = state.clip.bottom;
      if (bottom > top && (rect.y < top || rect.y + rect.height > bottom)) {
        const next = Math.max(0, Math.min(extent - height, current + rect.y + rect.height / 2 - (top + bottom) / 2));
        if (Math.abs(next - current) > 1) { pane.scrollTop = next; scrollAction = 'related_popup_pane'; }
      }
    } else if (!pane) { element.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' }); scrollAction = 'category_trigger'; }
  }
  const finiteRect = Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, Number.isFinite(state.rect[key]) ? Math.round(state.rect[key] * 100) / 100 : null]));
  const relatedScrollGeometry = [...new Set([pane, ...scrollableAncestors, column, popup, element.closest('.pulse-cascader-scroll-mode')].filter(Boolean))].slice(0, 6).map(current => {
    const box = current.getBoundingClientRect(), css = getComputedStyle(current);
    return { ...node(current), rect: Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, Number.isFinite(box[key]) ? Math.round(box[key] * 100) / 100 : null])),
      scrollTop: Number.isFinite(current.scrollTop) ? current.scrollTop : null, clientHeight: Number.isFinite(current.clientHeight) ? current.clientHeight : null, scrollHeight: Number.isFinite(current.scrollHeight) ? current.scrollHeight : null,
      overflowY: ['auto', 'scroll', 'hidden', 'clip', 'visible'].includes(css.overflowY) ? css.overflowY : 'other' };
  });
  return { target: node(element), rect: finiteRect, hit: node(state.hit), viewport: state.viewport, contained: state.contained, point: state.contained ? state.point : null, scrollAction, scrollableAncestorCount: scrollableAncestors.length, relatedScrollGeometry };
}

// The observed public Select supports user-created options. Only its own
// currently mounted input may receive search text; choosing and confirming the
// real option remains a separate visible action in the RPA adapter.
export function fillObservedSelectSearch(selector,expected,value){
  const current=new URL(location.href),official=current.protocol==='https:'&&['seller.us.tiktokshopglobalselling.com','seller-us.tiktok.com','seller.tiktokglobalshop.com','seller.tiktokshop.com'].includes(current.hostname);
  const fail=()=>{throw Error('自定义下拉的实际输入控件已变化或无法唯一确认。');};
  if(!official||!/^\/product\/(?:create|edit(?:\/[^/]+)?)$/u.test(current.pathname)||typeof value!=='string'||!value.trim()||value.length>4096||/[\u0000-\u001f\u007f]/u.test(value))return fail();
  const found=[...document.querySelectorAll(selector)],owner=found[0],registry=globalThis[Symbol.for('pod-observed-seller-controls-v1')];
  if(found.length!==1||!owner?.isConnected||!expected?.instanceId||registry?.nodes?.get(owner)!==expected.instanceId||!owner.matches('.core-select,.pulse-select,.arco-select,.ant-select')||owner.tagName.toLowerCase()!==expected.tag)return fail();
  const visible=element=>{if(!element?.isConnected||element.closest('[hidden],[aria-hidden="true"]'))return false;const rect=element.getBoundingClientRect();if(!(rect.width>0&&rect.height>0))return false;for(let item=element;item;item=item.parentElement){const css=getComputedStyle(item);if(css.display==='none'||['hidden','collapse'].includes(css.visibility)||Number(css.opacity)===0)return false;}return true;};
  if(!visible(owner)||owner.getAttribute('aria-disabled')==='true'||/(?:^|\s)(?:core|pulse|arco|ant)-select-disabled(?:\s|$)/u.test(owner.className||''))return fail();
  const inputs=[...owner.querySelectorAll('input')].filter(visible);
  if(inputs.length!==1)return fail();const input=inputs[0];
  if(input.disabled||input.readOnly||input.getAttribute('aria-disabled')==='true'||!['','text','search'].includes(input.getAttribute('type')||'')||/password|one-time-code/u.test(input.getAttribute('autocomplete')||''))return fail();
  input.focus();Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,value);
  input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  if(document.querySelector(selector)!==owner||registry.nodes.get(owner)!==expected.instanceId||!input.isConnected||!owner.contains(input)||input.value!==value)return fail();
  return {accepted:true,inputValue:input.value,instanceId:expected.instanceId};
}

// A native click on an already observed field is the only permitted creator of
// a no-listbox portal binding. Empty Qt menus have no aria-controls target.
export function observeCustomSelectPopupOpening(selector,expected,phase,token){
  const fail=()=>{throw Error('自定义下拉打开动作或所属字段无法确认。');},url=new URL(location.href);
  if(url.protocol!=='https:'||!['seller.us.tiktokshopglobalselling.com','seller-us.tiktok.com','seller.tiktokglobalshop.com','seller.tiktokshop.com'].includes(url.hostname)||!/^\/product\/(?:create|edit(?:\/[^/]+)?)$/u.test(url.pathname)||!['begin','claim'].includes(phase))return fail();
  const nodes=document.querySelectorAll(selector),owner=nodes[0],registry=globalThis[Symbol.for('pod-observed-seller-controls-v1')];
  if(nodes.length!==1||!owner?.isConnected||registry?.nodes?.get(owner)!==expected?.instanceId||owner.tagName.toLowerCase()!==expected.tag||!owner.matches('.core-select,.pulse-select,.arco-select,.ant-select'))return fail();
  const visible=node=>{if(!node?.isConnected||node.closest('[hidden],[aria-hidden="true"]'))return false;const r=node.getBoundingClientRect();if(!(r.width>0&&r.height>0))return false;for(let item=node;item;item=item.parentElement){const s=getComputedStyle(item);if(s.display==='none'||['hidden','collapse'].includes(s.visibility)||Number(s.opacity)===0)return false;}return true;};
  const expanded=node=>[node,...node.querySelectorAll('input,[role="combobox"]')].some(item=>item.getAttribute('aria-expanded')==='true')||/(?:^|\s)(?:core|pulse|arco|ant)-select-open(?:\s|$)/u.test(node.className||'');
  const popups=[...document.querySelectorAll('.core-select-popup,.pulse-select-popup,.arco-select-popup,.ant-select-dropdown')].filter(visible).filter(node=>!node.parentElement?.closest('.core-select-popup,.pulse-select-popup,.arco-select-popup,.ant-select-dropdown'));
  const openOwners=[...document.querySelectorAll('.core-select,.pulse-select,.arco-select,.ant-select')].filter(node=>visible(node)&&!popups.some(popup=>popup.contains(node))&&expanded(node));
  const key=Symbol.for('pod-custom-select-popup-owners-v1');if(!globalThis[key])Object.defineProperty(globalThis,key,{value:{owners:new WeakMap(),pending:null},configurable:true});const state=globalThis[key];
  if(phase==='begin'){
    if(!visible(owner)||popups.length||openOwners.length||owner.getAttribute('aria-disabled')==='true')return fail();
    const nonce=String(Date.now())+'-'+registry.next++;state.pending={owner,document,href:location.href,instanceId:expected.instanceId,token:nonce,at:Date.now()};return {accepted:true,token:nonce,instanceId:expected.instanceId};
  }
  const pending=state.pending;if(!pending||pending.token!==token||pending.owner!==owner||pending.document!==document||pending.href!==location.href||pending.instanceId!==expected.instanceId||Date.now()-pending.at>3000)return fail();
  if(!popups.length||!openOwners.length)return {accepted:false,pending:true};
  if(popups.length!==1||openOwners.length!==1||openOwners[0]!==owner||!visible(owner)||!(owner.contains(document.activeElement)||popups[0].contains(document.activeElement)))return fail();
  const popup=popups[0],editors=[...popup.querySelectorAll('.px-12.pb-8,.px-8.py-4.relative.w-full')].filter(visible);
  if(editors.length!==1||editors[0].querySelectorAll('input').length!==1)return fail();
  if(!registry.nodes.has(popup))registry.nodes.set(popup,'control-'+registry.next++);
  state.owners.set(popup,{owner,document,href:location.href,ownerInstanceId:expected.instanceId,popupInstanceId:registry.nodes.get(popup)});state.pending=null;
  return {accepted:true,instanceId:expected.instanceId,popupInstanceId:registry.nodes.get(popup)};
}

// The source CUSTOM_SELECT renderer keeps the editor in dropdownRender. Its
// search input is a different control and cannot create an option. Bind both
// the portal and its explicit Add button to the one observed field owner.
export function observedCustomSelectPopup(selector, expected, listProof, mode, value, operation = 'inspect') {
  const fail = () => { throw Error('自定义下拉的输入框、添加按钮或所属字段已变化，未执行创建。'); };
  const url = new URL(location.href);
  if (url.protocol !== 'https:' || !['seller.us.tiktokshopglobalselling.com','seller-us.tiktok.com','seller.tiktokglobalshop.com','seller.tiktokshop.com'].includes(url.hostname)
    || !/^\/product\/(?:create|edit(?:\/[^/]+)?)$/u.test(url.pathname) || !['text','number'].includes(mode) || !['inspect','fill','commit','focus-owner'].includes(operation)) return fail();
  const unique = query => { if (typeof query !== 'string' || !query) return fail(); const nodes = document.querySelectorAll(query); if (nodes.length !== 1) return fail(); return nodes[0]; };
  const visible = node => { if (!node?.isConnected || node.closest('[hidden],[aria-hidden="true"]')) return false; const rect = node.getBoundingClientRect(); if (!(rect.width > 0 && rect.height > 0)) return false;
    for (let item = node; item; item = item.parentElement) { const css = getComputedStyle(item); if (css.display === 'none' || ['hidden','collapse'].includes(css.visibility) || Number(css.opacity) === 0) return false; } return true; };
  const owner = unique(selector), registry = globalThis[Symbol.for('pod-observed-seller-controls-v1')];
  if (!registry?.nodes || !expected?.instanceId || registry.nodes.get(owner) !== expected.instanceId || owner.tagName.toLowerCase() !== expected.tag
    || !owner.matches('.core-select,.pulse-select,.arco-select,.ant-select') || !visible(owner) || owner.getAttribute('aria-disabled') === 'true' || /(?:^|\s)(?:core|pulse|arco|ant)-select-disabled(?:\s|$)/u.test(owner.className || '')) return fail();
  const popups = [...document.querySelectorAll('.core-select-popup,.pulse-select-popup,.arco-select-popup,.ant-select-dropdown')].filter(visible).filter(node => !node.parentElement?.closest('.core-select-popup,.pulse-select-popup,.arco-select-popup,.ant-select-dropdown'));
  const popup = unique(listProof?.containerSelector);
  if (popups.length !== 1 || popups[0] !== popup || listProof.busy !== false || popup.getAttribute('aria-busy') === 'true') return fail();
  const linked = node => [node,...node.querySelectorAll('input,[role="combobox"]')].some(helper => ['aria-controls','aria-owns'].some(key => (helper.getAttribute(key) || '').split(/\s+/u).filter(Boolean).some(id => {
    const targets = document.querySelectorAll('#' + CSS.escape(id)); return targets.length === 1 && (targets[0] === popup || popup.contains(targets[0])) && (listProof.relatedListIds || []).includes(id);
  })));
  const owners = [...document.querySelectorAll('.core-select,.pulse-select,.arco-select,.ant-select')].filter(node => visible(node) && !popup.contains(node) && linked(node));
  const targets=[owner,...owner.querySelectorAll('input,[role="combobox"]')].flatMap(node=>['aria-controls','aria-owns'].flatMap(key=>(node.getAttribute(key)||'').split(/\s+/u).filter(Boolean))).flatMap(id=>[...document.querySelectorAll('#'+CSS.escape(id))]);
  if(targets.length){if(owners.length!==1||owners[0]!==owner)return fail();}
  else{
    const binding=globalThis[Symbol.for('pod-custom-select-popup-owners-v1')]?.owners?.get(popup);
    const expanded=node=>[node,...node.querySelectorAll('input,[role="combobox"]')].some(item=>item.getAttribute('aria-expanded')==='true')||/(?:^|\s)(?:core|pulse|arco|ant)-select-open(?:\s|$)/u.test(node.className||'');
    const openOwners=[...document.querySelectorAll('.core-select,.pulse-select,.arco-select,.ant-select')].filter(node=>visible(node)&&!popup.contains(node)&&expanded(node));
    if(!binding||binding.document!==document||binding.href!==location.href||binding.owner!==owner||binding.ownerInstanceId!==expected.instanceId||binding.popupInstanceId!==registry.nodes.get(popup)||openOwners.length!==1||openOwners[0]!==owner)return fail();
  }
  const inputs = [...popup.querySelectorAll('input')].filter(node => visible(node) && !node.closest('[role="option"],[role="treeitem"],[role="menuitem"]'));
  const adds = [...popup.querySelectorAll('button')].filter(node => visible(node) && !node.closest('[role="option"],[role="treeitem"],[role="menuitem"],.core-input-number,.pulse-input-number,.arco-input-number,.ant-input-number'));
  if (inputs.length !== 1 || adds.length !== 1) return fail(); const input = inputs[0], add = adds[0], type = input.getAttribute('type') || 'text';
  if (operation !== 'inspect' && (input.disabled || input.getAttribute('aria-disabled') === 'true') || input.readOnly || /password|one-time-code/u.test(input.getAttribute('autocomplete') || '')
    || !['text','search','number'].includes(type) || mode === 'text' && type === 'number'
    || add.tagName !== 'BUTTON' || add.form && (add.getAttribute('type') || 'submit') !== 'button') return fail();
  // QHe and jcn use the same flex row: one input wrapper and one explicit
  // button. Captions are translated by different source keys, so association
  // comes from that source shape and portal ownership rather than one locale.
  let row = input.parentElement; while (row && row !== popup && !(row.classList?.contains('flex') && row.contains(add))) row = row.parentElement;
  const addText = String(add.innerText || add.textContent || '').trim();
  if (!row || row === popup || row.querySelectorAll('input').length !== 1 || [...row.querySelectorAll('button')].filter(node => !node.closest('.core-input-number,.pulse-input-number,.arco-input-number,.ant-input-number')).length !== 1
    || !addText || addText.length > 80 || /发布|保存|删除|提交|上架|publish|save|delete|submit|list product/iu.test(addText)) return fail();
  const wrapper=row.parentElement,has=name=>wrapper?.classList?.contains(name),generic=has('px-12')&&has('pb-8')&&row.classList.contains('space-x-8')&&row.classList.contains('flex-grow-1'),plugin=has('px-8')&&has('py-4')&&has('relative')&&has('w-full');
  const commaBehavior=generic&&!plugin?'delimiter':plugin&&!generic?'literal':'unknown';
  if(operation!=='inspect'&&commaBehavior==='unknown')return fail();
  const instance = node => { if (!registry.nodes.has(node)) registry.nodes.set(node,'control-' + registry.next++); return registry.nodes.get(node); };
  const cssPath = node => { const parts = []; for (let item = node; item && item !== document.documentElement; item = item.parentElement) { if (item.id && document.querySelectorAll('#' + CSS.escape(item.id)).length === 1) { parts.unshift('#' + CSS.escape(item.id)); break; }
    const tag = item.tagName.toLowerCase(), siblings = [...item.parentElement.children].filter(other => other.tagName === item.tagName); parts.unshift(tag + ':nth-of-type(' + (siblings.indexOf(item) + 1) + ')'); } return parts.join(' > '); };
  if (operation === 'fill') {
    if (typeof value !== 'string' || value !== value.trim() || !value || value.length > 4096 || /[\u0000-\u001f\u007f]/u.test(value)) return fail();
    if(value.includes(',')&&commaBehavior!=='literal')throw Error('POD_CUSTOM_COMMA_UNVERIFIED: 自定义下拉会拆分逗号或语义尚未确认，已保留原文，未创建。');
    input.focus(); Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,value);
    input.dispatchEvent(new Event('input',{bubbles:true})); input.dispatchEvent(new Event('change',{bubbles:true}));
    if (unique(selector) !== owner || !input.isConnected || !popup.contains(input) || mode === 'text' && input.value !== value || typeof input.value !== 'string' || !input.value.trim()) return fail();
  }
  const proof = {accepted:true,instanceId:expected.instanceId,popupInstanceId:instance(popup),inputInstanceId:instance(input),addInstanceId:instance(add),rowInstanceId:instance(row),editorInstanceId:instance(wrapper),inputValue:input.value,
    addSelector:cssPath(add),addText,mode,commaBehavior,addDisabled:add.disabled === true || add.getAttribute('aria-disabled') === 'true',pending:input.disabled === true || input.getAttribute('aria-disabled') === 'true',
    validationError:[...popup.querySelectorAll('.text-error,.text-function-error,[role="alert"]')].some(node => visible(node) && String(node.innerText || node.textContent || '').trim())};
  if(operation==='focus-owner'){
    // Escape belongs to the Select owner, not the independently rendered Add
    // footer. Focus only its observed search input; never click a chip or set
    // either input's value. The caller still verifies closure and selection.
    if(proof.pending||proof.validationError||proof.inputValue!=='')return fail();
    const searches=[...owner.querySelectorAll('input')].filter(node=>!popup.contains(node)&&visible(node));
    if(searches.length!==1)return fail();const search=searches[0],searchType=search.getAttribute('type')||'text',beforeValue=search.value,searchInstanceId=instance(search);
    if(search.disabled||search.readOnly||search.getAttribute('aria-disabled')==='true'||!['text','search'].includes(searchType)||/password|one-time-code/u.test(search.getAttribute('autocomplete')||''))return fail();
    search.focus({preventScroll:true});
    if(unique(selector)!==owner||unique(listProof.containerSelector)!==popup||registry.nodes.get(owner)!==expected.instanceId||registry.nodes.get(popup)!==proof.popupInstanceId||!search.isConnected||!owner.contains(search)||popup.contains(search)||document.activeElement!==search||search.value!==beforeValue||input.value!==''||input.disabled||input.getAttribute('aria-disabled')==='true'||[...popup.querySelectorAll('.text-error,.text-function-error,[role="alert"]')].some(node=>visible(node)&&String(node.innerText||node.textContent||'').trim()))return fail();
    return {...proof,focusedOwnerSearch:true,searchInstanceId,ownerSearchValueUnchanged:true};
  }
  if (operation === 'commit') {
    if (!value || ['instanceId','popupInstanceId','inputInstanceId','addInstanceId','rowInstanceId','editorInstanceId','inputValue','addSelector','addText','mode','commaBehavior'].some(key => proof[key] !== value[key]) || proof.addDisabled || proof.pending || proof.validationError) return fail();
  }
  return proof;
}

function interactSellerDom(selector, operation, value) {
  if (location.protocol !== 'https:' || !['seller.us.tiktokshopglobalselling.com', 'seller-us.tiktok.com', 'seller.tiktokglobalshop.com', 'seller.tiktokshop.com'].includes(location.hostname)) throw new Error('页面已离开官方商家中心。');
  const element = document.querySelector(selector); if (!element) throw new Error('页面控件已变化，请重新读取。');
  if (operation === 'scroll') { const target = selector === ':root' ? document.scrollingElement : element; target.scrollTop = value; target.dispatchEvent(new Event('scroll', { bubbles: true })); return true; }
  if (operation === 'select') {
    if (element.tagName !== 'SELECT') throw new Error('需要原生选择控件。');
    const values = Array.isArray(value) ? value : [value];
    if (values.some(item => ![...element.options].some(option => !option.disabled && option.value === item))) throw new Error('选项不在实际控件内。');
    for (const option of element.options) option.selected = values.includes(option.value);
  } else if (operation === 'fill') {
    element.focus();
    if (element.isContentEditable) element.textContent = value;
    else {
      const proto = element.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(element, value);
    }
  } else throw new Error('不支持的控件操作。');
  element.dispatchEvent(new Event('input', { bubbles: true })); element.dispatchEvent(new Event('change', { bubbles: true })); element.dispatchEvent(new Event('blur', { bubbles: true })); return true;
}

async function resolveEndpoint(connection, fetchImpl) {
  if (connection?.ws?.puppeteer) return assertLoopbackWebSocket(connection.ws.puppeteer);
  const port = String(connection?.debug_port || ''); if (!/^\d{1,5}$/u.test(port) || Number(port) < 1 || Number(port) > 65535) throw new Error('AdsPower 未返回本机浏览器连接。');
  const response = await fetchImpl('http://127.0.0.1:' + port + '/json/version', { signal: AbortSignal.timeout(10000), redirect: 'error' });
  if (!response.ok) throw new Error('无法连接 AdsPower 浏览器。');
  return assertLoopbackWebSocket((await response.json()).webSocketDebuggerUrl);
}

function safeLocalizedBrowserDiagnostics(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const stages = ['preflight', 'request', 'digest', 'fetch', 'response', 'stream', 'json', 'projection', 'complete'];
  const result = { stage: stages.includes(raw.stage) ? raw.stage : 'unknown' };
  for (const key of ['pageBeforeVerified', 'securityBeforeVerified', 'requestVerified', 'fetchStarted', 'responseReceived', 'httpOk', 'streamComplete', 'jsonParsed', 'codeIsZero', 'dataObject', 'productPropertiesArray', 'projectorAccepted', 'projectorRowsComplete', 'pageAfterVerified', 'securityAfterVerified']) result[key] = typeof raw[key] === 'boolean' ? raw[key] : null;
  for (const [key, maximum] of [['bodyBytes', 2 * 1024 * 1024 + 1], ['chunkCount', 4097], ['propertyRowCount', 201], ['projectedPropertyCount', 201], ['invalidPropertyCount', 201]]) result[key] = Number.isSafeInteger(raw[key]) && raw[key] >= 0 && raw[key] <= maximum ? raw[key] : null;
  return result;
}

function privateOptionListCensusObservation(raw, normalized, scope, previous) {
  const finite = value => typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= 10000000;
  const number = value => finite(value) ? Math.round(value * 1000000) / 1000000 : null;
  const count = value => Number.isSafeInteger(value) && value >= 0 && value <= 1000 ? value : null;
  const rowCount = count(raw?.rowCount), samples = rowCount ? [...new Set([0, 1, Math.floor(rowCount / 2) - 1, Math.floor(rowCount / 2), rowCount - 2, rowCount - 1].filter(index => index >= 0 && index < rowCount))] : [];
  const rows = (value, heightPair = false) => Array.isArray(value) && value.length === rowCount && value.every(pair => Array.isArray(pair) && pair.length === 3 && pair.every(finite) && pair[2] > 0 && (heightPair ? pair[1] > 0 : pair[1] > pair[0])) ? value.map(pair => [...pair]) : null;
  const rectRows = rows(raw?.flowRows), nativeRaw = raw?.nativeLayoutObservation, nativeRows = rows(nativeRaw?.rows, true);
  const parentKinds = ['row-host', 'scroll-pane', 'listbox', 'popup', 'body', 'document', 'popup-ancestor', 'other', 'none', 'unknown'];
  const ancestorKinds = (Array.isArray(nativeRaw?.ancestorKinds) ? nativeRaw.ancestorKinds : []).slice(0, 6).map(value => ({
    tag: ['div', 'span', 'ul', 'ol', 'li', 'section', 'article', 'main', 'body', 'html'].includes(value?.tag) ? value.tag : 'other',
    kind: parentKinds.includes(value?.kind) ? value.kind : 'unknown', position: ['static', 'relative', 'absolute', 'fixed', 'sticky'].includes(value?.position) ? value.position : 'unknown' }));
  const nativeComplete = nativeRaw?.scanComplete === true && nativeRaw.sameOffsetParent === true && nativeRaw.rowCount === rowCount && nativeRaw.capturedRowCount === rowCount && !!nativeRows && rowCount > 0;
  const nativeKey = nativeComplete ? JSON.stringify([nativeRaw.offsetParentKind, ancestorKinds, nativeRows, nativeRaw.hostBox, nativeRaw.paneBox, nativeRaw.parentPath]) : '';
  const accepted = normalized?.accepted === true, sameField = !!previous && previous.fieldFingerprint === scope.fieldFingerprint;
  const sameDocument = sameField && previous.documentFingerprint === scope.documentFingerprint, sameAssociation = sameField && previous.associationFingerprint === normalized.associationFingerprint;
  const comparable = accepted && sameDocument && sameAssociation && !!rectRows && previous.rectRows?.length === rowCount;
  const resetReason = !accepted ? 'not-accepted' : !previous ? 'first-for-field' : !sameField ? 'field-changed' : !sameDocument ? 'document-changed' : !sameAssociation ? 'association-changed' : 'none';
  const observation = { version: 1, structureOnly: true, complete: false, accepted, reason: typeof normalized?.reason === 'string' && /^[A-Z_]{1,80}$/u.test(normalized.reason) ? normalized.reason : 'OBSERVATION_FAILED',
    baselineKind: resetReason, equality: { document: sameField ? sameDocument : null, schema: sameField && accepted ? previous.schemaFingerprint === normalized.schemaFingerprint : null,
      association: sameField && accepted ? sameAssociation : null, geometry: sameField && accepted ? previous.geometryFingerprint === normalized.geometryFingerprint : null,
      nativeLayout: sameDocument && sameAssociation && nativeKey && previous.nativeKey ? nativeKey === previous.nativeKey : null },
    rowCount, geometry: {}, rectDrift: { compared: comparable, rowCount: comparable ? rowCount : 0, startMin: null, startMax: null, endMin: null, endMax: null, heightAbsMax: null },
    flowGeometrySamples: [], nativeLayout: { observedRowsComplete: nativeComplete, scanComplete: nativeRaw?.scanComplete === true,
      reason: ['OBSERVED', 'BUDGET', 'NONFINITE', 'NO_OFFSET_PARENT', 'MIXED_OFFSET_PARENTS', 'READ_FAILED'].includes(nativeRaw?.reason) ? nativeRaw.reason : 'UNAVAILABLE',
      rowCount: count(nativeRaw?.rowCount), capturedRowCount: count(nativeRaw?.capturedRowCount), sameOffsetParent: typeof nativeRaw?.sameOffsetParent === 'boolean' ? nativeRaw.sameOffsetParent : null,
      offsetParentKind: parentKinds.includes(nativeRaw?.offsetParentKind) ? nativeRaw.offsetParentKind : 'unknown', ancestorKinds,
      parentTag: ['div', 'span'].includes(nativeRaw?.parentTag) ? nativeRaw.parentTag : 'other', parentPosition: ['static', 'relative', 'absolute', 'fixed', 'sticky'].includes(nativeRaw?.parentPosition) ? nativeRaw.parentPosition : 'unknown',
      parentPathDepth: Array.isArray(nativeRaw?.parentPath) && nativeRaw.parentPath.length <= 80 ? nativeRaw.parentPath.length : null,
      parentRelations: {}, boxes: { host: {}, pane: {} }, offsetTopMin: null, offsetTopMax: null, offsetHeightMin: null, offsetHeightMax: null, offsetWidthMin: null, offsetWidthMax: null, samples: [] } };
  for (const key of ['parentContainsPopup', 'parentContainsHost', 'parentContainsPane', 'hostOffsetParentSame', 'paneOffsetParentSame', 'parentPathVerified']) observation.nativeLayout.parentRelations[key] = typeof nativeRaw?.[key] === 'boolean' ? nativeRaw[key] : null;
  for (const [kind, source] of [['host', nativeRaw?.hostBox], ['pane', nativeRaw?.paneBox]]) for (const key of ['offsetTop', 'offsetHeight', 'offsetWidth', 'clientTop', 'clientHeight', 'clientWidth', 'scrollHeight', 'scrollWidth']) observation.nativeLayout.boxes[kind][key] = number(source?.[key]);
  for (const key of ['scrollTop', 'clientHeight', 'scrollHeight', 'paddingTop', 'paddingBottom', 'firstContentOffset', 'lastContentOffset']) observation.geometry[key] = number(raw?.[key]);
  if (comparable) {
    const starts = rectRows.map((pair, index) => pair[0] - previous.rectRows[index][0]), ends = rectRows.map((pair, index) => pair[1] - previous.rectRows[index][1]);
    Object.assign(observation.rectDrift, { startMin: number(Math.min(...starts)), startMax: number(Math.max(...starts)), endMin: number(Math.min(...ends)), endMax: number(Math.max(...ends)),
      heightAbsMax: number(Math.max(...rectRows.map((pair, index) => Math.abs(pair[1] - pair[0] - (previous.rectRows[index][1] - previous.rectRows[index][0]))))) });
  }
  if (rectRows) for (const index of samples) observation.flowGeometrySamples.push({ index, start: number(rectRows[index][0]), end: number(rectRows[index][1]), height: number(rectRows[index][1] - rectRows[index][0]),
    startDelta: comparable ? number(rectRows[index][0] - previous.rectRows[index][0]) : null, endDelta: comparable ? number(rectRows[index][1] - previous.rectRows[index][1]) : null });
  if (nativeRows) {
    Object.assign(observation.nativeLayout, { offsetTopMin: number(Math.min(...nativeRows.map(pair => pair[0]))), offsetTopMax: number(Math.max(...nativeRows.map(pair => pair[0]))),
      offsetHeightMin: number(Math.min(...nativeRows.map(pair => pair[1]))), offsetHeightMax: number(Math.max(...nativeRows.map(pair => pair[1]))), offsetWidthMin: number(Math.min(...nativeRows.map(pair => pair[2]))), offsetWidthMax: number(Math.max(...nativeRows.map(pair => pair[2]))) });
    for (const index of samples) observation.nativeLayout.samples.push({ index, offsetTop: number(nativeRows[index][0]), offsetHeight: number(nativeRows[index][1]), offsetWidth: number(nativeRows[index][2]),
      offsetTopDelta: sameDocument && sameAssociation && previous.nativeRows?.length === rowCount ? number(nativeRows[index][0] - previous.nativeRows[index][0]) : null,
      offsetHeightDelta: sameDocument && sameAssociation && previous.nativeRows?.length === rowCount ? number(nativeRows[index][1] - previous.nativeRows[index][1]) : null,
      offsetWidthDelta: sameDocument && sameAssociation && previous.nativeRows?.length === rowCount ? number(nativeRows[index][2] - previous.nativeRows[index][2]) : null });
  }
  const baseline = accepted && rectRows ? comparable ? previous : { fieldFingerprint: scope.fieldFingerprint, documentFingerprint: scope.documentFingerprint,
    associationFingerprint: normalized.associationFingerprint, schemaFingerprint: normalized.schemaFingerprint, geometryFingerprint: normalized.geometryFingerprint, rectRows, nativeKey, nativeRows: nativeComplete ? nativeRows : null } : previous;
  return { observation, baseline };
}

function safeRejectedOptionListCensus(raw, publicReason) {
  const reasons = ['PAGE_UNVERIFIED', 'MODAL_PRESENT', 'FIELD_UNVERIFIED', 'SCAN_LIMIT', 'POPUP_NOT_UNIQUE', 'LISTBOX_NOT_UNIQUE', 'ASSOCIATION_UNVERIFIED', 'FIELD_NOT_OPEN', 'ROW_LIMIT', 'ROWS_UNVERIFIED', 'QUERY_UNVERIFIED', 'MOUNTED_PROOF_INCOMPLETE', 'NATIVE_LAYOUT_UNVERIFIED', 'OBSERVED_COMPLETE_MOUNTED_LIST', 'OBSERVATION_FAILED'];
  const stages = ['field', 'popup-tree', 'association', 'query', 'loading', 'row-tree', 'option-controls', 'geometry', 'complete'];
  const result = { version: 1, phase: raw?.accepted === true ? 'host-rejected' : 'raw-rejected',
    reason: reasons.includes(raw?.reason) ? raw.reason : 'OBSERVATION_FAILED', publicReason: reasons.includes(publicReason) ? publicReason : 'OBSERVATION_FAILED',
    observationStage: stages.includes(raw?.observationStage) ? raw.observationStage : 'unknown', countsComplete: false, counts: {}, flags: {}, geometry: {}, unknownChildren: [], unknownChildrenTruncated: raw?.unknownChildrenTruncated === true, flowGeometrySamples: [], flowGeometrySampledOnly: true };
  for (const key of ['popupCount', 'innerListboxCount', 'scrollPaneCount', 'ownerCount', 'rowCount', 'normalisedOptionCount', 'selectableOptionCount', 'disabledRowCount', 'missingLabelCount', 'duplicateLabelCount', 'unknownChildCount', 'unknownOptionControlCount', 'moreControlCount', 'coverageGapCount', 'coverageOverlapCount', 'declaredTotal']) result.counts[key] = Number.isSafeInteger(raw?.[key]) && raw[key] >= 0 && raw[key] <= 10000000 ? raw[key] : null;
  for (const key of ['associationVerified', 'paneIdentityVerifiable', 'ownerRevalidated', 'virtualMarker', 'ariaHidden', 'busy', 'countConflict', 'positionsComplete', 'finiteGeometry', 'flowVerified', 'completeMounted', 'emptyQueryVerified', 'atTop', 'atBottom', 'truncated']) result.flags[key] = typeof raw?.[key] === 'boolean' ? raw[key] : null;
  for (const key of ['scrollTop', 'clientHeight', 'scrollHeight', 'paddingTop', 'paddingBottom', 'firstContentOffset', 'lastContentOffset']) result.geometry[key] = Number.isFinite(raw?.[key]) && Math.abs(raw[key]) <= 10000000 ? Math.round(raw[key] * 1000) / 1000 : null;
  for (const sample of (Array.isArray(raw?.flowGeometrySamples) ? raw.flowGeometrySamples : []).slice(0, 6)) {
    if (!Number.isSafeInteger(sample?.index) || sample.index < 0 || sample.index >= 1000) continue;
    const safe = { index: sample.index };
    for (const key of ['start', 'end', 'height', 'marginTop', 'marginBottom', 'prevEndDelta', 'parentRowGap']) safe[key] = Number.isFinite(sample[key]) && Math.abs(sample[key]) <= 10000000 ? Math.round(sample[key] * 1000) / 1000 : null;
    safe.parentDisplay = ['block', 'flex', 'inline-flex', 'grid', 'inline-grid', 'contents', 'flow-root', 'list-item'].includes(sample.parentDisplay) ? sample.parentDisplay : 'other';
    safe.parentFlexDirection = ['row', 'row-reverse', 'column', 'column-reverse'].includes(sample.parentFlexDirection) ? sample.parentFlexDirection : 'other';
    safe.parentRowGapKind = ['normal', 'numeric'].includes(sample.parentRowGapKind) ? sample.parentRowGapKind : 'unknown'; result.flowGeometrySamples.push(safe);
  }
  if (!Array.isArray(raw?.unknownChildren)) return result;
  if (raw.unknownChildren.length > 8) result.unknownChildrenTruncated = true;
  const safeNode = node => {
    const classFiltered = node.classFiltered === true || typeof node.className !== 'string' || node.className.length > 180 || /[\x00-\x1f\x7f]|(?:https?|wss?|data|blob|file):|[A-Z][A-Z0-9+.-]*:\/\/|password|passwd|token|secret|cookie|credential|authorization|API.?key|验证码|密钥|@|\b\d{7,}\b|gh[pousr]_|github_pat_|(?:^|[\s_-])(?:sk|rk)[-_]|eyJ[A-Za-z0-9_-]{12,}|(?:^|[\s_-])(?:jwt|basic|bearer)(?:$|[\s_-])/iu.test(node.className);
    return { tag: ['div', 'span', 'ul', 'ol', 'li', 'input', 'svg', 'path', 'label', 'button', 'p', 'i', 'section'].includes(node.tag) ? node.tag : 'other',
      role: ['none', 'listbox', 'option', 'separator', 'button', 'searchbox', 'checkbox', 'radio', 'presentation', 'img', 'combobox'].includes(node.role) ? node.role : 'other',
      className: classFiltered ? '' : node.className, classFiltered,
      childCount: Number.isSafeInteger(node.childCount) && node.childCount >= 0 && node.childCount <= 2000 ? node.childCount : null,
      textLength: Number.isSafeInteger(node.textLength) && node.textLength >= 0 && node.textLength <= 1000000 ? node.textLength : null,
      hasTabindex: typeof node.hasTabindex === 'boolean' ? node.hasTabindex : null };
  };
  const textKind = value => ['create-cn', 'add-cn', 'create-en', 'add-en'].includes(value) ? value : 'unknown';
  let descendantCount = 0;
  for (const node of raw.unknownChildren.slice(0, 8)) {
    if (!['root', 'wrapper', 'host'].includes(node?.relation) || !['unknown-row', 'direct-text', 'unknown-child'].includes(node?.cause)) { result.unknownChildrenTruncated = true; continue; }
    const info = { relation: node.relation, cause: node.cause, ...safeNode(node) }; result.unknownChildren.push(info);
    if (info.relation === 'root' && info.cause === 'unknown-child' && info.tag === 'div' && info.className === 'pulse-select-extra' && (Object.hasOwn(node, 'knownTextKind') || Array.isArray(node.descendants))) {
      info.knownTextKind = textKind(node.knownTextKind); info.descendants = [];
      info.descendantsTruncated = node.descendantsTruncated !== false || !Array.isArray(node.descendants);
      for (const child of (Array.isArray(node.descendants) ? node.descendants : [])) {
        if (descendantCount >= 16) { info.descendantsTruncated = true; break; }
        const validParent = child?.relativeDepth === 1 ? child.parentIndex === null : Number.isSafeInteger(child?.relativeDepth) && child.relativeDepth >= 2 && child.relativeDepth <= 6 && Number.isSafeInteger(child.parentIndex) && child.parentIndex >= 0 && child.parentIndex < info.descendants.length && info.descendants[child.parentIndex].relativeDepth === child.relativeDepth - 1;
        if (!validParent) { info.descendantsTruncated = true; break; }
        descendantCount++; info.descendants.push({ relativeDepth: child.relativeDepth, parentIndex: child.parentIndex, ...safeNode(child), knownTextKind: textKind(child.knownTextKind) });
      }
    }
  }
  return result;
}

export async function connectTikTokBrowser(connection, { WebSocketClass = globalThis.WebSocket, fetchImpl = globalThis.fetch, timeoutMs = 15000, onResponseStructure, qaCombinedPopoverSnapshot = false } = {}) {
  if (typeof qaCombinedPopoverSnapshot !== 'boolean') throw new TypeError('专用页面 QA 合并读取设置必须为布尔值。');
  const endpoint = await resolveEndpoint(connection, fetchImpl), socket = new WebSocketClass(endpoint);
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => { socket.close(); reject(new Error('浏览器连接超时。')); }, timeoutMs);
    socket.addEventListener('open', () => { clearTimeout(timer); resolve(); }, { once: true });
    socket.addEventListener('error', () => { clearTimeout(timer); socket.close(); reject(new Error('无法连接本机浏览器。')); }, { once: true });
  });
  const transport = new TikTokCdpTransport(socket, { timeoutMs });
  return {
    async newPage(url, { qaDesktopViewport = false } = {}) {
      assertSellerUrl(url);
      if (typeof qaDesktopViewport !== 'boolean') throw new Error('专用页面 QA 视口设置必须为布尔值。');
      const step = async (driverStage, operation) => {
        try { return await operation(); }
        catch (error) { error.driverStage = driverStage; throw error; }
      };
      const { targetId } = await step('create_target', () => transport.send('Target.createTarget', { url: 'about:blank', background: true }));
      let sessionId;
      try { ({ sessionId } = await step('attach_target', () => transport.send('Target.attachToTarget', { targetId, flatten: true }))); }
      catch (error) { await transport.send('Target.closeTarget', { targetId }).catch(() => {}); throw error; }
      const command = (method, params, options) => transport.send(method, params, sessionId, options);
      let localizedPrivateDiagnostics = null, lastRejectedOptionListCensus = null, lastOptionListCensusObservation = null, optionListObservationBaseline = null, lastComplianceFieldStructure = null, qaCategoryObservation = null;
      const categoryDefinitions = createCategoryDefinitionObserver({ send: (method, params) => command(method, params, { timeoutMs: 10000 }), onResponseStructure,
        readLocalized: async ({ url: requestUrl, categoryId, isCurrent }) => {
          const failure = reason => ({ accepted: false, complete: false, reason });
          const diagnostics = { event: 'localized_definition_diagnostics', browser: null, host: { stage: 'scope_check', evaluationReturned: false, runtimeException: null, projectionAccepted: null }, observer: null }; localizedPrivateDiagnostics = diagnostics;
          if (ownedPageClosed || !isCurrent()) return failure('localized_scope_unverified');
          try {
            const expression = '(' + readLocalizedCategoryDefinitionInPage.toString() + ')(' + JSON.stringify(requestUrl) + ',' + JSON.stringify(categoryId) + ',(' + visibleSellerSecurity.toString() + '),(' + projectCategoryDefinition.toString() + '))';
            const result = await command('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, timeout: 10000 }, { timeoutMs: 10000 });
            diagnostics.browser = safeLocalizedBrowserDiagnostics(result.result?.value?.localizedDiagnostics);
            diagnostics.host = { stage: 'evaluation_returned', evaluationReturned: true, runtimeException: !!result.exceptionDetails, projectionAccepted: null };
            if (ownedPageClosed || !isCurrent()) return failure('localized_scope_unverified');
            if (result.exceptionDetails) return failure('localized_read_failed');
            const normalized = normalizeLocalizedCategoryDefinitionResult(result.result?.value, categoryId);
            diagnostics.host.stage = 'normalized'; diagnostics.host.projectionAccepted = normalized.accepted === true;
            return normalized;
          } catch { diagnostics.host.stage = 'evaluation_failed'; return failure('localized_read_failed'); }
        } });
      const stopCategoryObservation = transport.observeCategoryDefinitions(sessionId, message => categoryDefinitions.observe(message));
      const actionTrace = [];
      const actionSummaryEvents = new Set(['owned_target_activated_before_navigation', 'owned_page_foreground_before_navigation', 'owned_target_activated', 'owned_page_foreground',
        'known_guide_close_click_acknowledged', 'known_guide_close_dom_click_acknowledged', 'known_guide_prompt_waiting_for_paint', 'known_guide_prompt_frame_recovered',
        'observed_shop_menu_dom_click_acknowledged', 'observed_shop_menu_dom_close_acknowledged', 'observed_shop_menu_state_already_satisfied', 'shop_menu_state_observed',
        'read_control_preflight_begin', 'read_point_preflight_begin', 'read_point_preflight_end', 'read_point_preflight_failed', 'control_point_preflight_failed',
        'category_option_semantic_dom_preflight', 'read_control_dom_click_begin', 'read_control_dom_click_responded', 'read_control_dom_click_failed', 'read_control_dom_click_acknowledged',
        'read_expander_button_observed', 'read_control_timeout_postcondition_check', 'read_control_timeout_postcondition_observed', 'read_frame_recovery_captured', 'read_category_column_frame_captured', 'read_category_column_frame_rejected',
        'read_popup_dom_close_acknowledged', 'observed_category_definition_read', 'localized_category_definition_read', 'owned_javascript_dialog_observed', 'owned_late_command_response_observed',
        'read_category_native_begin', 'read_category_native_moved', 'read_category_native_pressed', 'read_category_native_acknowledged', 'read_category_native_failed']);
      const actionSummaryKinds = new Set(['category-trigger', 'category-option', 'attribute-trigger', 'attribute-option', 'show-optional', 'category', 'attribute', 'guide']);
      const actionSummaryCodes = new Set(['SELLER_CONTROL_STALE', 'SELLER_CONTROL_OBSCURED', 'SELLER_DOM_FAILED', 'SELLER_READ_CONTROL_STALE', 'SELLER_READ_MODAL_BLOCKED', 'SELLER_SECURITY_VERIFICATION', 'CDP_TIMEOUT', 'CDP_READ_FAILED']);
      const actionSummaryEntries = [], actionSummaryCounts = {}; let actionSummaryCount = 0, actionSummaryDropped = 0;
      const trace = (event, data = {}) => {
        actionTrace.push({ event, ...data }); if (actionTrace.length > 100) actionTrace.shift();
        if (!actionSummaryEvents.has(event)) return;
        const entry = { sequence: actionSummaryCount = Math.min(1000000000, actionSummaryCount + 1), event };
        actionSummaryCounts[event] = Math.min(1000000000, (actionSummaryCounts[event] || 0) + 1);
        if (actionSummaryKinds.has(data.kind)) entry.kind = data.kind;
        if (Number.isSafeInteger(data.categoryLevel) && data.categoryLevel >= 0 && data.categoryLevel < 10) entry.categoryLevel = data.categoryLevel;
        if (Number.isFinite(data.elapsedMs) && data.elapsedMs >= 0) entry.elapsedMs = Math.min(600000, Math.round(data.elapsedMs));
        if (actionSummaryCodes.has(data.code)) entry.code = data.code;
        if (typeof data.semanticCategoryOption === 'boolean') entry.semanticCategoryOption = data.semanticCategoryOption;
        if (typeof data.accepted === 'boolean') entry.accepted = data.accepted;
        if (Number.isSafeInteger(data.propertyCount) && data.propertyCount >= 0) entry.propertyCount = Math.min(100000, data.propertyCount);
        if (event === 'read_category_column_frame_rejected') {
          if (['initial', 'before-frame', 'after-frame', 'final'].includes(data.phase)) entry.phase = data.phase;
          if (['POPUP_NOT_OWNED', 'INITIAL_OPTION_UNVERIFIED', 'POPUP_OWNER_CHANGED', 'ACTION_SEQUENCE_CHANGED', 'FRESH_ITEM_UNVERIFIED', 'FRESH_READ_FAILED', 'TARGET_SELECTOR_CHANGED', 'TARGET_TAG_CHANGED', 'TARGET_ROLE_CHANGED', 'TARGET_TEXT_CHANGED', 'TARGET_LEVEL_CHANGED', 'TARGET_DISABLED', 'TARGET_READONLY', 'TARGET_DISABLED_CLASS', 'SECURITY_UNVERIFIED', 'SECURITY_BLOCKED', 'PAGE_BUSY', 'CATEGORY_BUSY', 'SHOP_MENU_VISIBLE', 'GUIDANCE_UNVERIFIED', 'GUIDANCE_VISIBLE', 'MODAL_VISIBLE', 'UNKNOWN_MODAL_VISIBLE', 'COLUMN_NOT_UNIQUE', 'COLUMN_BUSY', 'COLUMN_SELECTOR_MISSING', 'POPUP_SELECTOR_MISSING', 'PEER_NOT_UNIQUE', 'COLUMN_REFS_DUPLICATE', 'OPTION_MULTIPLE_COLUMNS', 'POPUP_NOT_UNIQUE', 'INITIAL_IDENTITY_UNVERIFIED', 'SHOP_NAME_CHANGED', 'REGION_CHANGED', 'SHOP_ID_CHANGED', 'COLUMN_SCOPE_CHANGED', 'GENERATION_UNVERIFIED', 'GENERATION_CHANGED', 'OWNED_PAGE_CLOSED', 'QUOTA_ALREADY_USED'].includes(data.reason)) entry.reason = data.reason;
        }
        actionSummaryEntries.push(entry);
        if (actionSummaryEntries.length > 48) { actionSummaryEntries.shift(); actionSummaryDropped = Math.min(1000000000, actionSummaryDropped + 1); }
      };
      const stopDialogObservation = transport.observeJavascriptDialogs(sessionId, data => trace('owned_javascript_dialog_observed', data));
      const stopLateObservation = transport.observeLateResponses(sessionId, data => trace('owned_late_command_response_observed', data));
      try {
        await step('Target.activateTarget', () => transport.send('Target.activateTarget', { targetId })); trace('owned_target_activated_before_navigation');
        await step('Page.enable', () => command('Page.enable'));
        await step('Page.bringToFront', () => command('Page.bringToFront')); trace('owned_page_foreground_before_navigation');
        await step('Runtime.enable', () => command('Runtime.enable'));
        await step('Network.enable', () => command('Network.enable', { maxTotalBufferSize: 8 * 1024 * 1024, maxResourceBufferSize: 2 * 1024 * 1024, maxPostDataSize: 0 }));
        if (qaDesktopViewport) {
          await step('Emulation.setDeviceMetricsOverride', () => command('Emulation.setDeviceMetricsOverride', { width: 1440, height: 1600, deviceScaleFactor: 1, mobile: false }));
          trace('owned_qa_viewport_applied', { width: 1440, height: 1600, deviceScaleFactor: 1, mobile: false });
        }
        await step('Page.navigate', () => command('Page.navigate', { url }));
      }
      catch (error) { stopDialogObservation(); stopLateObservation(); stopCategoryObservation(); categoryDefinitions.close(); await transport.send('Target.closeTarget', { targetId }).catch(() => {}); throw error; }
      let latest, categoryDefinitionStarted = false, categoryDefinitionRead, ownedPageClosed = false;
      const snapshotMetrics = { count: 0, failures: 0, totalMs: 0, maxMs: 0, lastMs: 0 };
      const evaluate = async (fn, args = [], { omitCensus = false, omitValues = false, timeoutMs } = {}) => {
        const serializedArgs = fn === visibleSellerDomWithShopPopover ? '(' + visibleSellerDom.toString() + '),(' + visibleShopPopoverState.toString() + '),(' + visibleAttributeCensus.toString() + '),(' + visibleOptionListBusyEvidence.toString() + ')'
          : fn === visibleSellerDom ? (omitCensus ? 'false' : '(' + visibleAttributeCensus.toString() + ')') + ',(' + visibleOptionListBusyEvidence.toString() + ')' + (omitValues ? ',true' : '')
          : fn === visibleSellerStructure ? '(' + visibleComplianceFieldStructureDiagnostic.toString() + ')' : args.map(item => JSON.stringify(item)).join(',') + (fn === clickKnownGuideClose ? ',(' + visibleKnownGuideClose.toString() + ')' : '');
        const result = await command('Runtime.evaluate', { expression: '(' + fn.toString() + ')(' + serializedArgs + ')', returnByValue: true, awaitPromise: fn === visibleControlPoint }, { timeoutMs });
        if (result.exceptionDetails) {
          const exception = result.exceptionDetails.exception, description = exception?.description;
          if(/POD_CUSTOM_COMMA_UNVERIFIED/u.test(description||result.exceptionDetails.text||''))throw Object.assign(new Error('此自定义下拉会拆分逗号或语义尚未确认，已保留原文，未创建。'),{code:'SELLER_CUSTOM_COMMA_UNVERIFIED'});
          const firstLine = typeof description === 'string' ? description.split(/\r?\n/u, 1)[0] : '';
          const controlStale = fn === visibleControlPoint && exception?.className === 'Error'
            && (firstLine === 'Error: POD_CONTROL_STALE' || !description && ['POD_CONTROL_STALE', 'Error: POD_CONTROL_STALE'].includes(result.exceptionDetails.text));
          const obscured = /POD_CONTROL_OBSCURED/u.test(result.exceptionDetails.exception?.description || result.exceptionDetails.text || '');
          const staleGuideClose = /POD_GUIDE_CLOSE_STALE/u.test(result.exceptionDetails.exception?.description || result.exceptionDetails.text || '');
          const staleShop = /POD_SHOP_TRIGGER_STALE/u.test(result.exceptionDetails.exception?.description || result.exceptionDetails.text || '');
          const staleRead = /POD_READ_CONTROL_STALE/u.test(result.exceptionDetails.exception?.description || result.exceptionDetails.text || '');
          const blockedReadModal = /POD_READ_MODAL_BLOCKED/u.test(result.exceptionDetails.exception?.description || result.exceptionDetails.text || '');
          const exceptionType = ['TypeError', 'ReferenceError', 'RangeError', 'SyntaxError', 'Error'].includes(result.exceptionDetails.exception?.className) ? result.exceptionDetails.exception.className : 'Error';
          throw Object.assign(new Error(controlStale ? '页面控件已变化，请重新观察。' : obscured ? '页面控件被弹窗或其他内容遮挡。' : staleGuideClose ? '商品引导关闭控件已变化，需要重新观察。' : staleShop ? '店铺入口已变化，需要重新观察。' : staleRead ? '只读类目或属性控件已变化，未执行点击。' : blockedReadModal ? '页面存在可见弹窗，未选择类目。' : '商家页面控件读取失败。'), { code: controlStale ? 'SELLER_CONTROL_STALE' : obscured ? 'SELLER_CONTROL_OBSCURED' : staleGuideClose ? 'SELLER_GUIDE_CLOSE_STALE' : staleShop ? 'SELLER_SHOP_TRIGGER_STALE' : staleRead ? 'SELLER_READ_CONTROL_STALE' : blockedReadModal ? 'SELLER_READ_MODAL_BLOCKED' : 'SELLER_DOM_FAILED', exceptionType, markerKind: controlStale ? 'control-stale' : 'none' });
        }
        return result.result?.value;
      };
      const ensureOfficial = async () => assertSellerUrl(await evaluate(function () { return location.href; }));
      const ensureUsProductCreate = async () => {
        if (ownedPageClosed) throw new Error('专用商品页面已关闭。');
        const value = new URL(await ensureOfficial());
        if (value.origin !== 'https://seller.us.tiktokshopglobalselling.com' || value.pathname !== '/product/create' || value.hash || value.searchParams.getAll('shop_region').length !== 1 || value.searchParams.get('shop_region') !== 'US') throw new Error('类目数据只能读取当前美国站商品编辑页。');
      };
      const readyInteraction = async () => {
        await ensureOfficial();
        const security = await evaluate(visibleSellerSecurity);
        if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
        // Foreground only this freshly created target. Background seller tabs can
        // acknowledge Input commands without delivering focused keyboard events.
        await transport.send('Target.activateTarget', { targetId }); trace('owned_target_activated');
        await command('Page.bringToFront'); trace('owned_page_foreground');
        await ensureOfficial();
      };
      const pointFor = async (item, visibleIntersection = false, categoryKind = '') => {
        if (categoryKind) {
          const started = Date.now(), deadline = started + 4000; let previous = '', stable = 0, last = null, scrollAllowed = true;
          trace('read_point_preflight_begin', { ref: item.ref, kind: categoryKind, budgetMs: 4000 });
          try {
            for (let sample = 0; sample < 80 && Date.now() < deadline; sample++) {
              last = await evaluate(visibleCategoryControlPoint, [item.selector, { kind: categoryKind, tag: item.tag, text: item.text || '' }, visibleIntersection, scrollAllowed], { timeoutMs: Math.max(1, Math.min(transport.timeoutMs, 1500, deadline - Date.now())) });
              if (last?.scrollAction && last.scrollAction !== 'none') { scrollAllowed = false; trace('read_point_related_scroll', { ref: item.ref, kind: categoryKind, action: last.scrollAction }); }
              const shape = JSON.stringify([last?.rect, last?.point]);
              stable = last?.contained && last.point ? shape === previous ? stable + 1 : 1 : 0; previous = shape;
              if (stable >= 3) { trace('read_point_preflight_end', { ref: item.ref, kind: categoryKind, elapsedMs: Date.now() - started, samples: sample + 1 }); return last.point; }
              if (Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, Math.min(50, deadline - Date.now())));
            }
            trace('observed_control_obscured', { ref: item.ref, hitCheck: last });
            throw Object.assign(new Error('页面控件被弹窗或其他内容遮挡。'), { code: 'SELLER_CONTROL_OBSCURED' });
          } catch (error) { trace('read_point_preflight_failed', { ref: item.ref, kind: categoryKind, elapsedMs: Date.now() - started, code: /^SELLER_[A-Z_]+$/u.test(error.code || '') ? error.code : /超时|timeout/iu.test(error.message || '') ? 'CDP_TIMEOUT' : 'CDP_READ_FAILED' }); throw error; }
        }
        try { return await evaluate(visibleControlPoint, [item.selector, false, visibleIntersection]); }
        catch (error) {
          trace('control_point_preflight_failed', { functionKind: 'control-point', code: ['SELLER_CONTROL_STALE', 'SELLER_CONTROL_OBSCURED', 'SELLER_DOM_FAILED'].includes(error?.code) ? error.code : /超时|timeout/iu.test(error?.message || '') ? 'CDP_TIMEOUT' : 'CDP_READ_FAILED', exceptionType: ['TypeError', 'ReferenceError', 'RangeError', 'SyntaxError', 'Error'].includes(error?.exceptionType) ? error.exceptionType : 'Error', markerKind: error?.code === 'SELLER_CONTROL_STALE' && error.markerKind === 'control-stale' ? 'control-stale' : 'none' });
          if (error.code === 'SELLER_CONTROL_OBSCURED') {
            let hitCheck = null; try { hitCheck = await evaluate(visibleControlPoint, [item.selector, true]); } catch { /* Preserve the original failed preflight. */ }
            trace('observed_control_obscured', { ref: item.ref, hitCheck });
          }
          throw error;
        }
      };
      const control = ref => { const item = latest?.controls?.find(item => item.ref === ref); if (!item || item.disabled) throw new Error('页面控件不可用。'); return item; };
      const customPopupWrites = new Map();
      const customPopupOwner = ref => {
        const item = control(ref), lists = latest?.optionLists || [];
        if (item.role !== 'combobox' || item.tag === 'select' || !item.instanceId || lists.length !== 1 || lists[0].busy !== false
          || (!(item.listIds || []).some(id => (lists[0].relatedListIds || []).includes(id)) && lists[0].customOwnerInstanceId!==item.instanceId)) throw Error('自定义下拉弹层无法与当前字段唯一关联。');
        return {item,list:lists[0],expected:{instanceId:item.instanceId,tag:item.tag}};
      };
      let pointerWindowObserved = false;
      const observeOwnedWindow = async () => {
        if (pointerWindowObserved) return; pointerWindowObserved = true;
        try { const result = await transport.send('Browser.getWindowForTarget', { targetId }); const state = result.bounds?.windowState;
          trace('owned_window_state_observed', { state: ['normal', 'minimized', 'maximized', 'fullscreen'].includes(state) ? state : 'unknown' });
        } catch { trace('owned_window_state_unavailable'); }
      };
      const verifyPointerTarget = async item => {
        const check = await evaluate(visiblePointerTarget, [item.selector, { tag: item.tag, text: item.text || '', instanceId: item.instanceId || '' }]);
        trace('observed_pointer_target_checked', { ref: item.ref, ...check });
        if (!check?.tagMatched || !check?.textMatched || check.instanceMatched === false) throw Object.assign(new Error('已观察控件已变化，未发送鼠标输入。'), { code: 'SELLER_CONTROL_STALE' });
      };
      let writeRecoveryAttempts = 0;
      let writeDiagnostics = { operation: 'read', recoveryAttempts: 0, dispatchState: 'not_dispatched' };
      const clickControl = async (ref, guideClose = false) => {
        let item = control(ref); const before = latest, observed = item;
        writeDiagnostics = { operation: 'click', recoveryAttempts: 0, dispatchState: 'not_dispatched' };
        for (;;) {
          try {
            await readyInteraction(); await observeOwnedWindow(); await verifyPointerTarget(item);
            const verify = async () => !guideClose ? null : evaluate(visibleKnownGuideClose, [item.selector, { tag: item.tag, className: item.uiHints?.className || '' }]);
            if (guideClose) { const check = await verify(); trace('known_guide_close_verified', { ref: item.ref, ...check }); }
            await command('DOM.getDocument', { depth: 0 });
            const point = await pointFor(item); await verify();
            await command('Input.dispatchMouseEvent', { type: 'mouseMoved', buttons: 0, ...point });
            const confirmed = await pointFor(item), check = await verify(); await verifyPointerTarget(item);
            // Once the transport is asked to press, a lost response is uncertain.
            // No branch may repeat this action, including Save draft / Publish.
            writeDiagnostics.dispatchState = 'unknown';
            await command('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', buttons: 1, clickCount: 1, ...confirmed });
            await command('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', buttons: 0, clickCount: 1, ...confirmed });
            writeDiagnostics.dispatchState = 'dispatched'; delete writeDiagnostics.code;
            trace(guideClose ? 'known_guide_close_click_acknowledged' : 'observed_control_click_acknowledged', { ref: item.ref, ...(check || {}) });
            return;
          } catch (error) {
            if (error?.code === 'SELLER_CONTROL_STALE' && writeDiagnostics.dispatchState === 'not_dispatched' && !guideClose && observed.tag !== 'button' && observed.role !== 'button' && writeDiagnostics.recoveryAttempts < 2) {
              try {
                writeDiagnostics.recoveryAttempts++;
                writeRecoveryAttempts = Math.min(2, writeRecoveryAttempts + 1);
                item = findRecoveredSellerControl(before, await readSnapshot(), observed);
                trace('write_control_reobserved', { operation: 'click', recoveryAttempts: writeDiagnostics.recoveryAttempts });
                continue;
              } catch (recoveryError) { error = recoveryError; }
            }
            writeDiagnostics.code = error?.code === 'SELLER_CONTROL_STALE' ? 'SELLER_CONTROL_STALE' : error?.code === 'SELLER_CONTROL_AMBIGUOUS' ? 'SELLER_CONTROL_AMBIGUOUS' : error?.code === 'SELLER_CONTROL_OBSCURED' ? 'SELLER_CONTROL_OBSCURED' : writeDiagnostics.dispatchState === 'unknown' ? 'SELLER_ACTION_UNCONFIRMED' : 'SELLER_OPERATION_FAILED';
            error.diagnostics = { ...writeDiagnostics }; error.dispatchState = writeDiagnostics.dispatchState;
            throw error;
          }
        }
      };
      let guidePromptFrameRecovered = false;
      const dismissKnownProductGuide = async ref => {
        await readyInteraction(); const observed = control(ref);
        const stale = () => Object.assign(new Error('商品引导关闭控件已变化，需要重新观察。'), { code: 'SELLER_GUIDE_CLOSE_STALE' });
        const freshClose = async () => {
          const state = await readSnapshot(), guides = (state.guidanceDialogs || []).filter(item => item.kind === 'image-to-draft');
          if (guides.length !== 1) throw stale();
          const matches = state.controls.filter(item => guides[0].closeRefs.includes(item.ref) && !item.disabled && item.tag === observed.tag && item.uiHints?.className === observed.uiHints?.className);
          if (matches.length !== 1) throw stale(); return matches[0];
        };
        let item = await freshClose(), check = await evaluate(clickKnownGuideClose, [item.selector, { tag: item.tag, className: item.uiHints?.className || '' }]);
        if (check?.action === 'prompt-pending') {
          trace('known_guide_prompt_waiting_for_paint');
          if (guidePromptFrameRecovered) throw stale(); guidePromptFrameRecovered = true;
          await ensureOfficial(); const security = await evaluate(visibleSellerSecurity);
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          await command('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
          await ensureOfficial(); trace('known_guide_prompt_frame_recovered');
          item = await freshClose(); check = await evaluate(clickKnownGuideClose, [item.selector, { tag: item.tag, className: item.uiHints?.className || '' }]);
          if (check?.action === 'prompt-pending') throw stale();
        }
        trace('known_guide_close_dom_click_acknowledged', { ref: item.ref, ...check });
      };
      const toggleShopMenu = async (ref, close) => {
        const observed = control(ref);
        if (!latest?.shopTriggers?.includes(ref) || !observed.text) throw Object.assign(new Error('无法核对当前店铺入口，未切换菜单。'), { code: 'SELLER_SHOP_TRIGGER_STALE' });
        await readyInteraction();
        const fresh = async () => {
          const state = await readSnapshot(), matches = state.controls.filter(item => (state.shopTriggers || []).includes(item.ref) && item.role === 'button' && item.tag === observed.tag && item.text === observed.text && !item.disabled);
          if (matches.length !== 1 || state.identity?.shopName && state.identity.shopName !== observed.text) throw Object.assign(new Error('当前店铺入口不能唯一重新确认。'), { code: 'SELLER_SHOP_TRIGGER_STALE' });
          const menuVisible = state.shopIdentityMenuVisible === true || (state.shopMenuShells || []).some(item => item.containsShopName && item.hasIdentityMarker);
          return { item: matches[0], menuVisible };
        };
        let current = await fresh();
        if (close !== current.menuVisible) { trace('observed_shop_menu_state_already_satisfied', { close }); return; }
        await verifyPointerTarget(current.item); await pointFor(current.item);
        current = await fresh();
        if (close !== current.menuVisible) { trace('observed_shop_menu_state_already_satisfied', { close }); return; }
        const item = current.item; await verifyPointerTarget(item);
        const rawPopover = await evaluate(visibleShopPopoverState);
        if (!close && (rawPopover.paintedCount > 0 || rawPopover.truncated)) throw Object.assign(new Error('店铺弹层可能已经显示，未重复点击入口。'), { code: 'SELLER_SHOP_MENU_PRESENT' });
        const target = await evaluate(clickObservedShopMenu, [item.selector, { tag: item.tag, text: item.text }]);
        trace(close ? 'observed_shop_menu_dom_close_acknowledged' : 'observed_shop_menu_dom_click_acknowledged', { ref: item.ref, target });
      };
      let activeReadPopup = null, readActionSequence = 0; const frameRecoveries = new Set(), categoryColumnFrames = new Set();
      const validReadItem = (state, item, kind) => {
        if (kind === 'category-trigger') return item.role === 'combobox' && /^(商品类目|产品类目|类目|Product category|Category)$/iu.test(item.label);
        if (kind === 'category-option') return Number.isInteger(item.categoryLevel) && ['option', 'menuitem', 'treeitem'].includes(item.role) && (state.categoryColumns || []).some(column => column.level === item.categoryLevel && column.optionRefs.includes(item.ref));
        if (kind === 'attribute-trigger') return item.role === 'combobox' && ['关键属性', '可选属性'].includes(item.section);
        if (kind === 'attribute-option') return activeReadPopup?.kind === 'attribute' && (state.optionLists || []).length === 1 && state.optionLists[0].optionRefs.includes(item.ref);
        return kind === 'show-optional' && item.role === 'button' && (item.text || item.label) === '显示选填属性';
      };
      const readStageMetrics = {}; let expanderObservation = null;
      const readStage = async (stage, operation) => {
        const started = Date.now(); trace('read_snapshot_stage_begin', { stage });
        const metrics = readStageMetrics[stage] ||= { count: 0, failures: 0, totalMs: 0, maxMs: 0, lastMs: 0 }; metrics.count++;
        try { const result = await operation(); trace('read_snapshot_stage_end', { stage, elapsedMs: Date.now() - started,
          ...(stage === 'visible_dom' ? { controlCount: (result?.controls || []).length } : stage === 'attribute_census' ? { groupCount: Array.isArray(result) ? result.length : null } : {}) }); return result; }
        catch (error) { metrics.failures++; trace('read_snapshot_stage_error', { stage, elapsedMs: Date.now() - started,
          code: /^SELLER_[A-Z_]+$/u.test(error.code || '') ? error.code : /超时|timed?\s*out|timeout/iu.test(error.message || '') ? 'CDP_TIMEOUT' : 'CDP_READ_FAILED', exceptionType: error.exceptionType || '' }); throw error; }
        finally { metrics.lastMs = Date.now() - started; metrics.totalMs += metrics.lastMs; metrics.maxMs = Math.max(metrics.maxMs, metrics.lastMs); }
      };
      const readSnapshot = async ({ omitValues = false } = {}) => {
        await readStage('official_url', ensureOfficial);
        const security = await readStage('security', () => evaluate(visibleSellerSecurity)); if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
        const state = await readStage('visible_dom', () => evaluate(visibleSellerDom, [], { omitCensus: true, omitValues })); assertSellerUrl(state.url);
        const attributeGroups = await readStage('attribute_census', () => evaluate(visibleAttributeCensus, [(state.controls || []).map(item => ({ selector: item.selector, label: item.label }))]));
        latest = { ...state, attributeGroups, securityChallenge: security, shopPopoverState: await readStage('shop_popover', () => evaluate(visibleShopPopoverState)) }; return latest;
      };
      const freshReadItem = async (observed, kind) => {
        const state = await readSnapshot(), matches = state.controls.filter(item => !item.disabled && item.tag === observed.tag && item.role === observed.role && item.label === observed.label && item.section === observed.section
          && (!observed.text || item.text === observed.text) && (kind !== 'category-option' || item.categoryLevel === observed.categoryLevel) && validReadItem(state, item, kind));
        const exact = matches.filter(item => item.selector === observed.selector);
        if (exact.length === 1) return exact[0];
        if (matches.length === 1) return matches[0];
        throw Object.assign(new Error('只读控件不能重新唯一定位，未点击。'), { code: 'SELLER_READ_CONTROL_STALE' });
      };
      const clickReadItem = async (observed, kind) => {
        trace('read_control_preflight_begin', { ref: observed.ref, kind, method: 'dom' });
        await readyInteraction(); let item = await freshReadItem(observed, kind);
        const categoryRead = kind === 'category-trigger';
        if (kind !== 'category-option') {
        await verifyPointerTarget(item); let point = await pointFor(item, categoryRead, categoryRead ? kind : '');
        if (categoryRead) {
          item = await freshReadItem(item, kind); await verifyPointerTarget(item); point = await pointFor(item, true, kind);
          await command('Input.dispatchMouseEvent', { type: 'mouseMoved', buttons: 0, ...point });
          trace('read_pointer_moved_to_observed_control', { ref: item.ref, kind, point });
          item = await freshReadItem(item, kind); await pointFor(item, false, kind);
        }
        item = await freshReadItem(item, kind); await verifyPointerTarget(item);
        } else { item = await freshReadItem(item, kind); trace('category_option_semantic_dom_preflight', { ref: item.ref, categoryLevel: item.categoryLevel }); }
        if (kind === 'show-optional') {
          const button = await evaluate(visibleReadExpanderButton, [item.selector]);
          const observed = { type: ['button', 'submit', 'reset'].includes(button?.type) ? button.type : 'unknown', typeAttribute: ['button', 'submit', 'reset', 'absent', 'other'].includes(button?.typeAttribute) ? button.typeAttribute : 'unknown', hasForm: button?.hasForm === true };
          trace('read_expander_button_observed', observed); expanderObservation = { ...observed, responseBudgetMs: 60000, elapsedMs: 0, outcome: 'pending' };
        }
        const clickStarted = Date.now(), responseBudgetMs = kind === 'show-optional' ? 60000 : transport.timeoutMs;
        trace('read_control_dom_click_begin', { ref: item.ref, kind, method: 'dom', responseBudgetMs });
        let result;
        try { result = await evaluate(clickReadSellerControl, [item.selector, { kind, tag: item.tag, text: item.text || '', section: item.section, ...(kind === 'category-option' ? { categoryLevel: item.categoryLevel } : {}) }], { timeoutMs: kind === 'show-optional' ? 60000 : undefined });
          if (kind === 'show-optional') expanderObservation = { ...expanderObservation, elapsedMs: Date.now() - clickStarted, outcome: 'responded' };
          trace('read_control_dom_click_responded', { ref: item.ref, kind, elapsedMs: Date.now() - clickStarted }); }
        catch (error) {
          if (kind === 'show-optional') expanderObservation = { ...expanderObservation, elapsedMs: Date.now() - clickStarted, outcome: /超时|timed?\s*out|timeout/iu.test(error.message || '') ? 'timeout' : 'failed' };
          trace('read_control_dom_click_failed', { ref: item.ref, kind, elapsedMs: Date.now() - clickStarted, code: /超时|timed?\s*out|timeout/iu.test(error.message || '') ? 'CDP_TIMEOUT' : /^SELLER_[A-Z_]+$/u.test(error.code || '') ? error.code : 'CDP_READ_FAILED' });
          if (kind !== 'show-optional' || !/超时|timed?\s*out|timeout/iu.test(error.message || '')) throw error;
          trace('read_control_timeout_postcondition_check', { ref: item.ref, kind });
          let confirmed = false; const started = Date.now();
          try {
            await readStage('frame_owned_target', async () => {
              const result = await transport.send('Target.getTargetInfo', { targetId }); const info = result?.targetInfo;
              if (!info || info.targetId !== targetId || info.type !== 'page') throw Object.assign(new Error('无法确认只读帧恢复的专用页面。'), { code: 'SELLER_FRAME_TARGET_UNVERIFIED' });
              assertSellerUrl(info.url);
            });
            await readStage('frame_capture', () => command('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false })); trace('read_frame_recovery_captured', { kind });
            await readStage('frame_official_url', ensureOfficial); const security = await readStage('frame_security', () => evaluate(visibleSellerSecurity));
            if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          } catch (captureError) { throw captureError.code === 'SELLER_SECURITY_VERIFICATION' ? captureError : error; }
          for (let sample = 0; sample < 4 && Date.now() - started < 30000; sample++) {
            let state; try { state = await readSnapshot(); } catch (readError) { throw readError.code === 'SELLER_SECURITY_VERIFICATION' ? readError : error; }
            const groups = (state.attributeGroups || []).filter(group => group.kind === '可选属性'), group = groups[0];
            const fields = state.controls.filter(control => control.section === '可选属性' && ['combobox', 'textbox'].includes(control.role) || control.section === '可选属性' && ['input', 'textarea', 'select'].includes(control.tag));
            confirmed = groups.length === 1 && group.expanded === true && group.fieldRowsVerified === true && group.scanComplete === true && !group.truncated && group.unresolvedCount === 0
              && group.candidateFieldCount > 0 && group.candidateFieldCount === fields.length && ['candidateControlCount', 'labelledControlCount', 'normalisedControlCount'].every(key => group[key] === fields.length);
            trace('read_control_timeout_postcondition_observed', { ref: item.ref, kind, sample, optionalGroupCount: groups.length, candidateFieldCount: Number.isSafeInteger(group?.candidateFieldCount) ? group.candidateFieldCount : null, capturedVisibleControlCount: fields.length, confirmed });
            if (confirmed) break;
            await new Promise(resolve => setTimeout(resolve, 150));
          }
          if (!confirmed) throw error;
          expanderObservation = { ...expanderObservation, outcome: 'effect_confirmed_after_timeout' };
          result = { effectConfirmedAfterTimeout: true };
        }
        trace('read_control_dom_click_acknowledged', { ref: item.ref, kind, activationTarget: result?.activationTarget, semanticCategoryOption: result?.semanticCategoryOption === true, defaultActionGuarded: result?.defaultActionGuarded === true }); return { item, result };
      };
      return {
        async readPublicProductFormStructure() {
          await ensureUsProductCreate();
          const beforeGeneration = await evaluate(function publicProductFormDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          if (ownedPageClosed || !Number.isFinite(beforeGeneration) || beforeGeneration <= 0) return normalizePublicProductFormStructure(null);
          const securityBefore = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (securityBefore?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          if (securityBefore?.detected !== false) return normalizePublicProductFormStructure(null);
          const raw = await evaluate(visiblePublicProductFormStructure, [], { timeoutMs: 5000 });
          await ensureUsProductCreate();
          const securityAfter = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (securityAfter?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const afterGeneration = await evaluate(function publicProductFormDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          await ensureUsProductCreate();
          if (ownedPageClosed || securityAfter?.detected !== false || beforeGeneration !== afterGeneration) return normalizePublicProductFormStructure(null);
          return normalizePublicProductFormStructure(raw);
        },
        async getDocumentFingerprint() {
          await ensureUsProductCreate();
          const before = await evaluate(function publicOptionListDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          const security = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const after = await evaluate(function publicOptionListDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          const afterSecurity = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (afterSecurity?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          await ensureUsProductCreate();
          if (ownedPageClosed || security?.detected !== false || afterSecurity?.detected !== false || !Number.isFinite(before) || before <= 0 || before !== after) return null;
          return createHash('sha256').update(JSON.stringify(before)).digest('hex');
        },
        async readPublicInputCensus(ref) {
          await ensureUsProductCreate();
          const observed = control(ref), allowed = ['制造商', '制造商地址', '制造商地址（省份）', '制造商地址（城市）', '制造商邮政编码', '制造商邮箱'];
          if (!allowed.includes(observed.label) || observed.section !== '可选属性' || !['div', 'span'].includes(observed.tag) || observed.role !== 'combobox' || observed.disabled || typeof observed.multiple !== 'boolean' || typeof observed.required !== 'boolean') return normalizePublicInputCensus({ reason: 'FIELD_UNVERIFIED' });
          const generation = await evaluate(function publicInputDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          if (!Number.isFinite(generation) || generation <= 0 || ownedPageClosed) return normalizePublicInputCensus(null);
          const sameField = item => item.selector === observed.selector && item.tag === observed.tag && item.role === observed.role && item.label === observed.label && item.section === observed.section && item.multiple === observed.multiple && item.required === observed.required && item.disabled === false;
          const scopeFor = state => {
            if (state.securityChallenge?.detected !== false || state.busy !== false || state.categoryBusy !== false || state.shopIdentityMenuVisible === true || !Array.isArray(state.guidanceDialogs) || state.guidanceDialogs.length || state.unknownModalCount > 0 || state.modalCount > 0 || (state.unknownModals || []).length || (state.optionLists || []).length || (state.categoryColumns || []).length) return null;
            const categories = state.controls.filter(item => item.role === 'combobox' && /^(商品类目|产品类目|类目|Product category|Category)$/iu.test(item.label || ''));
            if (categories.length !== 1 || !state.identity?.shopName || state.identity.region !== 'US') return null;
            const groupKeys = ['groupId', 'kind', 'expanded', 'fieldRowsVerified', 'scanComplete', 'truncated', 'candidateFieldCount', 'candidateControlCount', 'labelledControlCount', 'normalisedControlCount', 'missingLabelCount', 'unknownControlCount', 'unresolvedCount'];
            const groups = Array.isArray(state.attributeGroups) ? state.attributeGroups : [];
            if (!groups.some(group => group.kind === '可选属性' && group.expanded === true && group.fieldRowsVerified === true && group.scanComplete === true && group.truncated === false && group.missingLabelCount === 0 && group.unknownControlCount === 0 && group.unresolvedCount === 0 && group.candidateFieldCount > 0)) return null;
            return JSON.stringify([[categories[0].selector, categories[0].tag, categories[0].label, categories[0].text], [state.identity.shopName, state.identity.region], groups.map(group => groupKeys.map(key => group[key]))]);
          };
          const state = await readSnapshot({ omitValues: true }), fields = state.controls.filter(sameField), scope = scopeFor(state);
          if (fields.length !== 1 || scope === null) return normalizePublicInputCensus({ reason: 'FIELD_UNVERIFIED' });
          const item = fields[0], raw = await evaluate(visiblePublicInputCensus, [item.selector, { tag: item.tag, label: item.label, section: item.section, multiple: item.multiple, required: item.required }], { timeoutMs: 5000 });
          await ensureUsProductCreate(); const after = await readSnapshot({ omitValues: true });
          if (after.controls.filter(sameField).length !== 1 || scopeFor(after) !== scope || state.identity?.shopId && after.identity?.shopId && state.identity.shopId !== after.identity.shopId) return normalizePublicInputCensus({ reason: 'FIELD_UNVERIFIED' });
          const afterRaw = await evaluate(visiblePublicInputCensus, [item.selector, { tag: item.tag, label: item.label, section: item.section, multiple: item.multiple, required: item.required }], { timeoutMs: 5000 });
          const security = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const afterGeneration = await evaluate(function publicInputDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          await ensureUsProductCreate();
          if (ownedPageClosed || security?.detected !== false || generation !== afterGeneration || after.controls.filter(sameField).length !== 1 || scopeFor(after) !== scope) return normalizePublicInputCensus({ reason: 'FIELD_UNVERIFIED' });
          const result = normalizePublicInputCensus(raw), afterResult = normalizePublicInputCensus(afterRaw); if (!result.accepted) return result;
          if (!afterResult.accepted || JSON.stringify(result) !== JSON.stringify(afterResult) || raw.fieldRowIndex !== afterRaw.fieldRowIndex || JSON.stringify(raw.nativePath) !== JSON.stringify(afterRaw.nativePath)) return normalizePublicInputCensus({ reason: 'INPUT_UNVERIFIED' });
          const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
          return { ...result, documentFingerprint: digest(generation), schemaFingerprint: digest([result.ownerTag, result.ownerRole, result.nativeInput, result.fieldRowCount, result.ownerCount, result.nativeInputCount, result.writableInputCount, result.unknownControlCount, result.missingLabelCount, result.disabledControlCount, result.readOnlyControlCount]),
            associationFingerprint: digest([item.selector, item.tag, item.role, item.label, item.section, item.multiple, item.required, raw.fieldRowIndex, raw.nativePath, scope]) };
        },
        async readPublicOptionListCensus(ref) {
          lastRejectedOptionListCensus = null; lastOptionListCensusObservation = null;
          await ensureUsProductCreate();
          const generation = await evaluate(function publicOptionListDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          if (!Number.isFinite(generation) || generation <= 0 || ownedPageClosed) return normalizePublicOptionListCensus(null);
          const observed = control(ref);
          if (!validReadItem(latest, observed, 'attribute-trigger') || typeof observed.multiple !== 'boolean') return normalizePublicOptionListCensus({ reason: 'FIELD_UNVERIFIED' });
          const beforeSecurity = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (beforeSecurity?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          if (beforeSecurity?.detected !== false) return normalizePublicOptionListCensus(null);
          const state = await readSnapshot({ omitValues: true });
          const sameField = item => item.selector === observed.selector && item.tag === observed.tag && item.role === 'combobox'
            && item.label === observed.label && item.section === observed.section && item.multiple === observed.multiple
            && item.required === observed.required && !item.disabled;
          const fields = (state.controls || []).filter(sameField);
          if (fields.length !== 1) return normalizePublicOptionListCensus({ reason: 'FIELD_UNVERIFIED' });
          const item = fields[0], lists = (state.optionLists || []).filter(list => (item.listIds || []).some(id => (list.relatedListIds || []).includes(id)));
          if (lists.length !== 1 || (state.optionLists || []).length !== 1) return normalizePublicOptionListCensus({ reason: 'ASSOCIATION_UNVERIFIED' });
          const list = lists[0], associationIds = (item.listIds || []).filter(id => (list.relatedListIds || []).includes(id));
          const raw = await evaluate(visiblePublicOptionListCensus, [item.selector,
            { tag: item.tag, label: item.label, section: item.section, multiple: item.multiple },
            { containerSelector: list.containerSelector, selector: list.selector, relatedListIds: list.relatedListIds }], { timeoutMs: 5000 });
          await ensureUsProductCreate();
          const after = await readSnapshot({ omitValues: true }), afterFields = (after.controls || []).filter(sameField);
          const afterLists = (after.optionLists || []).filter(current => current.containerSelector === list.containerSelector && current.selector === list.selector
            && associationIds.some(id => (afterFields[0]?.listIds || []).includes(id) && (current.relatedListIds || []).includes(id)));
          const afterSecurity = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (afterSecurity?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const afterGeneration = await evaluate(function publicOptionListDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          await ensureUsProductCreate();
          if (ownedPageClosed || afterSecurity?.detected !== false || generation !== afterGeneration || afterFields.length !== 1 || afterLists.length !== 1 || (after.optionLists || []).length !== 1) return normalizePublicOptionListCensus({ reason: 'ASSOCIATION_UNVERIFIED' });
          const result = normalizePublicOptionListCensus(raw);
          if (!result.accepted) lastRejectedOptionListCensus = safeRejectedOptionListCensus(raw, result.reason);
          const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex'), documentFingerprint = digest(generation);
          const diagnostic = privateOptionListCensusObservation(raw, result, { documentFingerprint, fieldFingerprint: digest([item.selector, item.tag, item.role, item.label, item.section, item.multiple, item.required]) }, optionListObservationBaseline);
          lastOptionListCensusObservation = diagnostic.observation; optionListObservationBaseline = diagnostic.baseline;
          return result.accepted ? { ...result, documentFingerprint } : result;
        },
        async readPublicOptionIdentity(ref) {
          await ensureUsProductCreate();
          const observed = control(ref);
          if (!validReadItem(latest, observed, 'attribute-trigger') || typeof observed.multiple !== 'boolean') return safePublicOptionIdentity({ reason: 'FIELD_UNVERIFIED' });
          const state = await readSnapshot({ omitValues: true });
          const sameField = item => item.selector === observed.selector && item.tag === observed.tag && item.role === 'combobox'
            && item.label === observed.label && item.section === observed.section && item.multiple === observed.multiple && !item.disabled;
          const fields = (state.controls || []).filter(sameField);
          if (fields.length !== 1) return safePublicOptionIdentity({ reason: 'FIELD_UNVERIFIED' });
          const item = fields[0], lists = (state.optionLists || []).filter(list => (item.listIds || []).some(id => (list.relatedListIds || []).includes(id)));
          if (lists.length !== 1) return safePublicOptionIdentity({ reason: 'ASSOCIATION_UNVERIFIED' });
          const list = lists[0], refs = list.optionRefs || [];
          if (!refs.length || refs.length > 32 || new Set(refs).size !== refs.length) return safePublicOptionIdentity({ reason: refs.length > 32 ? 'ROW_LIMIT' : 'ROWS_UNVERIFIED' });
          const rows = refs.map(rowRef => (state.controls || []).filter(row => row.ref === rowRef));
          if (rows.some(matches => matches.length !== 1 || matches[0].role !== 'option' || matches[0].tag !== 'li')) return safePublicOptionIdentity({ reason: 'ROWS_UNVERIFIED' });
          const proof = { containerSelector: list.containerSelector, selector: list.selector, relatedListIds: list.relatedListIds };
          const result = safePublicOptionIdentity(await evaluate(visiblePublicOptionIdentity, [item.selector,
            { tag: item.tag, label: item.label, section: item.section, multiple: item.multiple }, proof, rows.map(([row]) => ({ selector: row.selector, text: row.text }))]));
          await ensureUsProductCreate();
          const after = await readSnapshot({ omitValues: true }), afterFields = (after.controls || []).filter(sameField);
          const associationIds = (item.listIds || []).filter(id => (list.relatedListIds || []).includes(id));
          const afterLists = (after.optionLists || []).filter(current => current.containerSelector === list.containerSelector && current.selector === list.selector
            && associationIds.some(id => (afterFields[0]?.listIds || []).includes(id) && (current.relatedListIds || []).includes(id)));
          if (afterFields.length !== 1 || afterLists.length !== 1) return safePublicOptionIdentity({ reason: 'ASSOCIATION_UNVERIFIED' });
          return result;
        },
        async beginCategoryDefinitionRead() {
          await ensureUsProductCreate();
          if (categoryDefinitionStarted) return;
          const security = await evaluate(visibleSellerSecurity);
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          categoryDefinitions.begin(); categoryDefinitionStarted = true;
        },
        async readCategoryDefinition() {
          await ensureUsProductCreate();
          if (!categoryDefinitionStarted) return { accepted: false, complete: false, reason: 'category_read_not_started' };
          if (!categoryDefinitionRead) categoryDefinitionRead = (async () => {
            const result = await categoryDefinitions.read();
            await ensureUsProductCreate();
            const security = await evaluate(visibleSellerSecurity);
            if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
            trace('observed_category_definition_read', { accepted: result?.accepted === true, propertyCount: Array.isArray(result?.properties) ? result.properties.length : 0 });
            return result;
          })();
          return categoryDefinitionRead;
        },
        async readLocalizedCategoryDefinition(locale) {
          if (ownedPageClosed || !categoryDefinitionStarted) return { accepted: false, complete: false, reason: 'localized_scope_unverified' };
          const result = await categoryDefinitions.readLocalizedCategoryDefinition(locale);
          if (localizedPrivateDiagnostics) localizedPrivateDiagnostics.observer = categoryDefinitions.localizedDiagnostics();
          trace('localized_category_definition_read', { accepted: result?.accepted === true });
          return result;
        },
        async beginQaCategoryNavigationObservation(ref) {
          const rejected = () => ({ accepted: false, reason: 'OBSERVATION_UNVERIFIED', structureOnly: true, complete: false });
          await ensureUsProductCreate(); if (qaCategoryObservation) return rejected();
          const observed = control(ref); if (!validReadItem(latest, observed, 'category-option') || observed.tag !== 'li') return rejected();
          const item = await freshReadItem(observed, 'category-option');
          if (item.selector !== observed.selector || latest.securityChallenge?.detected !== false || (latest.guidanceDialogs || []).length || latest.shopIdentityMenuVisible === true || latest.unknownModalCount > 0 || latest.modalCount > 0) return rejected();
          const generation = await evaluate(function qaCategoryDocumentGeneration() { return performance.timeOrigin; });
          if (!Number.isFinite(generation) || generation <= 0) return rejected();
          const expression = '(' + beginQaCategoryEventsInPage.toString() + ')(' + JSON.stringify(item.selector) + ',' + JSON.stringify({ tag: item.tag, text: item.text }) + ',(' + visibleQaCategoryNavigation.toString() + '))';
          const response = await command('Runtime.evaluate', { expression, returnByValue: false, awaitPromise: false }, { timeoutMs: 5000 });
          const objectId = response.result?.objectId;
          if (response.exceptionDetails || !objectId) return rejected();
          qaCategoryObservation = { objectId, generation };
          await ensureUsProductCreate();
          const security = await evaluate(visibleSellerSecurity);
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const afterGeneration = await evaluate(function qaCategoryDocumentGeneration() { return performance.timeOrigin; });
          await ensureUsProductCreate();
          if (security?.detected !== false || afterGeneration !== generation) return rejected();
          const initial = await command('Runtime.callFunctionOn', { objectId, functionDeclaration: 'function(){return this.accepted===true;}', returnByValue: true, awaitPromise: false }, { timeoutMs: 5000 });
          return initial.result?.value === true ? { accepted: true, structureOnly: true, complete: false } : rejected();
        },
        async readQaCategoryNavigationObservation(finish = false) {
          const rejected = () => ({ accepted: false, reason: 'OBSERVATION_UNVERIFIED', structureOnly: true, complete: false });
          if (typeof finish !== 'boolean' || !qaCategoryObservation) return rejected();
          const observation = qaCategoryObservation;
          await ensureUsProductCreate(); const before = await evaluate(visibleSellerSecurity);
          if (before?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          if (before?.detected !== false) return rejected();
          const raw = await command('Runtime.callFunctionOn', { objectId: observation.objectId, functionDeclaration: 'function(finish){return this.read(finish===true);}', arguments: [{ value: finish }], returnByValue: true, awaitPromise: false }, { timeoutMs: 5000 });
          if (raw.exceptionDetails) return rejected();
          await ensureUsProductCreate(); const after = await evaluate(visibleSellerSecurity);
          if (after?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const generation = await evaluate(function qaCategoryDocumentGeneration() { return performance.timeOrigin; });
          await ensureUsProductCreate();
          if (finish) { qaCategoryObservation = null; await command('Runtime.releaseObject', { objectId: observation.objectId }).catch(() => {}); }
          if (ownedPageClosed || after?.detected !== false || generation !== observation.generation) return rejected();
          return safeQaCategoryObservation(raw.result?.value);
        },
        // Dormant: callers must explicitly opt into this category-only native
        // read action. Publishing and ordinary click/read paths never use it.
        async clickReadCategoryOptionNative(ref) {
          const started = Date.now(); let observed;
          const stale = () => Object.assign(new Error('只读类目选项已变化，未发送后续鼠标输入。'), { code: 'SELLER_READ_CONTROL_STALE' });
          try {
            await ensureUsProductCreate(); observed = control(ref);
            trace('read_category_native_begin', { kind: 'category-option', categoryLevel: observed.categoryLevel });
            if (!validReadItem(latest, observed, 'category-option') || observed.tag !== 'li' || !observed.text || observed.readOnly === true || /(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(observed.uiHints?.className || '')) throw stale();
            let scope;
            const fresh = async () => {
              await ensureUsProductCreate(); const item = await freshReadItem(observed, 'category-option'), state = latest;
              if (item.selector !== observed.selector || item.tag !== observed.tag || item.role !== observed.role || item.text !== observed.text || item.categoryLevel !== observed.categoryLevel || item.readOnly === true
                || item.disabled !== false || /(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(item.uiHints?.className || '') || state.securityChallenge?.detected !== false || state.busy !== false || state.categoryBusy !== false || state.shopIdentityMenuVisible === true) throw stale();
              if (!Array.isArray(state.guidanceDialogs) || state.guidanceDialogs.length || state.modalCount > 0 || state.unknownModalCount > 0 || (state.unknownModals || []).length) throw Object.assign(new Error('页面存在可见弹窗，未点击类目。'), { code: 'SELLER_READ_MODAL_BLOCKED' });
              const columns = (state.categoryColumns || []).filter(column => column.level === item.categoryLevel && (column.optionRefs || []).includes(item.ref));
              if (columns.length !== 1 || columns[0].busy !== false || !columns[0].selector || !columns[0].popupSelector) throw stale();
              const column = columns[0], peers = state.controls.filter(control => (column.optionRefs || []).includes(control.ref) && control.categoryLevel === item.categoryLevel && control.text === item.text);
              if (peers.length !== 1 || new Set(column.optionRefs).size !== column.optionRefs.length || (state.categoryColumns || []).some(other => other !== column && (other.optionRefs || []).includes(item.ref))
                || new Set((state.categoryColumns || []).map(other => other.popupSelector)).size !== 1) throw stale();
              const currentScope = JSON.stringify([column.level, column.selector, column.popupSelector]);
              if (scope && scope !== currentScope) throw stale(); scope = currentScope;
              await ensureUsProductCreate(); return item;
            };
            let item = await fresh(); await readyInteraction(); item = await fresh(); await verifyPointerTarget(item);
            const point = await pointFor(item, true, 'category-option'); item = await fresh(); await verifyPointerTarget(item);
            await command('Input.dispatchMouseEvent', { type: 'mouseMoved', buttons: 0, ...point });
            trace('read_category_native_moved', { kind: 'category-option', categoryLevel: item.categoryLevel, elapsedMs: Date.now() - started });
            item = await fresh(); await verifyPointerTarget(item);
            const confirmed = await pointFor(item, true, 'category-option');
            if (![point.x, point.y, confirmed.x, confirmed.y].every(Number.isFinite) || Math.abs(point.x - confirmed.x) > .5 || Math.abs(point.y - confirmed.y) > .5) throw stale();
            item = await fresh(); await verifyPointerTarget(item);
            await command('Input.dispatchMouseEvent', { type: 'mousePressed', button: 'left', buttons: 1, clickCount: 1, ...confirmed });
            trace('read_category_native_pressed', { kind: 'category-option', categoryLevel: item.categoryLevel, elapsedMs: Date.now() - started });
            await command('Input.dispatchMouseEvent', { type: 'mouseReleased', button: 'left', buttons: 0, clickCount: 1, ...confirmed });
            readActionSequence++;
            trace('read_category_native_acknowledged', { kind: 'category-option', categoryLevel: item.categoryLevel, elapsedMs: Date.now() - started });
          } catch (error) {
            trace('read_category_native_failed', { kind: 'category-option', ...(Number.isInteger(observed?.categoryLevel) ? { categoryLevel: observed.categoryLevel } : {}), elapsedMs: Date.now() - started,
              code: ['SELLER_CONTROL_STALE', 'SELLER_CONTROL_OBSCURED', 'SELLER_READ_CONTROL_STALE', 'SELLER_READ_MODAL_BLOCKED', 'SELLER_SECURITY_VERIFICATION'].includes(error?.code) ? error.code : /超时|timed?\s*out|timeout/iu.test(error?.message || '') ? 'CDP_TIMEOUT' : 'CDP_READ_FAILED' });
            throw error;
          }
        },
        async clickReadControl(ref, kind) {
          const item = control(ref);
          if (!validReadItem(latest, item, kind)) throw Object.assign(new Error('该控件不属于允许的只读类目或属性操作。'), { code: 'SELLER_READ_CONTROL_STALE' });
          if (['category-trigger', 'attribute-trigger', 'show-optional'].includes(kind) && ((latest.optionLists || []).length || (latest.categoryColumns || []).length)) throw Object.assign(new Error('已有下拉菜单尚未关闭，未打开另一个只读控件。'), { code: 'SELLER_READ_CONTROL_STALE' });
          const clicked = await clickReadItem(item, kind);
          readActionSequence++;
          if (kind === 'category-trigger' || kind === 'attribute-trigger') activeReadPopup = { kind: kind === 'category-trigger' ? 'category' : 'attribute', source: clicked.item };
        },
        async prepareReadCategoryColumnFrame(ref) {
          let phase = 'initial', level = null, rejectionRecorded = false;
          const recordRejection = (reason, code = 'SELLER_READ_CONTROL_STALE') => {
            if (rejectionRecorded) return; rejectionRecorded = true;
            trace('read_category_column_frame_rejected', { kind: 'category-option', ...(Number.isInteger(level) && level >= 0 && level < 10 ? { categoryLevel: level } : {}), phase, reason, code });
          };
          const stale = reason => { recordRejection(reason); return Object.assign(new Error('当前类目列或目标已变化，未确认新的画面。'), { code: 'SELLER_READ_CONTROL_STALE' }); };
          const modal = reason => { recordRejection(reason, 'SELLER_READ_MODAL_BLOCKED'); return Object.assign(new Error('页面存在可见弹窗，未确认类目列画面。'), { code: 'SELLER_READ_MODAL_BLOCKED' }); };
          await ensureUsProductCreate();
          if (activeReadPopup?.kind !== 'category') throw stale('POPUP_NOT_OWNED');
          const popupOwner = activeReadPopup, sequence = readActionSequence, observed = control(ref), initialIdentity = latest?.identity || {};
          level = observed.categoryLevel;
          if (!validReadItem(latest, observed, 'category-option') || observed.tag !== 'li' || !observed.text || observed.readOnly === true) throw stale('INITIAL_OPTION_UNVERIFIED');
          let scope = '', knownShopId = initialIdentity.shopId || '';
          const fresh = async () => {
            await ensureUsProductCreate();
            if (activeReadPopup !== popupOwner) throw stale('POPUP_OWNER_CHANGED');
            if (readActionSequence !== sequence) throw stale('ACTION_SEQUENCE_CHANGED');
            let item;
            try { item = await freshReadItem(observed, 'category-option'); }
            catch (error) { recordRejection(error?.code === 'SELLER_READ_CONTROL_STALE' ? 'FRESH_ITEM_UNVERIFIED' : 'FRESH_READ_FAILED', actionSummaryCodes.has(error?.code) ? error.code : 'CDP_READ_FAILED'); throw error; }
            const state = latest;
            if (item.selector !== observed.selector) throw stale('TARGET_SELECTOR_CHANGED');
            if (item.tag !== observed.tag) throw stale('TARGET_TAG_CHANGED');
            if (item.role !== observed.role) throw stale('TARGET_ROLE_CHANGED');
            if (item.text !== observed.text) throw stale('TARGET_TEXT_CHANGED');
            if (item.categoryLevel !== observed.categoryLevel) throw stale('TARGET_LEVEL_CHANGED');
            if (item.disabled !== false) throw stale('TARGET_DISABLED');
            if (item.readOnly === true) throw stale('TARGET_READONLY');
            if (/(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(item.uiHints?.className || '')) throw stale('TARGET_DISABLED_CLASS');
            if (state.securityChallenge?.detected !== false) throw stale('SECURITY_UNVERIFIED');
            if (state.busy !== false) throw stale('PAGE_BUSY');
            if (state.categoryBusy !== false) throw stale('CATEGORY_BUSY');
            if (state.shopIdentityMenuVisible === true) throw stale('SHOP_MENU_VISIBLE');
            if (!Array.isArray(state.guidanceDialogs)) throw modal('GUIDANCE_UNVERIFIED');
            if (state.guidanceDialogs.length) throw modal('GUIDANCE_VISIBLE');
            if (state.modalCount > 0) throw modal('MODAL_VISIBLE');
            if (state.unknownModalCount > 0 || (state.unknownModals || []).length) throw modal('UNKNOWN_MODAL_VISIBLE');
            const columns = (state.categoryColumns || []).filter(column => column.level === item.categoryLevel && (column.optionRefs || []).includes(item.ref));
            if (columns.length !== 1) throw stale('COLUMN_NOT_UNIQUE');
            if (columns[0].busy !== false) throw stale('COLUMN_BUSY');
            if (!columns[0].selector) throw stale('COLUMN_SELECTOR_MISSING');
            if (!columns[0].popupSelector) throw stale('POPUP_SELECTOR_MISSING');
            const column = columns[0], peers = state.controls.filter(control => (column.optionRefs || []).includes(control.ref) && control.categoryLevel === item.categoryLevel && control.text === item.text);
            if (peers.length !== 1) throw stale('PEER_NOT_UNIQUE');
            if (new Set(column.optionRefs).size !== column.optionRefs.length) throw stale('COLUMN_REFS_DUPLICATE');
            if ((state.categoryColumns || []).some(other => other !== column && (other.optionRefs || []).includes(item.ref))) throw stale('OPTION_MULTIPLE_COLUMNS');
            if (new Set((state.categoryColumns || []).map(other => other.popupSelector)).size !== 1) throw stale('POPUP_NOT_UNIQUE');
            const identity = state.identity || {};
            if (!initialIdentity.shopName || initialIdentity.region !== 'US') throw stale('INITIAL_IDENTITY_UNVERIFIED');
            if (identity.shopName !== initialIdentity.shopName) throw stale('SHOP_NAME_CHANGED');
            if (identity.region !== initialIdentity.region) throw stale('REGION_CHANGED');
            if (knownShopId && identity.shopId && knownShopId !== identity.shopId) throw stale('SHOP_ID_CHANGED');
            if (identity.shopId) knownShopId = identity.shopId;
            const currentScope = JSON.stringify([column.level, column.selector, column.popupSelector]); if (scope && scope !== currentScope) throw stale('COLUMN_SCOPE_CHANGED'); scope = currentScope;
            await ensureUsProductCreate(); return item;
          };
          const before = await evaluate(function categoryColumnFrameDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          if (!Number.isFinite(before) || before <= 0) throw stale('GENERATION_UNVERIFIED');
          phase = 'before-frame';
          const item = await fresh(), key = sequence + ':' + item.categoryLevel;
          if (categoryColumnFrames.has(key)) { recordRejection('QUOTA_ALREADY_USED'); return false; }
          categoryColumnFrames.add(key);
          await command('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
          phase = 'after-frame';
          await fresh();
          phase = 'final';
          const after = await evaluate(function categoryColumnFrameDocumentGeneration() { return performance.timeOrigin; }, [], { timeoutMs: 5000 });
          const security = await evaluate(visibleSellerSecurity, [], { timeoutMs: 5000 });
          if (security?.detected) { recordRejection('SECURITY_BLOCKED', 'SELLER_SECURITY_VERIFICATION'); throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' }); }
          await ensureUsProductCreate();
          if (ownedPageClosed) throw stale('OWNED_PAGE_CLOSED');
          if (security?.detected !== false) throw stale('SECURITY_UNVERIFIED');
          if (activeReadPopup !== popupOwner) throw stale('POPUP_OWNER_CHANGED');
          if (readActionSequence !== sequence) throw stale('ACTION_SEQUENCE_CHANGED');
          if (before !== after) throw stale('GENERATION_CHANGED');
          trace('read_category_column_frame_captured', { kind: 'category-option', categoryLevel: item.categoryLevel }); return true;
        },
        async recoverReadFrame(kind) {
          await ensureOfficial();
          const security = await evaluate(visibleSellerSecurity);
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          const known = kind === 'guide' ? (latest?.guidanceDialogs || []).some(item => item.kind === 'image-to-draft') : ['category', 'attribute'].includes(kind) && activeReadPopup?.kind === kind;
          if (!known) throw Object.assign(new Error('没有对应的已观察只读弹层，未执行帧恢复。'), { code: 'SELLER_READ_CONTROL_STALE' });
          const key = kind === 'guide' ? kind : kind + ':' + readActionSequence;
          if (frameRecoveries.has(key)) return false;
          frameRecoveries.add(key);
          await command('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
          await ensureOfficial(); trace('read_frame_recovery_captured', { kind }); return true;
        },
        async closeReadPopup(kind) {
          await readyInteraction(); const state = await readSnapshot();
          const open = kind === 'category' ? (state.categoryColumns || []).length > 0 : kind === 'attribute' ? (state.optionLists || []).length > 0 : true;
          if (!open) { activeReadPopup = null; return; }
          if (!activeReadPopup || activeReadPopup.kind !== kind) throw Object.assign(new Error('当前下拉与已观察只读入口不对应，未关闭。'), { code: 'SELLER_READ_CONTROL_STALE' });
          await clickReadItem({ ...activeReadPopup.source, ...(kind === 'category' ? { text: '' } : {}) }, kind === 'category' ? 'category-trigger' : 'attribute-trigger');
          trace('read_popup_dom_close_acknowledged', { kind }); activeReadPopup = null;
        },
        noteShopMenuObservation(state) {
          const safeClass = value => { const text = String(value || '').slice(0, 180); return /token|secret|password|cookie|https?:|wss?:|@|\b\d{7,}\b/iu.test(text) ? '' : text; };
          trace('shop_menu_state_observed', { phase: ['hover', 'click', 'poll', 'close', 'recovery_check'].includes(state.phase) ? state.phase : 'unknown', sample: Number.isInteger(state.sample) ? state.sample : 0,
            rawPopoverCount: Number.isSafeInteger(state.rawPopover?.rawCount) ? state.rawPopover.rawCount : null, paintedPopoverCount: Number.isSafeInteger(state.rawPopover?.paintedCount) ? state.rawPopover.paintedCount : null, rawPopoverTruncated: state.rawPopover?.truncated === true,
            identityFound: state.identityFound === true, menuVisible: state.menuVisible === true, shells: (state.shells || []).slice(0, 10).map(item => ({ tag: safeClass(item.tag), role: safeClass(item.role), className: safeClass(item.className),
              bounds: Object.fromEntries(['x', 'y', 'width', 'height'].filter(key => Number.isFinite(item.bounds?.[key])).map(key => [key, Math.round(item.bounds[key] * 100) / 100])), containsShopName: item.containsShopName === true, hasIdentityMarker: item.hasIdentityMarker === true, hasVisibleChildren: item.hasVisibleChildren === true })) });
        },
        diagnosticsTrace() { const extra = [...(localizedPrivateDiagnostics ? [structuredClone(localizedPrivateDiagnostics)] : []), ...(lastComplianceFieldStructure ? [{ event: 'compliance_field_structure_observed', structure: structuredClone(lastComplianceFieldStructure) }] : [])]; const entries = actionTrace.map(item => ({ ...item })); return extra.length ? [...entries.slice(-(100 - extra.length)), ...extra] : entries; },
        getWriteDiagnostics() { return { ...writeDiagnostics, recoveryAttempts: Math.max(writeDiagnostics.recoveryAttempts, writeRecoveryAttempts) }; },
        getDiagnostics() { return { version: 1, actionSummary: { eventCount: actionSummaryCount, droppedCount: actionSummaryDropped, eventCounts: { ...actionSummaryCounts }, entries: actionSummaryEntries.map(entry => ({ ...entry })) }, ...(lastRejectedOptionListCensus ? { lastRejectedOptionListCensus: structuredClone(lastRejectedOptionListCensus) } : {}), ...(lastOptionListCensusObservation ? { lastOptionListCensusObservation: structuredClone(lastOptionListCensusObservation) } : {}), ...(lastComplianceFieldStructure ? { lastComplianceFieldStructure: structuredClone(lastComplianceFieldStructure) } : {}) }; },
        performanceDiagnostics() { return { ...snapshotMetrics, readStages: Object.fromEntries(Object.entries(readStageMetrics).map(([stage, metrics]) => [stage, { ...metrics }])), ...(expanderObservation ? { expanderObservation: { ...expanderObservation } } : {}) }; },
        async structureDiagnostics() {
          lastComplianceFieldStructure = null; await ensureOfficial();
          const structure = await evaluate(visibleSellerStructure);
          if (structure?.complianceFieldStructure) lastComplianceFieldStructure = normalizeComplianceFieldStructureDiagnostic(structure.complianceFieldStructure);
          if (structure && typeof structure === 'object') delete structure.complianceFieldStructure;
          return structure;
        },
        async metadata() {
          return evaluate(function () { return { hostname: location.hostname, title: document.title }; });
        },
        async screenshot() {
          await ensureOfficial();
          const result = await command('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true });
          // Discard the result if this owned page navigated while capture was pending.
          await ensureOfficial();
          if (typeof result.data !== 'string' || !result.data || result.data.length > 28000000) throw new Error('诊断截图不可用。');
          return Buffer.from(result.data, 'base64');
        },
        async profileSnapshot() {
          const currentUrl = await evaluate(function () { return location.href; });
          if(currentUrl==='about:blank')return {url:currentUrl,loading:true,identity:{},mainCategory:null};
          assertSellerUrl(currentUrl); const current = new URL(currentUrl);
          if (current.origin !== 'https://seller.us.tiktokshopglobalselling.com' || current.pathname !== '/profile/seller-profile-v2') throw new Error('店铺配对只能读取指定商家主页。');
          const security = await evaluate(visibleSellerSecurity);
          if (security?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
          return { ...await evaluate(visibleSellerProfile), securityChallenge: security };
        },
        async snapshot() {
          const started = Date.now(); snapshotMetrics.count++;
          try {
            const currentUrl = await readStage('snapshot_official_url', () => evaluate(function () { return location.href; }));
            if (currentUrl === 'about:blank') return { url: currentUrl, loading: true, controls: [], scrollables: [], identity: {} };
            assertSellerUrl(currentUrl);
            latest = await readStage(qaCombinedPopoverSnapshot ? 'snapshot_visible_dom_with_popover' : 'snapshot_visible_dom', async () => {
              const state = await evaluate(qaCombinedPopoverSnapshot ? visibleSellerDomWithShopPopover : visibleSellerDom);
              if (qaCombinedPopoverSnapshot && (!state?.shopPopoverState || typeof state.shopPopoverState !== 'object' || Array.isArray(state.shopPopoverState))) throw Object.assign(new Error('商家页面控件读取失败。'), { code: 'SELLER_DOM_FAILED', exceptionType: 'Error' });
              return state;
            }); assertSellerUrl(latest.url);
            latest.securityChallenge = await readStage('snapshot_security', () => evaluate(visibleSellerSecurity));
            if (!qaCombinedPopoverSnapshot) latest.shopPopoverState = await readStage('snapshot_shop_popover', () => evaluate(visibleShopPopoverState));
            return latest;
          } catch (error) { snapshotMetrics.failures++; throw error; }
          finally { const elapsed = Date.now() - started; snapshotMetrics.lastMs = elapsed; snapshotMetrics.totalMs += elapsed; snapshotMetrics.maxMs = Math.max(snapshotMetrics.maxMs, elapsed); }
        },
        async click(ref) { return clickControl(ref); },
        async dismissProductGuide(ref) { return dismissKnownProductGuide(ref); },
        async openObservedShopMenu(ref) { return toggleShopMenu(ref, false); },
        async closeObservedShopMenu(ref) { return toggleShopMenu(ref, true); },
        async hover(ref) {
          await readyInteraction(); const item = control(ref); await observeOwnedWindow(); await verifyPointerTarget(item);
          const point = await pointFor(item); await verifyPointerTarget(item);
          await command('Input.dispatchMouseEvent', { type: 'mouseMoved', buttons: 0, ...point });
          trace('observed_control_hover_acknowledged', { ref: item.ref });
        },
        async fill(ref, value) { await readyInteraction(); await evaluate(interactSellerDom, [control(ref).selector, 'fill', String(value)]); },
        async fillSelectSearch(ref,value){await readyInteraction();const item=control(ref);if(item.role!=='combobox'||item.tag==='select'||item.readOnly===true||!item.instanceId)throw Error('当前下拉不支持已确认的自定义输入。');return evaluate(fillObservedSelectSearch,[item.selector,{instanceId:item.instanceId,tag:item.tag},value]);},
        async openCustomSelectPopup(ref){
          await readyInteraction();const item=control(ref),expected={tag:item.tag,instanceId:item.instanceId};
          if(item.role!=='combobox'||item.tag==='select'||!item.instanceId)throw Error('自定义下拉所属字段未确认。');
          const opening=await evaluate(observeCustomSelectPopupOpening,[item.selector,expected,'begin',null]);
          await clickControl(ref);
          for(let attempt=0;attempt<20;attempt++){
            const bound=await evaluate(observeCustomSelectPopupOpening,[item.selector,expected,'claim',opening.token]);
            if(bound?.accepted===true)return bound;
            await new Promise(resolve=>setTimeout(resolve,50));
          }
          throw Error('自定义下拉的新弹层未与本次明确打开动作绑定。');
        },
        async inspectCustomSelectPopup(ref,mode){await readyInteraction();const {item,list,expected}=customPopupOwner(ref);return evaluate(observedCustomSelectPopup,[item.selector,expected,list,mode,null,'inspect']);},
        async fillCustomSelectPopup(ref,value,mode){
          await readyInteraction();const {item,list,expected}=customPopupOwner(ref);customPopupWrites.delete(item.selector);
          const proof=await evaluate(observedCustomSelectPopup,[item.selector,expected,list,mode,value,'fill']);
          if(proof?.accepted!==true||mode==='text'&&proof.inputValue!==value||typeof proof.inputValue!=='string'||proof.instanceId!==item.instanceId)throw Error('自定义下拉输入未确认。');
          customPopupWrites.set(item.selector,structuredClone(proof));return proof;
        },
        async commitCustomSelectPopup(ref,proof){
          await readyInteraction();const {item,list,expected}=customPopupOwner(ref),saved=customPopupWrites.get(item.selector);
          if(!saved||JSON.stringify(saved)!==JSON.stringify(proof))throw Error('自定义添加操作缺少同一字段的已确认输入。');
          await evaluate(observedCustomSelectPopup,[item.selector,expected,list,saved.mode,saved,'commit']);
          const button={selector:saved.addSelector,tag:'button',text:saved.addText},point=await pointFor(button);
          await evaluate(observedCustomSelectPopup,[item.selector,expected,list,saved.mode,saved,'commit']);await verifyPointerTarget(button);
          customPopupWrites.delete(item.selector);
          await command('Input.dispatchMouseEvent',{type:'mouseMoved',buttons:0,...point});
          await command('Input.dispatchMouseEvent',{type:'mousePressed',button:'left',buttons:1,clickCount:1,...point});
          await command('Input.dispatchMouseEvent',{type:'mouseReleased',button:'left',buttons:0,clickCount:1,...point});
          return {accepted:true,clicked:true,instanceId:item.instanceId,addInstanceId:saved.addInstanceId};
        },
        async closeCustomSelectPopup(ref,mode){
          await readyInteraction();const {item,list,expected}=customPopupOwner(ref);
          const focused=await evaluate(observedCustomSelectPopup,[item.selector,expected,list,mode,null,'focus-owner']);
          const checked=await evaluate(observedCustomSelectPopup,[item.selector,expected,list,mode,null,'inspect']);
          if(focused?.focusedOwnerSearch!==true||focused.ownerSearchValueUnchanged!==true||checked.inputValue!==''||checked.pending||checked.validationError||['instanceId','popupInstanceId','inputInstanceId','addInstanceId','rowInstanceId','editorInstanceId','commaBehavior'].some(key=>focused[key]!==checked[key]))throw Error('自定义下拉关闭前的字段归属、输入或校验状态已变化。');
          await ensureOfficial();
          const escape={key:'Escape',code:'Escape',windowsVirtualKeyCode:27};
          await command('Input.dispatchKeyEvent',{type:'keyDown',...escape});await command('Input.dispatchKeyEvent',{type:'keyUp',...escape});
          let stable=0;
          for(let attempt=0;attempt<25;attempt++){
            await new Promise(resolve=>setTimeout(resolve,100));const state=await readSnapshot(),owners=state.controls.filter(control=>control.selector===item.selector);
            if(owners.length!==1||owners[0].instanceId!==item.instanceId||owners[0].tag!==item.tag||owners[0].disabled)throw Error('自定义下拉关闭期间实际字段已变化。');
            const closed=!(state.optionLists||[]).length&&owners[0].expanded!=='true'&&!/(?:^|\s)(?:core|pulse|arco|ant)-select-open(?:\s|$)/u.test(owners[0].uiHints?.className||'')&&!state.busy;
            stable=closed?stable+1:0;if(stable>=3){customPopupWrites.delete(item.selector);return {accepted:true,closed:true,focusedOwnerSearch:true,instanceId:item.instanceId};}
          }
          throw Error('自定义下拉尚未确认关闭，未继续保存。');
        },
        async fillSpecification(ref,value){await readyInteraction();const item=control(ref);if(!latest?.specificationGroups?.some(group=>group.textEntryRefs.includes(ref)))throw Error('销售规格输入控件尚未观察确认。');await evaluate(fillObservedSpecificationInput,[item.selector,String(value)]);},
        async choose(ref, value) { await readyInteraction(); await evaluate(interactSellerDom, [control(ref).selector, 'select', value]); },
        async press(key) {
          await readyInteraction();
          const keys = { Escape: { key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 }, Enter: { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 }, Tab: { key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9 } };
          if (!keys[key]) throw new Error('不支持的快捷键。');
          await command('Input.dispatchKeyEvent', { type: 'keyDown', ...keys[key] }); await command('Input.dispatchKeyEvent', { type: 'keyUp', ...keys[key] });
          trace('key_input_acknowledged', { key });
        },
        async scroll(selector, top) {
          await readyInteraction();
          if (!latest?.scrollables?.some(item => item.selector === selector)) throw new Error('滚动区域未在页面中观察到。');
          await evaluate(interactSellerDom, [selector, 'scroll', top]);
        },
        async upload(ref, files, root) {
          await readyInteraction();
          const item = control(ref), paths = await validateSpoolFiles(root, files);
          const doc = await command('DOM.getDocument', { depth: 0 });
          const selected = await command('DOM.querySelector', { nodeId: doc.root.nodeId, selector: item.selector });
          const result = await command('DOM.resolveNode', { nodeId: selected.nodeId });
          const child = await command('Runtime.callFunctionOn', { objectId: result.object.objectId, functionDeclaration: `function(){const root=this.closest('[class*="upload"],[class*="Upload"],[data-testid*="upload"]')||this.parentElement;const found=this.matches('input[type="file"]')?[this]:[...root.querySelectorAll('input[type="file"]')];return found.length===1?found[0]:null;}`, returnByValue: false });
          if (child.result?.subtype === 'null' || !child.result?.objectId) throw new Error('无法唯一确定此上传控件对应的文件输入框。');
          await command('DOM.setFileInputFiles', { objectId: child.result.objectId, files: paths });
          await command('Runtime.releaseObject', { objectId: child.result.objectId }); await command('Runtime.releaseObject', { objectId: result.object.objectId });
        },
        async detach() { if (ownedPageClosed) return; ownedPageClosed = true; categoryDefinitionRead = undefined; categoryDefinitionStarted = false; localizedPrivateDiagnostics = null; lastComplianceFieldStructure = null; lastOptionListCensusObservation = null; optionListObservationBaseline = null; qaCategoryObservation = null; stopDialogObservation(); stopLateObservation(); stopCategoryObservation(); categoryDefinitions.close(); await transport.send('Target.detachFromTarget', { sessionId }); },
        async close() { if (ownedPageClosed) return; ownedPageClosed = true; categoryDefinitionRead = undefined; categoryDefinitionStarted = false; localizedPrivateDiagnostics = null; lastComplianceFieldStructure = null; lastOptionListCensusObservation = null; optionListObservationBaseline = null; qaCategoryObservation = null; stopDialogObservation(); stopLateObservation(); stopCategoryObservation(); categoryDefinitions.close(); await transport.send('Target.closeTarget', { targetId }); }
      };
    },
    // Closing this connection never closes the AdsPower profile or user-owned tabs.
    async close() { transport.close(); }
  };
}
