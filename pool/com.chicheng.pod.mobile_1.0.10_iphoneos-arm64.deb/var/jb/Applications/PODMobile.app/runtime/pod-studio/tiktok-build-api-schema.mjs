import {createHash} from 'node:crypto';
import {CATEGORY_BIND_PATH_HASH,API_SCHEMA_SOURCE,API_PROPERTY_FLAGS,API_PROPERTY_CLASSIFICATIONS,API_ZERO_RENDERER_CONTRACT,apiZeroMetadataEvidenceValid,apiPublicMetadataValid,deriveApiDefinitionFields,apiCategoryLeafStructureValid} from './dist/tiktok-builtin-api-proof.js';

const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const own=(v,k)=>{if(!plain(v))return undefined;const d=Object.getOwnPropertyDescriptor(v,k);return d&&Object.hasOwn(d,'value')?d.value:undefined;};
const id=v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,160}$/u.test(v);
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/u.test(v);
const text=(v,n=1024)=>typeof v==='string'&&v===v.trim()&&v.length>0&&v.length<=n&&!/[\u0000-\u001f\u007f]/u.test(v);
const displayText=(v,n=1024)=>typeof v==='string'&&v.trim().length>0&&v.length<=n&&!/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(v);
const sha=v=>createHash('sha256').update(typeof v==='string'?v:JSON.stringify(v)).digest('hex');
const keyFor=(section,label,ordinal)=>'dom-'+sha([section,label,ordinal].join('\0')).slice(0,24);
const COMPONENT_PATHS=new Set(['/api/v1/product/comp/get_schema','/api/v1/product/comp/get_schema_v2','/api/v1/product/comp/refetch_schema'].map(sha));
const MODEL_IDS=new Set(['property_comp','product_property_normal','legal_property_comp','product_property_compliance','compliance_conditional_comp','product_property_normal_comp','product_property_compliance_comp']);
const forbiddenKey=/(?:token|cookie|auth|secret|password|passwd|credentials?|headers?|seller_?id|shop_?id|merchant_?id|environment_?id|binding_?id|session_?id|user_?id)|^(?:actions?|requests?|responses?|__proto__|prototype|constructor)$/iu;
const forbiddenText=/(?:https?|wss?):\/\/|\bBearer\s+\S+|\b(?:password|cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|secret)\s*[:=]/iu;
const fail=reason=>{throw Object.assign(new Error(reason),{code:'BUILD_CATEGORY_API_UNVERIFIED'});};

function publicJson(value,{depth=0,option=false,budget={nodes:0}}={}){
  if(++budget.nodes>2000000||depth>24)fail('public_metadata_limit');
  if(value===null||typeof value==='boolean'||typeof value==='number'&&Number.isFinite(value))return value;
  if(typeof value==='string'){if(value.length>200000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value)||forbiddenText.test(value))fail('unsafe_public_metadata');return value;}
  if(Array.isArray(value)){if(value.length>100000)fail('public_array_limit');return value.map(x=>publicJson(x,{depth:depth+1,option,budget}));}
  if(!plain(value))fail('public_metadata_type');
  const result={};for(const key of Object.keys(value)){
    if(forbiddenKey.test(key))continue;
    const d=Object.getOwnPropertyDescriptor(value,key);if(!d||!Object.hasOwn(d,'value'))fail('public_metadata_accessor');
    result[key]=publicJson(d.value,{depth:depth+1,option:option||key==='options',budget});
  }return result;
}

function requestValid(e,{categoryId,region,locale,pathHash,body,projected=false}){
  return plain(e)&&e.version===1&&e.kind===(projected?'owned-category-public-projection':'owned-category-api-response')&&e.categoryId===categoryId&&e.region===region&&e.locale===locale
    &&e.endpointPathHash===pathHash&&['GET','POST'].includes(e.method)&&e.httpStatus===200&&e.responseComplete===true&&e.scopeVerified===true&&e.noProductContext===true
    &&hash(e.responseSha256)&&(projected?hash(e.publicProjectionSha256)&&e.publicProjectionSha256===sha(body):e.responseSha256===sha(body));
}
function projectionValid(value,kind){
  if(!plain(value)||value.accepted!==true||value.complete!==true||value.source!==(kind==='definition'?'observed-public-bind-info':'observed-public-component-schema')||!plain(value.projection)||value.projection.truncated!==false||value.projection.semanticOmitted!==0)return false;
  if(kind==='definition')return Array.isArray(value.productProperties)&&value.observedPropertyCount===value.productProperties.length&&Array.isArray(value.unknownPropertyKeys)&&value.unknownPropertyKeys.length===0;
  return plain(value.components)&&Array.isArray(value.componentKeys)&&JSON.stringify(value.componentKeys)===JSON.stringify(Object.keys(value.components));
}
function rejectPagination(value){
  if(!plain(value))return;
  for(const key of ['has_more','hasMore','has_next','hasNext','truncated','is_truncated'])if(own(value,key)===true)fail('response_pagination_incomplete');
  for(const key of ['next_cursor','nextCursor','next_page_token']){const v=own(value,key);if(v!==undefined&&v!==null&&v!==''&&v!==0&&v!=='0')fail('response_pagination_incomplete');}
}
function rejectNestedPagination(value,depth=0){if(depth>24)fail('public_metadata_limit');if(Array.isArray(value)){for(const row of value)rejectNestedPagination(row,depth+1);}else if(plain(value)){rejectPagination(value);for(const row of Object.values(value))if(plain(row)||Array.isArray(row))rejectNestedPagination(row,depth+1);}}
function normalizeDefinition(response,categoryId){
  if(!plain(response)||response.code!==0||!plain(response.data)||!Array.isArray(response.data.product_properties)||response.data.product_properties.length>1000)fail('category_definition_response_invalid');
  rejectPagination(response);rejectPagination(response.data);const properties=[],seen=new Set();
  for(const row of response.data.product_properties){
    if(!plain(row)||!id(row.id)||seen.has(row.id)||!displayText(row.name,255)||forbiddenText.test(row.name))fail('category_property_invalid');seen.add(row.id);rejectNestedPagination(row);
    const flags={},classification={};for(const k of API_PROPERTY_FLAGS){if(typeof own(row,k)!=='boolean')fail('category_property_flags_incomplete');flags[k]=row[k];}
    for(const k of API_PROPERTY_CLASSIFICATIONS){const v=own(row.label,k);if(typeof v!=='boolean')fail('category_property_classification_incomplete');classification[k]=v;}
    const reported=Object.hasOwn(row,'values');if(reported&&!Array.isArray(row.values))fail('category_value_list_missing');
    const raw=reported?row.values:[];if(raw.length>100000)fail('category_value_limit');
    const values=[],ids=new Set();for(const value of raw){if(!plain(value)||!id(value.id)||ids.has(value.id)||!displayText(value.name)||forbiddenText.test(value.name))fail('category_value_invalid');ids.add(value.id);values.push({id:value.id,name:value.name});}
    for(const k of ['total_values','value_count','total_value_count'])if(own(row,k)!==undefined&&row[k]!==values.length)fail('category_value_count_mismatch');
    const declaredCount=['total_values','value_count','total_value_count'].map(k=>own(row,k)).find(v=>v!==undefined);
    const property={id:row.id,name:row.name,flags,classification,values,valuesReported:reported,valueCount:values.length,declaredValueCount:declaredCount??null};
    const constraints={};for(const k of ['constraints','constraint','validation','validation_rules','rules','tip','is_sub_cascade_properties','name_key','is_custom','is_number_item','has_image','need_display','is_value_sortable','grouping_property','region_name','prohibit_upload_image','control','description','type','ui_type','property_id','property_name'])if(own(row,k)!==undefined)constraints[k]=publicJson(row[k]);
    if(Object.keys(constraints).length)property.constraints=constraints;
    if(own(row,'ui_properties')!==undefined)property.uiProperties=publicJson(row.ui_properties);
    const cascade={};for(const k of ['cascade_values','sales_cascade_properties_v2','items','children','cascade_type','overwrite_property','cascade_sub_properties','value_id'])if(own(row,k)!==undefined)cascade[k]=publicJson(row[k]);
    if(Object.keys(cascade).length)property.cascade=cascade;
    properties.push(property);
  }
  for(const k of ['property_count','total_properties'])if(own(response.data,k)!==undefined&&response.data[k]!==properties.length)fail('category_property_count_mismatch');
  return {categoryId,properties,salePropertiesExcluded:true,brandsExcluded:true};
}

function normalizeComponent(response,categoryId){
  if(!plain(response)||response.code!==0)fail('component_response_invalid');
  rejectPagination(response);rejectPagination(response.data);
  const stated=[own(response.schema_context,'category_id'),own(response.data?.schema_context,'category_id'),own(response.data,'category_id'),own(response,'category_id')];if(stated.some(v=>v!==undefined&&String(v)!==categoryId))fail('component_category_mismatch');
  const components=own(response,'components')??own(response.data,'components');
  let decoded=own(response,'component_schema')??own(response.data,'component_schema');
  if(components!==undefined){
    if(!Array.isArray(components)||components.length>1000)fail('component_list_invalid');
    const mapped={};for(const component of components){if(!plain(component)||!id(component.id)||Object.hasOwn(mapped,component.id))fail('component_list_invalid');mapped[component.id]=component;}decoded=mapped;
  }
  if(typeof decoded==='string'){if(Buffer.byteLength(decoded)>32*1024*1024)fail('component_body_limit');try{decoded=JSON.parse(decoded);}catch{fail('component_json_invalid');}}
  if(!plain(decoded))fail('component_schema_missing');const source=plain(decoded.models)?decoded.models:decoded,models=[];
  function collect(items,output){if(!Array.isArray(items)||items.length>1000)fail('component_items_invalid');for(const item of items){
    if(!plain(item))fail('component_field_invalid');
    if(id(item.id)&&item.ui_type!==undefined){const field={id:item.id,ui_type:item.ui_type};
      rejectNestedPagination(item.ui_properties);rejectNestedPagination(item.rules);rejectNestedPagination(item.control);
      for(const k of ['type','control','rules','description','ui_properties'])if(own(item,k)!==undefined)field[k]=publicJson(item[k]);
      let itemExtra=own(item,'extra');if(typeof itemExtra==='string'){if(itemExtra.length>200000)fail('component_extra_limit');try{itemExtra=JSON.parse(itemExtra);}catch{fail('component_extra_invalid');}}
      if(plain(itemExtra)){if(!apiPublicMetadataValid(itemExtra))fail('component_extra_not_public');if(Object.keys(itemExtra).length)field.extra=publicJson(itemExtra);}
      output.push(field);
    }else if(Array.isArray(item.items))collect(item.items,output);else fail('component_item_association_unknown');
  }}
  for(const [modelId,model] of Object.entries(source))if(MODEL_IDS.has(modelId)){
    if(!plain(model)||!Array.isArray(model.items)||model.id!==undefined&&model.id!==modelId)fail('component_model_incomplete');const fields=[];collect(model.items,fields);const publicModel={id:modelId,fields};for(const k of ['ui_type','type','control','rules','description','ui_properties'])if(own(model,k)!==undefined){rejectNestedPagination(model[k]);publicModel[k]=publicJson(model[k]);}models.push(publicModel);
  }
  if(!models.length)fail('category_attribute_component_missing');
  return {categoryId,models,complete:true,categoryScoped:true};
}

/** Public metadata only. No browser access or product/merchant writes. */
function buildLeaf(input={},projected=false){
  const rejected=(reason,metadata)=>({accepted:false,metadataComplete:!!metadata,complete:false,issues:[reason],...(metadata?{metadata}:{} )});let publicDefinition;
  try{
    const {categoryId,path,region='US',locale='zh-CN',capturedAt=new Date().toISOString(),requestEvidence,componentRequestEvidence}=input;
    let {definitionResponse,componentResponse}=input;
    const definitionInput=projected?input.definitionProjection:definitionResponse,componentInput=projected?input.componentProjection:componentResponse;
    if(!id(categoryId)||!Array.isArray(path)||!path.length||path.length>10||!path.every(p=>text(p,160))||!/^[A-Z]{2,6}$/u.test(region)||!/^[a-z]{2}(?:-[A-Z]{2})?$/u.test(locale)||!Number.isFinite(Date.parse(capturedAt)))fail('category_build_context_invalid');
    if(!requestValid(requestEvidence,{categoryId,region,locale,pathHash:CATEGORY_BIND_PATH_HASH,body:definitionInput,projected}))fail('category_request_scope_unverified');
    if(projected){if(!projectionValid(definitionInput,'definition'))fail('category_public_projection_incomplete');definitionResponse={code:0,data:{product_properties:definitionInput.productProperties}};}
    publicDefinition=normalizeDefinition(definitionResponse,categoryId);
    if(!COMPONENT_PATHS.has(componentRequestEvidence?.endpointPathHash)||!requestValid(componentRequestEvidence,{categoryId,region,locale,pathHash:componentRequestEvidence.endpointPathHash,body:componentInput,projected}))return rejected('component_request_scope_unverified',publicDefinition);
    if(projected){if(!projectionValid(componentInput,'components'))return rejected('component_public_projection_incomplete',publicDefinition);componentResponse={code:0,component_schema:componentInput.components};}
    const componentDefinition=normalizeComponent(componentResponse,categoryId),mapped=deriveApiDefinitionFields({publicDefinition,componentDefinition,keyFor});
    if(!mapped.accepted)return {accepted:false,metadataComplete:true,complete:false,issues:mapped.issues,metadata:{publicDefinition,componentDefinition}};
    const fields=mapped.fields,leaf={schemaVersion:1,schemaSource:API_SCHEMA_SOURCE,region,locale,categoryId,path:[...path],identityPath:[...(input.identityPath??path)],displayPath:[...(input.displayPath??path)],...(input.categoryIds!==undefined?{categoryIds:[...input.categoryIds]}:{}),capturedAt,fields,publicDefinition,componentDefinition,
      apiDefinitionEvidence:{version:1,kind:'category-form-api-capture',captureEncoding:projected?'whitelisted-public-projection':'api-response',categoryId,region,locale,definitionEndpointPathHash:CATEGORY_BIND_PATH_HASH,componentEndpointPathHash:componentRequestEvidence.endpointPathHash,
        definitionResponseDigestScope:requestEvidence.responseDigestScope??'capture-object-canonical-json',componentResponseDigestScope:componentRequestEvidence.responseDigestScope??'capture-object-canonical-json',
        definitionResponseSha256:requestEvidence.responseSha256,componentResponseSha256:componentRequestEvidence.responseSha256,publicDefinitionSha256:sha(publicDefinition),componentDefinitionSha256:sha(componentDefinition),
        ...(projected?{definitionProjectionSha256:requestEvidence.publicProjectionSha256,componentProjectionSha256:componentRequestEvidence.publicProjectionSha256}:{}),
        responseComplete:true,scopeVerified:true,propertyRowsComplete:true,componentRowsComplete:true,noProductContext:true,domObserved:false,commitVerified:false,
        propertyCount:publicDefinition.properties.length,fieldCount:fields.length,optionCount:fields.reduce((n,f)=>n+f.options.length,0),
        modeledPropertyIds:mapped.modeledPropertyIds,definitionOnlyPropertyIds:mapped.unmodeledPropertyIds},
      captureEvidence:{version:1,kind:'build-time-api-definition',fieldUniverseComplete:true,fieldUniverseScope:'returned-api-models',definitionUniverseComplete:true},commitVerified:false};
    if(!validateApiCategoryLeaf(leaf))fail('api_leaf_validation_failed');return {accepted:true,metadataComplete:true,complete:true,leaf,issues:[]};
  }catch(error){return rejected(error.code==='BUILD_CATEGORY_API_UNVERIFIED'?error.message:'category_build_response_invalid',publicDefinition);}
}

export function buildApiCategoryLeaf(input={}){return buildLeaf(input,false);}
/** Accept only loss-accounted public DTOs plus the owned capture's hash/scope proof. */
export function buildProjectedApiCategoryLeaf(input={}){return buildLeaf(input,true);}
export function buildZeroApiCategoryLeaf(input={}){
  try{
    const {categoryId,path,region='US',locale='zh-CN'}=input;
    if(!id(categoryId)||!Array.isArray(path)||!path.length||path.length>10||!path.every(p=>text(p,160))||!/^[A-Z]{2,6}$/u.test(region)||!/^[a-z]{2}(?:-[A-Z]{2})?$/u.test(locale))fail('category_build_context_invalid');
    const zero={...input.zeroEvidence,rendererContract:{...API_ZERO_RENDERER_CONTRACT}};
    if(!apiZeroMetadataEvidenceValid(zero,{categoryId,region,locale,digestFor:sha}))fail('zero_api_metadata_unverified');
    const sample=zero.samples[1],d=sample.definition,c=sample.typedComponents,publicDefinition={categoryId,properties:[],propertyListState:'absent',dataKeys:[...d.projection.dataKeys],salePropertiesExcluded:true,brandsExcluded:true},componentDefinition={categoryId,models:[],attributeModelsState:'absent',originalComponentIds:[...c.projection.componentIds],complete:true,categoryScoped:true};
    const leaf={schemaVersion:1,schemaSource:API_SCHEMA_SOURCE,region,locale,categoryId,path:[...path],identityPath:[...(input.identityPath??path)],displayPath:[...(input.displayPath??path)],...(input.categoryIds!==undefined?{categoryIds:[...input.categoryIds]}:{}),capturedAt:c.evidence.atUtc,fields:[],publicDefinition,componentDefinition,
      apiDefinitionEvidence:{version:1,kind:'category-form-api-capture',captureEncoding:'api-omitted-attribute-universe',categoryId,region,locale,definitionEndpointPathHash:CATEGORY_BIND_PATH_HASH,componentEndpointPathHash:c.evidence.endpointPathHash,
        definitionResponseSha256:d.evidence.responseSha256,componentResponseSha256:c.evidence.responseSha256,definitionProjectionSha256:d.evidence.publicProjectionSha256,componentProjectionSha256:c.evidence.publicProjectionSha256,
        definitionResponseDigestScope:d.evidence.responseDigestScope,componentResponseDigestScope:c.evidence.responseDigestScope,publicDefinitionSha256:sha(publicDefinition),componentDefinitionSha256:sha(componentDefinition),
        responseComplete:true,scopeVerified:true,propertyRowsComplete:true,componentRowsComplete:true,noProductContext:true,domObserved:false,commitVerified:false,propertyCount:0,fieldCount:0,optionCount:0,modeledPropertyIds:[],definitionOnlyPropertyIds:[],zeroAttributeMetadataEvidence:zero},
      captureEvidence:{version:1,kind:'build-time-api-definition',fieldUniverseComplete:true,fieldUniverseScope:'api-omitted-attribute-universe',definitionUniverseComplete:true},commitVerified:false};
    if(!validateApiCategoryLeaf(leaf))fail('zero_api_leaf_validation_failed');return {accepted:true,metadataComplete:true,complete:true,leaf,issues:[]};
  }catch(error){return {accepted:false,metadataComplete:false,complete:false,issues:[error.code==='BUILD_CATEGORY_API_UNVERIFIED'?error.message:'zero_api_metadata_invalid']};}
}
/** Shape diagnostics only; never returns a leaf or a capture/runtime proof. */
export function inspectApiCategoryResponses({categoryId,definitionResponse,componentResponse}={}){
  try{if(!id(categoryId))fail('category_build_context_invalid');const publicDefinition=normalizeDefinition(definitionResponse,categoryId),componentDefinition=normalizeComponent(componentResponse,categoryId),mapped=deriveApiDefinitionFields({publicDefinition,componentDefinition,keyFor});return {...mapped,publicDefinition,componentDefinition,complete:false,captureVerified:false};}
  catch(error){return {accepted:false,complete:false,captureVerified:false,issues:[error.code==='BUILD_CATEGORY_API_UNVERIFIED'?error.message:'category_build_response_invalid']};}
}

export function validateApiCategoryLeaf(leaf){
  try{return apiCategoryLeafStructureValid(leaf,{keyFor,digestFor:sha});}
  catch{return false;}
}
export {apiCategoryLeafStructureValid,deriveApiDefinitionFields};
