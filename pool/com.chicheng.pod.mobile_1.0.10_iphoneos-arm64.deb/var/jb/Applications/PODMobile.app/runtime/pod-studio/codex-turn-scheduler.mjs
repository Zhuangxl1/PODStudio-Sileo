import {
  DEFAULT_CODEX_MAX_CONCURRENT_TASKS,
  isCodexConcurrentTaskLimit,
} from './dist/codex-concurrency-contract.js';

export function createCodexTurnScheduler(initialLimit=DEFAULT_CODEX_MAX_CONCURRENT_TASKS){
  if(!isCodexConcurrentTaskLimit(initialLimit))throw new RangeError('Codex 并发上限须为 1–10。');
  let limit=initialLimit,scheduled=false,waitingBytes=0;
  const active=new Set(),waiting=[];
  function drain(){
    scheduled=false;
    while(active.size<limit&&waiting.length){
      const job=waiting.shift();
      waitingBytes-=job.bytes;
      active.add(job);
      job.start();
    }
  }
  function schedule(){
    if(scheduled||!waiting.length||active.size>=limit)return;
    scheduled=true;
    queueMicrotask(drain);
  }
  return {
    run(task,{signal,bytes=0}={}){
      if(typeof task!=='function'||!Number.isSafeInteger(bytes)||bytes<0)throw new TypeError('Codex 后台任务无效。');
      return new Promise((resolve,reject)=>{
        let started=false,finished=false;
        const scheduler=this,entry={bytes,start(){
          started=true;
          Promise.resolve().then(()=>{signal?.throwIfAborted();return task();}).then(value=>finish(null,value),finish);
        }};
        const finish=(error,value)=>{if(finished)return;finished=true;signal?.removeEventListener('abort',abort);scheduler.release(entry);error?reject(error):resolve(value);};
        const abort=()=>{if(!started)finish(signal.reason||new Error('Codex 后台任务已取消。'));};
        signal?.addEventListener('abort',abort,{once:true});
        if(signal?.aborted){abort();return;}
        if(scheduler.add(entry)===null)finish(new Error('助手排队已满，请稍后重试。'));
      });
    },
    add(job){
      const queued=waiting.length>0||active.size>=limit;
      if(queued&&(waiting.length>=100||waitingBytes+job.bytes>64*1024*1024))return null;
      waiting.push(job);
      waitingBytes+=job.bytes;
      if(queued)schedule();else drain();
      return queued;
    },
    release(job){
      const index=waiting.indexOf(job);
      if(index>=0)waitingBytes-=waiting.splice(index,1)[0].bytes;
      active.delete(job);
      schedule();
    },
    position(job){return waiting.indexOf(job)+1;},
    setLimit(value){
      if(!isCodexConcurrentTaskLimit(value))throw new RangeError('Codex 并发上限须为 1–10。');
      limit=value;
      schedule();
    },
    status(){return {maxConcurrentTasks:limit,running:active.size,queued:waiting.length};},
  };
}
