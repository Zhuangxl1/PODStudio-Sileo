import {CODEX_TRO_PROVIDER,CODEX_TRO_STRATEGY_VERSION,normalizeTroResearch} from './risk-tro-contract.mjs';
import {mkdir,readFile,open,rename,unlink,lstat} from 'node:fs/promises';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {runRiskReview,codexReviewUnavailable} from './risk-review-runner.mjs';
import {RISK_POLICY_VERSION,RISK_POLICY_SOURCES,riskHash,riskImage,riskText,riskProvenance,validateRiskReview} from './risk-review-contract.mjs';
import {RISK_INPUT_VERSION,DESCRIPTION_IMAGE_LIMIT,RISK_TOTAL_IMAGE_BYTES,describeRiskDescription,riskDescriptionReview,finishRiskDescription,riskImageByteLength,descriptionReviewError} from './risk-description-evidence.mjs';

const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const validScope=value=>typeof value==='string'&&/^[a-f0-9]{64}$/u.test(value);
const validId=value=>typeof value==='string'&&!!value.trim()&&value.length<=160&&!/[\u0000-\u001f\u007f]/u.test(value);
const sameContext=(a,b)=>a?.accountScope===b?.accountScope&&a?.contextId===b?.contextId;
const copy=value=>structuredClone(value);
const safeError=error=>/[\u4e00-\u9fff]/u.test(error?.message||'')?riskText(error.message,240):'商品风险检查未完成，请稍后重试。';
function context(input){if(!validScope(input?.accountScope)||!validId(input?.contextId))throw new Error('风险检查的账号连接已失效。');return{accountScope:input.accountScope,contextId:input.contextId};}
function checkedRow(row){if(!plain(row)||!['string','number'].includes(typeof row.id)||!validId(String(row.id??'')))throw new Error('风险检查商品编号无效。');return copy({...row,id:String(row.id)});}
const summarySeed=row=>validScope(row.reviewSourceHash)?riskHash(['api-snapshot-1',row.reviewSourceHash]):riskHash(Object.fromEntries(['id','title','description','notes','thumbnail','mainImages','imgUrls','shopIds','updatedAt','sourceHash','sourceRevision','reviewRevision'].filter(k=>Object.hasOwn(row,k)).map(k=>[k,row[k]])));
const BASE_DIRTY_TOKEN='0'.repeat(64);

/** A bounded persistent local screening queue; it never edits or publishes products. */
export function createMiaoshouRiskReview({root,readProduct,readImage,findExecutable,runReview=runRiskReview,troProvider,onResult,now=Date.now,
  timeoutMs=150000,maxAttempts=2,concurrency=5,wait=ms=>new Promise(resolve=>setTimeout(resolve,ms))}={}){
  if(typeof readProduct!=='function'||typeof readImage!=='function'||typeof runReview!=='function')throw new Error('商品风险检查连接不完整。');
  const limit=Math.max(1,Math.min(2,Number.isSafeInteger(maxAttempts)?maxAttempts:2)),budget=Math.max(10,Math.min(180000,timeoutMs));
  const parallelism=Number.isFinite(concurrency)?Math.max(1,Math.min(5,Math.floor(concurrency))):5;
  const jobs=new Map(),queue=[],queued=new Set(),active=new Set(),matchingQueue=[],matchingActive=new Set(),dirtyStates=new Map(),mutations=new Map();let current=null,generation=0,closed=false,pumping=false,matchingPump=false,paused=null,availabilityEpoch=0;
  const abortActive=()=>{for(const job of active)job.controller.abort();};
  const currentTro=result=>troProvider!==CODEX_TRO_PROVIDER||
    !result?.findings?.some(finding=>finding.type==='ip'&&finding.subject)||
    (result.troResearch?.provider===CODEX_TRO_PROVIDER&&result.troResearch.strategyVersion===CODEX_TRO_STRATEGY_VERSION);
  const directory=scope=>root?join(root,'miaoshou-risk',scope):null;
  const cachePath=(scope,id)=>join(directory(scope),riskHash(id)+'.json');
  const dirtyPath=(scope,id)=>join(directory(scope),riskHash(id)+'.dirty.json');
  const dirtyKey=(scope,id)=>scope+':'+riskHash(id);
  function live(job){return!closed&&job.generation===generation&&sameContext(job,current)&&jobs.get(job.id)===job;}
  function mutate(scope,id,work){
    const key=dirtyKey(scope,id),previous=mutations.get(key)||Promise.resolve(),next=previous.catch(()=>{}).then(work),tail=next.catch(()=>{});
    mutations.set(key,tail);tail.finally(()=>{if(mutations.get(key)===tail)mutations.delete(key);});return next;
  }
  async function atomicWrite(destination,value,guard=()=>true){
    const temporary=destination+'.'+randomUUID()+'.tmp';let handle;
    try{handle=await open(temporary,'wx');const serialized=JSON.stringify(value);if(Buffer.byteLength(serialized)>262144)throw new Error('检查结果超过存储上限');await handle.writeFile(serialized);await handle.sync();await handle.close();handle=null;
      if(guard()){await rename(temporary,destination);return true;}await unlink(temporary).catch(()=>{});return false;
    }catch(error){await handle?.close().catch(()=>{});await unlink(temporary).catch(()=>{});throw error;}
  }
  async function dirtyToken(scope,id){
    const key=dirtyKey(scope,id);let state=dirtyStates.get(key);
    if(!state){
      state={};state.ready=(async()=>{
        if(!root)return BASE_DIRTY_TOKEN;
        let bytes;try{bytes=await readFile(dirtyPath(scope,id));}catch(error){if(error?.code==='ENOENT')return BASE_DIRTY_TOKEN;throw new Error('该链接的本地更新标记无法读取，请检查本地存储。');}
        try{if(bytes.length>4096)throw Error();const value=JSON.parse(bytes.toString('utf8'));if(value?.version!==1||value.id!==id||value.accountScope!==scope||!validScope(value.token))throw Error();return value.token;}
        catch{throw new Error('该链接的本地更新标记无效，不能复用旧检查结果。');}
      })().then(token=>{state.token=token;return token;});state.ready.catch(()=>{});dirtyStates.set(key,state);
    }
    const token=await state.ready;return dirtyStates.get(key)===state?token:dirtyToken(scope,id);
  }
  async function load(scope,id){
    if(!root)return null;
    try{const bytes=await readFile(cachePath(scope,id));if(bytes.length>262144)return null;const value=JSON.parse(bytes.toString('utf8'));
      if(![1,2].includes(value?.version)||value.inputVersion!==RISK_INPUT_VERSION||value.id!==id||value.accountScope!==scope||value.policyVersion!==RISK_POLICY_VERSION||value.status!=='ready'&&value.status!=='partial')return null;
      if(value.version===2&&(!validScope(value.reviewSourceHash)||!validScope(value.dirtyToken)))return null;
      if(value.reviewSourceHash!==undefined&&!validScope(value.reviewSourceHash)||value.dirtyToken!==undefined&&!validScope(value.dirtyToken))return null;
      if(!/^[a-f0-9]{64}$/u.test(value.inputHash||'')||!plain(value.result))return null;
      const result=validateRiskReview(value.result,{coverage:value.result.coverage,now:Date.parse(value.result.reviewedAt)});
      if(value.result.troResearch)result.troResearch=normalizeTroResearch(value.result.troResearch);
      // This is a saved product check, not a claim of fresh legal research.
      // Its original provider, date, coverage and window remain historical facts.
      const descriptionReview=riskDescriptionReview(value.result.descriptionReview);if(!descriptionReview)return null;result.descriptionReview=descriptionReview;
      if(descriptionReview.kind==='empty'&&result.findings.some(item=>item.field==='description'))return null;
      if(!Number.isFinite(Date.parse(result.reviewedAt)))return null;
      if(value.status==='ready'&&(!Object.values(result.coverage).every(Boolean)||!descriptionReview.complete))return null;
      return{...value,dirtyToken:value.dirtyToken||BASE_DIRTY_TOKEN,result,error:value.status==='partial'?riskText(value.error||'',1000)||descriptionReviewError(descriptionReview):'',provenance:riskProvenance(value.provenance)};
    }catch{return null;}
  }
  async function persist(job,guard=()=>live(job)){
    if(!root||!guard())return;
    if(job.dirtyToken!==await dirtyToken(job.accountScope,job.id)||!guard())return;
    return mutate(job.accountScope,job.id,async()=>{
    const current=()=>guard()&&dirtyStates.get(dirtyKey(job.accountScope,job.id))?.token===job.dirtyToken;
    if(!current())return;
    const dir=directory(job.accountScope);await mkdir(dir,{recursive:true});if(!current())return;
    const destination=cachePath(job.accountScope,job.id);
    const value={version:validScope(job.reviewSourceHash)?2:1,inputVersion:RISK_INPUT_VERSION,id:job.id,accountScope:job.accountScope,policyVersion:RISK_POLICY_VERSION,inputHash:job.inputHash,
      ...(validScope(job.reviewSourceHash)?{reviewSourceHash:job.reviewSourceHash}:{}),dirtyToken:job.dirtyToken,
      sourceRevisionHash:typeof job.row.reviewRevision==='string'?riskHash(job.row.reviewRevision):null,seedHash:job.seedHash,status:job.status,result:job.result,...(job.error?{error:riskText(job.error,1000)}:{}),...(job.provenance?{provenance:job.provenance}:{})};
    return atomicWrite(destination,value,current);
    });
  }
  function adopt(job,cached){Object.assign(job,{status:cached.status,result:copy(cached.result),inputHash:cached.inputHash,error:cached.error||'',provenance:cached.provenance,cached:true,persisted:true,matching:false,needsCheck:false});}
  const matchingCount=()=>[...jobs.values()].filter(job=>job.matching).length;
  const progress=()=>({matching:matchingCount(),reused:[...jobs.values()].filter(job=>job.cached).length,checkTotal:[...jobs.values()].filter(job=>job.needsCheck).length,checkDone:[...jobs.values()].filter(job=>job.needsCheck&&['ready','partial','failed'].includes(job.status)).length});
  function publicJob(job){
    const result=job.result?copy(job.result):undefined;
    return{id:job.id,status:job.status,inputVersion:RISK_INPUT_VERSION,policyVersion:RISK_POLICY_VERSION,policySources:copy(RISK_POLICY_SOURCES),
      ...(result?{result,...result,reviewedAt:result.reviewedAt}:{}),...(job.error?{error:job.error}:{}),
      ...(job.inputHash?{inputHash:job.inputHash}:{}),...(job.provenance?{provenance:copy(job.provenance)}:{}),...(job.status==='pending'||job.status==='running'?{stale:!!result}:{}),
      ...(job.cached?{cached:true}:{}),...(job.matching?{matching:true}:{}),...(paused&&(job.status==='pending'||job.status==='running')?{paused:true,error:paused.error}:{})};
  }
  function notifyResult(job){
    if(!live(job)||!['ready','partial'].includes(job.status)||!job.result||typeof onResult!=='function')return;
    const notification={accountScope:job.accountScope,contextId:job.contextId,review:publicJob(job)};
    // Additional public-source research owns its queue and cannot hold a visual worker.
    try{Promise.resolve(onResult(notification)).catch(()=>{});}catch{}
  }
  function activate(input){
    const selected=context(input);if(sameContext(selected,current))return selected;
    generation++;abortActive();queue.length=0;matchingQueue.length=0;queued.clear();jobs.clear();current=selected;paused=null;availabilityEpoch++;return selected;
  }
  function scheduleCheck(job){if(!live(job))return;job.matching=false;job.needsCheck=true;if(!queued.has(job.id)){queued.add(job.id);queue.push(job.id);}queueMicrotask(pump);}
  async function match(job){
    job.dirtyToken=await dirtyToken(job.accountScope,job.id);if(!live(job))return;
    const cached=await load(job.accountScope,job.id);if(!live(job))return;job.loadedCache=cached;
    if(!job.force&&cached&&currentTro(cached.result)&&cached.reviewSourceHash===job.reviewSourceHash&&cached.dirtyToken===job.dirtyToken){adopt(job,cached);return;}
    if(cached?.result&&!job.result)job.result=copy(cached.result);scheduleCheck(job);
  }
  function pumpMatching(){
    if(matchingPump||closed)return;matchingPump=true;
    try{while(matchingQueue.length&&matchingActive.size<8){const job=matchingQueue.shift();if(!live(job))continue;matchingActive.add(job);
      job.matchWork=match(job).catch(error=>{if(live(job)){job.matching=false;job.status='failed';job.error=safeError(error);}}).finally(()=>{matchingActive.delete(job);notifyResult(job);if(!closed)queueMicrotask(pumpMatching);});
    }}finally{matchingPump=false;}
  }
  function enqueue(input,{force=false,resume=false}={}){
    if(closed)throw new Error('商品风险检查服务已关闭。');context(input);
    if(!Array.isArray(input.records)||input.records.length>50000)throw new Error('本次风险检查商品列表无效。');
    const rows=input.records.map(checkedRow),selected=activate(input);if(resume){paused=null;availabilityEpoch++;}
    let added=0;
    for(const row of rows){const seedHash=summarySeed(row),existing=jobs.get(row.id);
      const stable=!!root&&validScope(row.reviewSourceHash);
      if(existing&&(existing.status==='pending'||existing.status==='running'||stable&&existing.persisted&&currentTro(existing.result)&&['ready','partial'].includes(existing.status))&&existing.seedHash===seedHash&&!force){
        if(stable&&existing.persisted&&['ready','partial'].includes(existing.status)){existing.cached=true;existing.needsCheck=false;}
        continue;
      }
      if(existing&&active.has(existing))existing.controller.abort();
      if(queued.has(row.id)){queued.delete(row.id);for(let n=queue.length-1;n>=0;n--)if(queue[n]===row.id)queue.splice(n,1);}
      const job={...selected,id:row.id,row,seedHash,reviewSourceHash:validScope(row.reviewSourceHash)?row.reviewSourceHash:undefined,generation,status:'pending',force,controller:new AbortController(),...(existing?.result?{result:copy(existing.result)}:{})};
      jobs.set(row.id,job);if(stable){job.matching=true;matchingQueue.push(job);}else scheduleCheck(job);added++;
    }
    queueMicrotask(pumpMatching);queueMicrotask(pump);return{state:paused?'paused':'reviewing',queued:queue.length,running:active.size,maxConcurrent:parallelism,accepted:added,total:jobs.size,...progress(),policyVersion:RISK_POLICY_VERSION,...(paused||{})};
  }
  async function markChanged(input){
    if(closed)throw new Error('商品风险检查服务已关闭。');const selected=context(input);
    if(!Array.isArray(input.ids)||input.ids.length>500||input.ids.some(id=>!['string','number'].includes(typeof id)||!validId(String(id))))throw new Error('风险检查更新范围无效。');
    activate(selected);const ids=[...new Set(input.ids.map(String))],writes=[];
    for(const id of ids){const previous=jobs.get(id);previous?.controller.abort();jobs.delete(id);queued.delete(id);for(let n=queue.length-1;n>=0;n--)if(queue[n]===id)queue.splice(n,1);
      const token=riskHash(randomUUID()),key=dirtyKey(selected.accountScope,id),state={token};
      state.ready=mutate(selected.accountScope,id,async()=>{
        if(root){
          try{await mkdir(directory(selected.accountScope),{recursive:true});await atomicWrite(dirtyPath(selected.accountScope,id),{version:1,accountScope:selected.accountScope,id,token});}
          catch(error){
            // Preserve historical evidence but remove its active lookup name
            // if a dirty marker cannot be committed. This is not a retry or a
            // successful invalidation report; the caller still receives failure.
            try{const source=cachePath(selected.accountScope,id);if((await lstat(source)).isFile())await rename(source,join(directory(selected.accountScope),'invalidated-'+randomUUID()+'.json'));}catch{}
            throw error;
          }
        }
        return token;
      });
      state.ready.catch(()=>{});dirtyStates.set(key,state);writes.push(state.ready);
    }
    try{await Promise.all(writes);}catch{throw new Error('链接已修改，但本地更新标记尚未保存，不能复用旧检查结果；请检查本地存储。');}
    return{marked:ids.length};
  }
  function bounded(operation,job){
    const controller=job.controller;
    let drain;
    const result=new Promise((resolve,reject)=>{
      let settled=false;const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);controller.signal.removeEventListener('abort',abort);error?reject(error):resolve(value);};
      const abort=()=>finish(new Error('商品风险检查上下文已变化。'));
      const timer=setTimeout(()=>{finish(Object.assign(new Error('商品风险检查超时，请稍后重试。'),{code:'RISK_REVIEW_TIMEOUT'}));controller.abort();},budget);
      controller.signal.addEventListener('abort',abort,{once:true});if(controller.signal.aborted){abort();drain=Promise.resolve();return;}
      const work=Promise.resolve().then(()=>{controller.signal.throwIfAborted();return operation();});
      drain=work.then(()=>{},async error=>{if(error?.cleanupDone&&typeof error.cleanupDone.then==='function')await error.cleanupDone;});
      work.then(value=>finish(null,value),error=>finish(error));
    });
    // Abort ends the public attempt promptly, but its worker slot stays owned
    // until the transport/runner finally block has actually finished cleaning up.
    return {result,drained:drain};
  }
  function pause(job,epoch,error){if(live(job)&&epoch===availabilityEpoch&&!paused)paused={error,code:'CODEX_REVIEW_UNAVAILABLE'};}
  async function retryWait(job,delay){
    const signal=job.controller.signal;let abort;
    try{await Promise.race([Promise.resolve().then(()=>{signal.throwIfAborted();return wait(delay);}),new Promise((_resolve,reject)=>{abort=()=>reject(new Error('商品风险检查上下文已变化。'));signal.addEventListener('abort',abort,{once:true});if(signal.aborted)abort();})]);}
    finally{signal.removeEventListener('abort',abort);}
  }
  async function execute(job){
    job.dirtyToken=await dirtyToken(job.accountScope,job.id);if(!live(job))return;
    let cached=Object.hasOwn(job,'loadedCache')?job.loadedCache:await load(job.accountScope,job.id);if(!live(job))return;
    if(!job.force&&cached?.status==='ready'&&currentTro(cached.result)&&typeof job.row.reviewRevision==='string'&&job.row.reviewRevision
      &&cached.dirtyToken===job.dirtyToken&&cached.sourceRevisionHash===riskHash(job.row.reviewRevision)&&cached.seedHash===job.seedHash){adopt(job,cached);return;}
    if(cached?.result&&!job.result)job.result=cached.result;
    for(let attempt=0;attempt<limit;attempt++){
      if(!live(job))return;job.controller=new AbortController();job.status='running';job.error='';
      const controller=job.controller,token=Symbol();let stage='read';job.attemptToken=token;
      const epoch=availabilityEpoch,attemptStarted=Date.now();
      const attemptLive=()=>live(job)&&job.attemptToken===token&&!controller.signal.aborted;
      let operation,retry=false;
      try{
        operation=bounded(async()=>{
          const product=await readProduct(copy(job.row),{signal:controller.signal,contextId:job.contextId,accountScope:job.accountScope});if(!attemptLive())return;
          if(!plain(product))throw new Error('未读取到商品详情，尚未完成风险检查。');
          const provenance=riskProvenance(product.provenance);if(provenance)job.provenance=provenance;
          const rawTitle=typeof product.title==='string'?product.title:'',rawDescription=typeof product.description==='string'?product.description:'';
          const title=rawTitle.slice(0,4000),descriptionEvidence=describeRiskDescription(rawDescription,{available:typeof product.description==='string'&&product.coverage?.description!==false}),description=descriptionEvidence.text;
          const coverage={title:!!title.trim()&&product.coverage?.title!==false,description:!!description&&descriptionEvidence.sourceConfirmed,mainImage:false};
          const images=[],imageRoles=[],descriptionExtraReasons=[];let totalImageBytes=0,descriptionImagesRead=0;
          let image=null,imageError='';const first=Array.isArray(product.mainImages)?product.mainImages[0]:null;
          if(typeof first==='string'&&first){try{image=riskImage(await readImage(first,{signal:controller.signal,contextId:job.contextId,accountScope:job.accountScope}));coverage.mainImage=true;images.push(image);imageRoles.push({field:'mainImage',index:1});totalImageBytes+=riskImageByteLength(image);}catch(error){imageError=safeError(error);}}
          if(descriptionEvidence.sourceConfirmed)for(const [index,url]of descriptionEvidence.urls.slice(0,DESCRIPTION_IMAGE_LIMIT).entries()){
            if(!attemptLive())return;
            if(totalImageBytes>=RISK_TOTAL_IMAGE_BYTES){descriptionExtraReasons.push('image_bytes_limit');break;}
            try{const source=riskImage(await readImage(url,{signal:controller.signal,contextId:job.contextId,accountScope:job.accountScope}));if(!attemptLive())return;const size=riskImageByteLength(source);if(totalImageBytes+size>RISK_TOTAL_IMAGE_BYTES){descriptionExtraReasons.push('image_bytes_limit');continue;}images.push(source);imageRoles.push({field:'description',index:index+1});totalImageBytes+=size;descriptionImagesRead++;}
            catch(error){if(!attemptLive())return;descriptionExtraReasons.push('image_read_failed');}
          }
          coverage.description=descriptionEvidence.sourceConfirmed&&(!!description||descriptionImagesRead>0);
          if(!attemptLive())return;
          const truncated=rawTitle.length>4000;if(truncated)coverage.title=false;
          const inputHash=riskHash({inputVersion:RISK_INPUT_VERSION,title:rawTitle,descriptionSha256:riskHash(rawDescription),imageSha256:image?.sha256||null,descriptionImages:images.filter((_value,index)=>imageRoles[index].field==='description').map(value=>value.sha256),descriptionSource:{kind:descriptionEvidence.kind,total:descriptionEvidence.imageCount,reasons:descriptionEvidence.reasonCodes,extra:descriptionExtraReasons},coverage,policyVersion:RISK_POLICY_VERSION,...(provenance?{apiSource:[provenance.provider,provenance.detailId,provenance.shopId,provenance.endpoint]}:{})});
          if(!job.force&&cached&&currentTro(cached.result)&&cached.dirtyToken===job.dirtyToken&&cached.inputHash===inputHash){
            adopt(job,cached);
            // Legacy checks acquire a trusted list binding only after real
            // product and image hydration confirmed the original input hash.
            if(root&&validScope(job.reviewSourceHash)&&cached.reviewSourceHash!==job.reviewSourceHash){try{await persist(job,attemptLive);}catch{if(attemptLive()){job.cached=false;job.status='partial';job.error=[job.error,'历史检查已匹配，但本地关联尚未保存，请检查本地存储。'].filter(Boolean).join('；');}}}
            return;
          }
          if(!coverage.title&&!coverage.description&&!coverage.mainImage)throw new Error('标题、描述与主图均未完整读取，尚未完成风险检查。');
          let codexPath;stage='resolve';
          if(findExecutable){try{codexPath=await findExecutable();if(typeof codexPath!=='string'||!codexPath.trim())throw Error();}
            catch{throw codexReviewUnavailable('主机 Codex 尚未就绪，请检查登录后点击重新检查。');}}
          if(!attemptLive())return;
          stage='model';const raw=await runReview({title,description,coverage,image,images,imageRoles,descriptionEvidence:{kind:descriptionEvidence.kind,sourceConfirmed:descriptionEvidence.sourceConfirmed,textCharacters:descriptionEvidence.textCharacters,textTruncated:descriptionEvidence.textTruncated,htmlTruncated:descriptionEvidence.htmlTruncated,imageCount:descriptionEvidence.imageCount,imageIncludedCount:descriptionImagesRead},...(provenance?{provenance}:{})},{codexPath,signal:controller.signal,now,timeoutMs:Math.max(10,budget-(Date.now()-attemptStarted)-3000)});
          if(!attemptLive())return;
          const result=validateRiskReview(raw,{coverage,now:now()});
          if(raw.troResearch)result.troResearch=normalizeTroResearch(raw.troResearch);
          result.descriptionReview=finishRiskDescription(descriptionEvidence,{imagesRead:descriptionImagesRead,modelChecked:result.coverage.description,extraReasons:descriptionExtraReasons});
          if(result.descriptionReview.kind==='empty'&&result.descriptionReview.complete)result.coverage.description=true;
          const complete=Object.values(result.coverage).every(Boolean)&&result.descriptionReview.complete&&!truncated;
          Object.assign(job,{inputHash,result,status:complete?'ready':'partial',cached:false});
          if(!complete)job.error=[imageError,descriptionReviewError(result.descriptionReview),...(!Object.values(result.coverage).every(Boolean)?['部分内容尚未检查：'+['title','description','mainImage'].filter(k=>!result.coverage[k]).map(k=>({title:'标题',description:'描述',mainImage:'第一张主图'})[k]).join('、')]:[])].filter(Boolean).join('；');
          try{job.persisted=!!await persist(job,attemptLive);}catch{if(attemptLive()){job.error=[job.error,'本次风险检查结果尚未保存到本机，可重新检查。'].filter(Boolean).join('；');job.status='partial';job.persisted=false;}}
        },job);await operation.result;
        return;
      }catch(error){
        if(!live(job))return;job.error=safeError(error);job.status='failed';
        if(error?.code==='CODEX_REVIEW_UNAVAILABLE'){pause(job,epoch,job.error);return;}
        if(['RISK_REVIEW_TIMEOUT','CODEX_REVIEW_TIMEOUT'].includes(error?.code)&&stage!=='read'&&attempt+1===limit){job.error='Codex 商品检查持续超时，请检查主机连接后重新检查。';pause(job,epoch,job.error);return;}
        retry=attempt+1<limit;
      }finally{await operation?.drained;}
      if(!retry||!live(job)||paused)return;
      // A deadline-aborted attempt has drained; use a fresh controller for its
      // interruptible backoff so reset/close can still cancel the owned worker.
      job.controller=new AbortController();
      try{await retryWait(job,250*(attempt+1));}catch{return;}
    }
  }
  function pump(){
    if(pumping||closed||paused)return;pumping=true;
    try{while(queue.length&&active.size<parallelism&&!closed&&!paused){
      // A replaced same-ID job waits for its canceled predecessor to drain.
      const next=queue.findIndex(id=>![...active].some(job=>job.id===id));if(next<0)break;
      const [id]=queue.splice(next,1);queued.delete(id);const job=jobs.get(id);if(!job||!live(job))continue;
      active.add(job);job.status='running';
      job.work=execute(job).catch(error=>{if(live(job)){job.status='failed';job.error=safeError(error);}}).finally(()=>{active.delete(job);notifyResult(job);if(!closed&&!paused)queueMicrotask(pump);});
    }}finally{pumping=false;}
  }
  async function snapshot(input){
    const selected=context(input);if(closed)return{state:'closed',queued:0,running:active.size,maxConcurrent:parallelism,results:[]};
    if(!current)current=selected;
    if(!sameContext(selected,current))return{state:'unavailable',queued:0,running:active.size,maxConcurrent:parallelism,results:[]};
    const ids=input.ids===undefined?[...jobs.keys()].slice(0,500):input.ids;
    if(!Array.isArray(ids)||ids.length>500||ids.some(id=>!['string','number'].includes(typeof id)||!validId(String(id))))throw new Error('风险检查读取范围无效。');
    const readGeneration=generation,selectedIds=[...new Set(ids.map(String))],savedJobs=new Map();
    for(const value of selectedIds)if(!jobs.has(value)){
      try{const token=await dirtyToken(selected.accountScope,value),saved=await load(selected.accountScope,value);if(saved&&saved.dirtyToken===token)savedJobs.set(value,{id:value,...saved,cached:true});}
      catch(error){savedJobs.set(value,{id:value,status:'failed',error:safeError(error)});}
    }
    if(readGeneration!==generation||!sameContext(selected,current))return{state:'unavailable',queued:0,running:active.size,maxConcurrent:parallelism,results:[]};
    // Construct the public view only after disk reads; no stale running entry
    // may accompany a newly paused queue in the same snapshot.
    const results=selectedIds.map(value=>{const job=jobs.get(value)||savedJobs.get(value);return job?publicJob(job):{id:value,status:'pending',policyVersion:RISK_POLICY_VERSION,policySources:copy(RISK_POLICY_SOURCES)};});
    const counts={pending:0,running:0,ready:0,partial:0,failed:0};for(const job of jobs.values())counts[job.status]=(counts[job.status]||0)+1;
    const running=active.size,summary=progress();return{state:paused?'paused':queue.length||running||summary.matching?'reviewing':'idle',queued:queue.length,running,maxConcurrent:parallelism,total:jobs.size,counts,results,...summary,policyVersion:RISK_POLICY_VERSION,...(paused||{})};
  }
  return{enqueue,snapshot,markChanged,retry:input=>enqueue(input,{force:true,resume:true}),activate,reset(){generation++;abortActive();queue.length=0;matchingQueue.length=0;queued.clear();jobs.clear();current=null;paused=null;availabilityEpoch++;},
    close(){closed=true;generation++;abortActive();queue.length=0;matchingQueue.length=0;queued.clear();jobs.clear();current=null;paused=null;availabilityEpoch++;return Promise.allSettled([...active].map(job=>job.work).concat([...matchingActive].map(job=>job.matchWork),[...mutations.values()]));}};
}
