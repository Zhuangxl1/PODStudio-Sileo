import http from 'node:http';
import https from 'node:https';
import tls from 'node:tls';
import {EventEmitter} from 'node:events';
import {isIP} from 'node:net';
import {resolveCodexNetworkEnvironment} from './codex-network.mjs';

const DEFAULT_TIMEOUT=20000;
const proxyError=(code='SOURCE_IMAGE_PROXY')=>Object.assign(new Error('主图代理连接失败，请检查主机网络后重试。'),{code});
const findEnv=(env,name)=>{
  if(typeof env?.[name.toLowerCase()]==='string'&&env[name.toLowerCase()].trim())return env[name.toLowerCase()].trim();
  if(typeof env?.[name.toUpperCase()]==='string'&&env[name.toUpperCase()].trim())return env[name.toUpperCase()].trim();
  return '';
};
function proxyConfig(env){
  const value=findEnv(env,'https_proxy')||findEnv(env,'all_proxy')||findEnv(env,'http_proxy');
  const bypass=findEnv(env,'no_proxy');
  if(!value)return {proxy:null,bypass};
  if(value.length>2048||/[\s\\]/.test(value))throw proxyError('SOURCE_IMAGE_PROXY_CONFIG');
  let proxy;try{proxy=new URL(value);}catch{throw proxyError('SOURCE_IMAGE_PROXY_CONFIG');}
  if(!['http:','https:'].includes(proxy.protocol)||!proxy.hostname||proxy.username||proxy.password||proxy.search||proxy.hash||proxy.pathname!=='/'||proxy.port&&(!/^\d+$/.test(proxy.port)||Number(proxy.port)<1||Number(proxy.port)>65535))throw proxyError('SOURCE_IMAGE_PROXY_CONFIG');
  return {proxy,bypass};
}
const normalizedHost=value=>String(value||'').toLowerCase().replace(/^\[|\]$/g,'').replace(/\.$/,'');

/** NO_PROXY contains exact hosts or domain suffixes, optionally constrained by port. */
export function miaoshouImageProxyBypass(url,value){
  if(typeof value!=='string'||!value||value.length>16384)return false;
  const host=normalizedHost(url.hostname),port=url.port||'443';
  for(const raw of value.split(/[\s,]+/).slice(0,256)){
    let token=raw.trim().toLowerCase();if(!token)continue;
    if(token==='*')return true;
    let tokenPort='';
    if(token.startsWith('[')){
      const match=token.match(/^\[([^\]]+)\](?::(\d+))?$/);if(!match)continue;
      token=match[1];tokenPort=match[2]||'';
    }else if(token.indexOf(':')===token.lastIndexOf(':')&&token.includes(':')){
      const match=token.match(/^(.+):(\d+)$/);if(!match)continue;
      token=match[1];tokenPort=match[2];
    }
    if(tokenPort&&Number(tokenPort)!==Number(port))continue;
    token=normalizedHost(token.replace(/^\*?\./,''));
    if(!token||token.includes('*')||token.includes('/'))continue;
    if(host===token||!isIP(token)&&host.endsWith('.'+token))return true;
  }
  return false;
}

/**
 * https.get-compatible transport for the existing, separately validated image reader.
 * The reader supplies its pinned lookup; CONNECT never resolves the CDN a second time.
 * Configuration is read only and cached briefly. No credentials or URLs are logged.
 */
export function createMiaoshouProxyGet({
  isPublicIPv4,
  resolveEnvironment=resolveCodexNetworkEnvironment,
  directGet=https.get,
  httpRequest=http.request,
  httpsRequest=https.request,
  tlsConnect=tls.connect,
  createAgent=options=>new https.Agent(options),
  now=Date.now,
  cacheMs=1000
}={}){
  if(typeof isPublicIPv4!=='function')throw new TypeError('isPublicIPv4 is required');
  const ttl=Number.isFinite(cacheMs)?Math.min(5000,Math.max(0,cacheMs)):1000;
  let configPromise=null,expires=0;
  function configured(){
    if(!configPromise||now()>=expires){
      expires=now()+ttl;
      configPromise=Promise.resolve().then(()=>resolveEnvironment()).then(proxyConfig);
    }
    return configPromise;
  }
  return function getImageThroughConfiguredProxy(address,options={},onResponse){
    const facade=new EventEmitter();
    facade.destroyed=false;
    let targetRequest,connectRequest,tunnelSocket,secureSocket,agent,timer,finished=false;
    const duration=Number.isFinite(options.timeout)&&options.timeout>0?Math.min(DEFAULT_TIMEOUT,options.timeout):DEFAULT_TIMEOUT;
    const deadline=now()+duration;
    const destroy=resource=>{try{resource?.destroy();}catch{}};
    function cleanup(){
      clearTimeout(timer);destroy(targetRequest);destroy(connectRequest);destroy(secureSocket);
      if(tunnelSocket!==secureSocket)destroy(tunnelSocket);
      destroy(agent);
    }
    facade.destroy=error=>{
      if(facade.destroyed)return facade;
      facade.destroyed=true;finished=true;cleanup();
      if(error)queueMicrotask(()=>facade.emit('error',error));
      return facade;
    };
    facade.abort=()=>facade.destroy();
    const fail=error=>{
      if(finished||facade.destroyed)return;
      const code=typeof error?.code==='string'&&/^[A-Z][A-Z_\d]{1,80}$/.test(error.code)?error.code:'SOURCE_IMAGE_PROXY';
      facade.destroy(proxyError(code));
    };
    const timeout=()=>{
      if(finished||facade.destroyed)return;
      facade.emit('timeout');fail(proxyError('ETIMEDOUT'));
    };
    timer=setTimeout(timeout,duration);
    const remaining=()=>Math.max(1,deadline-now());
    const active=()=>{
      if(finished||facade.destroyed)return false;
      if(now()>=deadline){timeout();return false;}
      return true;
    };
    function responseReceived(response){
      if(finished||facade.destroyed){destroy(response);return;}
      response.once('end',()=>{finished=true;cleanup();});
      response.once('close',()=>{finished=true;cleanup();});
      try{if(typeof onResponse==='function')onResponse(response);}catch(error){fail(error);}
    }
    function watchRequest(request){
      targetRequest=request;
      request.on('error',fail);request.on('timeout',timeout);
      if(facade.destroyed||finished)destroy(request);
    }
    async function pinnedAddress(url){
      if(typeof options.lookup!=='function')throw proxyError('SOURCE_IMAGE_PROXY_TARGET');
      const records=await new Promise((resolve,reject)=>{
        options.lookup(url.hostname,{family:4,all:true},(error,result)=>error?reject(error):resolve(result));
      });
      if(!Array.isArray(records)||!records.length||records.some(record=>typeof record?.address!=='string'||isIP(record.address)!==4||!isPublicIPv4(record.address)))throw proxyError('SOURCE_IMAGE_PROXY_TARGET');
      return records[0].address;
    }
    Promise.resolve().then(async()=>{
      let url;try{url=address instanceof URL?new URL(address.href):new URL(address);}catch{throw proxyError('SOURCE_IMAGE_PROXY_TARGET');}
      if(url.protocol!=='https:'||url.username||url.password||url.port&&url.port!=='443')throw proxyError('SOURCE_IMAGE_PROXY_TARGET');
      const config=await configured();
      if(!active())return;
      const headers=Object.fromEntries(Object.entries(options.headers||{}).filter(([name])=>!/^proxy-(?:authorization|connection)$/i.test(name)));
      if(!config.proxy||miaoshouImageProxyBypass(url,config.bypass)){
        watchRequest(directGet(url,{...options,headers,rejectUnauthorized:true,timeout:remaining()},responseReceived));return;
      }
      const ip=await pinnedAddress(url);
      if(!active())return;
      const proxy=config.proxy;
      agent=createAgent({keepAlive:false,maxSockets:1});
      agent.createConnection=(_connectionOptions,callback)=>{
        if(!active()){callback(proxyError('ECONNRESET'));return;}
        let called=false;
        const done=(error,socket)=>{
          if(called){if(socket)destroy(socket);return;}called=true;
          if(finished||facade.destroyed){destroy(socket);return callback(proxyError('ECONNRESET'));}
          callback(error,socket);
        };
        const connectionFailure=error=>{done(proxyError(error?.code||'SOURCE_IMAGE_PROXY'));fail(error);};
        const requestProxy=proxy.protocol==='https:'?httpsRequest:httpRequest;
        try{
          connectRequest=requestProxy({
            protocol:proxy.protocol,hostname:normalizedHost(proxy.hostname),port:Number(proxy.port)||(proxy.protocol==='https:'?443:80),
            method:'CONNECT',path:ip+':443',headers:{Host:ip+':443'},agent:false,
            rejectUnauthorized:true,timeout:remaining()
          });
          connectRequest.on('error',connectionFailure);connectRequest.on('timeout',timeout);
          connectRequest.once('response',response=>{response.resume?.();connectionFailure(proxyError('SOURCE_IMAGE_PROXY_HTTP'));});
          connectRequest.once('connect',(response,socket,head)=>{
            tunnelSocket=socket;
            socket.on('error',connectionFailure);
            if(finished||facade.destroyed){destroy(socket);return;}
            if(response.statusCode!==200||head?.length){destroy(socket);connectionFailure(proxyError('SOURCE_IMAGE_PROXY_HTTP'));return;}
            socket.setTimeout?.(0);
            try{
              secureSocket=tlsConnect({socket,servername:normalizedHost(url.hostname),rejectUnauthorized:true,minVersion:'TLSv1.2'});
              secureSocket.on('error',connectionFailure);
              secureSocket.once('secureConnect',()=>{
                if(finished||facade.destroyed){destroy(secureSocket);return;}
                done(null,secureSocket);
              });
              if(finished||facade.destroyed)destroy(secureSocket);
            }catch(error){connectionFailure(error);}
          });
          if(finished||facade.destroyed)destroy(connectRequest);else connectRequest.end();
        }catch(error){connectionFailure(error);}
      };
      watchRequest(directGet(url,{...options,headers,agent,servername:normalizedHost(url.hostname),rejectUnauthorized:true,timeout:remaining()},responseReceived));
    }).catch(fail);
    return facade;
  };
}
