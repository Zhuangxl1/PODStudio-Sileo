import {open,readFile,mkdir,rename,unlink,readdir} from 'node:fs/promises';
import {resolve,isAbsolute} from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {validateCategoryAttributeTemplate,validateCategoryAttributeDefinition} from './dist/miaoshou-category-attribute-template-schema.js';
import {miaoshouId} from './dist/miaoshou-policy.js';

const failure=(message,code='MIAOSHOU_ATTRIBUTE_TEMPLATE_INVALID',status=400)=>Object.assign(new Error(message),{code,status});
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const id=value=>typeof value==='string'&&/^[a-f\d]{8}-[a-f\d]{4}-4[a-f\d]{3}-[89ab][a-f\d]{3}-[a-f\d]{12}$/u.test(value);
const normalizedName=value=>value.normalize('NFKC').trim().toLowerCase();
const empty=()=>({version:1,revision:0,items:[]});
const clone=value=>structuredClone(value);
const invalidStore=()=>failure('类目属性模板库未能读取，请保留原文件并核对后重试。','MIAOSHOU_ATTRIBUTE_TEMPLATE_STORAGE',503);

/** Account + leaf-category host library, with import support for old shop libraries. */
export function createMiaoshouCategoryAttributeTemplates({root,limit=200,now=Date.now}={}){
  if(root!==undefined&&(typeof root!=='string'||!isAbsolute(root)))throw new TypeError('类目属性模板库须使用主机绝对目录。');
  if(!Number.isSafeInteger(limit)||limit<1||limit>1000)throw new TypeError('类目属性模板数量上限无效。');
  const memory=new Map(),queues=new Map();let closed=false;
  const scope=input=>{if(closed)throw failure('类目属性模板库正在关闭。','MIAOSHOU_ATTRIBUTE_TEMPLATE_CLOSED',503);if(!plain(input)||typeof input.accountScope!=='string'||!/^[a-f\d]{64}$/u.test(input.accountScope)||input.scope!==undefined&&!['shop','category'].includes(input.scope))throw failure('类目属性模板账号或范围无效。');const shop=miaoshouId(input.shopId);return createHash('sha256').update(JSON.stringify([input.accountScope,input.scope==='category'?'category':shop,miaoshouId(input.categoryId)])).digest('hex');};
  const pathFor=scope=>root?resolve(root,'miaoshou-attribute-templates',scope+'.json'):null;
  function checked(data,expectedCategoryId){
    if(!plain(data)||Object.keys(data).some(key=>!['version','revision','items','defaultId','editorDefaultId','legacyScopes'].includes(key))||data.version!==1||!Number.isSafeInteger(data.revision)||data.revision<0||!Array.isArray(data.items)||data.items.length>limit)throw invalidStore();
    const legacyScopes=data.legacyScopes??[];
    if(!Array.isArray(legacyScopes)||legacyScopes.some(key=>typeof key!=='string'||!/^[a-f\d]{64}$/u.test(key))||new Set(legacyScopes).size!==legacyScopes.length)throw invalidStore();
    const names=new Set(),ids=new Set(),items=[];
    for(const item of data.items){
      if(!plain(item)||Object.keys(item).some(key=>!['id','name','attributes','definition','createdAt','updatedAt'].includes(key))||!id(item.id)||ids.has(item.id)||!['createdAt','updatedAt'].every(key=>typeof item[key]==='string'&&Number.isFinite(Date.parse(item[key]))))throw invalidStore();
      let preset,definition;try{definition=item.definition===undefined?undefined:validateCategoryAttributeDefinition(item.definition);if(definition&&definition.categoryId!==miaoshouId(expectedCategoryId))throw invalidStore();preset=validateCategoryAttributeTemplate({name:item.name,attributes:item.attributes},{definition});}catch{throw invalidStore();}
      const name=normalizedName(preset.name);if(names.has(name))throw invalidStore();names.add(name);ids.add(item.id);items.push({id:item.id,...preset,...(definition?{definition}:{}),createdAt:item.createdAt,updatedAt:item.updatedAt});
    }
    if(data.defaultId!==undefined&&!items.some(item=>item.id===data.defaultId&&item.attributes.length))throw invalidStore();
    if(data.editorDefaultId!==undefined&&!items.some(item=>item.id===data.editorDefaultId&&item.definition))throw invalidStore();
    return {version:1,revision:data.revision,items,...(data.defaultId?{defaultId:data.defaultId}:{}),...(data.editorDefaultId?{editorDefaultId:data.editorDefaultId}:{}),...(legacyScopes.length?{legacyScopes}:{})};
  }
  async function load(selected,input){
    if(!root)return clone(memory.get(selected)||empty());
    try{const raw=await readFile(pathFor(selected));if(raw.length>2*1024*1024)throw invalidStore();return checked(JSON.parse(raw.toString('utf8')),input.categoryId);}
    catch(error){if(error.code==='ENOENT')return empty();if(error.code==='MIAOSHOU_ATTRIBUTE_TEMPLATE_STORAGE')throw error;throw invalidStore();}
  }
  function validateInput(input,operation){
    const selected=scope(input),allowed=operation==='list'?['accountScope','shopId','categoryId']:operation==='create'?['accountScope','shopId','categoryId','revision','preset']:operation==='update'?['accountScope','shopId','categoryId','revision','id','preset']:['accountScope','shopId','categoryId','revision','id'];
    if(Object.keys(input).some(key=>key!=='scope'&&!allowed.includes(key)))throw failure('类目属性模板参数无效。');
    if(operation!=='list'&&(!Number.isSafeInteger(input.revision)||input.revision<0))throw failure('请先读取最新的类目属性模板库。');
    if(['update','remove'].includes(operation)&&!id(input.id))throw failure('类目属性模板编号无效。');
    if(['setDefault','setEditorDefault'].includes(operation)&&input.id!==null&&!id(input.id))throw failure('请选择一个有效模板或取消默认。');
    return selected;
  }
  function writeLibrary(selected,input,guard,change){
    const work=(queues.get(selected)||Promise.resolve()).catch(()=>{}).then(async()=>{
      let lock,temp;const path=pathFor(selected);
      try{
        if(path){await mkdir(resolve(root,'miaoshou-attribute-templates'),{recursive:true});try{lock=await open(path+'.lock','wx');}catch{throw failure('类目属性模板库正在修改或上次保存需要核对，请稍后重试。','MIAOSHOU_ATTRIBUTE_TEMPLATE_BUSY',409);}}
        await guard();const data=await load(selected,input);
        const result=change(data);
        if(result===false)return publicLibrary(data);
        if(data.revision>=Number.MAX_SAFE_INTEGER)throw failure('类目属性模板版本已达上限，请联系管理员。');
        data.revision++;
        if(Buffer.byteLength(JSON.stringify(data))>2*1024*1024)throw failure('类目属性模板库已达容量上限，请减少属性或删除不用的模板。');
        if(path){temp=path+'.'+randomUUID()+'.tmp';const file=await open(temp,'wx');try{await file.writeFile(JSON.stringify(data));await file.sync();}finally{await file.close();}await guard();await rename(temp,path);temp=null;}
        else {await guard();memory.set(selected,clone(data));}
        return {...publicLibrary(data),...(result?{item:clone(result)}:{})};
      }catch(error){if(error?.status===409||error?.code?.startsWith('MIAOSHOU_ATTRIBUTE_TEMPLATE_'))throw error;throw failure('类目属性模板未能保存，原模板数据已保留，请稍后重试。','MIAOSHOU_ATTRIBUTE_TEMPLATE_STORAGE',503);}
      finally{if(temp)await unlink(temp).catch(()=>{});if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}}
    });
    const settled=work.catch(()=>{});queues.set(selected,settled);void settled.finally(()=>{if(queues.get(selected)===settled)queues.delete(selected);});return work;
  }
  function mutate(input,operation,{guard=async()=>{},definition,editorDefault}={}){
    const selected=validateInput(input,operation),imported=definition===undefined?undefined:validateCategoryAttributeDefinition(definition);
    if(typeof guard!=='function'||editorDefault!==undefined&&typeof editorDefault!=='boolean'||imported&&!['create','update'].includes(operation))throw failure('类目属性模板操作参数无效。');
    if(imported&&(imported.categoryId!==miaoshouId(input.categoryId)||imported.source.shopId!==miaoshouId(input.shopId)))throw failure('属性资料不属于当前来源店铺与子类目。');
    input={...input,...(input.preset===undefined?{}:{preset:clone(input.preset)})};
    return writeLibrary(selected,input,guard,data=>{
        if(data.revision!==input.revision)throw failure('类目属性模板已被其他窗口修改，请刷新模板库后重试。','MIAOSHOU_ATTRIBUTE_TEMPLATE_CONFLICT',409);
        const index=data.items.findIndex(item=>item.id===input.id);
        if(operation!=='create'&&!(['setDefault','setEditorDefault'].includes(operation)&&input.id===null)&&index<0)throw failure('类目属性模板已删除，请刷新后重新选择。','MIAOSHOU_ATTRIBUTE_TEMPLATE_NOT_FOUND',409);
        const retained=operation==='update'?data.items[index].definition:undefined,entryDefinition=imported||retained;
        const preset=['remove','setDefault','setEditorDefault'].includes(operation)?null:validateCategoryAttributeTemplate(input.preset,{definition:entryDefinition});
        if(operation==='setDefault'&&input.id!==null&&!data.items[index].attributes.length||operation==='update'&&input.id===data.defaultId&&!preset.attributes.length)throw failure('仅保存字段的模板不能用于认领默认，请先取消认领默认或填写至少一项属性。');
        if(preset&&data.items.some(item=>item.id!==input.id&&normalizedName(item.name)===normalizedName(preset.name)))throw failure('此类目属性模板名称已存在，请使用其他名称。','MIAOSHOU_ATTRIBUTE_TEMPLATE_DUPLICATE',409);
        let item;
        const at=new Date(now()).toISOString();
        if(operation==='create'){
          if(data.items.length>=limit)throw failure('类目属性模板已达 '+limit+' 个，请先删除不用的模板。');
          item={id:randomUUID(),...preset,...(entryDefinition?{definition:entryDefinition}:{}),createdAt:at,updatedAt:at};data.items.push(item);
        }else if(operation==='update'){item={...data.items[index],...preset,...(entryDefinition?{definition:entryDefinition}:{}),updatedAt:at};data.items[index]=item;}
        else if(operation==='setDefault'){if(input.id===null)delete data.defaultId;else data.defaultId=input.id;}
        else if(operation==='setEditorDefault'){if(input.id===null)delete data.editorDefaultId;else {if(!data.items[index].definition)throw failure('此旧模板尚未保存子类目属性资料，请先从当前链接创建或更新。');data.editorDefaultId=input.id;}}
        else {data.items.splice(index,1);if(data.defaultId===input.id)delete data.defaultId;if(data.editorDefaultId===input.id)delete data.editorDefaultId;}
        if(item&&editorDefault===true){if(!item.definition)throw failure('请先读取并保存当前子类目的属性资料。');data.editorDefaultId=item.id;}
        return item;
    });
  }
  // Existing libraries use opaque scope hashes. Discover only hashes derived from
  // the current authorized account, its shops and the verified public leaf IDs.
  let discovery;
  async function listAll({accountScope,shopIds,categoryIds,sharedOnly=false,guard}){
    if(!Array.isArray(shopIds)||!Array.isArray(categoryIds))throw failure('模板来源范围无效。');
    const shops=[...new Set(shopIds.map(miaoshouId))],categories=[...new Set(categoryIds.map(miaoshouId))];
    if(!shops.length)return {items:[]};scope({accountScope,shopId:shops[0],categoryId:categories[0]||'1'});
    let available;
    if(root){try{available=new Set((await readdir(resolve(root,'miaoshou-attribute-templates'))).filter(n=>/^[a-f\d]{64}\.json$/u.test(n)).map(n=>n.slice(0,-5)));}catch(error){if(error.code!=='ENOENT')throw invalidStore();available=new Set();}}
    else available=new Set(memory.keys());
    const key=JSON.stringify([accountScope,shops,categories,[...available].sort()]);
    if(discovery?.key!==key){
      const found=[];
      if(available.size)for(let i=0;i<categories.length;i++){
        const categoryId=categories[i];
        for(const shopId of shops){const input={accountScope,shopId,categoryId},hash=scope(input);if(available.has(hash))found.push({hash,shopId,categoryId,scope:'shop'});}
        const hash=scope({accountScope,shopId:shops[0],categoryId,scope:'category'});if(available.has(hash))found.push({hash,shopId:'',categoryId,scope:'category'});
        if(i%128===0)await new Promise(resolve=>setImmediate(resolve));
      }
      discovery={key,found};
    }
    const items=[];
    if(sharedOnly){
      const byCategory=new Map();
      for(const row of discovery.found){
        if(!byCategory.has(row.categoryId))byCategory.set(row.categoryId,[]);
        if(row.shopId)byCategory.get(row.categoryId).push(row.shopId);
      }
      for(const [categoryId,legacyShopIds] of byCategory){
        const {library}=await resolveSharedEditor({accountScope,shopId:shops[0],categoryId,legacyShopIds},{guard});
        for(const item of library.items)items.push({...item,source:{shopId:'',categoryId,scope:'category'}});
      }
      return {items};
    }
    for(const source of discovery.found){const data=await load(source.hash,{categoryId:source.categoryId});for(const item of data.items)items.push({...item,source:{shopId:source.shopId,categoryId:source.categoryId,scope:source.scope}});}
    return {items};
  }
  function publicLibrary(data){return {revision:data.revision,items:clone(data.items),...(data.defaultId?{defaultId:data.defaultId}:{}),...(data.editorDefaultId?{editorDefaultId:data.editorDefaultId}:{})};}
  async function resolveSharedEditor({accountScope,shopId,categoryId,legacyShopIds=[]},{guard=async()=>{}}={}){
    const target={accountScope,shopId,categoryId,scope:'category'},selected=validateInput(target,'list');
    const category=await load(selected,target);
    const scanned=new Set(category.legacyScopes);
    const sources=[...new Set([shopId,...legacyShopIds].map(miaoshouId))].sort()
      .map(shopId=>scope({accountScope,shopId,categoryId})).filter(key=>!scanned.has(key));
    const legacy=(await Promise.all(sources.map(async key=>({key,...await load(key,target)})))).filter(row=>row.items.length);
    const library=legacy.length?await writeLibrary(selected,target,guard,data=>{
      const imported=new Set(data.legacyScopes);
      const names=new Set(data.items.map(item=>normalizedName(item.name)));
      const ids=new Set(data.items.map(item=>item.id));
      let changed=false;
      for(const source of legacy){
        if(imported.has(source.key))continue;
        if(data.items.length+source.items.length>limit)throw failure('当前子类目的旧模板合并后超过 '+limit+' 个。原有模板已保留，请先整理模板库。');
        for(const item of source.items){
          let name=item.name;
          for(let number=1;names.has(normalizedName(name));number++){
            const suffix='（旧模板 '+number+'）';
            name=Array.from(item.name).slice(0,80-Array.from(suffix).length).join('')+suffix;
          }
          const itemId=ids.has(item.id)?randomUUID():item.id;
          names.add(normalizedName(name));ids.add(itemId);
          data.items.push({...item,id:itemId,name});
        }
        imported.add(source.key);changed=true;
      }
      data.legacyScopes=[...imported];
      return changed?undefined:false;
    }):publicLibrary(category);
    const ready=library.items.filter(item=>item.definition);
    return {scope:'category',library,autoApplyId:library.editorDefaultId||(ready.length===1?ready[0].id:null)};
  }
  async function resolveEditor(input){
    if(!plain(input)||Object.keys(input).some(key=>!['accountScope','shopId','categoryId','scope'].includes(key))||input.scope!==undefined&&!['shop','category'].includes(input.scope))throw failure('编辑属性模板范围无效。');
    const base={accountScope:input.accountScope,shopId:input.shopId,categoryId:input.categoryId},shopKey=validateInput(base,'list'),categoryInput={...base,scope:'category'},categoryKey=validateInput(categoryInput,'list');
    const choices=[];
    if(input.scope!=='category')choices.push({scope:'shop',library:publicLibrary(await load(shopKey,base))});
    if(input.scope!=='shop')choices.push({scope:'category',library:publicLibrary(await load(categoryKey,categoryInput))});
    const ready=row=>row.library.items.filter(item=>item.definition),explicit=row=>ready(row).find(item=>item.id===row.library.editorDefaultId);
    for(const row of choices){const item=explicit(row);if(item)return {...row,autoApplyId:item.id};}
    for(const row of choices){const items=ready(row);if(items.length===1)return {...row,autoApplyId:items[0].id};}
    const selected=choices.find(row=>ready(row).length)||choices.find(row=>row.library.items.length)||choices.find(row=>row.scope==='category')||choices[0];
    return {...selected,autoApplyId:null};
  }
  return {
    listAll,
    async list(input){const selected=validateInput(input,'list'),data=await load(selected,input);return publicLibrary(data);},
    async editorList(input){const selected=validateInput(input,'list'),data=await load(selected,input);return publicLibrary(data);},
    resolveEditor,resolveSharedEditor,
    async setDefault(input,options){return mutate(input,'setDefault',options);},
    async setEditorDefault(input,options){return mutate(input,'setEditorDefault',options);},
    async create(input,options){return mutate(input,'create',options);},async update(input,options){return mutate(input,'update',options);},async remove(input,options){return mutate(input,'remove',options);},
    async close(){closed=true;await Promise.allSettled([...queues.values()]);}
  };
}
