import {randomUUID,createHash} from 'node:crypto';
import {miaoshouId} from './dist/miaoshou-policy.js';

const PAGE_SIZE=500,MAX_PAGES=200,MAX_TARGETS=50000,MAX_BATCHES=256;
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const copy=value=>structuredClone(value);
const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const validHash=value=>typeof value==='string'&&/^[a-f0-9]{64}$/u.test(value);
// Retain only a digest of upstream modification/version fields, never raw API
// payloads or read timestamps. These fields supplement title/image/association
// matching when the upstream list exposes a description-only edit revision.
export function miaoshouRiskSourceVersion(value){
  if(!plain(value))return undefined;
  const fields=['gmtModified','gmtUpdate','gmtUpdated','updateTime','updatedAt','modifyTime','modifiedTime','lastModifiedTime','lastUpdateTime','sourceRevision','sourceHash','ossMd5','version'];
  const parts=fields.filter(key=>Object.hasOwn(value,key)&&['string','number'].includes(typeof value[key])&&String(value[key]).trim()&&String(value[key]).length<=1024).map(key=>[key,String(value[key])]);
  for(const key of ['notes','description'])if(typeof value[key]==='string'&&value[key].length<=2*1024*1024)parts.push([key,hash(value[key])]);
  for(const key of ['imgUrls','mainImages'])if(Array.isArray(value[key])&&value[key].length<=30&&value[key].every(url=>typeof url==='string'&&url.length<=8192))parts.push([key,hash(value[key])]);
  return parts.length?hash(parts):undefined;
}
const stale=()=>Object.assign(new Error('商品检查的数据连接或批次已变化，请重新检查。'),{code:'RISK_API_SOURCE_STALE',status:409});
function selectedContext(value){
  if(typeof value?.contextId!=='string'||!value.contextId||value.contextId.length>160||/[\u0000-\u001f\u007f]/u.test(value.contextId)
    ||typeof value.accountScope!=='string'||!/^[a-f0-9]{64}$/u.test(value.accountScope))throw stale();
  return {contextId:value.contextId,accountScope:value.accountScope};
}
const same=(a,b)=>a?.contextId===b?.contextId&&a?.accountScope===b?.accountScope;
const readTime=value=>typeof value==='string'&&Number.isFinite(Date.parse(value))&&new Date(Date.parse(value)).toISOString()===value?value:undefined;
function associations(value){
  if(!Array.isArray(value))return undefined;
  return [...new Set(value.map(miaoshouId))].sort();
}
function collectionRow(value){
  if(!plain(value))throw new Error('妙手采集箱商品内容格式无效。');
  const id=miaoshouId(value.id??value.collectBoxDetailId);
  const shopIds=Object.hasOwn(value,'shopIds')?associations(value.shopIds)
    :Array.isArray(value.collectBoxDetailShopList)?associations(value.collectBoxDetailShopList.map(item=>item?.shopId)):undefined;
  // Only API fields are selected. UI overrides such as sourceTitle and
  // sourceThumbnail can never enter the model input through this reader.
  const sourceVersion=validHash(value.reviewSourceVersion)?value.reviewSourceVersion:miaoshouRiskSourceVersion(value);
  return {id,title:typeof value.title==='string'?value.title:'',thumbnail:typeof value.thumbnail==='string'?value.thumbnail:'',shopIds,apiReadAt:readTime(value.reviewApiReadAt),...(sourceVersion?{reviewSourceVersion:sourceVersion}:{})};
}
const sourceHash=row=>hash({version:1,id:row.id,title:row.title,thumbnail:row.thumbnail,shopIds:row.shopIds??null,sourceVersion:row.reviewSourceVersion??null});
function defaultNormalizeCollection(data){
  const rows=Array.isArray(data)?data:['detailList','records','list','items','rows','content'].map(key=>data?.[key]).find(Array.isArray);
  if(!rows)throw new Error('妙手采集箱列表格式无效，尚未读取检查内容。');
  return rows.map(collectionRow);
}

/** API-only product evidence; it has no credentials and exposes no write operation.
 * guard receives {contextId,accountScope,signal}, before and after every read.
 * prepare returns detached queue rows synchronously. collectionRows must be the
 * actual normalized rows returned by this sync, never the local merged cache. */
export function createMiaoshouRiskApiSource({client,guard=()=>{},now=Date.now,normalizeCollection=defaultNormalizeCollection}={}){
  if(typeof client?.call!=='function'||typeof guard!=='function'||typeof normalizeCollection!=='function')throw new TypeError('妙手商品检查的 API 读取连接不完整。');
  const batches=new Map(),owners=new Map();let current=null,generation=0,closed=false;
  const at=()=>new Date(now()).toISOString();
  function assertBatch(batch){if(closed||!batch||batch.generation!==generation||!same(batch,current)||batches.get(batch.id)!==batch||!batch.targets.size)throw stale();batch.controller.signal.throwIfAborted();}
  function assertRow(batch,id,options){assertBatch(batch);if(!same(batch,options)||owners.get(id)!==batch.id||!batch.targets.has(id))throw stale();options.signal?.throwIfAborted();}
  async function checkBatch(batch){assertBatch(batch);await guard({...current,signal:batch.controller.signal});assertBatch(batch);}
  async function checkRow(batch,id,options){assertRow(batch,id,options);await guard({contextId:batch.contextId,accountScope:batch.accountScope,signal:options.signal});assertRow(batch,id,options);}
  function clear(){generation++;for(const batch of batches.values())batch.controller.abort();batches.clear();owners.clear();current=null;}
  function snapshot(batch){
    assertBatch(batch);if(batch.snapshots)return Promise.resolve(batch.snapshots);
    if(batch.scanPromise)return batch.scanPromise;
    // A retry batch shares one collection scan for every queued target. A
    // single caller's cancellation must not cancel other waiting products.
    batch.scanPromise=(async()=>{
      const found=new Map(),seen=new Set();
      for(let pageNo=1;pageNo<=MAX_PAGES;pageNo++){
        await checkBatch(batch);
        const data=await client.call('list',{pageNo,pageSize:PAGE_SIZE},{guard:()=>assertBatch(batch)}),pageReadAt=at();await checkBatch(batch);
        const rows=normalizeCollection(data);if(!Array.isArray(rows))throw new Error('妙手采集箱列表格式无效。');
        let added=0;for(const input of rows){const row={...collectionRow(input),apiReadAt:pageReadAt};if(!seen.has(row.id)){seen.add(row.id);added++;}if(batch.targets.has(row.id))found.set(row.id,row);}
        // A short page is not an end marker: upstream may trim a page.
        if(!rows.length||[...batch.targets].every(id=>found.has(id))){batch.snapshots=found;batch.snapshotAt=at();return found;}
        if(!added)throw new Error('妙手采集箱分页重复，尚未确认检查内容。');
      }
      throw new Error('妙手采集箱超过单次检查读取上限，请重新同步后检查。');
    })();return batch.scanPromise;
  }
  return {
    prepare(input){
      if(closed)throw stale();const selected=selectedContext(input);
      if(!Array.isArray(input.records)||input.records.length>MAX_TARGETS)throw new Error('商品检查批次超过读取上限。');
      const rows=input.records.map(row=>{if(!plain(row))throw new Error('商品检查编号无效。');const result=copy(row);result.id=miaoshouId(row.id);delete result.reviewRevision;delete result.reviewSourceHash;return result;}),ids=rows.map(row=>row.id);
      if(new Set(ids).size!==ids.length)throw new Error('商品检查编号重复。');
      const initial=Object.hasOwn(input,'collectionRows')&&input.collectionRows!==undefined;
      let snapshots=null;
      if(initial){
        const values=input.collectionRows instanceof Map?[...input.collectionRows.values()]:input.collectionRows;
        if(!Array.isArray(values)||values.length>MAX_TARGETS)throw new Error('本轮妙手 API 快照无效。');
        snapshots=new Map();const wanted=new Set(ids);for(const value of values){const row=collectionRow(value);if(wanted.has(row.id))snapshots.set(row.id,row);}
      }
      const changing=!same(selected,current),retained=new Map();
      if(initial&&!changing)for(const id of ids){const previous=batches.get(owners.get(id)),before=previous?.snapshots?.get(id),after=snapshots.get(id);if(before&&after&&previous.targets.has(id)&&!previous.controller.signal.aborted&&sourceHash(before)===sourceHash(after)){retained.set(id,previous.id);previous.snapshots.set(id,{...after,apiReadAt:after.apiReadAt||at()});}}
      const incoming=new Set(ids.filter(id=>!retained.has(id))),remainingBatches=changing?0:[...batches.values()].filter(batch=>[...batch.targets].some(id=>!incoming.has(id))).length;
      const remainingOwners=changing?0:[...owners.keys()].filter(id=>!incoming.has(id)).length;
      if(remainingOwners+incoming.size>MAX_TARGETS||remainingBatches+(incoming.size?1:0)>MAX_BATCHES)throw new Error('仍有较多商品检查等待处理，请完成后再新增检查批次。');
      if(changing){clear();current=selected;}
      if(!rows.length)return [];
      const id=randomUUID(),batch={id,...selected,generation,targets:incoming,snapshots:initial?new Map([...snapshots].filter(([key])=>incoming.has(key))):null,snapshotAt:initial?at():null,scanPromise:null,controller:new AbortController()};
      for(const target of incoming){const previous=batches.get(owners.get(target));if(previous){previous.targets.delete(target);previous.snapshots?.delete(target);if(!previous.targets.size){previous.controller.abort();batches.delete(previous.id);}}owners.set(target,id);}
      if(incoming.size)batches.set(id,batch);
      return rows.map(row=>({...row,reviewSourceBatchId:retained.get(row.id)||id,...(snapshots?.has(row.id)?{reviewSourceHash:sourceHash(snapshots.get(row.id))}:{})}));
    },
    async readProduct(row,options){
      if(!plain(row)||!plain(options))throw stale();const selected=selectedContext(options),id=miaoshouId(row.id),batch=batches.get(row.reviewSourceBatchId);
      await checkRow(batch,id,{...options,...selected});const snapshots=await snapshot(batch);await checkRow(batch,id,options);
      const source=snapshots.get(id);if(!source)throw Object.assign(new Error('该商品已不在本轮妙手采集箱中，未提交检测。'),{code:'RISK_API_PRODUCT_MISSING'});
      if(!Array.isArray(source.shopIds))throw new Error('妙手 API 尚未确认关联店铺，未提交商品检测。');
      if(!source.shopIds.length){
        return {title:source.title,description:'',mainImages:source.thumbnail?[source.thumbnail]:[],coverage:{title:!!source.title,description:false},
          provenance:{provider:'miaoshou-api',detailId:id,shopId:null,endpoint:'collection',readAt:source.apiReadAt||batch.snapshotAt,collectionReadAt:source.apiReadAt||batch.snapshotAt,fields:{title:!!source.title,description:false,mainImages:!!source.thumbnail}}};
      }
      const shopId=source.shopIds[0];await checkRow(batch,id,options);
      const detail=await client.call('detail',{detailId:BigInt(id),shopId:BigInt(shopId)},{guard:()=>assertRow(batch,id,options)}),detailReadAt=at();await checkRow(batch,id,options);
      const info=detail?.shopCollectItemInfo;
      if(!plain(info)||miaoshouId(info.detailId)!==id||miaoshouId(info.shopId)!==shopId||!Array.isArray(detail.claimToShopIds)||!associations(detail.claimToShopIds).includes(shopId))throw new Error('妙手商品或关联店铺已变化，尚未提交检测。');
      const title=typeof info.title==='string'?info.title:'',description=typeof info.notes==='string'?info.notes:'',mainImages=Array.isArray(info.imgUrls)?info.imgUrls.map(url=>typeof url==='string'?url:''):[];
      return {title,description,mainImages,coverage:{title:typeof info.title==='string',description:typeof info.notes==='string'},
        provenance:{provider:'miaoshou-api',detailId:id,shopId,endpoint:'detail',readAt:detailReadAt,collectionReadAt:source.apiReadAt||batch.snapshotAt,fields:{title:typeof info.title==='string',description:typeof info.notes==='string',mainImages:typeof mainImages[0]==='string'&&!!mainImages[0]}}};
    },
    reset(){clear();},close(){closed=true;clear();}
  };
}
