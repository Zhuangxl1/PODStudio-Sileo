import {Agent,request} from 'node:https';
import {Readable} from 'node:stream';

const ENDPOINTS=new Set(['https://lanyiapi.cc','https://api.siliconflow.cn']);

/** A provider-scoped HTTP client; does not change Node's global proxy or auth. */
export function createProviderFetch({env={},requestImpl=request,AgentImpl=Agent}={}){
  const agent=new AgentImpl({keepAlive:true,maxSockets:8,proxyEnv:env});
  let closed=false;
  const fetchImpl=async(url,options={})=>{
    const target=new URL(url);
    if(closed||!ENDPOINTS.has(target.origin)||target.username||target.password||target.hash||!target.pathname.startsWith('/v1/'))throw new Error('Provider endpoint unavailable.');
    const encoded=new Request(target,options),signal=encoded.signal;
    signal.throwIfAborted();
    const body=encoded.body?Buffer.from(await encoded.arrayBuffer()):undefined;
    signal.throwIfAborted();
    return new Promise((resolve,reject)=>{
      const headers=Object.fromEntries(encoded.headers);headers['accept-encoding']='identity';
      if(body)headers['content-length']=String(body.length);
      const req=requestImpl(target,{method:encoded.method,headers,agent,signal},res=>{
        const status=res.statusCode||502;
        if(status>=300&&status<400){res.destroy();reject(new Error('Provider redirect refused.'));return;}
        const responseHeaders=new Headers();
        for(const [key,value] of Object.entries(res.headers))if(value!==undefined)responseHeaders.set(key,Array.isArray(value)?value.join(', '):value);
        resolve(new Response([204,205,304].includes(status)?null:Readable.toWeb(res),{status,headers:responseHeaders}));
      });
      req.once('error',reject);req.end(body);
    });
  };
  fetchImpl.close=()=>{closed=true;agent.destroy();};
  return fetchImpl;
}
