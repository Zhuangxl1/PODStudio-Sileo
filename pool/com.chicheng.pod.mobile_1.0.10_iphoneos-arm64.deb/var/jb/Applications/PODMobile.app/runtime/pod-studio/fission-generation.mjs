const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const text = (value, maximum = 160) => typeof value === 'string' && value.length > 0 && value.length <= maximum && value.trim().length > 0 && !/[\u0000-\u001f\u007f]/.test(value);
const assert = (condition, message) => { if (!condition) throw new Error(message); };
const imageData = value => typeof value === 'string' && /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value);

export const FISSION_GENERATION_PLACEMENTS = Object.freeze({
  front_only: 'front',
  back_only: 'back',
  front_back: 'front-back',
  left_chest_back: 'leftUpper-back'
});

function imageIds(value) {
  return Array.isArray(value) && value.length >= 1 && value.length <= 6 && value.every(id => text(id)) && new Set(value).size === value.length;
}

/**
 * Bind a generation request to already-synchronized target-store template pixels.
 * This function performs no I/O and does not invoke or attest to a native image
 * tool. Context image validity/size is the responsibility of syncContext; here
 * their exact data URLs must appear in the actual structured image input.
 */
export function validateFissionGenerationRequest({ context, input, request } = {}) {
  assert(object(context) && object(context.snapshot), '请先读取并同步当前设计器上下文。');
  assert(object(request) && Object.keys(request).every(key => ['contextToken', 'templateId', 'baseImageIds'].includes(key)), '裂变生图绑定参数无效。');
  assert(text(context.contextToken) && text(request.contextToken) && request.contextToken === context.contextToken, '裂变生图上下文已变化，请重新读取本店底图。');
  const snapshot = context.snapshot;
  assert(snapshot.contextToken === undefined || snapshot.contextToken === context.contextToken, '设计器上下文标识不一致，请重新同步。');
  const template = snapshot.template;
  const task = snapshot.fissionTask;
  const generation = snapshot.ui?.fissionGeneration;
  assert(object(template) && object(task) && object(task.targetStore) && object(generation), '缺少目标店铺对应位置的生图底图信息。');
  assert(generation.ready === true, '本店对应位置的服装底图尚未就绪，请先补齐模板。');
  assert(generation.contextToken === undefined || generation.contextToken === context.contextToken, '本店底图属于旧上下文，请重新读取。');
  assert(text(template.id) && text(request.templateId) && text(generation.templateId) && template.id === request.templateId && generation.templateId === template.id, '裂变生图模板已变化，请重新读取当前模板底图。');

  const target = task.targetStore;
  // templateShop is the exact ownership key; a newly entered store can instead
  // use its explicit name. Display aliases do not override a selected key.
  const targetShop = text(target.templateShop) ? target.templateShop : target.name;
  assert(text(targetShop) && text(template.shop) && text(generation.templateShop) && targetShop === template.shop && generation.templateShop === targetShop, '目标店铺与服装模板归属不一致，请选择本店模板。');
  assert(Object.hasOwn(FISSION_GENERATION_PLACEMENTS, task.placementMode) && generation.placementMode === task.placementMode && template.placementId === FISSION_GENERATION_PLACEMENTS[task.placementMode], '目标印花位置与模板底图不一致，请重新匹配对应位置。');
  assert(imageIds(generation.baseImageIds) && imageIds(request.baseImageIds), '裂变生图至少需要1张明确的本店底图，且底图ID不能重复。');
  const requiredIds = generation.baseImageIds;
  assert(request.baseImageIds.length === requiredIds.length && requiredIds.every(id => request.baseImageIds.includes(id)), '裂变生图必须包含当前位置所需的全部本店底图，不能替换或遗漏。');
  assert(Array.isArray(context.images), '同步上下文缺少实际底图像素。');
  assert(Array.isArray(input) && input.length >= 2 && input[0]?.type === 'text' && typeof input[0].text === 'string' && input[0].text.trim().length > 0, '裂变生图必须提交实际图片输入，文字说明不能代替读取底图。');

  const indexes = [];
  for (const id of requiredIds) {
    const images = context.images.filter(image => object(image) && image.id === id);
    assert(images.length === 1 && images[0].kind === 'fission_base' && imageData(images[0].dataUrl), '所需底图不属于当前上下文的本店服装底图。');
    const index = input.findIndex(item => object(item) && item.type === 'image' && item.url === images[0].dataUrl);
    assert(index >= 1, '实际生图图片输入缺少所需本店底图像素，不能仅在文字中声明已引用。');
    indexes.push(index);
  }

  return Object.freeze({
    validated: true,
    contextToken: context.contextToken,
    templateId: template.id,
    templateShop: targetShop,
    targetStoreName: text(target.name) ? target.name : targetShop,
    placementId: template.placementId,
    placementMode: task.placementMode,
    baseImageIds: Object.freeze([...requiredIds]),
    baseImageCount: requiredIds.length,
    inputImageIndexes: Object.freeze(indexes),
    nativeReferenceConfirmed: false
  });
}
