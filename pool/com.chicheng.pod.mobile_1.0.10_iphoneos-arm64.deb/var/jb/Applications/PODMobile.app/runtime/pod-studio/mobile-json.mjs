// Node Mobile 18 has neither JSON.rawJSON nor the JSON.parse source context.
// Parse integer tokens before conversion so 19-digit commerce IDs stay exact.
export function parseLosslessJSON(source) {
  if (typeof source !== 'string') source = String(source);
  let i = 0;
  const fail = () => { throw new SyntaxError('Invalid JSON'); };
  const space = () => { while (/[\x20\t\r\n]/.test(source[i] || '\0')) i++; };
  function string() {
    const start = i++;
    while (i < source.length) {
      const char = source[i++];
      if (char === '"') return JSON.parse(source.slice(start, i));
      if (char === '\\') i++;
    }
    return fail();
  }
  function value(depth = 0) {
    if (depth > 512) return fail();
    space(); const char = source[i];
    if (char === '"') return string();
    if (char === '{') {
      i++; const out = {}; space();
      if (source[i] === '}') { i++; return out; }
      while (true) {
        space(); if (source[i] !== '"') return fail();
        const key = string(); space(); if (source[i++] !== ':') return fail();
        const item = value(depth + 1);
        Object.defineProperty(out, key, {value:item, enumerable:true, configurable:true, writable:true});
        space(); const next = source[i++];
        if (next === '}') return out;
        if (next !== ',') return fail();
      }
    }
    if (char === '[') {
      i++; const out = []; space();
      if (source[i] === ']') { i++; return out; }
      while (true) {
        out.push(value(depth + 1)); space(); const next = source[i++];
        if (next === ']') return out;
        if (next !== ',') return fail();
      }
    }
    for (const [word, result] of [['true',true],['false',false],['null',null]]) {
      if (source.startsWith(word, i)) { i += word.length; return result; }
    }
    const number = /^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(source.slice(i));
    if (!number) return fail();
    i += number[0].length;
    const numeric = Number(number[0]);
    return /^-?\d+$/.test(number[0]) && !Number.isSafeInteger(numeric) ? BigInt(number[0]) : numeric;
  }
  const result = value(); space(); if (i !== source.length) return fail(); return result;
}

// BigInt values are emitted as numeric tokens; strings are always JSON escaped.
export function stringifyLosslessJSON(input) {
  const seen = new Set();
  function encode(value, key, depth = 0) {
    if (depth > 512) throw new TypeError('JSON nesting is too deep');
    if (value && typeof value === 'object' && typeof value.toJSON === 'function') value = value.toJSON(key);
    if (typeof value === 'bigint') return String(value);
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (seen.has(value)) throw new TypeError('Converting circular structure to JSON');
    if (value instanceof Number || value instanceof String || value instanceof Boolean) return JSON.stringify(value);
    seen.add(value);
    try {
      if (Array.isArray(value)) return '[' + Array.from({length:value.length}, (_, i) => encode(value[i], String(i), depth + 1) ?? 'null').join(',') + ']';
      const fields = [];
      for (const name of Object.keys(value)) {
        const item = encode(value[name], name, depth + 1);
        if (item !== undefined) fields.push(JSON.stringify(name) + ':' + item);
      }
      return '{' + fields.join(',') + '}';
    } finally { seen.delete(value); }
  }
  return encode(input, '');
}
