import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {lstat} from 'node:fs/promises';
import {isAbsolute,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

export const CODEX_PROVIDER_MODES=Object.freeze(['local','lanyi','siliconflow']);
const REMOTE_MODES=CODEX_PROVIDER_MODES.slice(1);
const SCRIPT=fileURLToPath(new URL('./provider-secrets.ps1',import.meta.url));
const FILE='codex-provider-settings.dpapi';
const MAX_OUTPUT_BYTES=16384;
const KEY_FORMAT=/^[\x21-\x7e]{1,4096}$/u;
const MODEL_FORMAT=/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/u;
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const hasKeys=(value,keys)=>plain(value)&&Object.keys(value).every(key=>keys.includes(key));
const unavailable=()=>Object.assign(new Error('无法读取或保存 Codex 服务设置，请检查主机 Windows 用户及数据目录。'),{code:'CODEX_PROVIDER_SETTINGS_UNAVAILABLE',status:503});
const invalid=message=>Object.assign(new Error(message),{code:'CODEX_PROVIDER_SETTINGS_INVALID',status:400});
const validKey=value=>typeof value==='string'&&(value===''||KEY_FORMAT.test(value));
const validModel=value=>typeof value==='string'&&(value===''||MODEL_FORMAT.test(value)&&!value.includes('://'));
const blankProvider=()=>({apiKey:'',imageModel:''});
const defaultSettings=()=>({version:1,mode:'local',revision:'default',providers:{lanyi:blankProvider(),siliconflow:blankProvider()}});

function nativeSecrets(mode,path,input){
  return new Promise((resolvePromise,reject)=>{
    const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',SCRIPT,'-Mode',mode,'-Path',path],
      {windowsHide:true,shell:false,stdio:['pipe','pipe','ignore']});
    let output=[],bytes=0,finished=false;
    const finish=(ok,value)=>{
      if(finished)return;
      finished=true;
      clearTimeout(timer);
      for(const chunk of output)chunk.fill(0);
      output=[];
      if(ok)resolvePromise(value);else reject(unavailable());
    };
    const stop=()=>{try{child.kill();}catch{}finish(false);};
    const timer=setTimeout(stop,10000);
    child.stdout.on('data',chunk=>{
      if(finished)return;
      bytes+=chunk.length;
      if(bytes>MAX_OUTPUT_BYTES){stop();return;}
      output.push(chunk);
    });
    child.stdout.on('error',stop);
    child.stdin.on('error',stop);
    child.once('error',stop);
    child.once('close',code=>{
      if(finished)return;
      if(code!==0){finish(false);return;}
      const result=Buffer.concat(output,bytes);
      try{
        const text=result.toString('utf8');
        if(mode==='write')finish(text==='saved',true);
        else finish(true,JSON.parse(text));
      }catch{finish(false);}
      finally{result.fill(0);}
    });
    // Only the private PowerShell pipe receives credential data.
    child.stdin.end(input===undefined?'':JSON.stringify(input));
  });
}

async function checkFile(path){
  let entry;
  try{entry=await lstat(path);}catch(error){if(error.code==='ENOENT')return;throw error;}
  if(!entry.isFile()||entry.isSymbolicLink()||entry.nlink!==1||entry.size>32768)throw unavailable();
}

function normalizeBundle(raw){
  if(plain(raw)&&Object.keys(raw).length===0)return defaultSettings();
  if(!hasKeys(raw,['version','mode','revision','providers'])||raw.version!==1||
    !CODEX_PROVIDER_MODES.includes(raw.mode)||typeof raw.revision!=='string'||
    !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u.test(raw.revision)||
    !hasKeys(raw.providers,REMOTE_MODES))throw unavailable();
  const providers=Object.fromEntries(REMOTE_MODES.map(mode=>{
    const item=raw.providers[mode];
    if(!hasKeys(item,['apiKey','imageModel'])||!validKey(item.apiKey)||!validModel(item.imageModel))throw unavailable();
    return [mode,{apiKey:item.apiKey,imageModel:item.imageModel}];
  }));
  const keys=REMOTE_MODES.map(mode=>providers[mode].apiKey).filter(Boolean);
  if(REMOTE_MODES.some(mode=>keys.includes(providers[mode].imageModel)))throw unavailable();
  return {version:1,mode:raw.mode,revision:raw.revision,providers};
}

function summary(settings){
  const providers={local:{configured:true,keyConfigured:false}};
  for(const mode of REMOTE_MODES){
    const {apiKey,imageModel}=settings.providers[mode],configured=Boolean(apiKey);
    providers[mode]={configured,keyConfigured:configured,imageModel};
  }
  return {mode:settings.mode,revision:settings.revision,keyConfigured:providers[settings.mode].keyConfigured,providers};
}

/** Host settings. Only getProvider() returns a credential for a pinned session. */
export function createCodexProviderSettings({root,readSecrets,writeSecrets}={}){
  if(typeof root!=='string'||!isAbsolute(root)||root.includes('\0'))throw unavailable();
  const path=join(resolve(root),FILE);
  const decrypt=readSecrets|| (async()=>{await checkFile(path);return nativeSecrets('read',path);});
  const encrypt=writeSecrets|| (async value=>{await checkFile(path);return nativeSecrets('write',path,value);});
  let settings,loading,queue=Promise.resolve();
  async function load(){
    if(settings)return settings;
    if(!loading){
      const pending=Promise.resolve().then(decrypt).then(normalizeBundle).catch(()=>{throw unavailable();});
      loading=pending;
      void pending.then(value=>{settings=value;},()=>{}).finally(()=>{if(loading===pending)loading=null;});
    }
    return loading;
  }

  async function publicStatus(){return summary(await load());}
  async function getProvider(mode){
    if(mode!==undefined&&!CODEX_PROVIDER_MODES.includes(mode))throw invalid('Codex 服务来源无效。');
    const current=await load(),selected=mode??current.mode,provider=current.providers[selected]||blankProvider();
    return Object.freeze({mode:selected,revision:current.revision,...provider});
  }
  function save(input){
    const pending=queue.then(async()=>{
      if(!hasKeys(input,['mode','apiKey','clearApiKey','imageModel'])||!CODEX_PROVIDER_MODES.includes(input.mode)||
        input.apiKey!==undefined&&typeof input.apiKey!=='string'||input.clearApiKey!==undefined&&typeof input.clearApiKey!=='boolean'||
        input.imageModel!==undefined&&input.imageModel!==null&&typeof input.imageModel!=='string')
        throw invalid('Codex 服务配置格式无效。');
      const {mode}=input;
      const apiKey=(input.apiKey||'').trim(),imageModel=typeof input.imageModel==='string'?input.imageModel.trim():'';
      if(!validKey(apiKey)||apiKey&&input.clearApiKey)throw invalid('API Key 格式无效。');
      if(!validModel(imageModel))throw invalid('图像模型名称格式无效。');
      if(mode==='local'&&(apiKey||input.clearApiKey||imageModel))throw invalid('本地 Codex 无需 API Key 或图像模型配置。');

      const current=await load();
      const next=structuredClone(current);
      next.mode=mode;
      if(mode!=='local'){
        const provider=next.providers[mode];
        if(input.clearApiKey)provider.apiKey='';
        else if(apiKey)provider.apiKey=apiKey;
        if(input.imageModel!==undefined)provider.imageModel=imageModel;
      }
      const keys=REMOTE_MODES.map(remote=>next.providers[remote].apiKey).filter(Boolean);
      if(REMOTE_MODES.some(remote=>keys.includes(next.providers[remote].imageModel)))throw invalid('请在 API Key 字段填写密钥。');
      if(JSON.stringify(next)===JSON.stringify(current))return summary(current);
      next.revision=randomUUID();
      try{if(await encrypt(next)!==true)throw unavailable();}catch{throw unavailable();}
      settings=next;
      return summary(next);
    });
    queue=pending.catch(()=>{});
    return pending;
  }
  return {publicStatus,getProvider,save};
}
