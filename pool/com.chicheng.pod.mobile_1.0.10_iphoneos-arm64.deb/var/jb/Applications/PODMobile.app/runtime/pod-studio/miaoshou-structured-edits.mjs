import {compileMiaoshouAttributeUpdates,validateMiaoshouAttributeDependencies} from './miaoshou-attribute-values.mjs';
import {resolveSkuStructureTemplate,validateSkuStructureTemplate,validateSkuVariantImages} from './dist/miaoshou-sku-structure-schema.js';
import {resolveDirectSkuReplacement} from './dist/miaoshou-sku-direct-replacement.js';
export const STRUCTURED_EDIT_KEYS=Object.freeze(['contextShopId','contextCategoryId','allSkuWeightGrams','brandFromSample','descriptionImages','attributes','certifications','manufacturerIds','responsiblePersonIds','skuPrices','skuInventory','sellerSku','skuUpdates','specifications','addSkus','replaceSkuStructure','preSale']);
const own=(v,k)=>Object.hasOwn(v,k),has=(v,k)=>own(v,k);
const fail=message=>{throw Object.assign(new Error(message),{code:'MIAOSHOU_EDIT_INVALID',status:400});};
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const flag=v=>v===true||v===1||v==='1'||v==='true';
function object(v,keys,label){if(!plain(v)||Reflect.ownKeys(v).some(k=>typeof k!=='string'||!keys.includes(k)||!own(Object.getOwnPropertyDescriptor(v,k),'value')))fail(label+'包含无效字段。');return v;}
function text(v,max,label){if(typeof v!=='string'||!v.trim()||Array.from(v).length>max||/[\u0000-\u001f\u007f]/u.test(v))fail(label+'格式无效。');return v;}
function id(v){return text(v,50,'选项 ID');}
function list(v,label,max=200){if(!Array.isArray(v)||!v.length||v.length>max||Array.from(v).some(x=>x===undefined))fail(label+'须选择有效项目。');return v;}
function unique(v,key,label){const ids=v.map(key);if(new Set(ids).size!==ids.length)fail(label+'存在重复项目。');}
function amount(v,label,integer=false){if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>Number.MAX_SAFE_INTEGER||(integer&&!Number.isSafeInteger(v)))fail(label+'必须为有效的非负'+(integer?'整数。':'数值。'));return v;}
function url(v){text(v,255,'文件链接');let u;try{u=new URL(v);}catch{fail('请填写完整 HTTPS 文件链接。');}if(u.protocol!=='https:'||u.username||u.password||/\s/u.test(v)||u.href.length>255)fail('文件链接须为不含凭据且不超过 255 字符的 HTTPS 链接。');return v;}
function idList(v,label){list(v,label);v.forEach(id);unique(v,x=>x,label);}
export function validateStructuredChanges(changes){
  object(changes,STRUCTURED_EDIT_KEYS,'复杂编辑');const fields=Object.keys(changes).filter(k=>!k.startsWith('context'));
  if(!fields.length)fail('请选择复杂编辑项目。');id(changes.contextShopId);id(changes.contextCategoryId);
  if(has(changes,'allSkuWeightGrams')){const weight=amount(changes.allSkuWeightGrams,'SKU重量');if(weight<1||weight>100000)fail('SKU重量须在1–100000g之间。');}
  if(has(changes,'descriptionImages')){object(changes.descriptionImages,['ticket','sourceUrls'],'描述图');text(changes.descriptionImages.ticket,64,'描述图预览');list(changes.descriptionImages.sourceUrls,'描述图片',15);changes.descriptionImages.sourceUrls.forEach(v=>text(v,4096,'描述图片地址'));}
  if(has(changes,'brandFromSample')){object(changes.brandFromSample,['detailId'],'品牌样例');if(!/^\d+$/.test(changes.brandFromSample.detailId)||typeof changes.brandFromSample.detailId!=='string')fail('品牌样例商品编号无效。');}
  if(has(changes,'attributes')){list(changes.attributes,'产品属性');unique(changes.attributes,x=>x.id,'产品属性');for(const a of changes.attributes){object(a,['id','values','clear'],'产品属性');id(a.id);if(a.clear!==undefined&&a.clear!==true)fail('清空属性须明确设置。');if(a.clear===true){if(!Array.isArray(a.values)||a.values.length)fail('清空属性必须明确提供空值列表。');continue;}list(a.values,'属性值');for(const v of a.values){object(v,['id','name'],'属性值');if(v.id)id(v.id);else text(v.name,255,'自定义属性值');}unique(a.values,v=>v.id||v.name,'属性值');}}
  if(has(changes,'certifications')){list(changes.certifications,'证书');unique(changes.certifications,x=>x.id,'证书');for(const c of changes.certifications){object(c,['id','files','expirationDate'],'证书');id(c.id);list(c.files,'证书文件',20);for(const f of c.files){object(f,['fileUrl','fileName','fileType','fileId'],'证书文件');url(f.fileUrl);text(f.fileName,255,'文件名');text(f.fileType,30,'文件类型');if(f.fileId!==undefined)id(f.fileId);}if(c.expirationDate!==undefined){if(!/^\d{4}-\d{2}-\d{2}$/.test(c.expirationDate)||Number.isNaN(Date.parse(c.expirationDate))||new Date(c.expirationDate).toISOString().slice(0,10)!==c.expirationDate)fail('证书到期日期无效。');}}}
  for(const k of ['manufacturerIds','responsiblePersonIds'])if(has(changes,k))idList(changes[k],'制造商/负责人');
  if(has(changes,'skuPrices')){object(changes.skuPrices,['price','originPrice','priceIncludeVat'],'SKU 价格');if(!Object.keys(changes.skuPrices).length)fail('请填写价格。');Object.values(changes.skuPrices).forEach(v=>amount(v,'价格'));}
  if(has(changes,'skuInventory')){object(changes.skuInventory,['warehouseId','stock'],'库存');id(changes.skuInventory.warehouseId);amount(changes.skuInventory.stock,'库存',true);}
  if(has(changes,'sellerSku')){object(changes.sellerSku,['mode','value'],'平台 SKU');if(!['prefix','suffix','template'].includes(changes.sellerSku.mode))fail('平台 SKU 编辑模式无效。');text(changes.sellerSku.value,50,'平台 SKU 前后缀');}
  if(has(changes,'skuUpdates')){
    if(['skuPrices','skuInventory','sellerSku'].some(key=>has(changes,key)))fail('逐SKU修改不能与全量价格、库存或平台SKU修改同时提交。');
    list(changes.skuUpdates,'逐SKU修改',20000);unique(changes.skuUpdates,value=>value?.key,'逐SKU修改');
    for(const update of changes.skuUpdates){
      object(update,['key','price','originPrice','priceIncludeVat','itemNum','inventory'],'逐SKU修改');text(update.key,1000,'SKU原键');
      if(['__proto__','prototype','constructor'].includes(update.key)||Object.keys(update).length===1)fail('请选择有效的原SKU并填写至少一项修改。');
      for(const key of ['price','originPrice','priceIncludeVat'])if(has(update,key))amount(update[key],'SKU价格');
      if(has(update,'itemNum'))text(update.itemNum,50,'平台SKU');
      if(has(update,'inventory')){object(update.inventory,['warehouseId','stock'],'逐SKU库存');id(update.inventory.warehouseId);amount(update.inventory.stock,'库存',true);}
    }
  }
  if(has(changes,'specifications')){list(changes.specifications,'规格');unique(changes.specifications,x=>x.attrId,'规格');for(const a of changes.specifications){object(a,['attrId','name','values'],'规格');id(a.attrId);if(a.name!==undefined)text(a.name,255,'规格名称');if(a.values!==undefined){list(a.values,'规格值');unique(a.values,x=>x.id,'规格值');for(const v of a.values){object(v,['id','name','imageUrl'],'规格值');id(v.id);if(v.name!==undefined)text(v.name,255,'规格值名称');if(v.imageUrl!==undefined)url(v.imageUrl);if(v.name===undefined&&v.imageUrl===undefined)fail('规格值没有修改内容。');}}if(a.name===undefined&&a.values===undefined)fail('规格没有修改内容。');}}
  if(has(changes,'addSkus')){list(changes.addSkus,'新增 SKU',100);for(const sku of changes.addSkus){object(sku,['attributes','price','originPrice','priceIncludeVat','stock','warehouseId','itemNum'],'新增 SKU');list(sku.attributes,'规格组合',10);unique(sku.attributes,x=>x.attrId,'规格组合');for(const a of sku.attributes){object(a,['attrId','valueId','imageUrl'],'规格组合');id(a.attrId);id(a.valueId);if(has(a,'imageUrl'))url(a.imageUrl,255,'规格图片');}amount(sku.price,'销售价');for(const field of ['originPrice','priceIncludeVat'])if(has(sku,field))amount(sku[field],'价格');amount(sku.stock,'库存',true);id(sku.warehouseId);text(sku.itemNum,50,'平台 SKU');}}
  if(has(changes,'replaceSkuStructure')){
    if(['skuPrices','skuInventory','sellerSku','skuUpdates','specifications','addSkus','preSale'].some(key=>has(changes,key)))fail('替换规格与价格不能与其他销售属性修改同时保存。');
    const value=object(changes.replaceSkuStructure,['detailId','template','mappings','warehouseId','mode','seed','variantImages'],'替换规格与价格');
    if(typeof value.detailId!=='string'||!/^[1-9]\d{0,24}$/u.test(value.detailId))fail('规格替换的商品编号无效。');
    const template=validateSkuStructureTemplate(value.template);
    if(value.mode==='direct'){if(has(value,'mappings')||typeof value.seed!=='string'||!/^\d{13,16}$/u.test(value.seed)||!Number.isSafeInteger(Number(value.seed)))fail('直接替换规格参数无效。');validateSkuVariantImages(value.variantImages,template);}
    else{if(has(value,'mode')||has(value,'seed')||has(value,'variantImages'))fail('规格替换模式无效。');object(value.mappings,['dimensions'],'规格映射');list(value.mappings.dimensions,'规格映射',3);}
    if(has(value,'warehouseId'))id(value.warehouseId);
  }
  if(has(changes,'preSale')){object(changes.preSale,['type'],'预售');if(changes.preSale.type!=='NONE')fail('官方文档未提供其他预售枚举，目前仅支持取消预售 NONE。');}
  return fields;
}
export function structuredContextNeeds(changes){const fields=validateStructuredChanges(changes),needs=[];
  if(fields.some(k=>['attributes','certifications','addSkus','replaceSkuStructure'].includes(k)))needs.push('metadata');
  if(fields.some(k=>['skuInventory','addSkus'].includes(k))||has(changes,'replaceSkuStructure')&&has(changes.replaceSkuStructure,'warehouseId'))needs.push('warehouses');
  if(fields.includes('skuUpdates')&&changes.skuUpdates.some(value=>has(value,'inventory')))needs.push('warehouses');
  if(fields.includes('manufacturerIds'))needs.push('manufacturers');if(fields.includes('responsiblePersonIds'))needs.push('responsiblePersons');return needs;
}
function mergeById(existing,updates,key){if(!Array.isArray(existing))fail('原有商品资料结构无效。');const out=structuredClone(existing);for(const value of updates){const i=out.findIndex(x=>String(x[key])===String(value[key]));if(i<0)out.push(value);else out[i]={...out[i],...value};}return out;}
function requireWarehouse(ctx,id){if(!Array.isArray(ctx.warehouses)||!ctx.warehouses.some(w=>String(w.warehouseId)===id))fail('所选仓库不属于当前商品店铺。');}
function withInventory(sku,{warehouseId,stock},ctx){
  requireWarehouse(ctx,warehouseId);const maps=sku.shopIdToWarehouseIdAndStockMap??{};
  if(!plain(maps)||!plain(maps[ctx.shopId]??{}))fail('原有仓库库存结构无效。');const ownMap={...(maps[ctx.shopId]??{}),[warehouseId]:String(stock)};
  const nums=Object.values(ownMap).map(v=>typeof v==='string'&&/^\d+$/.test(v)?Number(v):v);nums.forEach(v=>amount(v,'原仓库库存',true));const total=nums.reduce((a,b)=>a+b,0);amount(total,'库存总数',true);
  return {...sku,stock:total,shopIdToWarehouseIdAndStockMap:{...maps,[ctx.shopId]:ownMap}};
}
/** Returns absolute top-level patches. Requires authoritative context for each
 * target. Never reuse a prior product's data as the body of another product. */
export function compileStructuredPatch(info,changes,ctx){
  validateStructuredChanges(changes);
  if(changes.contextShopId!==ctx.shopId||changes.contextCategoryId!==ctx.categoryId)fail('该商品店铺或类目与编辑样例不同，请分组编辑。');
  const out={};
  if(changes.descriptionImages){if(typeof ctx.descriptionNotes!=='string')fail('描述图未经过预览核验。');out.notes=ctx.descriptionNotes;}
  if(changes.brandFromSample){if(ctx.brandSampleId!==changes.brandFromSample.detailId)fail('品牌样例未重新核验。');out.brandId=text(ctx.brandId,20,'样例商品品牌');}
  if(changes.certifications){const defs=ctx.metadata?.categoryConfig?.productCertifications;
    if(!Array.isArray(defs))fail('未读取到认证类型。');const updates=changes.certifications.map(c=>{if(!defs.some(d=>String(d.id)===c.id))fail('证书类型不适用于当前类目。');return {id:c.id,files:structuredClone(c.files),...(c.expirationDate!==undefined?{gmtExpirationDate:c.expirationDate}:{})};});
    out.productCertifications=mergeById(info.productCertifications??[],updates,'id');
  }
  if(changes.attributes){
    const updates=compileMiaoshouAttributeUpdates(changes.attributes,ctx.metadata);
    const cleared=new Set(changes.attributes.filter(a=>a.clear===true).map(a=>a.id));
    const existing=info.productAttributes??[];if(!Array.isArray(existing))fail('原有商品资料结构无效。');
    out.productAttributes=mergeById(existing.filter(a=>!cleared.has(String(a.attributeId))),updates.filter(a=>!cleared.has(a.attributeId)),'attributeId');
    validateMiaoshouAttributeDependencies(out.productAttributes,out.productCertifications??info.productCertifications??[],ctx.metadata);
  }
  for(const [key,source] of [['manufacturerIds','manufacturers'],['responsiblePersonIds','responsiblePersons']])if(changes[key]){if(!Array.isArray(ctx[source])||changes[key].some(id=>!ctx[source].some(x=>String(x.id)===id)))fail('制造商或负责人不属于当前店铺。');out[key]=[...changes[key]];}
  if(changes.replaceSkuStructure){
    const {detailId,template,mappings,warehouseId}=changes.replaceSkuStructure;
    if(detailId!==String(info.detailId))fail('规格替换的目标商品已变化，请重新读取并应用模板。');
    if(warehouseId!==undefined)requireWarehouse(ctx,warehouseId);
    if(changes.replaceSkuStructure.mode==='direct'){
      const resolved=resolveDirectSkuReplacement({template,warehouseId,seed:changes.replaceSkuStructure.seed,variantImages:changes.replaceSkuStructure.variantImages,context:{...ctx,info,product:{title:info.title}}});
      if(!resolved.ok)fail('规格替换未通过当前商品核验：'+resolved.issues.map(issue=>issue.message).join('；'));
      Object.assign(out,resolved.patch);
    }else{
    const resolved=resolveSkuStructureTemplate({template,mappings,warehouseId,replace:true,context:{...ctx,info,product:{title:info.title}}});
    if(!resolved.ok||!resolved.replacementPlan)fail('规格替换未通过当前商品核验：'+resolved.issues.map(issue=>issue.message).slice(0,5).join('；'));
    if(JSON.stringify(resolved.mappings)!==JSON.stringify(mappings))fail('规格映射已变化或未完整确认，请重新应用模板。');
    const {removedKeys,dimensions,updates,additions}=resolved.replacementPlan,skuMap=structuredClone(info.skuMap);
    for(const key of removedKeys)skuMap[key].isDelete='1';
    const chosen=new Map(dimensions.map(dimension=>[dimension.attrId,new Set(dimension.values.map(value=>value.id))]));
    const skuPropertyList=info.skuPropertyList.map(prop=>({...prop,attrValueList:prop.attrValueList.filter(value=>chosen.get(String(prop.attrId)).has(String(value.attrValueId)))}));
    const updated=updates.length||additions.length?compileStructuredPatch({...info,skuMap,skuPropertyList},{contextShopId:ctx.shopId,contextCategoryId:ctx.categoryId,...(updates.length?{skuUpdates:updates}:{}),...(additions.length?{addSkus:additions}:{})},ctx):{};
    const available=updated.skuPropertyList??skuPropertyList;
    out.skuMap=updated.skuMap??skuMap;
    out.skuPropertyList=dimensions.map(dimension=>{
      const prop=available.find(value=>String(value.attrId)===dimension.attrId);
      return {...prop,attrValueList:dimension.values.map(({id,name})=>{
        const value=prop.attrValueList.find(option=>String(option.attrValueId)===id);
        return {...(value??{attrValueId:id,attrValue:name}),imgUrl:''};
      })};
    });
    }
  }
  if(changes.specifications){if(!Array.isArray(info.skuPropertyList))fail('原商品没有可编辑规格。');const props=structuredClone(info.skuPropertyList);
    for(const update of changes.specifications){const matching=props.filter(p=>String(p.attrId)===update.attrId);if(matching.length!==1)fail('原商品未能唯一确认该规格。');const [prop]=matching;if(update.name!==undefined)prop.attrName=update.name;
      for(const v of update.values??[]){const options=prop.attrValueList?.filter(x=>String(x.attrValueId)===v.id);if(options?.length!==1)fail('原商品未能唯一确认该规格值。');const [old]=options;if(v.name!==undefined)old.attrValue=v.name;if(v.imageUrl!==undefined)old.imgUrl=v.imageUrl;}
      if(new Set(prop.attrValueList.map(x=>x.attrValue)).size!==prop.attrValueList.length)fail('修改后规格值名称重复。');
    }if(new Set(props.map(x=>x.attrName)).size!==props.length)fail('修改后规格名称重复。');out.skuPropertyList=props;
  }
  if(['skuPrices','skuInventory','sellerSku','skuUpdates','addSkus','preSale'].some(k=>has(changes,k))){
    if(!plain(info.skuMap)||Object.keys(info.skuMap).length>20000)fail('原商品 SKU 结构无效。');const skus=structuredClone(info.skuMap);
    const keys=Object.keys(skus).filter(k=>{if(!plain(skus[k]))fail('原 SKU 结构无效。');return !flag(skus[k].isDelete);});
    if(!keys.length&&!changes.addSkus)fail('原商品没有可编辑的有效 SKU。');
    const activeKeys=new Set(keys),updates=new Map((changes.skuUpdates||[]).map(value=>[value.key,value]));
    for(const key of updates.keys())if(!activeKeys.has(key))fail('所选SKU已不存在或已删除，请重新读取后修改。');
    for(const [index,key] of keys.sort().entries()){let sku=skus[key];if(changes.skuPrices)Object.assign(sku,changes.skuPrices);
      if(changes.skuInventory)sku=withInventory(sku,changes.skuInventory,ctx);
      const update=updates.get(key);if(update){for(const field of ['price','originPrice','priceIncludeVat','itemNum'])if(has(update,field))sku[field]=update[field];if(update.inventory)sku=withInventory(sku,update.inventory,ctx);}
      if(changes.sellerSku){const {mode,value}=changes.sellerSku;
        if((mode!=='template'||value.includes('{sku}'))&&(typeof sku.itemNum!=='string'||!sku.itemNum.trim()))fail('存在未填写平台 SKU 的规格，请使用不含原 SKU 的模板。');
        if(mode==='template'){
          if(value.replace(/\{(?:productId|index|sku)\}/g,'').match(/[{}]/))fail('平台 SKU 模板仅支持 {productId}、{index} 和 {sku}。');
          sku.itemNum=value.replace(/\{(productId|index|sku)\}/g,(_m,token)=>token==='productId'?String(info.detailId):token==='index'?String(index+1):sku.itemNum);
        }else sku.itemNum=mode==='prefix'?value+sku.itemNum:sku.itemNum+value;
        text(sku.itemNum,50,'修改后平台 SKU');}
      if(changes.preSale)sku.preSale={type:'NONE'};
      Object.defineProperty(skus,key,{value:sku,writable:true,enumerable:true,configurable:true});
    }
    const addedProps=changes.addSkus?structuredClone(out.skuPropertyList??info.skuPropertyList):null;
    for(const addition of changes.addSkus??[]){const props=addedProps;if(!Array.isArray(props)||!props.length||addition.attributes.length!==props.length)fail('新增 SKU 必须选择商品全部规格。');
      const ids=props.map(prop=>{const selected=addition.attributes.find(a=>a.attrId===String(prop.attrId));if(!selected||!/^\d+$/.test(selected.valueId))fail('新增 SKU 必须选择有效规格值。');
        if(!Array.isArray(prop.attrValueList))fail('规格值列表无效。');
        if(!prop.attrValueList.some(v=>String(v.attrValueId)===selected.valueId)){
          const definition=ctx.metadata?.categorySaleAttrList?.find(d=>String(d.attrId)===String(prop.attrId));const value=definition?.values?.find(v=>String(v.id)===selected.valueId);
          if(!value)fail('新增规格值不在当前后台选项中。');
          prop.attrValueList.push({attrValueId:selected.valueId,attrValue:String(value.name)});
        }if(has(selected,'imageUrl')){if(prop!==props[0])fail('新增SKU的规格图片仅能设置第一维，其他维度原图保留。');prop.attrValueList.find(v=>String(v.attrValueId)===selected.valueId).imgUrl=selected.imageUrl;}return selected.valueId;});
      const key=';'+ids.sort((a,b)=>BigInt(a)<BigInt(b)?-1:BigInt(a)>BigInt(b)?1:0).join(';')+';';
      if(own(skus,key))fail('该规格组合已存在，不能重复添加。');
      Object.defineProperty(skus,key,{value:withInventory({price:addition.price,...Object.fromEntries(['originPrice','priceIncludeVat'].filter(field=>has(addition,field)).map(field=>[field,addition[field]])),itemNum:addition.itemNum,isDelete:'0'},addition,ctx),enumerable:true,writable:true,configurable:true});
    }
    if(changes.sellerSku||changes.addSkus||changes.skuUpdates?.some(value=>has(value,'itemNum'))){const nums=Object.values(skus).filter(v=>!flag(v.isDelete)).map(v=>v.itemNum).filter(v=>v!==undefined&&v!=='');if(new Set(nums).size!==nums.length)fail('修改后平台 SKU 重复。');}
    out.skuMap=skus;if(addedProps){for(const prop of addedProps)if(new Set(prop.attrValueList.map(v=>v.attrValue)).size!==prop.attrValueList.length)fail('新增规格值与现有名称重复，请在后台核对。');out.skuPropertyList=addedProps;}
  }
  if(has(changes,'allSkuWeightGrams')){
    const source=out.skuMap??info.skuMap;
    if(source!==undefined&&source!==null){if(!plain(source)||Object.keys(source).length>20000)fail('商品 SKU 资料格式无效。');out.skuMap=structuredClone(source);for(const sku of Object.values(out.skuMap)){if(!plain(sku))fail('商品 SKU 资料格式无效。');sku.weight=changes.allSkuWeightGrams/1000;}}
  }
  return out;
}
