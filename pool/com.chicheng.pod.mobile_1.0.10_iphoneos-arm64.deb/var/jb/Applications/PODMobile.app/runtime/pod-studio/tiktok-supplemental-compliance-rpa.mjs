import { supplementalComplianceTargets, buildSupplementalComplianceField } from './dist/tiktok-supplemental-compliance.js';

// The two fixed-label getters must establish the real compliance section/row.
// A normal snapshot label alone never establishes that association.
const reads = new WeakMap();
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value)
  && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
const own = (value, key) => { if (!plain(value)) return undefined; const descriptor = Object.getOwnPropertyDescriptor(value, key); return descriptor && Object.hasOwn(descriptor, 'value') ? descriptor.value : undefined; };
const fingerprint = value => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value);
const clean = value => typeof value === 'string' ? value.replace(/\s+/gu, ' ').trim() : '';
const identityKeys = ['shopId', 'shopName', 'region', 'idKind'];
const descriptorKeys = ['label', 'section', 'ordinal', 'groupCount', 'required', 'multiple', 'controlType'];
const sampleKeys = ['accepted', 'complete', 'localDraftOnly', 'commitVerified', 'ownerTag', 'ownerRole', 'scanComplete', 'ownerRevalidated',
  'fieldAssociationVerified', 'sectionAssociationVerified', 'truncated', 'fieldRowCount', 'ownerCount', 'labelCount', 'sectionOwnerCount',
  'unknownControlCount', 'missingLabelCount', 'disabledControlCount', 'readOnlyControlCount', 'documentFingerprint', 'schemaFingerprint', 'associationFingerprint'];
const scopeError = () => Object.assign(new Error('补充合规读取期间页面或读取上下文发生变化，本次结果未保存。'), { code: 'SELLER_SUPPLEMENTAL_COMPLIANCE_SCOPE_CHANGED' });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const abort = signal => { if (signal?.aborted) throw signal.reason || Object.assign(new Error('任务已取消。'), { code: 'SELLER_READ_ABORTED' }); };
const scopeSignature = context => JSON.stringify([context.categoryId, context.categoryPath, context.documentFingerprint, context.attributeContext,
  identityKeys.map(key => clean(context.identity?.[key]))]);

function operations(page, options) {
  const { context, assertScope, contextFingerprint, readSnapshot = currentPage => currentPage.snapshot(), signal, nowMs = () => Date.now() } = options;
  if (!plain(context) || !fingerprint(context.documentFingerprint) || !fingerprint(context.attributeContext)
    || typeof context.categoryId !== 'string' || !/^[A-Za-z0-9_-]{1,160}$/u.test(context.categoryId)
    || !Array.isArray(context.categoryPath) || !context.categoryPath.length || context.categoryPath.some(value => !clean(value))
    || !clean(context.identity?.shopId) || !clean(context.identity?.shopName) || clean(context.identity?.region) !== 'US'
    || typeof assertScope !== 'function' || typeof contextFingerprint !== 'function' || typeof readSnapshot !== 'function'
    || typeof nowMs !== 'function') throw scopeError();
  const started = nowMs(); if (!Number.isFinite(started)) throw scopeError();
  const deadline = started + 30000;
  const check = () => { abort(signal); const current = nowMs(); if (!Number.isFinite(current)) throw scopeError(); if (current >= deadline) throw Object.assign(new Error('补充合规控件读取超时，本次结果未保存。'), { code: 'SELLER_SUPPLEMENTAL_COMPLIANCE_READ_TIMEOUT' }); };
  const verify = snapshot => {
    check();
    let url; try { url = new URL(snapshot?.url); } catch { throw scopeError(); }
    if (url.protocol !== 'https:' || url.hostname !== 'seller.us.tiktokshopglobalselling.com' || !/^\/product\/create\/?$/u.test(url.pathname)
      || url.hash || url.searchParams.getAll('shop_region').length !== 1 || url.searchParams.get('shop_region') !== 'US') throw scopeError();
    if (snapshot.securityChallenge?.detected !== false) throw Object.assign(new Error('页面安全状态尚未确认，本次读取已停止。'), { code: snapshot.securityChallenge?.detected === true ? 'SELLER_SECURITY_VERIFICATION' : 'SELLER_SUPPLEMENTAL_COMPLIANCE_SCOPE_CHANGED' });
    if (identityKeys.some(key => clean(snapshot.identity?.[key]) && clean(context.identity[key])
      && clean(snapshot.identity[key]).toLocaleLowerCase() !== clean(context.identity[key]).toLocaleLowerCase())) throw scopeError();
    const asserted = assertScope(snapshot, context);
    if (asserted === false || asserted && typeof asserted.then === 'function') throw scopeError();
    if (contextFingerprint(snapshot) !== context.attributeContext) throw scopeError();
    check();
  };
  const fresh = async () => { check(); const state = await readSnapshot(page); check(); verify(state); return state; };
  const document = async () => { check(); const value = await page.getDocumentFingerprint(); check(); if (value !== context.documentFingerprint) throw scopeError(); return value; };
  return { check, verify, fresh, document, context, wait: options.wait || sleep };
}

function sample(raw) {
  const descriptor = own(raw, 'descriptor');
  return { ...Object.fromEntries(sampleKeys.map(key => [key, own(raw, key)])), descriptor: Object.fromEntries(descriptorKeys.map(key => [key, own(descriptor, key)])) };
}

function fieldFor(target, observation) {
  const value = observation.descriptor;
  if (value.label !== target.label || value.section !== '商品合规' || value.ordinal !== 1 || value.groupCount !== 1
    || value.controlType !== 'select' || typeof value.required !== 'boolean' || typeof value.multiple !== 'boolean') return null;
  return { key: target.key, ...value };
}

function createCache(page, options, entries) {
  const cache = Object.freeze({ version: 1, fields: entries.map(entry => structuredClone(entry.field)) });
  reads.set(cache, { page, context: options.context ? scopeSignature(options.context) : '', entries, finalized: false });
  return cache;
}

/** Same owned page/read only. Missing capability or an unverified target yields
 * no local field. No menu is opened, no value is read or written, and no HTTP,
 * pointer, screenshot, navigation or cleanup action is performed by this helper.
 * assertScope and contextFingerprint must be synchronous, pure scope checks. */
export async function probeSupplementalComplianceFields(page, options = {}) {
  if (typeof page?.readPublicComplianceFieldCensus !== 'function' || typeof page.getDocumentFingerprint !== 'function') return createCache(page, options, []);
  const op = operations(page, options), { definition, context } = options, entries = [];
  await op.fresh(); await op.document();
  for (const target of supplementalComplianceTargets) {
    const observations = []; let field;
    for (let index = 0; index < 3; index++) {
      await op.fresh(); op.check();
      const raw = await page.readPublicComplianceFieldCensus(target.label); op.check();
      await op.fresh(); await op.document();
      if (own(raw, 'accepted') !== true) break;
      if (own(raw, 'documentFingerprint') !== context.documentFingerprint) throw scopeError();
      const observation = sample(raw), current = fieldFor(target, observation);
      if (!current || field && JSON.stringify(current) !== JSON.stringify(field)) break;
      field = current; observations.push(observation);
      if (index < 2) { await op.wait(100); op.check(); }
    }
    if (observations.length !== 3) continue;
    const built = buildSupplementalComplianceField({ field, categoryId: context.categoryId, definition, samples: observations });
    if (built.accepted === true) entries.push({ target, descriptor: field, observations, field: built.field, signature: JSON.stringify(built.field) });
  }
  await op.fresh(); await op.document();
  return createCache(page, options, entries);
}

/** Re-read every proposed target once using its fixed label. The caller still
 * independently verifies the final full identity and primary mapper signature
 * before attaching these fields to a response. No primary groups or whole-read
 * completeness flags are changed. A cache cannot cross pages/reads or be reused. */
export async function finalizeSupplementalComplianceFields(page, cache, options = {}) {
  const registration = reads.get(cache);
  if (!registration || registration.finalized) throw scopeError();
  registration.finalized = true;
  if (registration.page !== page || registration.context !== (options.context ? scopeSignature(options.context) : '')) throw scopeError();
  if (typeof page?.readPublicComplianceFieldCensus !== 'function' || typeof page.getDocumentFingerprint !== 'function') return [];
  const op = operations(page, options), result = [];
  await op.fresh(); await op.document();
  if (!registration.entries.length) return result;
  for (const entry of registration.entries) {
    await op.fresh(); op.check();
    const raw = await page.readPublicComplianceFieldCensus(entry.target.label); op.check();
    await op.fresh(); await op.document();
    if (own(raw, 'accepted') !== true) continue;
    if (own(raw, 'documentFingerprint') !== options.context.documentFingerprint) throw scopeError();
    const observation = sample(raw), first = entry.observations[0], field = fieldFor(entry.target, observation);
    if (!field || JSON.stringify(field) !== JSON.stringify(entry.descriptor)
      || ['schemaFingerprint', 'associationFingerprint', 'ownerTag', 'ownerRole'].some(key => observation[key] !== first[key])) throw scopeError();
    const built = buildSupplementalComplianceField({ field, categoryId: options.context.categoryId, definition: options.definition, samples: entry.observations });
    const verified = buildSupplementalComplianceField({ field, categoryId: options.context.categoryId, definition: options.definition, samples: [...entry.observations, observation] });
    // The fourth sample revalidates the original three-sample proof; retaining
    // its stableSamples=3 makes the public field signature directly comparable.
    if (built.accepted !== true || verified.accepted !== true || JSON.stringify(built.field) !== entry.signature) throw scopeError();
    result.push(built.field);
  }
  await op.fresh(); await op.document();
  return result;
}
