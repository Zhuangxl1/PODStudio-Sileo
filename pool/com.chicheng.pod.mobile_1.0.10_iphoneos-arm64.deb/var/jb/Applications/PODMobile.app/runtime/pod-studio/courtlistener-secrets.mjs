import {spawn} from 'node:child_process';
import {constants} from 'node:fs';
import {lstat, mkdir, mkdtemp, open, readdir, realpath, rename, rmdir, unlink} from 'node:fs/promises';
import {dirname, isAbsolute, join, parse, relative, resolve, sep} from 'node:path';
import {fileURLToPath} from 'node:url';

const PROJECT = fileURLToPath(new URL('./', import.meta.url));
const SCRIPT = fileURLToPath(new URL('./provider-secrets.ps1', import.meta.url));
const MAX_CIPHERTEXT_BYTES = 4096;
const MAX_OUTPUT_BYTES = 512;
const safeError = (code = 'COURTLISTENER_CREDENTIALS_UNAVAILABLE') => Object.assign(new Error(
  code === 'COURTLISTENER_TOKEN_INVALID' ? 'CourtListener Token 格式无效。' :
  code === 'COURTLISTENER_CREDENTIALS_UNSUPPORTED' ? 'CourtListener 凭据需要 Windows 本机加密存储。' :
  'CourtListener 本机加密凭据不可用，请检查当前 Windows 账号及用户目录权限。',
), {code, status: code === 'COURTLISTENER_TOKEN_INVALID' ? 400 : 503});
const validToken = value => typeof value === 'string' && value.length === 40 && /^[a-fA-F0-9]{40}$/.test(value);
const canonical = value => process.platform === 'win32' ? value.toLowerCase() : value;
const samePath = (left, right) => canonical(resolve(left)) === canonical(resolve(right));
const within = (parent, child) => {
  const path = relative(canonical(resolve(parent)), canonical(resolve(child)));
  return path === '' || path !== '..' && !path.startsWith('..' + sep) && !isAbsolute(path);
};
const sameFile = (left, right) => left && right && left.dev === right.dev && left.ino === right.ino &&
  left.size === right.size && left.mtimeMs === right.mtimeMs && left.ctimeMs === right.ctimeMs;

/** Host-only API. Supply the service's external user-data root; never expose writeToken over HTTP. */
export function createCourtListenerCredentials({root, spawnImpl = spawn, platform = process.platform, timeoutMs = 10000} = {}) {
  if (typeof root !== 'string' || !isAbsolute(root) || root.includes('\0') ||
      within(PROJECT, root) || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 30000) throw safeError();
  const directory = resolve(root, 'courtlistener'), tokenPath = join(directory, 'token.dpapi');
  const lockPath = join(directory, '.token-write.lock');
  let queue = Promise.resolve();
  const serial = operation => {
    const pending = queue.then(operation, operation);
    queue = pending.catch(() => {});
    return pending;
  };
  const supported = () => {if (platform !== 'win32') throw safeError('COURTLISTENER_CREDENTIALS_UNSUPPORTED');};

  // Check every ancestor, including user-data root ancestors: junctions and links are refused.
  async function checkedDirectory(path, create = false) {
    const base = parse(path).root;
    let current = base;
    for (const part of ['', ...relative(base, path).split(sep).filter(Boolean)]) {
      if (part) current = join(current, part);
      let entry;
      try {entry = await lstat(current);} catch (error) {
        if (error.code !== 'ENOENT') throw error;
        if (!create) return false;
        try {await mkdir(current, {mode: 0o700});} catch (mkdirError) {if (mkdirError.code !== 'EEXIST') throw mkdirError;}
        entry = await lstat(current);
      }
      if (entry.isSymbolicLink() || !entry.isDirectory() || !samePath(await realpath(current), current)) throw safeError();
    }
    return true;
  }

  async function snapshot(path) {
    let entry;
    try {entry = await lstat(path);} catch (error) {if (error.code === 'ENOENT') return null; throw error;}
    if (entry.isSymbolicLink() || !entry.isFile() || entry.nlink !== 1 || entry.size < 1 || entry.size > MAX_CIPHERTEXT_BYTES) throw safeError();
    const file = await open(path, constants.O_RDONLY | (constants.O_NOFOLLOW || 0));
    try {
      const before = await file.stat();
      if (!sameFile(entry, before)) throw safeError();
      const bytes = Buffer.alloc(MAX_CIPHERTEXT_BYTES + 1);
      try {
        const {bytesRead} = await file.read(bytes, 0, bytes.length, 0);
        const after = await file.stat();
        if (bytesRead !== before.size || !sameFile(before, after) || !sameFile(after, await lstat(path))) throw safeError();
        return {entry: after, bytes: Buffer.from(bytes.subarray(0, bytesRead))};
      } finally {bytes.fill(0);}
    } finally {await file.close();}
  }

  function native(mode, path, token) {
    return new Promise((done, reject) => {
      let child, timer, settled = false, output = Buffer.alloc(0);
      const finish = (error, value) => {
        if (settled) return;
        settled = true; clearTimeout(timer); output.fill(0);
        if (error) reject(safeError()); else done(value);
      };
      const stop = () => {try {child?.kill();} catch {} finish(true);};
      try {
        child = spawnImpl('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass',
          '-File', SCRIPT, '-Mode', mode, '-Path', path], {windowsHide: true, shell: false, stdio: ['pipe', 'pipe', 'ignore']});
        timer = setTimeout(stop, timeoutMs);
        child.stdout.on('data', chunk => {
          if (settled) return;
          const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
          if (output.length + bytes.length > MAX_OUTPUT_BYTES) return stop();
          const combined = Buffer.concat([output, bytes]); output.fill(0); output = combined;
        });
        child.stdout.on('error', stop);
        child.stdin.on('error', stop);
        child.once('error', stop);
        child.once('close', code => {
          if (settled) return;
          if (code !== 0) return finish(true);
          try {
            const text = output.toString('utf8');
            if (mode === 'write') return text === 'saved' ? finish(false, true) : finish(true);
            const value = JSON.parse(text);
            // A missing file is handled before decrypting; {} and foreign provider keys are invalid here.
            if (!value || Array.isArray(value) || Object.keys(value).length !== 1 ||
                !Object.hasOwn(value, 'token') || !validToken(value.token)) return finish(true);
            finish(false, value.token);
          } catch {finish(true);}
        });
        // Never place the token in argv, environment variables, diagnostics, or public status.
        child.stdin.end(mode === 'write' ? JSON.stringify({token}) : '');
      } catch {stop();}
    });
  }

  async function read() {
    supported();
    if (!await checkedDirectory(directory)) return null;
    const before = await snapshot(tokenPath);
    if (!before) return null;
    try {
      const token = await native('read', tokenPath);
      await checkedDirectory(directory);
      const after = await snapshot(tokenPath);
      try {if (!after || !sameFile(before.entry, after.entry) || !before.bytes.equals(after.bytes)) throw safeError();}
      finally {after?.bytes.fill(0);}
      return token;
    } finally {before.bytes.fill(0);}
  }

  async function cleanupStage(path, identity) {
    if (!path || dirname(path) !== directory || !within(directory, path)) return;
    try {
      await checkedDirectory(directory);
      const current = await lstat(path);
      if (current.isSymbolicLink() || !current.isDirectory() || current.ino !== identity.ino || current.dev !== identity.dev ||
          !samePath(await realpath(path), path)) return;
      // Non-recursive cleanup cannot traverse a replaced subdirectory or junction.
      for (const name of await readdir(path)) {
        if (/^token\.dpapi(?:\.[a-f0-9]{32}\.(?:tmp|bak))?$/.test(name)) await unlink(join(path, name));
      }
      await rmdir(path);
    } catch {} // Only encrypted bytes can remain after an interrupted native helper.
  }

  async function write(token) {
    supported();
    if (!validToken(token)) throw safeError('COURTLISTENER_TOKEN_INVALID');
    await checkedDirectory(directory, true);
    let lock, lockIdentity, stage, stageIdentity, previous;
    try {
      lock = await open(lockPath, 'wx', 0o600);
      lockIdentity = await lock.stat();
      previous = await snapshot(tokenPath);
      // Refuse to replace an existing profile that cannot be decrypted or has the wrong schema.
      if (previous) await read();
      stage = await mkdtemp(join(directory, '.token-stage-'));
      stageIdentity = await lstat(stage);
      await checkedDirectory(stage);
      const stagedPath = join(stage, 'token.dpapi');
      await native('write', stagedPath, token);
      const staged = await snapshot(stagedPath);
      if (!staged) throw safeError();
      try {
        if (await native('read', stagedPath) !== token) throw safeError();
        await checkedDirectory(stage);
        const current = await snapshot(tokenPath);
        try {
          if (previous ? !current || !sameFile(previous.entry, current.entry) || !previous.bytes.equals(current.bytes) : current !== null) throw safeError();
        } finally {current?.bytes.fill(0);}
        const checkedStage = await snapshot(stagedPath);
        try {
          if (!checkedStage || !sameFile(staged.entry, checkedStage.entry) || !staged.bytes.equals(checkedStage.bytes)) throw safeError();
        } finally {checkedStage?.bytes.fill(0);}
        // Same-volume atomic promotion happens only after encryption and round-trip validation succeed.
        await rename(stagedPath, tokenPath);
      } finally {staged.bytes.fill(0);}
      return {configured: true, storage: 'windows-dpapi'};
    } finally {
      previous?.bytes.fill(0);
      await cleanupStage(stage, stageIdentity);
      if (lock) {
        await lock.close().catch(() => {});
        try {
          await checkedDirectory(directory);
          const current = await lstat(lockPath);
          if (!current.isSymbolicLink() && current.ino === lockIdentity.ino && current.dev === lockIdentity.dev) await unlink(lockPath);
        } catch {}
      }
    }
  }

  // All filesystem and native-process failures collapse to fixed, credential-free errors.
  const guarded = operation => serial(async () => {
    try {return await operation();} catch (error) {
      if (['COURTLISTENER_TOKEN_INVALID', 'COURTLISTENER_CREDENTIALS_UNSUPPORTED'].includes(error?.code)) throw safeError(error.code);
      throw safeError();
    }
  });
  return Object.freeze({
    readToken: () => guarded(read),
    writeToken: token => guarded(() => write(token)),
    status: () => guarded(async () => ({configured: Boolean(await read()), storage: 'windows-dpapi'})),
  });
}
