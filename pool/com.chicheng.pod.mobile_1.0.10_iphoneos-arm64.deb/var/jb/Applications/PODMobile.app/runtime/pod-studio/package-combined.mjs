import {verifyPackagedCatalogForBuild} from './scripts/verify-tiktok-catalog.mjs';
import {readFile,writeFile,readdir,mkdir,access,copyFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {zipFileSource,pinZipValue,writeStreamingZip,digestZipValue} from './streaming-zip.mjs';
import {loadHandoverKnowledge} from './handover-knowledge.mjs';
import {loadPackagedTemplateSeeds} from './package-template-seeds.mjs';

const project=fileURLToPath(new URL('./',import.meta.url)),output=resolve(process.env.POD_PACKAGE_OUTPUT||resolve(project,'../delivery'));
const catalogBuildProof=verifyPackagedCatalogForBuild(project);
const version='1.77',folderName='POD设计器_整合完整版_v'+version,exeName='POD服装设计器_整合版_v'+version+'.exe';
const destination=resolve(output,folderName),files=new Map();
const knowledge=await loadHandoverKnowledge();
const generatedKnowledge=JSON.parse(await readFile(resolve(project,'dist/handover/assistant-knowledge.json'),'utf8'));
if(JSON.stringify(generatedKnowledge)!==JSON.stringify(knowledge))throw new Error('交接知识索引缺失或过期：请先运行 node handover-knowledge.mjs --build。');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function add(source,target=source){files.set(target,zipFileSource(resolve(project,source)));}
async function rootDocument(source,target){const html=await readFile(resolve(project,source),'utf8');files.set(target,Buffer.from(html.replaceAll('../dist/handover/','dist/handover/')));}
async function tree(directory){if(directory==='docs/agent-sync')return;for(const entry of await readdir(resolve(project,directory),{withFileTypes:true})){const path=directory+'/'+entry.name;if(entry.isDirectory())await tree(path);else if(entry.isFile())await add(path);}}
async function firstExisting(paths){for(const path of paths)try{await access(path);return path;}catch{}throw new Error('缺少打包产物：请先构建离线 HTML 和 Windows EXE。');}

// Only public program files are included. Host configuration, encrypted profiles,
// materials, Codex accounts, logs and QA output are never distribution inputs.
for(const directory of ['dist','tests','docs','launcher','third-party','resources/tiktok-catalog'])await tree(directory);
for(const file of ['.gitignore','README.md','package.json','server.mjs','desktop-gateway.mjs','desktop-launcher.mjs','start-desktop.ps1',
  'codex-bridge.mjs','codex-provider-settings.mjs','lanyi-provider.mjs','lanyi-image-runtime.mjs','siliconflow-runtime.mjs','provider-http.mjs','codex-network.mjs','codex-launcher.mjs','assistant-service.mjs','listing-suggestion-service.mjs','listing-suggestion-runner.mjs','listing-suggestion-contract.mjs','handover-knowledge.mjs','design-rules.mjs','fission-generation.mjs','quick-fission.mjs','solid-white-print.mjs','启动Codex助手.cmd','miaoshou-client.mjs','courtlistener-client.mjs','courtlistener-secrets.mjs','brand-research-client.mjs','brand-risk-research.mjs','miaoshou-risk-review.mjs','miaoshou-risk-api-source.mjs','risk-review-runner.mjs','risk-review-contract.mjs','risk-description-evidence.mjs','risk-tro-contract.mjs','risk-tro-runner.mjs','miaoshou-service.mjs','miaoshou-listing-title-evidence.mjs','miaoshou-batch.mjs','miaoshou-product-edits.mjs','miaoshou-claim-defaults.mjs','miaoshou-size-chart-library.mjs','miaoshou-category-attribute-templates.mjs','miaoshou-local-category-attributes.mjs','miaoshou-category-names.mjs','miaoshou-attribute-values.mjs','miaoshou-sku-presets.mjs','miaoshou-sku-structure-templates.mjs','miaoshou-edit-fields.mjs','miaoshou-edit-context.mjs','miaoshou-structured-edits.mjs','miaoshou-description-images.mjs','miaoshou-description-templates.mjs','miaoshou-mockup-template-bindings.mjs','miaoshou-cache.mjs','miaoshou-replacement.mjs','miaoshou-image.mjs','lan-launcher.mjs','lan-server.mjs','design-folder-store.mjs','lan-addresses.mjs',
  'global-settings.mjs','storage-root.mjs','host-materials.mjs','host-templates.mjs','adspower-settings.mjs','adspower-client.mjs','tiktok-publishing-service.mjs','tiktok-shop-category-cache.mjs','tiktok-schema-store.mjs','tiktok-builtin-catalog.mjs','tiktok-catalog-codec.mjs','streaming-zip.mjs','tiktok-build-api-schema.mjs','tiktok-seller-rpa.mjs','tiktok-supplemental-compliance-rpa.mjs','tiktok-browser-driver.mjs','tiktok-category-definition.mjs','tiktok-category-localized-definition.mjs','tiktok-category-definition-observer.mjs','tiktok-category-definition-fields.mjs','seed-template-library.mjs','builtin-template-calibration.mjs','provider-secrets.ps1','build-handover.mjs','build-standalone.mjs','validate-standalone.mjs','standalone-module-graph.mjs',
  'package-desktop.mjs','package-lan.mjs','package-lan-delivery.mjs','package-combined.mjs','package-template-seeds.mjs','scripts/build-template-seeds.mjs','scripts/verify-tiktok-catalog.mjs','scripts/finalize-tiktok-catalog.mjs'])await add(file);
for(const [path,bytes] of await loadPackagedTemplateSeeds({project}))files.set(path,bytes);
const integration='integrations/urpiclink/';
for(const file of ['README.md','LICENSE','UPSTREAM.md','main.go','go.mod','go.sum','run-server.ps1','copy-service-key.ps1',
  'read-service-key.ps1','复制服务访问密钥.cmd','启动图床服务.cmd','启动图床服务.ps1','bin/urpiclink.exe','config/config.example.yaml'])await add(integration+file);
for(const directory of ['config','configstore','handler','models','service'])for(const entry of await readdir(resolve(project,integration+directory),{withFileTypes:true}))if(entry.isFile()&&entry.name.endsWith('.go'))await add(integration+directory+'/'+entry.name);
files.set('runtime/node.exe',zipFileSource(process.execPath));
await add('third-party/NODE_LICENSE.txt','runtime/NODE_LICENSE.txt');
// Retain the small XML parser dependencies used by the source test suite.
const require=createRequire(import.meta.url);
let xmlPackage;try{xmlPackage=require.resolve('xml-js/package.json');}catch{xmlPackage=resolve(dirname(process.execPath),'../node_modules/xml-js/package.json');}
const dependencyPackages=[['xml-js',xmlPackage,'LICENSE'],['sax',createRequire(xmlPackage).resolve('sax/package.json'),'LICENSE.md']];
for(const [name,packagePath,license] of dependencyPackages){
  const root=dirname(packagePath),metadata=JSON.parse(await readFile(packagePath,'utf8'));
  files.set('node_modules/'+name+'/package.json',Buffer.from(JSON.stringify(Object.fromEntries(['name','version','main','license','dependencies','engines'].filter(key=>Object.hasOwn(metadata,key)).map(key=>[key,metadata[key]])),null,2)));
  files.set('node_modules/'+name+'/'+license,await readFile(resolve(root,license)));
  for(const entry of await readdir(resolve(root,'lib'),{withFileTypes:true}))if(entry.isFile()&&entry.name.endsWith('.js'))files.set('node_modules/'+name+'/lib/'+entry.name,await readFile(resolve(root,'lib',entry.name)));
}
files.set(exeName,zipFileSource(await firstExisting([resolve(output,exeName),resolve(project,exeName)])));
files.set('POD服装设计器.html',await readFile(await firstExisting([resolve(project,'build/combined/POD服装设计器.html'),resolve(project,'POD服装设计器.html')])));
await rootDocument('docs/POD局域网版操作手册.html','POD局域网版操作手册.html');
await add('docs/API配置说明.md','API配置说明.md');
await add('docs/交接包深度解析.md','交接包深度解析.md');
await rootDocument('docs/整合版使用说明.html','整合版使用说明.html');
await rootDocument('docs/模板库使用说明.html','模板库使用说明.html');
await add('docs/模板库使用说明.md','模板库使用说明.md');
await add('docs/印花区域文件使用说明.md','印花区域文件使用说明.md');
// One copy of the original handover asset tree lives below dist/handover.
// The root entry is only a link, so reference PNGs are never duplicated.
files.set('GPT交接资料.html',Buffer.from('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GPT 交接资料</title><body><h1>GPT 交接资料</h1><p>资料库保留文档及14张原图：7张干净母版、7张原始衣色参考。七色母版归属Zeesloop，白色C版干净双面母版为初始默认；首次使用需确认印花区域。</p><p><a href="dist/handover/index.html">打开交接资料库</a></p><p><a href="整合版使用说明.html#handover">查看整合与使用说明</a></p></body></html>'));

// Both familiar main entries start the same native global/LAN application.
const launch='@echo off\r\nchcp 65001 >nul\r\nsetlocal\r\nif not exist "%~dp0'+exeName+'" (\r\n  echo Please extract the complete package before starting POD.\r\n  pause\r\n  exit /b 1\r\n)\r\nstart "" "%~dp0'+exeName+'"\r\n';
files.set('启动设计器.cmd',Buffer.from(launch));files.set('一键启动POD与GitHub图床.cmd',Buffer.from(launch));
const quick="POD v1.77：程序制作时采集并校验完整类目属性库；首次从商家主页仅配对店名和主营类目，以后直接读取内置的细分类目、属性与下拉参数。保存商品后通过 AdsPower 填写到目标店铺并保存为 TikTok 草稿，等待人工检查上架。每张已返回图片可立即提取印花，已登记 PNG 可单独一键套图；每会话支持主任务加 4 个后台分支。各分支保留自己的来源图、店铺与模板，单位置印花不会自动复制到其他位置；只有明确正反同图或实际返回对应分面时才应用到对应位置。\r\n\r\nPOD TikTok 商品链接工作台 v1.77\r\n\r\n1. 解压完整软件包，先退出旧启动器，再双击 POD服装设计器_整合版_v1.77.exe。启动或访问局域网根地址默认进入 TikTok 商品链接工作台；首开是空白新商品，不会自动载入最近草稿。旧商品请从“草稿箱”明确打开。需要管理模板、素材时，从工作台进入原设计工具；返回后，URL 与刷新会保持所选模式。\r\n2. 选择店铺后可依次添加多个规格模板。无须先选素材，系统即按模板添加顺序和颜色顺序准备空白服装图片：主图与展示图、详情图默认各取前 7 张，每个 SKU 颜色都有独立模板图片；默认图片包也取前 7 张。模板暂未校准仍保留全部颜色和英文 Type。所有款式、颜色固定使用 S、M、L、XL、XXL、XXXL，8 色自动展开 48 行 SKU，可逐行编辑售价、库存、标价和商家 SKU。\r\n3. 在各款式下勾选服装颜色，按印花位置选择素材，或启用正反同图。位置、区域和遮挡沿用实际模板库；待校准的模板可从款式旁快捷编辑入口进入原区域与遮挡编辑窗口，确认保存后返回工作台。\r\n4. 选择素材后自动生成已校准模板的预览，未校准或渲染失败的颜色保留规格与空白图片。自动预览不会提前替换上架用图；未成功完成保存的空白商品图片可放大或下载，但不能作为已完成贴图导出最终 Excel。\r\n5. 点击“保存并贴图”，设计库成功确认后才以实际效果替换自动商品图片；手动本地导入或从设计库引用的图片保留。重复保存同一结果不重复入库，部分成功会显示已完成与待处理数量。需要微调时点击“编辑效果”，可调整缩放、旋转、位置、不透明度和材质；模板可印边界及遮挡继续生效。人工调整按新版本保存，原设计保留。常规图片导出与上传固定为 1080×1080。\r\n6. 主图与展示图、详情图、尺码表都支持从设计库选择高清图片或本地导入。主图/展示图与详情图各最多 9 张，尺码表 1 张，顺序可调整。Excel 没有独立详情图列时，详情图保存在草稿与图片包中。\r\n7. “上架资料与库存设置”与图片、SKU 区域共同覆盖实际 47 列模板，提供：类目、品牌、描述、包装、GTIN 类型和识别码、标价、拍卖与起拍价、两个仓库库存、商品属性及 SDS 资质链接；尺码表可用图片、链接或 ID。SKU 行的“资料”窗口可单独填写识别码、标价、起拍价和分仓库存。逐码设置优先于颜色和商品默认值；显式 0 库存、手工 SKU、旧 2XL/3XL 数据保留。新商品默认库存为 999；空值和明确填写的数字不会被默认值覆盖。属性与资质请按实际商品事实填写。\r\n8. 默认商家 SKU 使用商品创建时的上海日期 YYYYMMDD、英文颜色、尺码；多款式再附加英文 Type，保存重开或修改标题不会改变该日期，手工逐码 SKU 优先。未知英文名称需手动确认。真实 Excel 支持三组规格时分别填写 Color、Size、Type，只有两组时自动合并 Color / Type 并保留独立尺码。资料缺失、未完成贴图、重复规格或重复 SKU 会提示修改。图片上传与后台上架由用户主动点击触发；勾选目标店铺并保存商品后，将同步到店铺草稿队列；不会自动发布。\r\n9. 商品草稿与原设计库保存在当前浏览器；新开界面保持空白，通过草稿箱恢复已保存商品及其原图片、人工资料。主机素材和模板沿用局域网共享设置。本包不包含个人素材、实际草稿、Token、账号、私密配置或生产数据；模板库仅包含 14 张公开样例，用户已有模板目录不在本包中。\r\n10. 同目录离线 HTML 可直接打开工作台，进行本地设计与草稿操作；主机共享素材、联网图床和 Codex 助手仍需对应服务与网络。原生 EXE 内置 Node 和图床程序，Codex App Server 需主机已安装并登录。\r\n\r\n11. v1.77 保留后台贴图与编辑表单互不阻塞的流程，新增多店铺 AdsPower 连接。点击管理店铺，首次读取对应环境商家主页中的真实店名和主营类目并保存；以后直接使用保存的店铺与主营细分类目。主营范围外的大类不可操作。首次配对不逐类采集；类目及属性始终读取已随程序打包并通过校验的完整数据库。勾选目标店铺并点击“保存商品并同步草稿”后，先保存当前商品内容，主机再按这份保存结果逐店铺填写新建商品页并点击保存草稿，验证保存回执。完成显示“已存 TikTok 草稿，待人工检查”；不会点击最终发布按钮。失败或结果未确认时先核对任务队列，再使用原任务编号重试。详见 docs/TikTok多店铺与属性选项.md。离线 HTML 继续支持本地设计，实际后台读取和上架需要主机服务及已登录的 AdsPower 环境。\r\n\r\n安装包准备过程不会停止或重启现有 5180 服务。请在准备切换时自行退出旧启动器；不要同时启动两份局域网服务。\r\n\r\n保留 1.69 的店铺与款式选择、参考图印花位置比对以及后台 Worker 套图；新增按店铺与类目隔离的真实属性读取。未完整核验的类目不能上架。\r\n";
files.set('先看这里.txt',Buffer.from('\ufeff'+quick));
const entries=[];for(const [path,value]of files){const digest=await digestZipValue(value);entries.push({path,...digest});files.set(path,pinZipValue(value,digest));}entries.sort((a,b)=>a.path.localeCompare(b.path,'en'));
const manifest={version,entryPoint:exeName,runtime:process.version,files:entries};
files.set('文件清单.json',Buffer.from(JSON.stringify(manifest,null,2)));
files.set('SHA256SUMS.txt',Buffer.from(entries.map(entry=>entry.sha256+'  '+entry.path).join('\r\n')+'\r\n'));
await mkdir(destination,{recursive:true});
for(const [path,value]of files){const target=resolve(destination,path);if(!target.startsWith(destination+'\\')&&!target.startsWith(destination+'/'))throw new Error('无效的打包目标。');await mkdir(dirname(target),{recursive:true});if(value?.source)await copyFile(value.source,target);else await writeFile(target,value?.data||value);}
const archive=resolve(output,folderName+'.zip'),result=await writeStreamingZip(archive,[...files].map(([path,value])=>[folderName+'/'+path,value]));
console.log(JSON.stringify({folder:destination,archive,files:files.size,archiveBytes:result.bytes,sha256:(await digestZipValue(zipFileSource(archive))).sha256}));

