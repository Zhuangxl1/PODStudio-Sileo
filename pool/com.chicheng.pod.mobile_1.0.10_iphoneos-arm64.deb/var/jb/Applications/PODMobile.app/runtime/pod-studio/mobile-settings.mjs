import {uploadImage,validateUploadEndpoint} from './dist/image-upload.js';
import {createMiniToolsImageClient} from './mini-tools-image.mjs';
import {uploadScdnImage,normalizeScdnCdnDomain} from './scdn-image.mjs';
import {createHash,randomUUID} from 'node:crypto';
import {createGitHubMaterialHost} from '../shared/sync/github-material-host.mjs';

const modes = ['lanyi','siliconflow'];
const key = value => typeof value === 'string' && /^[\x21-\x7e]{1,4096}$/.test(value);
const fail = (message, status = 400) => Object.assign(new Error(message), {status, code:'MOBILE_SETTINGS'});
export function normalizeMobileConfig(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw fail('手机配置格式无效。');
  const output = {};
  const schema = {desktop:['endpoint','pairToken'],github:['owner','repo','branch','token'],ai:['provider','endpoint','model','apiKey'],miaoshou:['appKey','appSecret'],tro:['provider','model','prompt','imageInput','lanyiApiKey','siliconflowApiKey','courtListenerToken'],upload:['provider','endpoint','fileField','responsePath','authHeaderName','authValue','userId','duration','cdnDomain']};
  for (const group of Object.keys(schema)) {
    const item = value[group] || {};
    if (typeof item !== 'object' || Array.isArray(item) || Object.keys(item).some(name => !schema[group].includes(name))) throw fail('手机配置字段无效。');
    output[group] = {};
    for (const name of schema[group]) if (item[name] !== undefined) {
      if (typeof item[name] !== 'string' || item[name].length > (group==='tro'&&name==='prompt'?16000:4096) || (group==='tro'&&name==='prompt'?/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/:/[\x00-\x1f\x7f]/).test(item[name])) throw fail('手机配置内容无效。');
      output[group][name] = item[name].trim();
    }
  }
  if (output.ai.provider && !modes.includes(output.ai.provider)) throw fail('手机端支持蓝移或硅基流动图像 API，本地 Codex 不可用。');
  const fixed = output.ai.provider === 'siliconflow' ? 'https://api.siliconflow.cn/v1' : 'https://lanyiapi.cc/v1';
  if (output.ai.endpoint && output.ai.endpoint.replace(/\/+$/, '') !== fixed) throw fail('当前图像提供方须使用内置 API 地址。');
  if(output.tro.provider&&!modes.includes(output.tro.provider))throw fail('TRO 检索请选择蓝移或硅基流动。');
  if(output.tro.imageInput&&!['enabled','disabled'].includes(output.tro.imageInput))throw fail('请选择有效的主图输入方式。');
  const upload=output.upload;
  if(upload.provider&&!['github','imgurl','custom','mini-tools','scdn'].includes(upload.provider))throw fail('请选择有效图床。');
  if(upload.provider==='custom'&&upload.endpoint)validateUploadEndpoint(upload.endpoint);
  if(upload.cdnDomain)normalizeScdnCdnDomain(upload.cdnDomain);
  return output;
}

export function createMobileProviderSettings({getConfig,saveConfig}) {
  let revision = randomUUID(), previous = '';
  function current() {
    const ai = getConfig().ai || {}, fingerprint = JSON.stringify(ai);
    if (fingerprint !== previous) { revision = randomUUID(); previous = fingerprint; }
    return {mode:modes.includes(ai.provider) ? ai.provider : 'lanyi',apiKey:ai.apiKey || '',imageModel:ai.model || '',revision};
  }
  async function publicStatus() {
    const value = current();
    return {mode:value.mode,revision:value.revision,keyConfigured:Boolean(value.apiKey),providers:{
      local:{configured:false,keyConfigured:false,available:false,message:'iOS 不运行电脑 Codex 进程。'},
      ...Object.fromEntries(modes.map(mode => [mode,{configured:mode===value.mode&&Boolean(value.apiKey),keyConfigured:mode===value.mode&&Boolean(value.apiKey),imageModel:mode===value.mode?value.imageModel:''}]))}};
  }
  return {
    publicStatus,
    async getProvider(mode) {
      if (mode !== undefined && !modes.includes(mode)) throw fail('手机端无法运行本地 Codex。',503);
      const value = current();
      return mode && mode !== value.mode ? {...value,mode,apiKey:'',imageModel:''} : value;
    },
    async save(input) {
      if (!input || !modes.includes(input.mode) || Object.keys(input).some(name => !['mode','apiKey','clearApiKey','imageModel'].includes(name))) throw fail('请选择蓝移或硅基流动图像 API。');
      if (input.apiKey && !key(input.apiKey) || input.clearApiKey !== undefined && typeof input.clearApiKey !== 'boolean' || input.apiKey && input.clearApiKey) throw fail('API Key 格式无效。');
      if (input.imageModel !== undefined && (typeof input.imageModel !== 'string' || input.imageModel && !/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/.test(input.imageModel) || input.imageModel?.includes('://'))) throw fail('图像模型名称无效。');
      const old = current(), same = old.mode === input.mode;
      await saveConfig({...getConfig(),ai:{provider:input.mode,apiKey:input.clearApiKey?'':input.apiKey || (same?old.apiKey:''),model:input.imageModel ?? (same?old.imageModel:'')}});
      return publicStatus();
    },
  };
}

export function createMobileMiaoshouSettings({getConfig,saveConfig}) {
  return {
    async read() { return {...(getConfig().miaoshou || {})}; },
    async accountScope() { const value = getConfig().miaoshou; return value?.appKey ? createHash('sha256').update(value.appKey).digest('hex') : ''; },
    async status() { const value = getConfig().miaoshou; return {configured:Boolean(value?.appKey && value?.appSecret)}; },
    async save(value) {
      if (!value || Object.keys(value).some(name => !['appKey','appSecret'].includes(name)) || !key(value.appKey) || !key(value.appSecret)) throw fail('请填写有效的妙手 App Key 与 App Secret。');
      await saveConfig({...getConfig(),miaoshou:{appKey:value.appKey,appSecret:value.appSecret}});
      return this.status();
    },
  };
}

export function createMobileUploadSettings({getConfig,fetchImpl=fetch}) {
  return {
    async publicStatus() {
      const gh = getConfig().github || {}, up=getConfig().upload||{}, configured = up.provider&&up.provider!=='github' ? up.provider==='scdn'||Boolean(up.provider==='custom'?up.endpoint:up.authValue) : Boolean(gh.owner && gh.repo && gh.token);
      return {configured,tokenConfigured:Boolean(up.provider&&up.provider!=='github'?up.authValue:gh.token),uploadProvider:getConfig().upload?.provider||'github',materialFolderName:'电脑在线素材与最近使用',maxFileBytes:25*1024*1024,revision:'mobile-upload-v2'};
    },
    async upload(payload,contentType,{signal}={}) {
      const gh = getConfig().github || {};
      const up=getConfig().upload||{};
      if ((!up.provider||up.provider==='github')&&(!gh.owner || !gh.repo || !gh.token)) throw fail('请先在手机连接设置中配置 GitHub 图床。',503);
      const form = await new Request('http://127.0.0.1/',{method:'POST',headers:{'Content-Type':contentType || ''},body:payload}).formData();
      const file = form.get('file');
      if (!(file instanceof Blob)) throw fail('未收到有效图片。');
      if(up.provider==='scdn')return uploadScdnImage(file,{scdnCdnDomain:up.cdnDomain,fetchImpl,signal});
      if(up.provider==='mini-tools')return createMiniToolsImageClient({fetchImpl}).upload(file,{userId:up.userId,apiKey:up.authValue,duration:up.duration||'30-day'},{signal});
      if(['custom','imgurl'].includes(up.provider))return uploadImage(file,{provider:up.provider,endpoint:up.provider==='imgurl'?'https://www.imgurl.org/api/v3/upload':up.endpoint,fileField:up.fileField||'file',responsePath:up.responsePath||'data.url',authHeaderName:up.authHeaderName||'Authorization',authValue:up.authValue||'',fetchImpl,signal});
      const host = createGitHubMaterialHost({owner:gh.owner,repo:gh.repo,branch:gh.branch || 'master',tokenProvider:()=>gh.token,fetchImpl});
      const result = await host.ensureHosted({bytes:new Uint8Array(await file.arrayBuffer()),mimeType:file.type},{signal});
      return result.url;
    },
  };
}
