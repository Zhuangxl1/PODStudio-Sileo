import {createReadStream} from 'node:fs';
import {open,lstat,rename,unlink} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {randomUUID,createHash} from 'node:crypto';
import {Readable} from 'node:stream';
import {createDeflateRaw} from 'node:zlib';

const ZIP32_LIMIT=0xffffffff,MAX_ENTRIES=0xfffe;
const crcTable=Uint32Array.from({length:256},(_,index)=>{let value=index;for(let bit=0;bit<8;bit++)value=value&1?0xedb88320^(value>>>1):value>>>1;return value>>>0;});
const updateCrc=(crc,bytes)=>{for(const byte of bytes)crc=crcTable[(crc^byte)&255]^(crc>>>8);return crc>>>0;};
const archiveError=message=>Object.assign(new Error(message),{code:'PACKAGE_ZIP_LIMIT'});
const sourceFile=value=>value&&typeof value==='object'&&!ArrayBuffer.isView(value)&&typeof value.source==='string';
const buffer=value=>typeof value==='string'?Buffer.from(value):Buffer.isBuffer(value)?value:ArrayBuffer.isView(value)?Buffer.from(value.buffer,value.byteOffset,value.byteLength):null;

/** References are opened one at a time, so a catalog never occupies a second
 * full in-memory copy while its archive is being built. */
export const zipFileSource=source=>Object.freeze({source:resolve(source)});

export function pinZipValue(value,{size,sha256}){
  if(!Number.isSafeInteger(size)||size<0||typeof sha256!=='string'||!/^[a-f0-9]{64}$/u.test(sha256))throw new TypeError('压缩包来源校验无效。');
  const data=sourceFile(value)?{source:value.source}:{data:Buffer.from(buffer(value)||value.data)};
  return Object.freeze({...data,expectedSize:size,expectedSha256:sha256});
}

export async function describeZipValue(value){
  if(sourceFile(value)){
    const info=await lstat(value.source);if(!info.isFile()||info.isSymbolicLink())throw new Error('压缩包来源必须是已确认的普通文件。');
    if(value.expectedSize!==undefined&&value.expectedSize!==info.size)throw new Error('来源文件与文件清单不一致。');
    return {size:info.size,mtimeMs:info.mtimeMs,file:value.source,...(value.expectedSha256?{expectedSha256:value.expectedSha256}:{})};
  }
  const data=buffer(value)||buffer(value?.data);if(!data)throw new TypeError('不支持的压缩包文件内容。');
  if(value?.expectedSize!==undefined&&value.expectedSize!==data.length)throw new Error('来源内容与文件清单不一致。');
  return {size:data.length,data,...(value.expectedSha256?{expectedSha256:value.expectedSha256}:{})};
}

export async function digestZipValue(value){
  const description=await describeZipValue(value),hash=createHash('sha256');let size=0;
  for await(const bytes of description.file?createReadStream(description.file):[description.data]){size+=bytes.length;hash.update(bytes);}
  if(size!==description.size)throw new Error('来源文件在校验过程中发生变化。');
  if(description.file){const after=await lstat(description.file);if(!after.isFile()||after.isSymbolicLink()||after.size!==description.size||after.mtimeMs!==description.mtimeMs)throw new Error('来源文件在校验过程中发生变化。');}
  const sha256=hash.digest('hex');if(description.expectedSha256&&description.expectedSha256!==sha256)throw new Error('来源内容与文件清单校验不一致。');return {size,sha256};
}

/** Standard UTF-8 ZIP32 with data descriptors. Bounds are checked before any
 * output is opened and again while writing; oversized archives are never
 * emitted with truncated 32-bit sizes or entry counts. */
export async function writeStreamingZip(target,entries,{level=6,maxBytes=ZIP32_LIMIT-1,onProgress}={}){
  if(!Number.isInteger(level)||level<0||level>9||!Number.isSafeInteger(maxBytes)||maxBytes<22||maxBytes>=ZIP32_LIMIT)throw new TypeError('压缩参数无效。');
  const items=[...entries];if(items.length>MAX_ENTRIES)throw archiveError('压缩包文件数超过 ZIP32 上限，请合并字典分片。');
  const names=new Set(),records=[];let bound=22;
  for(const [name,value]of items){
    if(typeof name!=='string'||!name||/^[\/\\]|[\\:\u0000-\u001f\u007f]/u.test(name)||name.split('/').some(part=>!part||part==='.'||part==='..'))throw new Error('压缩包内路径无效。');
    const encoded=Buffer.from(name),identity=name.toLocaleLowerCase('en-US');if(encoded.length>0xffff||names.has(identity))throw new Error('压缩包包含重复或过长的文件名。');names.add(identity);
    const description=await describeZipValue(value),size=description.size;
    if(!Number.isSafeInteger(size)||size<0||size>=ZIP32_LIMIT)throw archiveError('单个压缩包文件超过 ZIP32 上限。');
    bound+=30+46+16+encoded.length*2+size+Math.ceil(size/4096)+Math.ceil(size/16384)+Math.ceil(size/33554432)+64;
    if(bound>maxBytes)throw archiveError('压缩包体积超过安全上限，请减少重复资源或使用更小的分片。');
    records.push({name,encoded,...description});
  }
  const destination=resolve(target),temporary=resolve(dirname(destination),'.pod-zip-'+randomUUID()+'.tmp');
  let handle,offset=0;
  const write=async data=>{
    if(offset+data.length>maxBytes)throw archiveError('压缩包达到安全体积上限，已停止写入。');
    for(let index=0;index<data.length;){const result=await handle.write(data,index,data.length-index,offset);if(!result.bytesWritten)throw new Error('压缩包写入没有前进。');index+=result.bytesWritten;offset+=result.bytesWritten;}
  };
  try{
    handle=await open(temporary,'wx');const central=[];
    for(const [index,record]of records.entries()){
      const start=offset,local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x0808,6);local.writeUInt16LE(8,8);local.writeUInt16LE(33,12);local.writeUInt16LE(record.encoded.length,26);
      await write(local);await write(record.encoded);let crc=0xffffffff,rawSize=0,compressedSize=0;const sourceHash=record.expectedSha256?createHash('sha256'):null;
      const reader=record.file?createReadStream(record.file,{highWaterMark:64*1024}):Readable.from([record.data]);
      const deflater=createDeflateRaw({level});
      const input=Readable.from((async function*(){for await(const chunk of reader){rawSize+=chunk.length;if(rawSize>record.size)throw new Error('来源文件在压缩过程中发生变化。');crc=updateCrc(crc,chunk);sourceHash?.update(chunk);yield chunk;}})());
      input.on('error',error=>deflater.destroy(error));input.pipe(deflater);
      try{for await(const chunk of deflater){compressedSize+=chunk.length;if(compressedSize>=ZIP32_LIMIT)throw archiveError('压缩文件超过 ZIP32 上限。');await write(chunk);}}
      finally{reader.destroy();input.destroy();deflater.destroy();}
      if(rawSize!==record.size)throw new Error('来源文件在压缩过程中发生变化。');
      if(sourceHash&&sourceHash.digest('hex')!==record.expectedSha256)throw new Error('来源内容与文件清单校验不一致，未替换压缩包。');
      if(record.file){const after=await lstat(record.file);if(!after.isFile()||after.isSymbolicLink()||after.size!==record.size||after.mtimeMs!==record.mtimeMs)throw new Error('来源文件在压缩过程中发生变化。');}
      crc=(crc^0xffffffff)>>>0;const descriptor=Buffer.alloc(16);descriptor.writeUInt32LE(0x08074b50);descriptor.writeUInt32LE(crc,4);descriptor.writeUInt32LE(compressedSize,8);descriptor.writeUInt32LE(rawSize,12);await write(descriptor);
      const header=Buffer.alloc(46);header.writeUInt32LE(0x02014b50);header.writeUInt16LE(20,4);header.writeUInt16LE(20,6);header.writeUInt16LE(0x0808,8);header.writeUInt16LE(8,10);header.writeUInt16LE(33,14);header.writeUInt32LE(crc,16);header.writeUInt32LE(compressedSize,20);header.writeUInt32LE(rawSize,24);header.writeUInt16LE(record.encoded.length,28);header.writeUInt32LE(start,42);central.push(header,record.encoded);
      onProgress?.({files:index+1,total:records.length,bytes:offset});
    }
    const centralOffset=offset;for(const part of central)await write(part);const centralSize=offset-centralOffset;
    const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(records.length,8);end.writeUInt16LE(records.length,10);end.writeUInt32LE(centralSize,12);end.writeUInt32LE(centralOffset,16);await write(end);
    await handle.sync();await handle.close();handle=undefined;await rename(temporary,destination);
    return {archive:destination,files:records.length,bytes:offset,uncompressedBytes:records.reduce((sum,item)=>sum+item.size,0)};
  }catch(error){if(handle)await handle.close().catch(()=>{});await unlink(temporary).catch(()=>{});throw error;}
}
