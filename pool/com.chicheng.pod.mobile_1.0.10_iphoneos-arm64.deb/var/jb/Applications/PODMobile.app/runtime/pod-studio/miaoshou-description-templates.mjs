import {mkdir,open,readFile,rename,unlink} from 'node:fs/promises';
import {isAbsolute,resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {validateMiaoshouDescriptionTemplate} from './dist/miaoshou-description-template-schema.js';

const fail=(message,code='MIAOSHOU_DESCRIPTION_TEMPLATE_INVALID',status=400)=>Object.assign(new Error(message),{code,status});
const idPattern=/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u;
const nameKey=name=>name.normalize('NFKC').trim().toLowerCase();
const empty=()=>({version:1,revision:0,items:[]});
const maxBytes=4*1024*1024;
const limit=50;

export function createMiaoshouDescriptionTemplates({root}={}){
  if(root!==undefined&&(typeof root!=='string'||!isAbsolute(root)))throw new TypeError('产品描述模板库需要主机绝对目录。');
  const folder=root?resolve(root,'miaoshou-description-templates'):null;
  const memory=new Map(),queues=new Map();
  let closed=false;

  function keyFor({accountScope,shopId}){
    if(closed)throw fail('产品描述模板库正在关闭。','MIAOSHOU_DESCRIPTION_TEMPLATE_CLOSED',503);
    if(typeof accountScope!=='string'||!/^[a-f0-9]{64}$/u.test(accountScope)||typeof shopId!=='string'||!/^[1-9][0-9]{0,24}$/u.test(shopId))throw fail('产品描述模板的店铺或账号无效。');
    return accountScope+'-'+shopId;
  }

  async function load(key){
    if(!folder)return structuredClone(memory.get(key)||empty());
    try{
      const bytes=await readFile(resolve(folder,key+'.json'));
      if(bytes.length>maxBytes)throw new Error();
      const data=JSON.parse(bytes.toString('utf8'));
      if(data?.version!==1||!Number.isSafeInteger(data.revision)||data.revision<0||!Array.isArray(data.items)||data.items.length>limit)throw new Error();
      const ids=new Set(),names=new Set();
      const items=data.items.map(item=>{
        // Existing template files predate the upload limit and must still be readable.
        const {name,description}=validateMiaoshouDescriptionTemplate(
          {name:item.name,description:item.description},{maxImages:Infinity});
        if(typeof item.id!=='string'||!idPattern.test(item.id)||ids.has(item.id)||names.has(nameKey(name))||typeof item.updatedAt!=='string'||!Number.isFinite(Date.parse(item.updatedAt)))throw new Error();
        ids.add(item.id);
        names.add(nameKey(name));
        return {id:item.id,name,description,updatedAt:item.updatedAt};
      });
      return {version:1,revision:data.revision,items};
    }catch(error){
      if(error.code==='ENOENT')return empty();
      throw fail('无法读取店铺描述模板，原模板文件已保留。','MIAOSHOU_DESCRIPTION_TEMPLATE_STORAGE',503);
    }
  }

  async function mutate(input,template,{guard=async()=>{}}={}){
    const key=keyFor(input),{revision,id}=input;
    if(!Number.isSafeInteger(revision)||revision<0||((Object.hasOwn(input,'id')||!template)&&(typeof id!=='string'||!idPattern.test(id))))throw fail('产品描述模板编号或版本无效。');
    const pending=queues.get(key)||Promise.resolve();
    const work=pending.then(async()=>{
      let lock,temp;
      const path=folder?resolve(folder,key+'.json'):null;
      try{
        if(path){
          await mkdir(folder,{recursive:true});
          try{lock=await open(path+'.lock','wx');}
          catch(error){if(error.code==='EEXIST')throw fail('此店铺的描述模板正在保存，请稍后重试。','MIAOSHOU_DESCRIPTION_TEMPLATE_BUSY',409);throw error;}
        }
        await guard();
        const data=await load(key);
        if(data.revision!==revision||revision===Number.MAX_SAFE_INTEGER)throw fail('此店铺的描述模板已变化，请刷新后再修改。','MIAOSHOU_DESCRIPTION_TEMPLATE_CONFLICT',409);
        const index=data.items.findIndex(item=>item.id===id);
        if(id&&index<0)throw fail('描述模板已删除或不属于此店铺。','MIAOSHOU_DESCRIPTION_TEMPLATE_NOT_FOUND',409);
        if(template){
          if(data.items.some(item=>item.id!==id&&nameKey(item.name)===nameKey(template.name)))throw fail('此店铺已有同名描述模板。','MIAOSHOU_DESCRIPTION_TEMPLATE_DUPLICATE',409);
          const item={id:id||randomUUID(),...template,updatedAt:new Date().toISOString()};
          if(index>=0)data.items[index]=item;
          else{
            if(data.items.length>=limit)throw fail('每家店铺最多保存 '+limit+' 个描述模板。');
            data.items.push(item);
          }
        }else data.items.splice(index,1);
        data.revision++;
        if(path){
          const bytes=JSON.stringify(data);
          if(Buffer.byteLength(bytes)>maxBytes)throw fail('描述模板库内容过大，请减少模板数量。');
          temp=path+'.'+randomUUID()+'.tmp';
          const file=await open(temp,'wx');
          try{await file.writeFile(bytes);await file.sync();}finally{await file.close();}
          await guard();
          await rename(temp,path);
          temp=null;
        }else{
          await guard();
          memory.set(key,structuredClone(data));
        }
        return {revision:data.revision,items:data.items};
      }catch(error){
        if(error.code?.startsWith('MIAOSHOU_DESCRIPTION_TEMPLATE_')||error.code==='CONTEXT_CHANGED')throw error;
        throw fail('描述模板保存失败，原模板数据已保留。','MIAOSHOU_DESCRIPTION_TEMPLATE_STORAGE',503);
      }finally{
        if(temp)await unlink(temp).catch(()=>{});
        if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}
      }
    });
    const settled=work.catch(()=>{});
    queues.set(key,settled);
    void settled.then(()=>{if(queues.get(key)===settled)queues.delete(key);});
    return work;
  }

  return {
    async list(input){const {revision,items}=await load(keyFor(input));return {revision,items};},
    async save(input,options){return mutate(input,validateMiaoshouDescriptionTemplate(input.template),options);},
    async remove(input,options){return mutate(input,null,options);},
    async close(){closed=true;await Promise.all([...queues.values()]);}
  };
}
