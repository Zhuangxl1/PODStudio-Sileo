import {open,readFile,mkdir,rename,unlink} from 'node:fs/promises';
import {resolve,isAbsolute} from 'node:path';
import {randomUUID} from 'node:crypto';
import {validateSkuStructureTemplate,isShopLocalSkuTemplate,localSkuTemplateForShop} from './dist/miaoshou-sku-structure-schema.js';

const failure=(message,code='MIAOSHOU_SKU_STRUCTURE_INVALID',status=400)=>Object.assign(new Error(message),{code,status});
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const id=value=>typeof value==='string'&&/^[a-f\d]{8}-[a-f\d]{4}-4[a-f\d]{3}-[89ab][a-f\d]{3}-[a-f\d]{12}$/u.test(value);
const normalizedName=value=>value.normalize('NFKC').trim().toLowerCase();
const nameKey=value=>(value.scope?.shop?.id||'')+':'+normalizedName(value.name);
const shopIdentifier=value=>typeof value==='string'&&/^[1-9]\d{0,24}$/u.test(value);
const empty=()=>({version:1,revision:0,items:[]});
const clone=value=>structuredClone(value);
const invalidStore=()=>failure('规格组合模板库未能读取，请保留原文件并核对后重试。','MIAOSHOU_SKU_STRUCTURE_STORAGE',503);

/** Account-scoped host storage shared by all products and LAN clients. */
export function createMiaoshouSkuStructureTemplates({root,limit=100,now=Date.now}={}){
  if(root!==undefined&&(typeof root!=='string'||!isAbsolute(root)))throw new TypeError('规格组合模板库须使用主机绝对目录。');
  if(!Number.isSafeInteger(limit)||limit<1||limit>1000)throw new TypeError('规格组合模板数量上限无效。');
  const memory=new Map(),queues=new Map();let closed=false;
  const scope=input=>{if(closed)throw failure('规格组合模板库正在关闭。','MIAOSHOU_SKU_STRUCTURE_CLOSED',503);if(!plain(input)||typeof input.accountScope!=='string'||!/^[a-f\d]{64}$/u.test(input.accountScope))throw failure('规格组合模板账号连接无效。');return input.accountScope;};
  const pathFor=scope=>root?resolve(root,'miaoshou-sku-structure-templates',scope+'.json'):null;
  function checked(data){
    if(!plain(data)||Object.keys(data).some(key=>!['version','revision','items','defaultByShop'].includes(key))||data.version!==1||!Number.isSafeInteger(data.revision)||data.revision<0||!Array.isArray(data.items)||data.items.length>limit)throw invalidStore();
    const names=new Set(),ids=new Set(),items=[];
    for(const item of data.items){
      if(!plain(item)||Object.keys(item).some(key=>!['id','name','dimensions','rows','scope','createdAt','updatedAt'].includes(key))||!id(item.id)||ids.has(item.id)||!['createdAt','updatedAt'].every(key=>typeof item[key]==='string'&&Number.isFinite(Date.parse(item[key]))))throw invalidStore();
      let preset;try{preset=validateSkuStructureTemplate({name:item.name,dimensions:item.dimensions,rows:item.rows,...(Object.hasOwn(item,'scope')?{scope:item.scope}:{})});}catch{throw invalidStore();}
      const name=nameKey(preset);if(names.has(name))throw invalidStore();names.add(name);ids.add(item.id);items.push({id:item.id,...preset,createdAt:item.createdAt,updatedAt:item.updatedAt});
    }
    if(data.defaultByShop!==undefined){if(!plain(data.defaultByShop)||Object.keys(data.defaultByShop).length>1000)throw invalidStore();for(const [shopId,templateId]of Object.entries(data.defaultByShop))if(!shopIdentifier(shopId)||!id(templateId)||!items.some(item=>item.id===templateId&&isShopLocalSkuTemplate(item,shopId)))throw invalidStore();}
    return {version:1,revision:data.revision,items,...(data.defaultByShop?{defaultByShop:{...data.defaultByShop}}:{})};
  }
  async function load(selected){
    if(!root)return clone(memory.get(selected)||empty());
    try{const raw=await readFile(pathFor(selected));if(raw.length>16*1024*1024)throw invalidStore();return checked(JSON.parse(raw.toString('utf8')));}
    catch(error){if(error.code==='ENOENT')return empty();if(error.code==='MIAOSHOU_SKU_STRUCTURE_STORAGE')throw error;throw invalidStore();}
  }
  function validateInput(input,operation){
    const selected=scope(input),shopMode=operation.endsWith('Shop'),op=shopMode?operation.slice(0,-4):operation,allowed=op==='list'?['accountScope']:op==='create'?['accountScope','revision','template']:op==='update'?['accountScope','revision','id','template']:['accountScope','revision','id'];
    if(shopMode)allowed.push('shopId',...(op==='create'||op==='update'?['shopName','makeDefault']:[]));
    if(Object.keys(input).some(key=>!allowed.includes(key)))throw failure('规格组合模板参数无效。');
    if(shopMode&&!shopIdentifier(input.shopId))throw failure('SKU模板店铺范围无效。');
    if(op!=='list'&&(!Number.isSafeInteger(input.revision)||input.revision<0))throw failure('请先读取最新的 规格组合模板库。');
    if(['update','remove'].includes(op)&&!id(input.id)||op==='setDefault'&&input.id!==null&&!id(input.id))throw failure('规格组合模板编号无效。');
    if(shopMode&&input.makeDefault!==undefined&&typeof input.makeDefault!=='boolean')throw failure('SKU模板默认选项无效。');
    return selected;
  }
  function shopView(data,shopId,item){return {shopId,revision:data.revision,items:clone(data.items.filter(value=>isShopLocalSkuTemplate(value,shopId))).map(value=>({...value,...localSkuTemplateForShop({name:value.name,dimensions:value.dimensions,rows:value.rows,scope:value.scope},{shopId,shopName:value.scope.shop.name})})),...(data.defaultByShop?.[shopId]?{defaultId:data.defaultByShop[shopId]}:{}),...(item?{item:clone(item)}:{})};}
  function mutate(input,operation,{guard=async()=>{}}={}){
    const selected=validateInput(input,operation),shopMode=operation.endsWith('Shop'),op=shopMode?operation.slice(0,-4):operation,preset=['remove','setDefault'].includes(op)?null:shopMode?localSkuTemplateForShop(input.template,{shopId:input.shopId,shopName:input.shopName}):validateSkuStructureTemplate(input.template);
    if(typeof guard!=='function')throw failure('SKU模板保存核验无效。');
    input={...input};
    const work=(queues.get(selected)||Promise.resolve()).catch(()=>{}).then(async()=>{
      let lock,temp;const path=pathFor(selected);
      try{
        if(path){await mkdir(resolve(root,'miaoshou-sku-structure-templates'),{recursive:true});try{lock=await open(path+'.lock','wx');}catch{throw failure('规格组合模板库正在修改或上次保存需要核对，请稍后重试。','MIAOSHOU_SKU_STRUCTURE_BUSY',409);}}
        await guard();const data=await load(selected);
        if(data.revision!==input.revision)throw failure('规格组合模板已被其他窗口修改，请刷新模板库后重试。','MIAOSHOU_SKU_STRUCTURE_CONFLICT',409);
        if(data.revision>=Number.MAX_SAFE_INTEGER)throw failure('规格组合模板版本已达上限，请联系管理员。');
        const index=data.items.findIndex(item=>item.id===input.id);
        if(op!=='create'&&!(op==='setDefault'&&input.id===null)&&(index<0||shopMode&&!isShopLocalSkuTemplate(data.items[index],input.shopId)))throw failure('规格组合模板已删除或不属于本店铺，请刷新后重新选择。','MIAOSHOU_SKU_STRUCTURE_NOT_FOUND',409);
        if(preset&&data.items.some(item=>item.id!==input.id&&nameKey(item)===nameKey(preset)))throw failure('此 规格组合模板名称已存在，请使用其他名称。','MIAOSHOU_SKU_STRUCTURE_DUPLICATE',409);
        let item;
        const at=new Date(now()).toISOString();
        if(op==='create'){
          if(data.items.length>=limit)throw failure('规格组合模板已达 '+limit+' 个，请先删除不用的模板。');
          item={id:randomUUID(),...preset,createdAt:at,updatedAt:at};data.items.push(item);
        }else if(op==='update'){item={...data.items[index],...preset,updatedAt:at};data.items[index]=item;}
        else if(op==='remove')data.items.splice(index,1);
        if(data.defaultByShop)for(const [shop,templateId]of Object.entries(data.defaultByShop))if(!data.items.some(item=>item.id===templateId&&isShopLocalSkuTemplate(item,shop)))delete data.defaultByShop[shop];
        if(shopMode&&(op==='setDefault'||input.makeDefault===true)){
          data.defaultByShop??={};const nextId=op==='setDefault'?input.id:item.id;
          if(nextId===null)delete data.defaultByShop[input.shopId];else data.defaultByShop[input.shopId]=nextId;
        }
        if(data.defaultByShop&&!Object.keys(data.defaultByShop).length)delete data.defaultByShop;
        data.revision++;
        if(path){temp=path+'.'+randomUUID()+'.tmp';const file=await open(temp,'wx');try{const bytes=JSON.stringify(data);if(Buffer.byteLength(bytes)>16*1024*1024)throw failure('规格组合模板库内容过大，请减少模板数量。');await file.writeFile(bytes);await file.sync();}finally{await file.close();}await guard();await rename(temp,path);temp=null;}
        else {await guard();memory.set(selected,clone(data));}
        return shopMode?shopView(data,input.shopId,item):{revision:data.revision,items:clone(data.items),...(item?{item:clone(item)}:{})};
      }catch(error){if(error?.code?.startsWith('MIAOSHOU_SKU_STRUCTURE_')||error?.code==='CONTEXT_CHANGED')throw error;throw failure('规格组合模板未能保存，原模板数据已保留，请稍后重试。','MIAOSHOU_SKU_STRUCTURE_STORAGE',503);}
      finally{if(temp)await unlink(temp).catch(()=>{});if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}}
    });
    const settled=work.catch(()=>{});queues.set(selected,settled);void settled.finally(()=>{if(queues.get(selected)===settled)queues.delete(selected);});return work;
  }
  return {
    async list(input){const selected=validateInput(input,'list'),data=await load(selected);return {revision:data.revision,items:clone(data.items)};},
    async listShop(input){const selected=validateInput(input,'listShop'),data=await load(selected);return shopView(data,input.shopId);},
    async saveShop(input,options){return mutate(input,Object.hasOwn(input,'id')?'updateShop':'createShop',options);},
    async removeShop(input,options){return mutate(input,'removeShop',options);},
    async setShopDefault(input,options){return mutate(input,'setDefaultShop',options);},
    async create(input){return mutate(input,'create');},async update(input){return mutate(input,'update');},async remove(input){return mutate(input,'remove');},
    async close(){closed=true;await Promise.allSettled([...queues.values()]);}
  };
}
