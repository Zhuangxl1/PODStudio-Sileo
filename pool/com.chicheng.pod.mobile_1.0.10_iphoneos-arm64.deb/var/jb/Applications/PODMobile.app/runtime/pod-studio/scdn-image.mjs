import {parseUploadRetryAfter} from './dist/image-upload.js';

export const SCDN_UPLOAD_URL = 'https://img.scdn.io/api/v1.php';
export const SCDN_DEFAULT_CDN_DOMAIN = 'esaimg.cdn1.vip';
export const SCDN_CDN_DOMAINS = Object.freeze([
  SCDN_DEFAULT_CDN_DOMAIN,
  'edgeoneimg.cdn1.vip',
  'img.scdn.io',
  'cloudflareimg.cdn.sn',
  'edgeoneimg.cdn.sn',
  'cloudflarecnimg.scdn.io',
  'anycastimg.scdn.io',
]);

const FORMATS = Object.freeze({'image/png':'png','image/jpeg':'jpg','image/webp':'webp'});
const UPLOAD_TIMEOUT_MS = 85_000;
const RESPONSE_MAX_BYTES = 64 * 1024;

function uploadError(message, status, code, extra) {
  return Object.assign(new Error(message), {name:'PodImageUploadError',status,code}, extra);
}

export function normalizeScdnCdnDomain(value) {
  const domain = typeof value === 'string' ? value.trim().toLowerCase() : value;
  if (domain === undefined || domain === '') return SCDN_DEFAULT_CDN_DOMAIN;
  if (SCDN_CDN_DOMAINS.includes(domain)) return domain;
  throw uploadError('请选择 SCDN 官方列表中的 CDN 域名。',400,'POD_UPLOAD_SCDN_INPUT');
}

function resultError() {
  return uploadError('SCDN 未确认上传成功或未返回所选 CDN 的公开图片直链。',502,'POD_UPLOAD_SCDN_RESULT');
}

async function readResult(response) {
  if (response.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') {
    void response.body?.cancel().catch(()=>{});
    throw resultError();
  }
  const reader = response.body?.getReader();
  if (!reader) throw resultError();
  const decoder = new TextDecoder();
  let bytes = 0, body = '';
  try {
    while (true) {
      const {done,value} = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > RESPONSE_MAX_BYTES) throw resultError();
      body += decoder.decode(value,{stream:true});
    }
    return JSON.parse(body + decoder.decode());
  } catch {
    throw resultError();
  } finally {
    void reader.cancel().catch(()=>{});
    reader.releaseLock();
  }
}

function directUrl(value, domain) {
  if (typeof value !== 'string' || value.length > 255 || /[\s\\]/u.test(value)) throw resultError();
  let url;
  try { url = new URL(value); }
  catch { throw resultError(); }
  if (url.protocol !== 'https:' || url.hostname !== domain || url.port || url.username || url.password
    || url.search || url.hash || !/^\/i\/[A-Za-z0-9_-][A-Za-z0-9_.-]*\.(?:png|jpe?g|webp)$/iu.test(url.pathname)) {
    throw resultError();
  }
  return url.href;
}

function responseError(response) {
  switch (response.status) {
    case 400: return uploadError('SCDN 拒绝了这张图片，请检查文件是否完整。',400,'POD_UPLOAD_SCDN_INPUT');
    case 403: return uploadError('SCDN 拒绝了上传请求，请核对图床访问状态。',403,'POD_UPLOAD_SCDN_FORBIDDEN');
    case 413: return uploadError('图片超过 SCDN 对该格式的上传大小限制。',413,'POD_UPLOAD_SCDN_SIZE');
    case 415: return uploadError('SCDN 无法识别这张图片，请使用有效的 PNG、JPG 或 WebP。',415,'POD_UPLOAD_SCDN_FORMAT');
    case 429: return uploadError('SCDN 上传过于频繁，请稍后重试。',429,'POD_UPLOAD_SCDN_RATE_LIMIT',
      {retryAfterMs:parseUploadRetryAfter(response.headers.get('retry-after')) ?? 5000});
    default: return uploadError('SCDN 上传服务暂时无法确认结果。',502,'POD_UPLOAD_PROVIDER_HTTP');
  }
}

/** Upload a rendered product image through the server-side SCDN connection. */
export async function uploadScdnImage(blob,{scdnCdnDomain,fetchImpl=fetch,signal}={}) {
  const domain = normalizeScdnCdnDomain(scdnCdnDomain);
  if (!(blob instanceof Blob) || !blob.size) throw uploadError('请选择要上传到 SCDN 的图片。',400,'POD_UPLOAD_SCDN_INPUT');
  const type = blob.type.toLowerCase();
  const format = Object.hasOwn(FORMATS,type) ? FORMATS[type] : undefined;
  if (!format) throw uploadError('请选择 PNG、JPG 或 WebP 图片。',415,'POD_UPLOAD_SCDN_FORMAT');
  const timeout = AbortSignal.timeout(UPLOAD_TIMEOUT_MS);
  const requestSignal = signal ? AbortSignal.any([signal,timeout]) : timeout;
  const body = new FormData();
  body.append('image',blob,'pod-effect.'+format);
  body.append('outputFormat',format);
  body.append('cdn_domain',domain);
  try {
    requestSignal.throwIfAborted();
    const response = await fetchImpl(SCDN_UPLOAD_URL,{
      method:'POST',headers:{Accept:'application/json'},body,
      redirect:'error',credentials:'omit',signal:requestSignal,
    });
    requestSignal.throwIfAborted();
    if (response.redirected) throw resultError();
    if (!response.ok) {
      void response.body?.cancel().catch(()=>{});
      throw responseError(response);
    }
    const result = await readResult(response);
    requestSignal.throwIfAborted();
    if (result?.success !== true) throw resultError();
    const url = directUrl(result.url ?? result.data?.url,domain);
    if (result.url != null && result.data?.url != null && directUrl(result.data.url,domain) !== url) throw resultError();
    return url;
  } catch (error) {
    if (signal?.aborted) throw uploadError('SCDN 图片上传已取消。');
    if (timeout.aborted) throw uploadError('等待 SCDN 响应超时，上传结果尚未确认。',502,'POD_UPLOAD_PROVIDER_TIMEOUT');
    if (error?.name === 'PodImageUploadError') throw error;
    throw uploadError('无法确认 SCDN 上传结果，请检查网络后重试。',502,'POD_UPLOAD_PROVIDER_TRANSPORT');
  }
}
