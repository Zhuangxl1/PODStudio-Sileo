import {createHash} from 'node:crypto';

// This is a local, value-free audit format. Object member order has no meaning;
// array order and value types remain significant. Never persist product values.
export const MIAOSHOU_FIELD_HASH_SCHEME='sha256-canonical-object-keys-v1';
const own=(value,key)=>value!==null&&typeof value==='object'&&Object.hasOwn(value,key);
const record=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const digest=value=>createHash('sha256').update(value).digest('hex');
function encoded(value){
  if(value===undefined)return ['undefined'];
  if(value===null)return ['null'];
  if(typeof value==='bigint')return ['bigint',String(value)];
  if(Array.isArray(value))return ['array',value.map(encoded)];
  if(record(value))return ['object',Object.keys(value).sort().map(key=>[key,encoded(value[key])])];
  return [typeof value,value];
}
export const miaoshouFieldHash=value=>digest(JSON.stringify(encoded(value)));
export const miaoshouFieldAt=(value,path)=>path.reduce((current,key)=>own(current,key)?current[key]:undefined,value);
export const miaoshouFieldsEqual=(a,b)=>miaoshouFieldHash(a)===miaoshouFieldHash(b);

/** The client validates the official success envelope; its save data must still
 * contain the required opaque marker. A malformed/lost receipt stays unknown. */
export function requireMiaoshouSaveData(data){
  if(!record(data)||typeof data.ossMd5!=='string'||!data.ossMd5.trim())
    throw Object.assign(new Error('妙手保存回执不完整，结果暂时无法确认，请核对后再操作。'),{code:'REMOTE_UNCERTAIN',status:502,definitive:false});
  return data.ossMd5;
}
export function createMiaoshouSaveReceipt(data,{operationId,detailId,shopId,scope,acknowledgedAt}){
  const marker=requireMiaoshouSaveData(data);
  return {version:1,api:'save_shop_collect_item_info',outcome:'acknowledged',operationId,detailId,shopId,accountScope:scope,result:'success',code:'success',ossMd5Hash:digest(marker),acknowledgedAt};
}

/** Review only changed leaves of selected patches. Arrays are kept whole and in
 * order: normalizing their order could conceal an actual SKU/image change. */
export function createMiaoshouFieldExpectations(info,patch){
  const entries=new Map();
  function add(before,after,path){
    if(miaoshouFieldsEqual(before,after))return;
    if(record(before)&&record(after)){
      for(const key of new Set([...Object.keys(before),...Object.keys(after)]))add(before[key],after[key],[...path,key]);
    }else entries.set(JSON.stringify(path),{path:[...path],expectedHash:miaoshouFieldHash(after)});
  }
  for(const item of patch){
    const before=miaoshouFieldAt(info,item.path);
    if(miaoshouFieldsEqual(before,item.value))entries.set(JSON.stringify(item.path),{path:[...item.path],expectedHash:miaoshouFieldHash(item.value)});
    else add(before,item.value,item.path);
  }
  return {scheme:MIAOSHOU_FIELD_HASH_SCHEME,fields:[...entries.values()]};
}
export function reviewMiaoshouFields(info,expectations,checkedAt){
  if(expectations?.scheme!==MIAOSHOU_FIELD_HASH_SCHEME||!expectations.fields?.length)return {state:'unavailable',reason:'legacy_expected_values_unavailable',checkedAt,fields:[]};
  const fields=expectations.fields.map(({path,expectedHash})=>({path:[...path],state:miaoshouFieldHash(miaoshouFieldAt(info,path))===expectedHash?'matched':'different'}));
  return {state:fields.every(field=>field.state==='matched')?'matched':'different',checkedAt,fields};
}
