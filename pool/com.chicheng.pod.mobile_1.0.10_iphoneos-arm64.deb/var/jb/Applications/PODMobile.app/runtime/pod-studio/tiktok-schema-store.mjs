import {mkdir,writeFile,rename,unlink,stat,readdir} from 'node:fs/promises';
import {readFileSync,lstatSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash,randomBytes} from 'node:crypto';

const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const sha=value=>createHash('sha256').update(value).digest('hex');
const fail=message=>Object.assign(new Error(message),{code:'PUBLISH_SCHEMA',status:409});
const keys=['bindingId','shopId','region','categoryPath','readAt','source'];
export function createTikTokSchemaStore({root,inlineBytes=128*1024,maxBlobBytes=16*1024*1024,maxCacheBytes=64*1024*1024,maxReferencedBytes=4*1024*1024*1024}={}){
  const directory=resolve(root,'publishing-schemas'),cache=new Map();let cacheBytes=0,diskBytes;
  function referenceValid(record){const ref=record?.schemaStorage;return plain(record)&&record.summaryOnly===true&&plain(ref)&&ref.version===1&&typeof ref.sha256==='string'&&/^[a-f0-9]{64}$/u.test(ref.sha256)&&ref.file===ref.sha256+'.json'&&Number.isSafeInteger(ref.size)&&ref.size>0&&ref.size<=maxBlobBytes&&keys.every(key=>typeof record[key]==='string')&&Number.isSafeInteger(record.fieldCount)&&record.fieldCount>=0&&record.fieldCount<=1000&&Number.isSafeInteger(record.optionCount)&&record.optionCount>=0&&record.optionCount<=10000000;}
  function fileInfo(record){if(!referenceValid(record))throw fail('类目缓存索引无效，请重新读取该细分类目。');try{const dir=lstatSync(directory),file=lstatSync(join(directory,record.schemaStorage.file));if(!dir.isDirectory()||dir.isSymbolicLink()||!file.isFile()||file.isSymbolicLink()||file.size!==record.schemaStorage.size)throw new Error();return file;}catch{throw fail('该细分类目的缓存原件缺失或大小异常，请重新读取。');}}
  function evict(){while(cacheBytes>maxCacheBytes&&cache.size){const [key,entry]=cache.entries().next().value;cache.delete(key);cacheBytes-=entry.bytes;}}
  function materialize(record){
    if(record?.summaryOnly!==true){if(record?.schemaStorage!==undefined)throw fail('类目缓存引用与摘要标记不一致，请重新读取。');return record;}
    const info=fileInfo(record),ref=record.schemaStorage,key=ref.sha256;let value,prior=cache.get(key);
    if(prior&&(prior.mtimeMs!==info.mtimeMs||prior.ctimeMs!==info.ctimeMs)){cache.delete(key);cacheBytes-=prior.bytes;prior=null;}
    if(prior){cache.delete(key);cache.set(key,prior);value=prior.value;}
    else{let bytes;try{bytes=readFileSync(join(directory,ref.file));if(bytes.length!==ref.size||sha(bytes)!==ref.sha256)throw new Error();value=JSON.parse(bytes.toString('utf8'));}catch{throw fail('该细分类目的缓存校验失败，请重新读取。');}cache.set(key,{value,bytes:ref.size,mtimeMs:info.mtimeMs,ctimeMs:info.ctimeMs});cacheBytes+=ref.size;evict();}
    if(!plain(value)||value.summaryOnly!==undefined||value.schemaStorage!==undefined||!Array.isArray(value.fields)||value.fields.length!==record.fieldCount||value.fields.reduce((sum,field)=>sum+(field.options?.length||0),0)!==record.optionCount||keys.some(name=>value[name]!==record[name])||['complete','status','draftComplete','reasonCode'].some(name=>value[name]!==record[name]))throw fail('类目缓存原件与所属店铺、类目或完整度索引不一致，请重新读取。');
    // Mutable failures live in the index; never revive the old successful blob.
    return {...value,...(Object.hasOwn(record,'lastReadFailure')?{lastReadFailure:structuredClone(record.lastReadFailure)}:{})};
  }
  async function externalize(record){
    if(record?.summaryOnly===true){if(!referenceValid(record))throw fail('类目缓存索引无效，请重新读取。');return record;}
    if(!plain(record)||record.schemaStorage!==undefined)throw fail('类目缓存格式无效。');let bytes=Buffer.from(JSON.stringify(record));if(bytes.length>maxBlobBytes)throw fail('单个细分类目的缓存超过 16 MB，请分段核对后重新读取。');if(bytes.length<=inlineBytes)return record;record={...record,draftComplete:record.draftComplete===true};bytes=Buffer.from(JSON.stringify(record));if(bytes.length>maxBlobBytes)throw fail('单个细分类目的缓存超过 16 MB，请分段核对后重新读取。');
    const digest=sha(bytes),filename=digest+'.json',target=join(directory,filename);await mkdir(directory,{recursive:true});const directoryInfo=lstatSync(directory);if(!directoryInfo.isDirectory()||directoryInfo.isSymbolicLink())throw fail('类目缓存目录无效。');
    let existing;try{existing=lstatSync(target);}catch(error){if(error.code!=='ENOENT')throw error;}
    if(existing&&(!existing.isFile()||existing.isSymbolicLink()))throw fail('类目缓存原件不能是目录或链接。');
    const intact=existing&&existing.size===bytes.length&&sha(readFileSync(target))===digest;
    if(!intact){
      if(diskBytes===undefined){diskBytes=0;const entries=await readdir(directory,{withFileTypes:true});if(entries.length>100000)throw fail('类目缓存文件过多，请归档后继续。');for(const entry of entries)if(/^[a-f0-9]{64}\.json(?:\.corrupt-[a-f0-9]+)?$/u.test(entry.name)){if(!entry.isFile()||entry.isSymbolicLink())throw fail('类目缓存目录含有异常引用。');diskBytes+=(await stat(join(directory,entry.name))).size;}}
      if(diskBytes+bytes.length>maxReferencedBytes)throw fail('类目缓存文件总量超过 4 GB，请归档不再使用的店铺后继续。');
      if(existing)await rename(target,target+'.corrupt-'+randomBytes(8).toString('hex'));
      const temporary=target+'.'+randomBytes(8).toString('hex')+'.tmp';try{await writeFile(temporary,bytes,{flag:'wx'});await rename(temporary,target);diskBytes+=bytes.length;}finally{await unlink(temporary).catch(()=>{});}
    }

    return {...Object.fromEntries(keys.map(key=>[key,record[key]])),complete:record.complete===true,status:record.status,draftComplete:record.draftComplete===true,...(record.reasonCode!==undefined?{reasonCode:record.reasonCode}:{}),...(Object.hasOwn(record,'lastReadFailure')?{lastReadFailure:structuredClone(record.lastReadFailure)}:{}),fieldCount:record.fields.length,optionCount:record.fields.reduce((sum,field)=>sum+(field.options?.length||0),0),summaryOnly:true,schemaStorage:{version:1,file:filename,sha256:digest,size:bytes.length}};
  }
  function validateBudget(records){if(!Array.isArray(records)||records.length>20000)throw fail('细分类目缓存数量超过 20,000 个，请归档不再使用的店铺。');let bytes=0;const hashes=new Set();for(const record of records){if(record.summaryOnly===true){if(!referenceValid(record))throw fail('类目缓存索引无效。');if(!hashes.has(record.schemaStorage.sha256)){hashes.add(record.schemaStorage.sha256);bytes+=record.schemaStorage.size;}}else bytes+=Buffer.byteLength(JSON.stringify(record));if(bytes>maxReferencedBytes)throw fail('类目缓存总量超过 4 GB，请归档不再使用的店铺后继续同步。');}return bytes;}
  function summaryAvailable(record){try{fileInfo(record);return true;}catch{return false;}}
  return {externalize,materialize,validateBudget,referenceValid,summaryAvailable,directory,cacheStats:()=>({entries:cache.size,bytes:cacheBytes,maxBytes:maxCacheBytes})};
}
