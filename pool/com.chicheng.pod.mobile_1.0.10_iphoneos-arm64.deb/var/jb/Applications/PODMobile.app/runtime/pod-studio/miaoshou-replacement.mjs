import {createHash,randomUUID} from 'node:crypto';
import {miaoshouId,requireSingleShop} from './dist/miaoshou-policy.js';
import {serializeMiaoshou} from './miaoshou-client.mjs';
const fingerprint=value=>createHash('sha256').update(serializeMiaoshou(value)).digest('hex');
export function validateMiaoshouDetail(data,{detailId,shopId}){
  requireSingleShop(data?.claimToShopIds,shopId);
  const info=data?.shopCollectItemInfo;
  if(!info||miaoshouId(info.detailId)!==detailId||miaoshouId(info.shopId)!==shopId||typeof data.ossMd5!=='string'||!data.ossMd5||!Array.isArray(info.imgUrls))throw Object.assign(new Error('妙手商品与目标链接不一致，请刷新后重试。'),{status:409,code:'DETAIL_MISMATCH'});
  return data;
}
export function createMiaoshouReplacement({client,now=Date.now}){
  const tickets=new Map(),locks=new Set();
  const prune=()=>{for(const [id,t]of tickets)if(t.expires<now()&&!locks.has(t.detailId))tickets.delete(id);};
  async function read(target){return validateMiaoshouDetail(await client.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)}),target);}
  return {
    async prepare({detailId,shopIds}){
      prune();const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)};
      const detail=await read(target),ticket=randomUUID();if(tickets.size>=200)throw new Error('进行中的套图较多，请稍后重试。');
      tickets.set(ticket,{...target,fingerprint:fingerprint(detail),expires:now()+30*60*1000,state:'ready'});
      return {ticket,...target,mainImage:detail.shopCollectItemInfo.imgUrls[0]||'',mainImages:[...detail.shopCollectItemInfo.imgUrls],title:detail.shopCollectItemInfo.title||''};
    },
    async replace({ticket,imageUrl,imageUrls}){
      prune();const task=tickets.get(ticket);if(!task||task.state!=='ready')throw Object.assign(new Error('替换任务已完成、过期或需要核对，请刷新链接。'),{status:409});
      if(imageUrls!==undefined&&imageUrl!==undefined)throw new Error('请提交一组完整的替换图片。');
      const values=imageUrls??[imageUrl];
      if(!Array.isArray(values)||values.length<1||values.length>15)throw new Error('请选择 1–15 张效果图，整组替换原主图。');
      const urls=values.map(value=>{let url;try{if(typeof value!=='string')throw Error();url=new URL(value);}catch{throw new Error('请先完成图片上传。');}if(url.protocol!=='https:'||url.username||url.password||url.href.length>8192)throw new Error('效果图需要有效的 HTTPS 图片链接。');return url.href;});
      if(new Set(urls).size!==urls.length)throw new Error('替换图片不能重复。');
      if(locks.has(task.detailId))throw Object.assign(new Error('该链接正在替换主图，请等待当前任务完成。'),{status:409});
      locks.add(task.detailId);
      try{
        // Fresh authoritative claimToShopIds: changes after opening the modal
        // must block both normal and Codex-assisted replacement.
        const current=await read(task);
        if(fingerprint(current)!==task.fingerprint)throw Object.assign(new Error('采集箱商品已更新，请刷新后重新套图，避免覆盖其他修改。'),{status:409,code:'STALE_PRODUCT'});
        task.state='submitting';
        const next={...current.shopCollectItemInfo,imgUrls:urls};
        await client.call('save',{ossMd5:current.ossMd5,shopCollectItemInfo:next,detailId:BigInt(task.detailId),shopId:BigInt(task.shopId)});
        const verified=await read(task);
        if(JSON.stringify(verified.shopCollectItemInfo.imgUrls)!==JSON.stringify(urls))throw Object.assign(new Error('妙手尚未返回完整的新主图组，请刷新核对；本地效果图已保留。'),{status:502,code:'VERIFY_FAILED'});
        task.state='complete';return {detailId:task.detailId,shopId:task.shopId,mainImage:urls[0],imageUrls:urls,verified:true};
      }catch(error){if(task.state==='submitting')task.state='uncertain';throw error;}finally{locks.delete(task.detailId);}
    }
  };
}
