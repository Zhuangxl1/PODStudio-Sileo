import {verifyPackagedCatalogForBuild} from './scripts/verify-tiktok-catalog.mjs';
import {readFile,writeFile,readdir,mkdir,copyFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {zipFileSource,writeStreamingZip,digestZipValue} from './streaming-zip.mjs';
import {loadPackagedTemplateSeeds} from './package-template-seeds.mjs';

const project=fileURLToPath(new URL('./',import.meta.url)),output=resolve(process.env.POD_PACKAGE_OUTPUT||resolve(project,'../delivery'));
const catalogBuildProof=verifyPackagedCatalogForBuild(project);
const zip=new Map();
async function add(file,target=file){zip.set(target,zipFileSource(resolve(project,file)));}
async function publicTree(directory){for(const entry of await readdir(resolve(project,directory),{withFileTypes:true})){const path=directory+'/'+entry.name;if(entry.isDirectory())await publicTree(path);else if(entry.isFile())await add(path);}}
for(const directory of ['dist','tests','docs','launcher','third-party','resources/tiktok-catalog'])await publicTree(directory);
for(const file of ['README.md','package.json','server.mjs','desktop-gateway.mjs','desktop-launcher.mjs','start-desktop.ps1','启动设计器.cmd','一键启动POD与GitHub图床.cmd','codex-bridge.mjs','codex-provider-settings.mjs','lanyi-provider.mjs','lanyi-image-runtime.mjs','siliconflow-runtime.mjs','provider-http.mjs','codex-network.mjs','codex-launcher.mjs','assistant-service.mjs','listing-suggestion-service.mjs','listing-suggestion-runner.mjs','listing-suggestion-contract.mjs','handover-knowledge.mjs','design-rules.mjs','fission-generation.mjs','quick-fission.mjs','solid-white-print.mjs','启动Codex助手.cmd','miaoshou-client.mjs','courtlistener-client.mjs','courtlistener-secrets.mjs','brand-research-client.mjs','brand-risk-research.mjs','miaoshou-risk-review.mjs','miaoshou-risk-api-source.mjs','risk-review-runner.mjs','risk-review-contract.mjs','risk-description-evidence.mjs','risk-tro-contract.mjs','risk-tro-runner.mjs','miaoshou-service.mjs','miaoshou-listing-title-evidence.mjs','miaoshou-batch.mjs','miaoshou-product-edits.mjs','miaoshou-claim-defaults.mjs','miaoshou-size-chart-library.mjs','miaoshou-category-attribute-templates.mjs','miaoshou-local-category-attributes.mjs','miaoshou-category-names.mjs','miaoshou-attribute-values.mjs','miaoshou-sku-presets.mjs','miaoshou-sku-structure-templates.mjs','miaoshou-edit-fields.mjs','miaoshou-edit-context.mjs','miaoshou-structured-edits.mjs','miaoshou-description-images.mjs','miaoshou-description-templates.mjs','miaoshou-mockup-template-bindings.mjs','miaoshou-cache.mjs','miaoshou-replacement.mjs','miaoshou-image.mjs','lan-launcher.mjs','lan-server.mjs','design-folder-store.mjs','lan-addresses.mjs','global-settings.mjs','storage-root.mjs','host-materials.mjs','host-templates.mjs','adspower-settings.mjs','adspower-client.mjs','tiktok-publishing-service.mjs','tiktok-shop-category-cache.mjs','tiktok-schema-store.mjs','tiktok-builtin-catalog.mjs','tiktok-catalog-codec.mjs','streaming-zip.mjs','tiktok-build-api-schema.mjs','tiktok-seller-rpa.mjs','tiktok-supplemental-compliance-rpa.mjs','tiktok-browser-driver.mjs','tiktok-category-definition.mjs','tiktok-category-localized-definition.mjs','tiktok-category-definition-observer.mjs','tiktok-category-definition-fields.mjs','seed-template-library.mjs','builtin-template-calibration.mjs','provider-secrets.ps1','build-handover.mjs','build-standalone.mjs','validate-standalone.mjs','standalone-module-graph.mjs','package-desktop.mjs','package-lan.mjs','package-lan-delivery.mjs','package-combined.mjs','package-template-seeds.mjs','scripts/build-template-seeds.mjs','scripts/verify-tiktok-catalog.mjs','scripts/finalize-tiktok-catalog.mjs'])await add(file);
for(const [path,bytes] of await loadPackagedTemplateSeeds({project}))zip.set(path,bytes);
const integration='integrations/urpiclink/';
// Explicit allowlist: private YAML, encrypted profiles, credentials, logs and runtime data are never packaged.
for(const file of ['README.md','LICENSE','UPSTREAM.md','main.go','go.mod','go.sum','run-server.ps1','copy-service-key.ps1','read-service-key.ps1','复制服务访问密钥.cmd','启动图床服务.cmd','启动图床服务.ps1','bin/urpiclink.exe','config/config.example.yaml'])await add(integration+file);
for(const directory of ['config','configstore','handler','models','service']){
  for(const entry of await readdir(resolve(project,integration+directory),{withFileTypes:true}))if(entry.isFile()&&entry.name.endsWith('.go'))await add(integration+directory+'/'+entry.name);
}
zip.set('POD服装设计器.html',zipFileSource(resolve(project,'build/combined/POD服装设计器.html')));
zip.set('runtime/node.exe',zipFileSource(process.execPath));
await add('third-party/NODE_LICENSE.txt','runtime/NODE_LICENSE.txt');
const require=createRequire(import.meta.url);
let xmlPackage;try{xmlPackage=require.resolve('xml-js/package.json');}catch{xmlPackage=resolve(dirname(process.execPath),'../node_modules/xml-js/package.json');}
for(const [name,packagePath,license] of [['xml-js',xmlPackage,'LICENSE'],['sax',createRequire(xmlPackage).resolve('sax/package.json'),'LICENSE.md']]){
  const root=dirname(packagePath),metadata=JSON.parse(await readFile(packagePath,'utf8'));
  zip.set('node_modules/'+name+'/package.json',JSON.stringify(Object.fromEntries(['name','version','main','license','dependencies','engines'].filter(key=>Object.hasOwn(metadata,key)).map(key=>[key,metadata[key]])),null,2));
  zip.set('node_modules/'+name+'/'+license,await readFile(resolve(root,license)));
  for(const entry of await readdir(resolve(root,'lib'),{withFileTypes:true}))if(entry.isFile()&&entry.name.endsWith('.js'))zip.set('node_modules/'+name+'/lib/'+entry.name,await readFile(resolve(root,'lib',entry.name)));
}
await mkdir(output,{recursive:true});
const target=resolve(output,'POD设计器_一键启动版_v1.77.zip'),archive=await writeStreamingZip(target,zip);
await copyFile(target,resolve(output,'POD设计器_源码及启动程序_v1.77.zip'));
console.log(JSON.stringify({files:zip.size,bytes:archive.bytes,archive:target}));

