import {mkdir,readFile,writeFile,rename,unlink} from 'node:fs/promises';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {TITLE_TRANSLATION_VERSION,titleTranslationKey,validateTitleItems,validateTitleTranslationResult} from './title-translation-contract.mjs';

export function createMiaoshouTitleTranslations({root,run,now=Date.now,queueDelayMs=40}={}){
  const entries=new Map(),loads=new Map(),queue=[];
  let closed=false,timer,running=null;
  const controller=new AbortController();
  const file=(scope,key)=>root?join(root,'title-translations',scope,key+'.json'):null;
  async function load(scope,title){
    const key=titleTranslationKey(title),identity=scope+':'+key;
    if(entries.has(identity))return entries.get(identity);
    if(loads.has(identity))return loads.get(identity);
    const pending=(async()=>{
      let saved;try{const path=file(scope,key);if(path)saved=JSON.parse(await readFile(path,'utf8'));}catch{}
      const entry={scope,key,title,status:'queued'};
      if(saved?.version===TITLE_TRANSLATION_VERSION&&saved.title===title&&saved.key===key){
        try{entry.translation=validateTitleTranslationResult({items:[{key,translation:saved.translation}]},[{key,title}])[0].translation;entry.status='ready';}catch{}
      }
      entries.set(identity,entry);return entry;
    })().finally(()=>loads.delete(identity));
    loads.set(identity,pending);return pending;
  }
  async function persist(entry){
    const path=file(entry.scope,entry.key);if(!path)return;
    const temp=path+'.'+randomUUID()+'.tmp';
    try{await mkdir(join(root,'title-translations',entry.scope),{recursive:true});await writeFile(temp,JSON.stringify({version:TITLE_TRANSLATION_VERSION,key:entry.key,title:entry.title,translation:entry.translation,updatedAt:new Date(now()).toISOString()}),{flag:'wx',mode:0o600});await rename(temp,path);}
    finally{await unlink(temp).catch(()=>{});}
  }
  function schedule(){if(closed||running||timer||!queue.length)return;timer=setTimeout(()=>{timer=null;void pump();},queueDelayMs);timer.unref?.();}
  async function pump(){
    if(closed||running)return;
    const scope=queue[0]?.scope,batch=[];
    for(let index=0;index<queue.length&&batch.length<10;)if(queue[index].scope===scope)batch.push(...queue.splice(index,1));else index++;
    if(!batch.length)return;
    const work=(async()=>{
      const selected=[];
      for(const entry of batch){try{await entry.guard?.();selected.push(entry);}catch{entry.status='failed';entry.message='商品连接已变化，保留原标题。';}}
      if(!selected.length)return;
      try{
        if(typeof run!=='function')throw new Error('标题翻译服务未就绪。');
        const input=selected.map(({key,title})=>({key,title}));
        const output=validateTitleTranslationResult({items:await run(input,{signal:controller.signal,onStart(){for(const entry of selected)entry.status='running';}})},input);
        controller.signal.throwIfAborted();
        const results=new Map(output.map(item=>[item.key,item.translation]));
        for(const entry of selected){
          try{await entry.guard?.();entry.translation=results.get(entry.key);entry.status='ready';await persist(entry).catch(()=>{});}
          catch{entry.status='failed';entry.message='商品连接已变化，保留原标题。';}
        }
      }catch{
        for(const entry of selected){entry.status='failed';entry.message=closed?'标题翻译已停止，保留原标题。':'标题翻译未完成，保留原标题。';}
      }
    })();
    running=work;try{await work;}finally{if(running===work)running=null;schedule();}
  }
  return {
    async request({accountScope,contextId,items,guard}){
      if(closed)throw new Error('标题翻译服务已关闭。');
      if(!/^[a-f0-9]{64}$/u.test(accountScope||'')||typeof contextId!=='string'||!contextId)throw new Error('标题翻译连接无效。');
      const normalized=validateTitleItems(items);await guard?.();
      const loaded=await Promise.all(normalized.map(item=>load(accountScope,item.title)));await guard?.();
      if(closed)throw new Error('标题翻译服务已关闭。');
      for(const entry of loaded){
        entry.guard=guard;
        if(entry.status==='queued'&&!entry.enqueued){entry.enqueued=true;queue.push(entry);}
      }
      schedule();
      return {contextId,items:normalized.map((item,index)=>{
        const entry=loaded[index];return {...item,status:entry.status,...(entry.status==='ready'?{translation:entry.translation}:{}),...(entry.message?{message:entry.message}:{})};
      })};
    },
    async close(){closed=true;clearTimeout(timer);timer=null;controller.abort();queue.length=0;await running;},
  };
}
