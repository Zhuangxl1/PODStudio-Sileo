import {createHash,randomUUID} from 'node:crypto';
import {sanitizeMiaoshouValue} from './miaoshou-client.mjs';
import {miaoshouId} from './dist/miaoshou-policy.js';

const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
const message=(value,redactions)=>sanitizeMiaoshouValue(value,redactions,400);
const uncertain=id=>({detailId:id,state:'needs_review',code:'REMOTE_UNCERTAIN',message:'妙手未返回可对应到此商品的删除回执，请核对原任务，勿重复提交。'});

/** Counters alone identify all-success/all-failure. Partial success needs an
 * exact failure map before any remaining IDs can be treated as successful. */
export function miaoshouDeleteResults(raw,ids,redactions=[]){
  const errors=raw?.errorMap===undefined?{}:raw.errorMap;
  if(!object(raw)||!object(errors)||!Number.isSafeInteger(raw.successNum)||!Number.isSafeInteger(raw.failNum)||
    raw.successNum<0||raw.failNum<0||raw.successNum+raw.failNum!==ids.length)return ids.map(uncertain);
  const failed=Object.keys(errors),selected=new Set(ids);
  if(failed.some(id=>!selected.has(id)||typeof errors[id]!=='string'||!errors[id].trim())||
    (failed.length!==raw.failNum&&!(raw.successNum===0&&failed.length===0)))return ids.map(uncertain);
  return ids.map(detailId=>raw.successNum===0||Object.hasOwn(errors,detailId)
    ?{detailId,state:'failed',code:'REMOTE_REJECTED',definitive:true,message:'妙手拒绝删除'+(message(errors[detailId]||raw.errorMsg,redactions)?'：'+message(errors[detailId]||raw.errorMsg,redactions):'，请检查商品状态。')}
    :{detailId,state:'succeeded',message:'妙手已确认删除。'});
}

/** Submit only the confirmed selection, once, using the existing TK endpoint.
 * Journal reservations survive ambiguous responses and prevent silent retries. */
export function createMiaoshouBatchDelete({getRecords,accountScope,getContextId,assertOpen,acquire,journal,call,removeDeleted,getRedactions=async()=>[]}={}){
  return async function deleteSelected(items,{expectedScope,expectedContextId}={}){
    if(!Array.isArray(items)||!items.length||items.length>20)throw new Error('每组删除须为 1–20 个商品。');
    const ids=items.map(item=>miaoshouId(item.detailId));
    if(new Set(ids).size!==ids.length)throw new Error('删除选择包含重复商品。');
    const guard=async()=>{
      assertOpen();
      if(await accountScope()!==expectedScope||expectedContextId!==undefined&&getContextId()!==expectedContextId)
        throw Object.assign(new Error('妙手连接已变化，未继续删除。'),{code:'CONTEXT_CHANGED'});
      assertOpen();
    };
    await guard();
    const release=acquire(ids),results=new Map();
    let reserved=[],dispatched=false,redactions=[];
    const finish=()=>ids.map(id=>results.get(id)||uncertain(id));
    const recordStates=async rows=>{
      if(!rows.length)return true;
      try{await journal.transitionMany(rows.map(row=>({operationId:row.operationId,state:row.state})),expectedScope);return true;}
      catch{return false;}
    };
    try{
      redactions=await getRedactions();
      await guard();
      const entries=[];
      for(const item of items){
        const row=getRecords().get(item.detailId);
        if(!row||![item.title,item.sourceTitle].includes(row.title)||
          JSON.stringify([...(row.shopIds||[])].sort())!==JSON.stringify([...(item.shopIds||[])].sort())){
          results.set(item.detailId,{detailId:item.detailId,state:'failed',code:'MIAOSHOU_DELETE_STALE',message:'商品或关联店铺已变化，请重新选择后删除。'});continue;
        }
        const timestamp=new Date().toISOString();
        entries.push({operationId:randomUUID(),key:createHash('sha256').update(JSON.stringify([expectedScope,'delete',item.detailId,''])).digest('hex'),
          accountScope:expectedScope,action:'delete',detailId:item.detailId,shopId:'',state:'submitting',createdAt:timestamp,updatedAt:timestamp});
      }
      if(!entries.length)return finish();
      const reservation=await journal.reserveMany(entries);
      reserved=reservation.reserved;
      for(const entry of reservation.existing)results.set(entry.detailId,{detailId:entry.detailId,state:'needs_review',code:'ACTION_REVIEW_REQUIRED',message:'此商品已有删除提交记录，请查询原任务，勿重复提交。'});
      if(!reserved.length)return finish();
      await guard();
      let response;
      try{
        dispatched=true;
        response=await call('delete',{detailIds:reserved.map(entry=>BigInt(entry.detailId))},{guard});
      }catch(error){
        const definitive=error.definitive===true||error.notDispatched===true;
        await recordStates(reserved.map(entry=>({...entry,state:definitive?'failed':'uncertain'})));
        for(const entry of reserved)results.set(entry.detailId,{detailId:entry.detailId,state:definitive?'failed':'needs_review',
          code:definitive?'REMOTE_REJECTED':'REMOTE_UNCERTAIN',definitive,
          message:message(error.message,redactions)||'删除结果暂时无法确认，请查询原任务，勿重复提交。'});
        return finish();
      }
      const received=miaoshouDeleteResults(response,reserved.map(entry=>entry.detailId),redactions);
      const byId=new Map(received.map(row=>[row.detailId,row]));
      const recorded=await recordStates(reserved.map(entry=>({...entry,state:byId.get(entry.detailId).state==='succeeded'?'deleted':byId.get(entry.detailId).state==='failed'?'failed':'uncertain'})));
      for(const result of received)results.set(result.detailId,{...result,...(!recorded?{message:result.message+' 本地操作记录尚未更新，原提交记录已保留。'}:{})});
      const deleted=received.filter(row=>row.state==='succeeded').map(row=>row.detailId);
      if(deleted.length)try{await guard();await removeDeleted(deleted);}catch{
        for(const id of deleted)results.get(id).message+=' 本地列表尚未刷新，请重新同步。';
      }
      return finish();
    }catch(error){
      if(reserved.length&&!dispatched)await recordStates(reserved.map(entry=>({...entry,state:'failed'})));
      for(const id of ids)if(!results.has(id))results.set(id,{detailId:id,state:dispatched?'needs_review':'failed',code:dispatched?'REMOTE_UNCERTAIN':error.code||'MIAOSHOU_DELETE_FAILED',message:message(error.message,redactions)||'删除未完成。'});
      return finish();
    }finally{release();}
  };
}
