// Pure field contract. No network, credentials, transaction or publication logic.
// Verified official schema: https://qrzmpphmpd.apifox.cn/492780434e0 (2026-10-27).
const descriptor = (id, label, group, fields, status = 'flat', extra = {}) =>
  Object.freeze({id, label, group, fields: Object.freeze(fields), status, ...extra});
export const MIAOSHOU_EDIT_FIELDS = Object.freeze([
  descriptor('title', '标题', '基础信息', ['title'], 'flat', {minLength:25,maxLength:255}),
  descriptor('description', '描述', '基础信息', ['notes'], 'flat', {maxLength:10000}),
  descriptor('descriptionImageOptimization', '描述图优化', '基础信息', [], 'unconfirmed'),
  descriptor('productAttributes', '产品属性', '类目属性', ['productAttributes'], 'structured'),
  descriptor('brandId', '品牌', '类目属性', ['brandId'], 'flat', {context:'allowedBrandIds',maxLength:20}),
  descriptor('productCertifications', '资质证书', '类目属性', ['productCertifications'], 'structured'),
  descriptor('manufacturerAndResponsible', '制造商与负责人', '类目属性', ['manufacturerIds','responsiblePersonIds'], 'structured'),
  descriptor('specificationNames', '规格名称', '销售属性/SKU信息', ['skuPropertyList'], 'structured'),
  descriptor('sellerSku', '平台SKU', '销售属性/SKU信息', ['skuMap.*.itemNum'], 'structured'),
  descriptor('sourcePrice', '货源价格', '销售属性/SKU信息', ['skuMap.*.originPrice'], 'structured'),
  descriptor('warehouseInventory', '仓库与库存', '销售属性/SKU信息', ['skuMap.*.stock','skuMap.*.shopIdToWarehouseIdAndStockMap'], 'structured'),
  descriptor('productIdentifier', '产品识别码', '销售属性/SKU信息', [], 'unconfirmed'),
  descriptor('addSku', '添加SKU', '销售属性/SKU信息', ['skuPropertyList','skuMap'], 'structured'),
  descriptor('preSale', '预售类型', '销售属性/SKU信息', ['skuMap.*.preSale'], 'incomplete-enum'),
  descriptor('listedPrice', '标价', '销售属性/SKU信息', ['skuMap.*.price','skuMap.*.priceIncludeVat'], 'needs-semantics'),
  descriptor('mainImages', '产品主图', '产品图片', ['imgUrls'], 'flat', {maxItems:15}),
  descriptor('skuImages', 'SKU图', '产品图片', ['skuPropertyList.*.attrValueList.*.imgUrl'], 'structured'),
  descriptor('sizeChartUrl', '尺码表', '产品图片', ['sizeChartType','sizeChart'], 'flat', {context:'sizeChartSupported',maxLength:255}),
  descriptor('videoUrl', '产品视频', '产品图片', ['mainImgVideoUrl'], 'flat', {maxLength:255}),
  descriptor('weightGrams', '包裹重量', '物流信息', ['weight'], 'flat', {inputUnit:'g',outputUnit:'kg',minimum:1,maximum:100000}),
  descriptor('packageDimensionsCm', '包裹尺寸', '物流信息', ['packageLength','packageWidth','packageHeight'], 'flat', {unit:'cm',minimum:1,maximum:1000}),
  descriptor('codEnabled', 'COD', '物流信息', ['isCodOpen'], 'flat', {context:'codSupported'}),
  descriptor('deliveryMode', '发货方式', '物流信息', ['deliveryOptionSetType'], 'flat', {onlyValue:'default'})
]);
const descriptors = new Map(MIAOSHOU_EDIT_FIELDS.map(d => [d.id,d]));
const own = (value,key) => Object.prototype.hasOwnProperty.call(value,key);
function fail(field,message) {
  throw Object.assign(new Error(message),{code:'MIAOSHOU_EDIT_INVALID',field});
}
function record(value,field) {
  if(!value || typeof value !== 'object' || ![Object.prototype,null].includes(Object.getPrototypeOf(value)))
    fail(field,'编辑数据必须是普通对象。');
  for(const key of Reflect.ownKeys(value)) {
    if(typeof key !== 'string' || ['__proto__','constructor','prototype'].includes(key) || !own(Object.getOwnPropertyDescriptor(value,key),'value'))
      fail(field,'编辑数据包含不支持的字段。');
  }
  return value;
}
function str(value,field,min,max) {
  if(typeof value !== 'string' || Array.from(value).length<min || Array.from(value).length>max || value.includes('\0'))
    fail(field,`${descriptors.get(field)?.label||field}长度或格式无效。`);
  return value;
}
function number(value,field,min,max) {
  if(typeof value !== 'number' || !Number.isFinite(value) || value<min || value>max)
    fail(field,`${descriptors.get(field)?.label||field}必须在 ${min}–${max} 之间。`);
  return value;
}
function publicUrl(value,field,max=8192) {
  str(value,field,1,max);
  let url;try { url = new URL(value); } catch { fail(field,'请填写完整图片或视频网址。'); }
  if(url.protocol!=='https:' || url.username || url.password || /\s/.test(value))
    fail(field,'图片或视频须为不含登录凭据的 HTTPS 网址。');
  // URL reachability/upload validation belongs to the existing media layer.
  return value;
}

/** Only explicit selected fields are serialized. Context must belong to the
 * target shop/category and be loaded by the caller; never reuse it across shops.
 * values may contain UI history but it is never inspected or serialized.
 * Omitting a field preserves it. Clearing fields is not implicit.
 */
export function compileMiaoshouFlatPatch({selectedFields, values, context = {}}) {
  if(!Array.isArray(selectedFields) || !selectedFields.length || selectedFields.length>descriptors.size)
    fail('selectedFields','请勾选本次要修改的字段。');
  if(new Set(selectedFields).size!==selectedFields.length)fail('selectedFields','修改字段不能重复。');
  record(values,'values');record(context,'context');
  const patch={};
  for(const id of selectedFields) {
    const d=descriptors.get(id);
    if(!d || d.status!=='flat')fail(id,'此项不能使用普通字段批量编辑，请使用对应的专用编辑功能。');
    if(!own(values,id))fail(id,'已勾选的修改字段没有填写内容。');
    const v=values[id];
    switch(id) {
      case 'title': patch.title=str(v,id,25,255);if(/[\u0000-\u001f\u007f]/u.test(v))fail(id,'标题包含无效控制字符。');if(!v.trim())fail(id,'标题不能为空白。');break;
      case 'description': patch.notes=str(v,id,1,10000);if(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(v))fail(id,'描述包含无效控制字符。');if(!v.trim())fail(id,'描述不能为空白。');break;
      case 'brandId':
        str(v,id,1,20);
        if(!Array.isArray(context.allowedBrandIds) || !context.allowedBrandIds.includes(v))fail(id,'请从当前店铺允许的品牌中选择。');
        patch.brandId=v;break;
      case 'mainImages':
        if(!Array.isArray(v) || !v.length || v.length>15)fail(id,'主图数量必须为 1–15 张。');
        patch.imgUrls=Array.from(v,url=>publicUrl(url,id));break;
      case 'sizeChartUrl':
        if(context.sizeChartSupported!==true)fail(id,'请先确认当前店铺类目支持尺码表。');
        patch.sizeChart=publicUrl(v,id,255);patch.sizeChartType='image';break;
      case 'videoUrl':patch.mainImgVideoUrl=publicUrl(v,id,255);break;
      case 'weightGrams':patch.weight=number(v,id,1,100000)/1000;break;
      case 'packageDimensionsCm':
        record(v,id);
        if(Object.keys(v).length!==3 || !['length','width','height'].every(k=>own(v,k)))fail(id,'请填写完整的长、宽、高（cm）。');
        patch.packageLength=number(v.length,id,1,1000);
        patch.packageWidth=number(v.width,id,1,1000);
        patch.packageHeight=number(v.height,id,1,1000);break;
      case 'codEnabled':
        if(context.codSupported!==true)fail(id,'请先确认当前店铺类目支持 COD。');
        if(typeof v!=='boolean')fail(id,'COD 必须选择开启或关闭。');
        patch.isCodOpen=v?'1':'0';break;
      case 'deliveryMode':
        if(v!=='default')fail(id,'妙手开放接口仅支持默认发货方式。');
        patch.deliveryOptionSetType='default';break;
    }
  }
  return patch;
}

/** Local merge only. Caller still owns fresh detail fetch, ossMd5 optimistic
 * concurrency, confirmation, per-item journal and verification after saving.
 * No raw patch argument is accepted, so a caller cannot bypass compilation.
 */
export function applyMiaoshouFlatPatch(shopCollectItemInfo, edit) {
  record(shopCollectItemInfo,'shopCollectItemInfo');
  return {...structuredClone(shopCollectItemInfo),...compileMiaoshouFlatPatch(edit)};
}
