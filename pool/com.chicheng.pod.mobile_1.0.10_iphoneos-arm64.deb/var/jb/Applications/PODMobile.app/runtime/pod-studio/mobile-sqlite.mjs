import {nativeBinding} from './mobile-native.mjs';
export const DatabaseSync = nativeBinding().DatabaseSync;
export const backup = nativeBinding().backup;
