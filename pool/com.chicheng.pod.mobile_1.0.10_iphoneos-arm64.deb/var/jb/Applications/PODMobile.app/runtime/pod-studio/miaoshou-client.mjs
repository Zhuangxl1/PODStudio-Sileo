import {createHmac} from 'node:crypto';
import {setTimeout as sleep} from 'node:timers/promises';
import {requireMiaoshouSaveData} from './miaoshou-save-receipt.mjs';
import {parseLosslessJSON,stringifyLosslessJSON} from './mobile-json.mjs';
export const MIAOSHOU_PATHS=Object.freeze({descriptionMatting:'/open/v1/product/picture/matting/auto_ai_matting_multi',warehouses:'/open/v1/product/collect_box/tiktok/collect_box/get_shop_warehouse_list',manufacturers:'/open/v1/product/collect_box/tiktok/collect_box/get_manufacturer_list',responsiblePersons:'/open/v1/product/collect_box/tiktok/collect_box/get_responsible_person_list',categoryMetadata:'/open/v1/product/collect_box/tiktok/collect_box/get_category_metadata',shops:'/open/v1/product/shop/shop/get_shop_list',claim:'/open/v1/product/collect_box/tiktok/collect_box/claim_to_shop',delete:'/open/v1/product/collect_box/tiktok/collect_box/delete_collect_box_detail',publish:'/open/v1/product/collect_box/tiktok/collect_box/save_move_collect_task',publishRecords:'/open/v1/product/collect_box/tiktok/move_collect/search_move_collect_list',list:'/open/v1/product/collect_box/tiktok/collect_box/search_collect_box_detail_list',detail:'/open/v1/product/collect_box/tiktok/collect_box/get_shop_collect_item_info',siteDetail:'/open/v1/product/collect_box/tiktok/collect_box/get_site_collect_item_info',save:'/open/v1/product/collect_box/tiktok/collect_box/save_shop_collect_item_info'});
// Keep integer IDs exact, including nested IDs in the unmodified shop payload.
export function parseMiaoshouJSON(source){
  return parseLosslessJSON(source);
}
export const serializeMiaoshou=stringifyLosslessJSON;
export function miaoshouSignature(path,timestamp,body,{appKey,appSecret}){return createHmac('sha256',appSecret).update(appSecret+path+timestamp+appKey+body+appSecret).digest('hex');}
export const sanitizeMiaoshouValue=(value,redactions=[],max=350)=>{
      if(!['string','number','boolean','bigint'].includes(typeof value))return '';
      let message=String(value);for(const value of redactions)if(value)message=message.split(value).join('[已隐藏]');
      return message.replace(/(?:app[-_ ]?(?:key|secret)|x[-_ ]?(?:app[-_ ]?key|sign)|authorization|access[-_ ]?token|api[-_ ]?key)\s*[:=]\s*[^,;\s]+/gi,'凭据=[已隐藏]').replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,max);
};

export function createMiaoshouClient({settings,fetchImpl=fetch,now=Date.now,wait=(ms,signal)=>sleep(ms,undefined,{signal}),minIntervalMs=1200}){
  const queues={foreground:[],normal:[],background:[]};
  const turns=['foreground','foreground','foreground','foreground','normal','normal','background'];
  let nextAt=0,cursor=0,draining=false,cooldown=null,cooldownUntil=0;
  const readOnly=new Set(['list','detail','siteDetail','shops','publishRecords','categoryMetadata','warehouses','manufacturers','responsiblePersons']);
  const cancelled=()=>new DOMException('妙手读取已取消。','AbortError');
  const temporaryCodes=new Set(['httpgatewaytimeout','upstreamerror','upstreamconnecttimeout','upstreamreadtimeout','upstreamreset','systemerror','redisconnectionerror','redistimeout']);
  const retryAfter=response=>{const value=response.headers?.get?.('retry-after');if(!value)return 0;const seconds=Number(value),delay=Number.isFinite(seconds)?seconds*1000:Date.parse(value)-now();return Number.isFinite(delay)?Math.max(0,Math.min(60000,delay)):0;};
  async function beforeDispatch(operation,work){try{return await work();}catch(error){if(operation==='save')error.notDispatched=true;throw error;}}
  async function request({operation,body,guard,signal,timeoutMs}){
    const path=MIAOSHOU_PATHS[operation];if(!path)throw new Error('妙手接口不存在。');
    const config=await beforeDispatch(operation,()=>settings.read());if(!config.appKey||!config.appSecret)throw Object.assign(new Error('请先在本机配置妙手开放平台连接。'),{status:503,notDispatched:true});
    const timestamp=String(Math.floor(now()/1000)),signature=miaoshouSignature(path,timestamp,body,config);let response,text;const writing=['save','claim','delete','publish','descriptionMatting'].includes(operation);
    await beforeDispatch(operation,guard);
    const deadline=AbortSignal.timeout(timeoutMs);
    try{response=await fetchImpl('https://openapi-erp.91miaoshou.com'+path,{method:'POST',redirect:'error',signal:signal?AbortSignal.any([signal,deadline]):deadline,headers:{'Content-Type':'application/json','Accept':'application/json','x-app-key':config.appKey,'x-timestamp':timestamp,'x-sign':signature},body});
      const chunks=[];let bytes=0;for await(const chunk of response.body){bytes+=chunk.length;if(bytes>12*1024*1024)throw Object.assign(new Error(),{code:'RESPONSE_TOO_LARGE'});chunks.push(chunk);}text=Buffer.concat(chunks).toString('utf8');
    }catch(error){if(signal?.aborted)throw cancelled();const timeout=deadline.aborted||['TimeoutError','AbortError'].includes(error?.name),tooLarge=error?.code==='RESPONSE_TOO_LARGE';throw Object.assign(new Error(writing?'妙手操作结果暂时无法确认，请刷新核对，不要重复提交。':tooLarge?'妙手返回数据超过单次读取上限，请联系平台核对。':timeout?'妙手读取超时，请稍后重试。':'妙手连接暂时失败，请检查网络或稍后重试。'),{status:502,code:writing?'REMOTE_UNCERTAIN':tooLarge?'REMOTE_FORMAT':timeout?'REMOTE_TIMEOUT':'REMOTE_CONNECTION',retryable:!writing&&!tooLarge});}
    // A response to a transmitted write belongs to its original target even if
    // the UI/account closes meanwhile. Preserve that receipt; never invite replay.
    if(operation!=='save')await guard();
    let result;try{result=parseMiaoshouJSON(text);}catch{const temporary=[429,502,503,504].includes(response.status);throw Object.assign(new Error(writing?'妙手操作返回格式无效，结果暂时无法确认，请核对后再操作。':temporary?'妙手服务暂时无法响应（HTTP '+response.status+'），请稍后重试。':'妙手返回格式无效，请稍后刷新。'),{status:502,code:writing?'REMOTE_UNCERTAIN':temporary?'REMOTE_TEMPORARY':'REMOTE_FORMAT',httpStatus:response.status,retryable:!writing&&temporary,retryAfterMs:retryAfter(response)});}
    const code=String(result?.code??'').toLowerCase(),flag=String(result?.result??'').toLowerCase();
    // Official envelopes identify success with result:'success'. A conflicting
    // explicit result must never be hidden by a numeric code from another API.
    const accepted=operation==='save'?result?.result==='success'&&result?.code==='success':flag?['success','true','ok'].includes(flag):['success','0','200','ok'].includes(code);
    if(!response.ok||!accepted){
      const redactions=[config.appKey,config.appSecret,signature],remoteCode=sanitizeMiaoshouValue(result?.code,redactions,80),remoteMessage=sanitizeMiaoshouValue(result?.reason??result?.message??result?.msg??result?.errorMsg,redactions,350),httpStatus=response.status;
      const known={appNotFound:'应用不存在或未启用，请检查 App Key 和审核状态。',appNoPermission:'应用没有该接口权限，请在妙手开放平台检查授权。',signMissing:'请求签名缺失，请检查连接配置。',signInvalid:'签名验证失败，请检查 App Key 与 App Secret 是否配套。',signExpired:'请求时间已过期，请校准主机时间。',ipNotInWhitelist:'当前主机出口 IP 不在妙手白名单中。',routeNotFound:'妙手接口路径不存在，请更新软件。'};
      const explicitFailure=['fail','failed','failure','error','false'].includes(flag);
      const limited=/^(account|app|api|platform|accountApi)Qp[smd]RateLimit$/.test(remoteCode);
      const reportedLimit=readOnly.has(operation)&&httpStatus===200&&!known[remoteCode]
        &&(explicitFailure||['fail','failed','failure','error','false'].includes(code))
        &&/请求(?:过于|过|太)频繁|请求频率(?:过高|超过限制)|请求(?:达到|超过).{0,8}频率限制/u.test(remoteMessage);
      const safeReason=known[remoteCode]||(limited||reportedLimit?'妙手接口请求达到频率限制，请稍后重试。':remoteMessage);
      const gatewayFailure=!known[remoteCode]&&!limited&&(temporaryCodes.has(remoteCode.toLowerCase())||[502,503,504].includes(httpStatus));
      const temporary=gatewayFailure||!known[remoteCode]&&!limited&&httpStatus===429;
      // A gateway may produce a JSON failure after an upstream write. Keep its
      // result uncertain unless the response identifies a definite rejection.
      const definite=writing&&!gatewayFailure&&(explicitFailure||[400,401,403,404,422].includes(httpStatus)||Boolean(known[remoteCode])||limited);
      throw Object.assign(new Error('妙手接口未成功（HTTP '+httpStatus+(remoteCode?' / '+remoteCode:'')+'）'+(safeReason?'：'+safeReason:'，请检查开放平台权限或刷新核对。')),{status:502,code:limited||known[remoteCode]?remoteCode:reportedLimit?'REMOTE_RATE_LIMIT':definite?'REMOTE_REJECTED':writing?'REMOTE_UNCERTAIN':'REMOTE_REJECTED',definitive:definite,remoteCode,remoteMessage:known[remoteCode]||limited||reportedLimit?safeReason:remoteMessage,httpStatus,retryable:!writing&&(temporary||reportedLimit),retryAfterMs:retryAfter(response)});
    }
    if(operation==='save')requireMiaoshouSaveData(result.data);
    return result.data;
  }
  const pending=()=>Object.values(queues).some(queue=>queue.length);
  function take(){
    for(let checked=0;checked<turns.length;checked++){
      const priority=turns[cursor];cursor=(cursor+1)%turns.length;
      if(queues[priority].length)return queues[priority].shift();
    }
  }
  function settle(job,success,value){
    if(job.settled)return;
    job.settled=true;
    job.signal?.removeEventListener('abort',job.abort);
    if(success)job.resolve(value);else job.reject(value);
  }
  function enqueue(job){if(!job.settled){queues[job.priority].push(job);queueMicrotask(()=>void drain());}}
  function defer(job,delay,global){
    const waiting=Promise.resolve().then(()=>wait(delay,global?undefined:job.signal));
    if(global)cooldown=waiting;
    waiting.then(async()=>{if(!job.settled){await job.guard();enqueue(job);}}).catch(error=>settle(job,false,error))
      .finally(()=>{if(cooldown===waiting)cooldown=null;if(pending())queueMicrotask(()=>void drain());});
  }
  function failed(job,error){
    if(job.settled)return;
    const limited=/(QpsRateLimit|QpmRateLimit)$/.test(error.code||'');
    const delay=Math.max((limited&&error.code.includes('Qpm')?60000:2000)*2**job.attempt,error.retryAfterMs||0);
    const global=limited||error.code==='REMOTE_RATE_LIMIT'||error.retryAfterMs>0||error.httpStatus===429;
    if(job.attempt>=job.maxRetries||(!limited&&!error.retryable)){
      if(global)cooldownUntil=Math.max(cooldownUntil,Date.now()+delay);
      if(job.attempt>0)error.message+='（已自动重试 '+job.attempt+' 次，仍未成功）';
      settle(job,false,error);return;
    }
    job.attempt++;
    defer(job,delay,global);
  }
  async function drain(){
    if(draining)return;draining=true;
    try{
      while(pending()){
        try{
          if(cooldown)await cooldown.catch(()=>{});
          const delay=Math.max(nextAt,cooldownUntil)-Date.now();
          if(delay>0)await wait(delay);
          cooldownUntil=0;
        }catch(error){const job=take();if(job)settle(job,false,error);continue;}
        // Choose after pacing so a foreground request arriving during the wait
        // can precede queued background work. Only one request runs at a time.
        const job=take();if(!job)continue;
        let attempted=false;
        try{
          await beforeDispatch(job.operation,job.guard);
          if(!job.bodyReady){job.body=await beforeDispatch(job.operation,()=>serializeMiaoshou(job.payload));job.bodyReady=true;}
          attempted=true;
          settle(job,true,await request(job));
        }catch(error){failed(job,error);}
        finally{if(attempted)nextAt=Date.now()+minIntervalMs;}
      }
    }finally{draining=false;if(pending())queueMicrotask(()=>void drain());}
  }
  return {call(operation,payload,{guard=()=>{},priority='foreground',signal,timeoutMs,maxRetries}={}){
    if(typeof guard!=='function')return Promise.reject(new TypeError('妙手请求核验函数无效。'));
    if(!Object.hasOwn(queues,priority))return Promise.reject(new Error('妙手请求优先级无效。'));
    const reading=readOnly.has(operation);
    if(reading&&(signal!==undefined&&!(signal instanceof AbortSignal)
      ||timeoutMs!==undefined&&(!Number.isInteger(timeoutMs)||timeoutMs<1||timeoutMs>60000)
      ||maxRetries!==undefined&&(!Number.isInteger(maxRetries)||maxRetries<0||maxRetries>3))){
      return Promise.reject(new TypeError('妙手读取超时、重试或取消选项无效。'));
    }
    const timeoutLimit=reading?(priority==='background'?15000:60000):30000;
    const retryLimit=reading?(priority==='background'?1:3):0;
    const readSignal=reading?signal:undefined;
    return new Promise((resolve,reject)=>{
      const check=async()=>{
        if(readSignal?.aborted)throw cancelled();
        await guard();
        if(readSignal?.aborted)throw cancelled();
      };
      const job={operation,payload,guard:readSignal?check:guard,priority,signal:readSignal,resolve,reject,attempt:0,bodyReady:false,
        timeoutMs:reading?Math.min(timeoutMs??timeoutLimit,timeoutLimit):timeoutLimit,
        maxRetries:reading?Math.min(maxRetries??retryLimit,retryLimit):retryLimit};
      job.abort=()=>{
        const queue=queues[priority],index=queue.indexOf(job);
        if(index>=0)queue.splice(index,1);
        settle(job,false,cancelled());
      };
      if(readSignal?.aborted){job.abort();return;}
      readSignal?.addEventListener('abort',job.abort,{once:true});
      enqueue(job);
    });
  }};
}
