import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {win32} from 'node:path';

const runFile=promisify(execFile);
const WINDOWS_PROXY_SCRIPT=`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$podProxy = Get-ItemProperty -LiteralPath 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings' -ErrorAction Stop
[ordered]@{
  ProxyEnable = [bool]$podProxy.ProxyEnable
  ProxyServer = [string]$podProxy.ProxyServer
  ProxyOverride = [string]$podProxy.ProxyOverride
} | ConvertTo-Json -Compress
`;

async function readSystemWindowsProxy(env){
  const executable=win32.join(env.SystemRoot||env.SYSTEMROOT||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
  const {stdout}=await runFile(executable,['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(WINDOWS_PROXY_SCRIPT,'utf16le').toString('base64')],{windowsHide:true,timeout:2500,maxBuffer:16384,encoding:'utf8'});
  // Registry output stays inside this resolver; it is never sent to a browser or log.
  return JSON.parse(stdout.replace(/^\uFEFF/,'').trim());
}

function staticProxy(value){
  if(typeof value!=='string'||!value||value.length>2048||/[\s\\]/.test(value))return undefined;
  const explicitScheme=/^[a-z][a-z\d+.-]*:\/\//i.test(value);
  if(!explicitScheme&&!/^(?:\[[\da-f:.]+\]|[^:/?#@]+):\d{1,5}$/i.test(value))return undefined;
  try{
    const url=new URL(explicitScheme?value:'http://'+value);
    if(!['http:','https:'].includes(url.protocol)||!url.hostname||url.username||url.password||url.search||url.hash||url.pathname!=='/'||(url.port&&Number(url.port)<1))return undefined;
    return url.protocol+'//'+url.host;
  }catch{return undefined;}
}

function windowsProxyEntries(value){
  if(typeof value!=='string'||value.length>4096)return {};
  const setting=value.trim();
  if(!setting.includes('=')){const shared=staticProxy(setting);return shared?{HTTP_PROXY:shared,HTTPS_PROXY:shared}:{};}
  const entries={};
  for(const entry of setting.split(';')){
    const match=entry.trim().match(/^(http|https)\s*=\s*(.+)$/i);if(!match)continue;
    const proxy=staticProxy(match[2].trim());if(proxy)entries[match[1].toUpperCase()+'_PROXY']=proxy;
  }
  return entries;
}

function windowsBypass(value){
  const items=['localhost','127.0.0.1','::1'];
  if(typeof value!=='string'||value.length>16384)return items.join(',');
  for(const raw of value.split(';').slice(0,128)){
    let entry=raw.trim();
    if(!entry||entry.toLowerCase()==='<local>')continue;
    if(entry==='*')return '*';
    if(entry.startsWith('*.'))entry=entry.slice(1);
    // Only exact hosts/IPs and domain suffixes have portable NO_PROXY semantics.
    if(!/^(?:\.?[a-z\d](?:[a-z\d.-]*[a-z\d])?(?::\d{1,5})?|\[[\da-f:.]+\](?::\d{1,5})?|::1)$/i.test(entry))continue;
    if(!items.includes(entry))items.push(entry);
  }
  return items.join(',');
}

/** Child-process-only proxy inheritance; never edits Windows or the parent environment. */
export async function resolveCodexNetworkEnvironment({env=process.env,platform=process.platform,readWindowsProxy}={}){
  const resolved={...env};
  const explicit=Object.entries(env).some(([key,value])=>/^(?:https?|all)_proxy$/i.test(key)&&typeof value==='string'&&value.trim());
  if(platform!=='win32'||explicit)return resolved;
  try{
    const settings=await (readWindowsProxy?readWindowsProxy():readSystemWindowsProxy(env));
    if(!settings||![true,1,'1'].includes(settings.ProxyEnable))return resolved;
    const proxies=windowsProxyEntries(settings.ProxyServer);
    if(!Object.keys(proxies).length)return resolved;
    Object.assign(resolved,proxies);
    if(!Object.keys(env).some(key=>/^no_proxy$/i.test(key)))resolved.NO_PROXY=windowsBypass(settings.ProxyOverride);
  }catch{
    // PAC-only, absent registry data, or failed inspection retains direct/default routing.
  }
  return resolved;
}
