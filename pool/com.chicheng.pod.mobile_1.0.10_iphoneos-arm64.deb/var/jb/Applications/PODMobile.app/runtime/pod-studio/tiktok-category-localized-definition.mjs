/** Fixed public failures. Neither browser errors nor request metadata escape. */
export const LOCALIZED_CATEGORY_DEFINITION_REASONS = Object.freeze([
  'localized_scope_unverified', 'localized_request_unverified',
  'localized_response_unavailable', 'localized_response_limit',
  'localized_response_invalid', 'localized_response_unverified',
  'localized_values_limit', 'localized_timeout', 'localized_read_failed'
]);

/** Copy only the existing category projection contract from an untrusted CDP value.
 * A bad value invalidates its own property; bad property identity invalidates the
 * response. This function has no browser or transport dependencies.
 */
export function normalizeLocalizedCategoryDefinitionResult(value, categoryId) {
  const failed = reason => ({ accepted: false, complete: false, reason });
  const reasons = ['localized_scope_unverified', 'localized_request_unverified', 'localized_response_unavailable', 'localized_response_limit', 'localized_response_invalid', 'localized_response_unverified', 'localized_values_limit', 'localized_timeout', 'localized_read_failed'];
  const hash = 'd796912ebc77a546509f75d5f4e8236a229bb0436c88a359503ab109eac027ef';
  const plain = item => item !== null && typeof item === 'object' && !Array.isArray(item);
  const id = item => typeof item === 'string' && /^[A-Za-z0-9_-]{1,160}$/u.test(item);
  // Match the pure catalogue projector without relying on atob/Buffer or an
  // external closure when this normalizer is serialized into an isolated VM.
  const basicCredential = value => {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    for (const match of value.matchAll(/\bBasic\s+([^\s,;]+)/giu)) {
      const encoded = match[1]; if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded)) continue;
      const bare = encoded.replace(/=+$/u, ''), remainder = bare.length % 4, padding = encoded.length - bare.length;
      if (remainder === 1 || padding && (encoded.length % 4 !== 0 || padding !== (4 - remainder) % 4)) continue;
      let buffer = 0, bits = 0, colon = false;
      for (const character of bare) {
        buffer = buffer * 64 + alphabet.indexOf(character); bits += 6;
        if (bits >= 8) { bits -= 8; if (Math.floor(buffer / 2 ** bits) === 58) colon = true; buffer %= 2 ** bits; }
      }
      if (buffer === 0 && colon) return true;
    }
    return false;
  };
  const text = (item, max) => typeof item === 'string' && item.trim().length > 0 && item.length <= max && !/[\u0000-\u001f\u007f]|(?:https?|wss?):\/\/|\bBearer\s+\S+|\b(?:password|passwd|cookie|authorization|api[_ -]?key|access[_ -]?token|refresh[_ -]?token|token|secret)\s*[:=]|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/iu.test(item) && !basicCredential(item);
  try {
    if (!id(categoryId) || !plain(value)) return failed('localized_response_unverified');
    if (value.accepted !== true) return failed(reasons.includes(value.reason) ? value.reason : 'localized_response_unverified');
    if (value.complete !== false || value.source !== 'controlled-seller-category-definition' || value.locale !== 'en-US' || value.language !== 'en-US'
      || value.categoryId !== categoryId || value.endpointPathHash !== hash || value.responseComplete !== true || value.propertyRowsComplete !== true
      || value.truncated === true || !Array.isArray(value.properties) || !value.properties.length || value.properties.length > 200) return failed('localized_response_unverified');
    const properties = [], propertyIds = new Set(); let total = 0;
    for (const row of value.properties) {
      if (!plain(row) || !id(row.apiId) || !text(row.displayLabel, 255) || propertyIds.has(row.apiId) || typeof row.valid !== 'boolean'
        || !Array.isArray(row.values) || row.values.length > 10000 || row.truncated === true) return failed('localized_response_unverified');
      propertyIds.add(row.apiId);
      const observed = row.observedValueCount;
      if (observed !== undefined && (!Number.isSafeInteger(observed) || observed < row.values.length || observed > 10000)) return failed('localized_response_unverified');
      if ((total += observed ?? row.values.length) > 20000) return failed('localized_values_limit');
      const property = { apiId: row.apiId, displayLabel: row.displayLabel, flags: {}, classification: {}, values: [], valid: row.valid };
      if (row.valuesState !== undefined) { if (!['reported-array','not-reported','invalid'].includes(row.valuesState)) return failed('localized_response_unverified'); property.valuesState=row.valuesState; if(row.valuesState==='invalid'||row.valuesState==='not-reported'&&row.values.length) property.valid=false; }
      if (plain(row.flags)) for (const key of ['is_enum', 'is_input', 'is_necessary', 'is_multi_choice', 'is_number']) if (typeof row.flags[key] === 'boolean') property.flags[key] = row.flags[key];
      if (plain(row.classification)) for (const key of ['key_property', 'binding_property', 'shopping_guide_property', 'legal_property']) if (typeof row.classification[key] === 'boolean') property.classification[key] = row.classification[key];
      if (row.cascadePresent === true) property.cascadePresent = true;
      if (typeof row.subCascadeProperty === 'boolean') property.subCascadeProperty = row.subCascadeProperty;
      if (observed !== undefined) property.observedValueCount = observed;
      const ids = new Set();
      for (const option of row.values) {
        if (!plain(option) || !id(option.apiId) || !text(option.displayLabel, 1024) || ids.has(option.apiId)) { property.valid = false; continue; }
        ids.add(option.apiId); property.values.push({ apiId: option.apiId, displayLabel: option.displayLabel });
      }
      if (observed !== undefined && observed !== property.values.length) property.valid = false;
      properties.push(property);
    }
    return { accepted: true, complete: false, source: 'controlled-seller-category-definition', locale: 'en-US', language: 'en-US', categoryId,
      endpointPathHash: hash, responseComplete: true, propertyRowsComplete: true, properties };
  } catch { return failed('localized_response_unverified'); }
}

/** One explicit read on the already owned official create page. Standalone for
 * Runtime.evaluate serialization; the caller supplies the trusted pure projector.
 * The original URL remains private. No language setting or HTML is changed.
 */
export async function readLocalizedCategoryDefinitionInPage(requestUrl, categoryId, securityReader, projector) {
  const origin = 'https://seller.us.tiktokshopglobalselling.com';
  const hash = 'd796912ebc77a546509f75d5f4e8236a229bb0436c88a359503ab109eac027ef';
  const maximum = 2 * 1024 * 1024;
  // Internal diagnostics contain only fixed stages and bounded primitives. Each
  // returned snapshot is independent of any late continuation after a timeout.
  const diagnostics = { stage: 'preflight', pageBeforeVerified: null, securityBeforeVerified: null, requestVerified: null,
    fetchStarted: null, responseReceived: null, httpOk: null, streamComplete: null, jsonParsed: null, codeIsZero: null,
    dataObject: null, productPropertiesArray: null, projectorAccepted: null, projectorRowsComplete: null,
    pageAfterVerified: null, securityAfterVerified: null, bodyBytes: null, chunkCount: null, propertyRowCount: null,
    projectedPropertyCount: null, invalidPropertyCount: null };
  const failed = reason => ({ accepted: false, complete: false, reason, localizedDiagnostics: { ...diagnostics } });
  const id = item => typeof item === 'string' && /^[A-Za-z0-9_-]{1,160}$/u.test(item);
  const pageMatches = () => {
    try { const page = new URL(location.href); return page.origin === origin && page.pathname === '/product/create' && !page.username && !page.password && !page.hash
      && page.searchParams.getAll('shop_region').length === 1 && page.searchParams.get('shop_region') === 'US'; } catch { return false; }
  };
  const secure = () => { try { return typeof securityReader === 'function' && securityReader()?.detected === false; } catch { return false; } };
  let timer, reader, controller, stopped = false, timedOut = false;
  const cancelReader = () => { const current = reader; reader = undefined; try { if (current) Promise.resolve(current.cancel()).catch(() => {}); } catch {} };
  try {
    if (!id(categoryId) || typeof projector !== 'function') return failed('localized_scope_unverified');
    diagnostics.pageBeforeVerified = pageMatches();
    if (!diagnostics.pageBeforeVerified) return failed('localized_scope_unverified');
    diagnostics.securityBeforeVerified = secure();
    if (!diagnostics.securityBeforeVerified) return failed('localized_scope_unverified');
    diagnostics.stage = 'request'; diagnostics.requestVerified = false;
    let url;
    try {
      if (typeof requestUrl !== 'string' || requestUrl.length > 16384 || /[\u0000-\u0020\u007f]/u.test(requestUrl)) return failed('localized_request_unverified');
      url = new URL(requestUrl);
      if (url.origin !== origin || url.username || url.password || url.hash || url.searchParams.getAll('category_id').length !== 1 || url.searchParams.get('category_id') !== categoryId
        || url.searchParams.getAll('locale').length !== 1 || url.searchParams.get('locale') !== 'en-US'
        || url.searchParams.getAll('language').length !== 1 || url.searchParams.get('language') !== 'en-US') return failed('localized_request_unverified');
    } catch { return failed('localized_request_unverified'); }
    controller = new AbortController();
    const deadline = new Promise(resolve => { timer = setTimeout(() => {
      timedOut = true; stopped = true;
      try { controller.abort(); } catch {}
      cancelReader(); resolve(failed('localized_timeout'));
    }, 10000); });
    const attempt = (async () => {
      try {
        diagnostics.stage = 'digest';
        const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(url.pathname));
        if (stopped) return failed('localized_timeout');
        if ([...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('') !== hash) return failed('localized_request_unverified');
        diagnostics.requestVerified = true;
        diagnostics.pageBeforeVerified = pageMatches();
        if (!diagnostics.pageBeforeVerified) return failed('localized_scope_unverified');
        diagnostics.securityBeforeVerified = secure();
        if (!diagnostics.securityBeforeVerified) return failed('localized_scope_unverified');
        diagnostics.stage = 'fetch'; diagnostics.fetchStarted = true;
        const response = await fetch(requestUrl, { method: 'GET', mode: 'same-origin', credentials: 'same-origin', redirect: 'error', signal: controller.signal });
        if (stopped) return failed('localized_timeout');
        diagnostics.stage = 'response'; diagnostics.responseReceived = !!response;
        diagnostics.httpOk = !!response && Number.isInteger(response.status) && response.status >= 200 && response.status < 300;
        if (!response || !Number.isInteger(response.status) || response.status < 200 || response.status >= 300 || response.redirected === true
          || ['opaque', 'opaqueredirect'].includes(response.type) || (response.url !== undefined && response.url !== url.href)
          || !response.body || typeof response.body.getReader !== 'function') return failed('localized_response_unavailable');
        reader = response.body.getReader();
        diagnostics.stage = 'stream'; diagnostics.bodyBytes = 0; diagnostics.chunkCount = 0; diagnostics.streamComplete = false;
        const chunks = []; let length = 0;
        for (;;) {
          const part = await reader.read();
          if (stopped) return failed('localized_timeout');
          if (!part || typeof part.done !== 'boolean') return failed('localized_response_invalid');
          if (part.done) break;
          diagnostics.chunkCount = Math.min(diagnostics.chunkCount + 1, 4097);
          if (part.value instanceof Uint8Array) diagnostics.bodyBytes = Math.min(length + part.value.byteLength, maximum + 1);
          if (!(part.value instanceof Uint8Array) || (length += part.value.byteLength) > maximum || chunks.length >= 4096) return failed('localized_response_limit');
          // Own each chunk even when a stream producer reuses its backing buffer.
          chunks.push(part.value.slice());
        }
        diagnostics.streamComplete = true;
        const bytes = new Uint8Array(length); let offset = 0;
        for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
        let responseData;
        diagnostics.stage = 'json'; diagnostics.jsonParsed = false;
        try { responseData = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { return failed('localized_response_invalid'); }
        diagnostics.jsonParsed = true;
        diagnostics.codeIsZero = responseData !== null && typeof responseData === 'object' && !Array.isArray(responseData) && responseData.code === 0;
        diagnostics.dataObject = responseData?.data !== null && typeof responseData?.data === 'object' && !Array.isArray(responseData.data);
        diagnostics.productPropertiesArray = diagnostics.dataObject && Array.isArray(responseData.data.product_properties);
        if (diagnostics.productPropertiesArray) diagnostics.propertyRowCount = Math.min(responseData.data.product_properties.length, 201);
        diagnostics.pageAfterVerified = pageMatches();
        if (!diagnostics.pageAfterVerified) return failed('localized_scope_unverified');
        diagnostics.securityAfterVerified = secure();
        if (!diagnostics.securityAfterVerified) return failed('localized_scope_unverified');
        diagnostics.stage = 'projection';
        const projection = projector({ categoryId, response: responseData });
        diagnostics.projectorAccepted = projection?.accepted === true;
        diagnostics.projectorRowsComplete = typeof projection?.propertyRowsComplete === 'boolean' ? projection.propertyRowsComplete : null;
        if (Array.isArray(projection?.properties)) {
          diagnostics.projectedPropertyCount = Math.min(projection.properties.length, 201);
          diagnostics.invalidPropertyCount = projection.properties.slice(0, 201).filter(property => property?.valid === false).length;
        }
        if (!projection || projection.accepted !== true) return failed(projection?.reason === 'category_values_limit' ? 'localized_values_limit' : 'localized_response_unverified');
        if (projection.responseComplete !== true || projection.propertyRowsComplete !== true || projection.truncated === true || projection.categoryId !== categoryId
          || projection.endpointPathHash !== hash || !Array.isArray(projection.properties) || !projection.properties.length || projection.properties.length > 200) return failed('localized_response_unverified');
        // projector is the fixed, trusted standalone whitelist projector. Copy
        // only its public root contract; the host independently normalizes rows.
        diagnostics.stage = 'complete';
        return { accepted: true, complete: false, source: 'controlled-seller-category-definition', locale: 'en-US', language: 'en-US', categoryId,
          endpointPathHash: hash, responseComplete: true, propertyRowsComplete: true, properties: projection.properties, localizedDiagnostics: { ...diagnostics } };
      } catch { return failed(timedOut ? 'localized_timeout' : 'localized_read_failed'); }
    })();
    return await Promise.race([attempt, deadline]);
  } catch { return failed(timedOut ? 'localized_timeout' : 'localized_read_failed'); }
  finally {
    stopped = true; if (timer !== undefined) clearTimeout(timer); cancelReader();
    // Also stop an unconsumed response after an early HTTP/scope failure.
    try { controller?.abort(); } catch {}
  }
}
