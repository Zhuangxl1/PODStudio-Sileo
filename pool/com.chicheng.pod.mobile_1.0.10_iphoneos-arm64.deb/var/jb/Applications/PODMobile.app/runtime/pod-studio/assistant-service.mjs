import {createListingSuggestionService} from './listing-suggestion-service.mjs';
import {access,appendFile,mkdir,rename,stat} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {timingSafeEqual} from 'node:crypto';
import {once} from 'node:events';
import {createCodexBridge} from './codex-bridge.mjs';
import {createCodexProviderSettings,CODEX_PROVIDER_MODES} from './codex-provider-settings.mjs';
import {createCodexConcurrencySettings} from './codex-concurrency-settings.mjs';
import {DEFAULT_CODEX_MAX_CONCURRENT_TASKS} from './dist/codex-concurrency-contract.js';
import {canonicalProjectRoot,loadHandoverKnowledge,buildHandoverInstructions,lookupHandoverKnowledge,selectHandoverImageInputs} from './handover-knowledge.mjs';
import {publicDesignRules} from './design-rules.mjs';
import {CODEX_BACKGROUND_LIMIT} from './dist/codex-designer-contract.js';

const root=await canonicalProjectRoot(import.meta.url);
const INTERNAL_ORIGIN='http://127.0.0.1:4173',PREFIX='/__pod/codex';
const REQUEST_TIMEOUT_MS=65000,TURN_RECEIPT_TIMEOUT_MS=125000,EVENT_POLL_TIMEOUT_MS=10000;
// Node fetch follows the browser forbidden-port list even on loopback. Windows
// may allocate one of these to listen(0), so do not advertise an unusable bridge.
const FORBIDDEN_PORTS=new Set([1,7,9,11,13,15,17,19,20,21,22,23,25,37,42,43,53,69,77,79,87,95,101,102,103,104,109,110,111,113,115,117,119,123,135,137,139,143,161,179,389,427,465,512,513,514,515,526,530,531,532,540,548,554,556,563,587,601,636,989,990,993,995,1719,1720,1723,2049,3659,4045,5060,5061,6000,6566,6665,6666,6667,6668,6669,6697,10080]);
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
const json=(res,status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));};

export async function loadAssistantKnowledge(options={}){
  const knowledge=await loadHandoverKnowledge(options);
  return {
    summary:knowledge.summary,
    ...(knowledge.designRules?{fissionRules:publicDesignRules(knowledge.designRules)}:{}),
    instructions:buildHandoverInstructions(knowledge),
    lookup:args=>lookupHandoverKnowledge(knowledge,args),
    reference:async assetId=>{const images=await selectHandoverImageInputs(knowledge,{ids:[assetId],includeData:true,maxImages:1});if(images.length!==1)throw new Error('参考资料无效。');return images[0];}
  };
}

/** Owned loopback bridge shared through the LAN gateway; credentials stay here. */
export function createAssistantService({codexPath,createBridge=createCodexBridge,loadKnowledge=loadAssistantKnowledge,fetchImpl=fetch,onStatus=()=>{},checkAccess=access,learningRoot,providerRoot,providerSettings=providerRoot?createCodexProviderSettings({root:providerRoot}):undefined,concurrencySettings=createCodexConcurrencySettings({root:providerRoot||(learningRoot?resolve(learningRoot,'..'):undefined)}),diagnosticsRoot=learningRoot?resolve(learningRoot,'..','diagnostics'):undefined}={}){
  let bridge,base,knowledge,starting,closed=false,status={status:'starting',message:'正在准备 Codex 助手…',available:false};
  let maxConcurrentTasks=DEFAULT_CODEX_MAX_CONCURRENT_TASKS;
  const backgroundTasks=new Set();
  let diagnosticWrites=Promise.resolve(),diagnosticPending=0;
  const recordDiagnostic=fields=>{
    if(!diagnosticsRoot||diagnosticPending>=32)return;
    // Only structural connection metadata; never prompts, images, native
    // error text, credentials, account identifiers, or thread identifiers.
    const safe={time:new Date().toISOString()};
    for(const key of ['source','method','reason'])if(typeof fields[key]==='string'&&/^[a-zA-Z0-9_./-]{1,80}$/.test(fields[key]))safe[key]=fields[key];
    for(const key of ['status','elapsedMs','code'])if(Number.isSafeInteger(fields[key]))safe[key]=fields[key];
    if(typeof fields.willRetry==='boolean')safe.willRetry=fields.willRetry;
    if(safe.source==='image-generation'){
      // These values describe the shape of the native result, never its contents.
      if(['completed','succeeded','in_progress','generating','pending','failed','blocked','canceled','missing','other'].includes(fields.nativeImageStatus))safe.nativeImageStatus=fields.nativeImageStatus;
      if(['absent','empty','data-url','base64','file-id','other'].includes(fields.resultKind))safe.resultKind=fields.resultKind;
      if(Number.isSafeInteger(fields.resultLength)&&fields.resultLength>=0&&fields.resultLength<=36*1024*1024)safe.resultLength=fields.resultLength;
      if(typeof fields.savedPathProvided==='boolean')safe.savedPathProvided=fields.savedPathProvided;
      if(!['blocked','moderation','quota','timeout','capability','busy','generation_failed','generation_canceled','missing_result','missing_file','invalid_file','unsafe_path','invalid_encoding',
        'unreadable_file','result_metadata_limit','candidate_canceled','candidate_failed_status','candidate_format'].includes(safe.reason))delete safe.reason;
    }
    diagnosticPending++;
    diagnosticWrites=diagnosticWrites.then(async()=>{
      await mkdir(diagnosticsRoot,{recursive:true});const path=join(diagnosticsRoot,'codex-connection.jsonl');
      if((await stat(path).catch(()=>null))?.size>512*1024)await rename(path,path+'.previous');
      await appendFile(path,JSON.stringify(safe)+'\n',{mode:0o600});
    }).catch(()=>{}).finally(()=>{diagnosticPending--;});
  };
  const sessions=new Map(),connecting=new Set();
  const onSessionClosed=key=>{
    for(const [slot,record] of sessions)if(record.key===key){sessions.delete(slot);break;}
  };
  const listingSuggestions=createListingSuggestionService({findExecutable});
  const publish=value=>{status={...status,...value};try{onStatus({type:'assistant.status',...status});}catch{}return {...status};};
  async function findExecutable(){
    const candidates=[codexPath,process.env.POD_CODEX_PATH,resolve(root,'runtime/codex.exe'),join(process.env.USERPROFILE||'','.codex','plugins','.plugin-appserver','codex.exe')].filter(Boolean);
    for(const candidate of candidates)try{await checkAccess(candidate);return candidate;}catch{}
    throw new Error('未找到 Codex 运行程序，请安装或打开 Codex 后点击“重试助手”。');
  }
  async function start(){
    if(closed)return {...status};if(bridge)return {...status};if(starting)return starting;
    starting=(async()=>{
      publish({status:'starting',available:false,message:'正在载入 GPT 交接知识并准备 Codex 助手…'});
      try{
        maxConcurrentTasks=(await concurrencySettings.get()).maxConcurrentTasks;
        let executable;
        try{executable=await findExecutable();}
        catch(error){if(!providerSettings||(await providerSettings.getProvider()).mode==='local')throw error;}
        knowledge=await loadKnowledge();
        let server;
        for(let attempt=0;attempt<100;attempt++){
          server=createBridge({codexPath:executable,available:Boolean(executable),knowledge,onSessionClosed,onDiagnostic:recordDiagnostic,maxConcurrentTasks,...(learningRoot?{learningRoot}:{})});
          try{server.listen(0,'127.0.0.1');await once(server,'listening');}catch(error){server.closeSessions?.();server.close();server=undefined;if(['EADDRINUSE','EACCES'].includes(error.code)&&attempt<99)continue;throw error;}
          if(!FORBIDDEN_PORTS.has(server.address().port))break;
          await new Promise(done=>server.close(done));server=undefined;
        }
        if(!server)throw new Error('无法分配助手端口。');
        if(closed){server.closeSessions?.();server.close();return {...status};}
        bridge=server;base='http://127.0.0.1:'+server.address().port;
        bridge.setMaxConcurrentTasks?.(maxConcurrentTasks);
        return publish({status:'ready',available:true,message:'Codex 助手已就绪，局域网共用主机账号；GPT 交接知识已载入。'});
      }catch(error){return publish({status:'unavailable',available:false,message:/未找到 Codex/.test(error.message||'')?error.message:'Codex 助手准备失败，请检查随包交接资料和 Codex 运行程序后重试。'});}
      finally{starting=undefined;}
    })();return starting;
  }
  async function body(req,limit=8*1024*1024){const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>limit){const error=new Error('助手请求内容过大。');error.status=413;throw error;}chunks.push(chunk);}return Buffer.concat(chunks);}
  async function disconnect(record){if(!base||!record)return;try{await fetchImpl(base+PREFIX+'/disconnect',{method:'POST',headers:{Origin:INTERNAL_ORIGIN,Authorization:'Bearer '+record.key,'Content-Type':'application/json'},body:'{}',redirect:'error',signal:AbortSignal.timeout(3000)});}catch{}}
  async function handle(req,res,{csrf,isHost=false,loadMiaoshouTitle}={}){
    const url=new URL(req.url,'http://127.0.0.1'),route=req.method+' '+url.pathname;
    const accessMode={hostOnly:false,accountMode:'host-shared',canManageAccount:isHost===true};
    if(route==='GET '+PREFIX+'/status')return json(res,200,{success:true,data:{...status,app:'pod-codex-bridge',managed:true,...accessMode,...(knowledge?{knowledge:knowledge.summary}:{})}});
    if(url.pathname===PREFIX+'/concurrency-settings'){
      if(!csrf)return json(res,401,{success:false,message:'设计器连接已失效，请刷新网页。'});
      try{
        if(req.method==='GET')return json(res,200,{success:true,data:{...await concurrencySettings.get(),canManageConcurrency:isHost===true}});
        if(req.method!=='POST')return json(res,405,{success:false,message:'设置操作不支持。'});
        if(!isHost||req.headers.origin!=='http://'+req.headers.host&&req.headers.origin!=='https://'+req.headers.host||!equal(req.headers['x-pod-session'],csrf))return json(res,403,{success:false,message:'请在启动电脑的设置中管理并发会话上限。'});
        let input;try{input=JSON.parse((await body(req,1024)).toString('utf8'));}catch{return json(res,400,{success:false,message:'并发会话设置格式无效。'});}
        const saved=await concurrencySettings.save(input);
        maxConcurrentTasks=saved.maxConcurrentTasks;
        bridge?.setMaxConcurrentTasks?.(maxConcurrentTasks);
        return json(res,200,{success:true,data:{...saved,canManageConcurrency:true}});
      }catch(error){return json(res,error.status===400?400:503,{success:false,message:error.code==='CODEX_CONCURRENCY_SETTINGS_INVALID'?error.message:'并发会话设置读取或保存失败，请检查主机数据目录。'});}
    }
    if(url.pathname===PREFIX+'/provider-settings'){
      if(!csrf)return json(res,401,{success:false,message:'设计器连接已失效，请刷新网页。'});
      if(!providerSettings)return json(res,503,{success:false,message:'服务设置尚未由主机启动程序准备。'});
      try{
        if(req.method==='GET')return json(res,200,{success:true,data:{...await providerSettings.publicStatus(),canManageProvider:isHost===true}});
        if(req.method!=='POST')return json(res,405,{success:false,message:'设置操作不支持。'});
        if(!isHost||req.headers.origin!=='http://'+req.headers.host&&req.headers.origin!=='https://'+req.headers.host||!equal(req.headers['x-pod-session'],csrf))return json(res,403,{success:false,message:'请在启动电脑的设置中管理 API 服务。'});
        let input;try{input=JSON.parse((await body(req,16384)).toString('utf8'));}catch{return json(res,400,{success:false,message:'服务配置格式无效。'});}
        const saved=await providerSettings.save(input);
        if(!bridge)void start();
        return json(res,200,{success:true,data:{...saved,canManageProvider:true}});
      }catch(error){return json(res,error.status===400?400:503,{success:false,message:error.code==='CODEX_PROVIDER_SETTINGS_INVALID'?error.message:'服务配置读取或保存失败，请检查主机数据目录。'});}
    }
    if(url.pathname.startsWith(PREFIX+'/listing-suggestions'))return listingSuggestions.handle(req,res,{csrf,loadMiaoshouTitle});
    if(!bridge||!base)return json(res,503,{success:false,message:status.message});
    if(!csrf)return json(res,401,{success:false,message:'设计器连接已失效，请刷新网页。'});
    if(url.pathname.startsWith(PREFIX+'/learning')&&req.headers.origin!==undefined){
      let caller;try{caller=new URL(req.headers.origin);}catch{}
      if(!caller||!['http:','https:'].includes(caller.protocol)||caller.origin!==req.headers.origin||caller.host!==req.headers.host)return json(res,403,{success:false,message:'学习请求来源不允许。'});
    }
    const allowed=new Set(['POST '+PREFIX+'/connect','POST '+PREFIX+'/rpc','POST '+PREFIX+'/respond','POST '+PREFIX+'/disconnect','GET '+PREFIX+'/events','POST '+PREFIX+'/context','POST '+PREFIX+'/media','POST '+PREFIX+'/results/adopt','POST '+PREFIX+'/extractions/adopt','POST '+PREFIX+'/extractions/admit','POST '+PREFIX+'/extractions/recovery-preview','POST '+PREFIX+'/extractions/recover','GET '+PREFIX+'/fission-rules','GET '+PREFIX+'/learning','POST '+PREFIX+'/learning/begin','POST '+PREFIX+'/learning/outcome','POST '+PREFIX+'/learning/feedback']);
    const mediaRead=req.method==='GET'&&/^\/__pod\/codex\/media\/media-[a-f0-9]{32}$/.test(url.pathname);
    if(!allowed.has(route)&&!mediaRead)return json(res,404,{success:false,message:'助手接口不存在。'});
    const isConnect=route==='POST '+PREFIX+'/connect';
    const requestStarted=Date.now(),isEvents=route==='GET '+PREFIX+'/events';
    let connectingKey;
    const controller=new AbortController();res.once('close',()=>{if(!res.writableEnded)controller.abort();});
    try{
      if(route==='POST '+PREFIX+'/connect'){
        const incoming=await body(req,256*1024);let input;try{input=JSON.parse(incoming.toString('utf8')||'{}');}catch{return json(res,400,{success:false,message:'助手连接内容无效。'});}if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['sessionSlot','taskSlot','provider','providerRevision'].includes(key))||input.provider!==undefined&&!CODEX_PROVIDER_MODES.includes(input.provider)||input.providerRevision!==undefined&&(typeof input.providerRevision!=='string'||input.providerRevision.length>64))return json(res,400,{success:false,message:'助手连接参数不允许。'});
        const sessionSlot=input.sessionSlot??1;if(!Number.isInteger(sessionSlot)||sessionSlot<1||sessionSlot>5)return json(res,400,{success:false,message:'助手最多支持 5 个会话，请选择 1 至 5。'});
        const taskSlot=input.taskSlot??0;if(!Number.isInteger(taskSlot)||taskSlot<0||taskSlot>CODEX_BACKGROUND_LIMIT)return json(res,400,{success:false,message:'后台任务编号无效。'});
        const slotKey=csrf+':'+sessionSlot+':'+taskSlot;
        if(connecting.has(slotKey))return json(res,409,{success:false,message:'此会话正在连接助手，请等待连接完成。'});
        if(!sessions.has(slotKey)&&([...sessions.values()].filter(value=>value.csrf===csrf).length+[...connecting].filter(key=>key.startsWith(csrf+':')).length>=25||sessions.size+connecting.size>=50))return json(res,429,{success:false,message:'连接任务过多，请关闭多余助手后重试。'});
        connectingKey=slotKey;connecting.add(slotKey);
        let providerConfig;
        if(input.providerRevision!==undefined){
          providerConfig=[...sessions.values()].find(record=>record.csrf===csrf&&record.sessionSlot===sessionSlot&&record.providerConfig?.mode===input.provider&&record.providerConfig?.revision===input.providerRevision)?.providerConfig;
          if(!providerConfig)return json(res,409,{success:false,message:'原会话服务配置已结束，请新建会话使用当前设置。'});
        }else{
          providerConfig=providerSettings?await providerSettings.getProvider():Object.freeze({mode:'local',revision:'default'});
          if(input.provider!==undefined&&input.provider!==providerConfig.mode)return json(res,409,{success:false,message:'服务设置已变化，请新建会话。'});
        }
        if(providerConfig.mode!=='local'&&!providerConfig.apiKey)return json(res,400,{success:false,message:'请先在主机助手设置中填写所选服务的 API Key。'});
        const existing=sessions.get(slotKey);if(existing){sessions.delete(slotKey);await disconnect(existing);}
        // The bridge initializes the runtime, then reads its configuration and capabilities.
        const response=await fetchImpl(base+PREFIX+'/connect',{method:'POST',headers:{Origin:INTERNAL_ORIGIN,'X-POD-Launch':bridge.issueLaunch(providerConfig),'Content-Type':'application/json'},body:JSON.stringify({sessionSlot,taskSlot}),redirect:'error',signal:AbortSignal.any([controller.signal,AbortSignal.timeout(130000)])});
        const result=await response.json();if(!response.ok||result.success!==true||!/^[a-f0-9]{64}$/.test(result.data?.session||''))return json(res,response.ok?502:response.status,{success:false,message:typeof result.message==='string'?result.message:'Codex 助手连接失败，请重试。'});
        sessions.set(slotKey,{key:result.data.session,csrf,sessionSlot,taskSlot,providerConfig});return json(res,200,{success:true,data:{...result.data,provider:providerConfig.mode,providerRevision:providerConfig.revision,available:true,sessionSlot,taskSlot,maxConversationSlots:5,maxTaskSlots:CODEX_BACKGROUND_LIMIT,maxConcurrentTasks,...accessMode,...(providerConfig.mode!=='local'?{canManageAccount:false}:{}),knowledge:knowledge.summary}});
      }
      const record=[...sessions.values()].find(value=>value.csrf===csrf&&equal(req.headers.authorization,'Bearer '+value.key));if(!record)return json(res,401,{success:false,message:'助手连接已失效，请重新连接。'});
      const payload=req.method==='POST'?await body(req,route==='POST '+PREFIX+'/media'?Math.ceil(25*1024*1024/3)*4+8192:8*1024*1024):undefined;
      let timeout=req.method==='POST'?REQUEST_TIMEOUT_MS:null;
      if(route==='GET '+PREFIX+'/events'&&url.searchParams.get('poll')==='1')timeout=EVENT_POLL_TIMEOUT_MS;
      if(route==='POST '+PREFIX+'/rpc'){
        let input;try{input=JSON.parse(payload.toString('utf8'));}catch{return json(res,400,{success:false,message:'助手请求不是有效的 JSON。'});}
        const managesAccount=['account/login/start','account/login/cancel'].includes(input?.method)||(input?.method==='account/read'&&input?.params?.refreshToken===true);
        if(isHost!==true&&managesAccount)return json(res,403,{success:false,message:'主机 Codex 账号由启动电脑管理，请在主机完成登录或切换账号。'});
        if(input?.method==='turn/start')timeout=TURN_RECEIPT_TIMEOUT_MS;
      }
      const signal=timeout===null?controller.signal:AbortSignal.any([controller.signal,AbortSignal.timeout(timeout)]);
      const response=await fetchImpl(base+url.pathname+url.search,{method:req.method,headers:{Origin:INTERNAL_ORIGIN,Authorization:'Bearer '+record.key,...(payload?{'Content-Type':'application/json'}:{})},...(payload?{body:payload}:{}),redirect:'error',signal});
      if(route==='GET '+PREFIX+'/events'&&response.ok){
        res.writeHead(200,{'Content-Type':'application/x-ndjson; charset=utf-8','Cache-Control':'no-store',...(response.headers.get('X-POD-Event-Mode')==='poll'?{'X-POD-Event-Mode':'poll',...(['0','1'].includes(response.headers.get('X-POD-Event-More'))?{'X-POD-Event-More':response.headers.get('X-POD-Event-More')}:{}),...(/^(?:0|[1-9]\d*)$/.test(response.headers.get('X-POD-Event-Cursor')||'')?{'X-POD-Event-Cursor':response.headers.get('X-POD-Event-Cursor')}:{})}:{})});res.flushHeaders();
        for await(const chunk of response.body){if(!res.write(chunk))await once(res,'drain',{signal:controller.signal});}return res.end();
      }
      if(mediaRead&&response.ok){
        const mime=String(response.headers.get('content-type')||'').split(';')[0].trim().toLowerCase(),length=response.headers.get('content-length');
        if(!['image/png','image/jpeg','image/webp'].includes(mime)||length!==null&&(!Number.isSafeInteger(Number(length))||Number(length)<1||Number(length)>25*1024*1024)){await response.body?.cancel();throw new Error('图片响应无效或过大。');}
        res.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',...(length!==null?{'Content-Length':length}:{})});
        let bytes=0;for await(const chunk of response.body){bytes+=chunk.length;if(bytes>25*1024*1024)throw new Error('图片响应过大。');if(!res.write(chunk))await once(res,'drain',{signal:controller.signal});}
        return res.end();
      }
      const text=await response.text();if(text.length>1024*1024)throw new Error('响应过大。');
      if(isEvents&&!response.ok)recordDiagnostic({source:'event-proxy',reason:'http_error',status:response.status,elapsedMs:Date.now()-requestStarted});
      if(route==='POST '+PREFIX+'/disconnect'){
        const slotKey=csrf+':'+record.sessionSlot+':'+record.taskSlot;
        if(sessions.get(slotKey)===record)sessions.delete(slotKey);
      }
      res.writeHead(response.status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});return res.end(text);
    }catch(error){
      if(res.destroyed)return;
      recordDiagnostic({source:isEvents?'event-proxy':'request-proxy',reason:error.name==='TimeoutError'?'timeout':error.name==='AbortError'?'aborted':'transport_error',elapsedMs:Date.now()-requestStarted});
      if(res.headersSent){if(!res.writableEnded)res.destroy();return;}
      if(error.status===413)return json(res,413,{success:false,message:'助手请求内容过大。'});
      if(error.name==='TimeoutError')return json(res,504,{success:false,message:isConnect?'连接主机 Codex 助手超时，请重试连接。':'主机 Codex 请求超时，请核对任务结果。'});
      return json(res,502,{success:false,message:isEvents?'助手结果通道暂时中断，正在恢复原任务。':'Codex 助手连接失败，请在启动窗口点击“重试助手”。'});
    }
    finally{if(connectingKey)connecting.delete(connectingKey);}
  }
  async function runBackgroundTask(task,{signal,bytes=0}={}){
    const controller=new AbortController(),abort=()=>controller.abort(signal?.reason);
    let finished;const record={controller,done:new Promise(resolve=>{finished=resolve;})};
    signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();backgroundTasks.add(record);
    try{
      controller.signal.throwIfAborted();await start();controller.signal.throwIfAborted();
      if(closed||!bridge?.runBackgroundTask)throw new Error('Codex 后台服务尚未就绪。');
      return await bridge.runBackgroundTask(async()=>{
        controller.signal.throwIfAborted();
        return task({codexPath:await findExecutable(),signal:controller.signal});
      },{signal:controller.signal,bytes});
    }finally{signal?.removeEventListener('abort',abort);backgroundTasks.delete(record);finished();}
  }
  async function close(){closed=true;const background=[...backgroundTasks];for(const task of background)task.controller.abort();listingSuggestions.close();sessions.clear();connecting.clear();const server=bridge;bridge=undefined;base=undefined;if(server){server.closeSessions?.();server.closeAllConnections?.();await new Promise(done=>server.close(done));}await Promise.all(background.map(task=>task.done));await diagnosticWrites;publish({status:'unavailable',available:false,message:'Codex 助手已停止。'});}
  return {start,handle,close,findExecutable,runBackgroundTask,status:()=>({...status,...(knowledge?{knowledge:knowledge.summary}:{})})};
}
