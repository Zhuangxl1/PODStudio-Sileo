import {createHash,randomUUID} from 'node:crypto';
import {mkdir,open,readFile,rename,unlink} from 'node:fs/promises';
import {isAbsolute,resolve} from 'node:path';
import {miaoshouId,singleShopPolicy} from './dist/miaoshou-policy.js';
import {randomMiaoshouPackage} from './dist/miaoshou-package-defaults.js';
import {compileMiaoshouFlatPatch} from './miaoshou-edit-fields.mjs';
import {miaoshouEditRevision} from './miaoshou-edit-context.mjs';
import {validateMiaoshouDetail} from './miaoshou-replacement.mjs';
import {serializeMiaoshou} from './miaoshou-client.mjs';

const fail=(code,message,status=400)=>Object.assign(new Error(message),{code,status});
const validRevision=value=>Number.isSafeInteger(value)&&value>=0;
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const chartUrl=value=>compileMiaoshouFlatPatch({selectedFields:['sizeChartUrl'],values:{sizeChartUrl:value},context:{sizeChartSupported:true}}).sizeChart;
const empty=()=>({version:1,revision:0,sizeChartUrl:null});
const chartState=info=>serializeMiaoshou([info.sizeChartType,info.sizeChart]);
const packageState=info=>serializeMiaoshou([
  info.weight,info.packageLength,info.packageWidth,info.packageHeight,
  Object.keys(info.skuMap||{}).sort().map(key=>[key,info.skuMap[key]?.weight])
]);

export function createMiaoshouClaimSizeCharts({root}={}){
  if(root!==undefined&&(typeof root!=='string'||!isAbsolute(root)))throw new TypeError('认领尺码表须使用主机绝对目录。');
  const memory=new Map(),queues=new Map();let closed=false;
  const selected=input=>{
    if(closed)throw fail('MIAOSHOU_CLAIM_CHART_CLOSED','认领尺码表服务已关闭。',503);
    if(!plain(input)||typeof input.accountScope!=='string'||!/^[a-f0-9]{64}$/u.test(input.accountScope))throw fail('MIAOSHOU_CLAIM_CHART_SCOPE','无法确认妙手账号。');
    return createHash('sha256').update(JSON.stringify([input.accountScope,miaoshouId(input.shopId)])).digest('hex');
  };
  const pathFor=key=>root?resolve(root,'miaoshou-claim-size-charts',key+'.json'):null;
  const view=data=>({revision:data.revision,sizeChartUrl:data.sizeChartUrl});
  async function load(key){
    if(!root)return memory.get(key)||empty();
    try{
      const raw=await readFile(pathFor(key));if(raw.length>4096)throw Error();const data=JSON.parse(raw.toString('utf8'));
      if(!plain(data)||data.version!==1||!validRevision(data.revision)||Object.keys(data).some(k=>!['version','revision','sizeChartUrl'].includes(k))||data.sizeChartUrl!==null&&chartUrl(data.sizeChartUrl)!==data.sizeChartUrl)throw Error();
      return data;
    }catch(error){if(error.code==='ENOENT')return empty();throw fail('MIAOSHOU_CLAIM_CHART_STORAGE','认领尺码表配置无法读取，请保留原文件并核对。',503);}
  }
  function mutate(input,remove,{guard=async()=>{}}={}){
    const key=selected(input),revision=input.revision;if(!validRevision(revision))throw fail('MIAOSHOU_CLAIM_CHART_INVALID','请先读取最新的店铺尺码表配置。');
    const sizeChartUrl=remove?null:chartUrl(input.sizeChartUrl);
    const work=(queues.get(key)||Promise.resolve()).then(async()=>{
      let lock,temp;const path=pathFor(key);
      try{
        if(path){await mkdir(resolve(root,'miaoshou-claim-size-charts'),{recursive:true});try{lock=await open(path+'.lock','wx');}catch(error){if(error.code!=='EEXIST')throw error;throw fail('MIAOSHOU_CLAIM_CHART_BUSY','店铺尺码表配置正在修改，请稍后重试。',409);}}
        await guard();const current=await load(key);
        if(current.revision!==revision)throw fail('MIAOSHOU_CLAIM_CHART_CONFLICT','店铺尺码表配置已变化，请刷新后重试。',409);
        if(current.sizeChartUrl===sizeChartUrl)return view(current);
        if(revision>=Number.MAX_SAFE_INTEGER)throw fail('MIAOSHOU_CLAIM_CHART_STORAGE','店铺尺码表配置版本已达上限。',503);
        const next={version:1,revision:revision+1,sizeChartUrl};
        if(path){temp=path+'.'+randomUUID()+'.tmp';const file=await open(temp,'wx');try{await file.writeFile(JSON.stringify(next));await file.sync();}finally{await file.close();}await guard();await rename(temp,path);temp=null;}
        else {await guard();memory.set(key,next);}
        return view(next);
      }catch(error){if(error.code?.startsWith('MIAOSHOU_')||error.code==='CONTEXT_CHANGED')throw error;throw fail('MIAOSHOU_CLAIM_CHART_STORAGE','店铺尺码表配置未能保存，原配置已保留。',503);}
      finally{if(temp)await unlink(temp).catch(()=>{});if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}}
    });
    const settled=work.catch(()=>{});queues.set(key,settled);void settled.finally(()=>{if(queues.get(key)===settled)queues.delete(key);});return work;
  }
  return {async list(input){return view(await load(selected(input)));},save:(input,options)=>mutate(input,false,options),remove:(input,options)=>mutate(input,true,options),async close(){closed=true;await Promise.allSettled([...queues.values()]);}};
}

const result=(state,message,extra={})=>({state,message,...extra});
function claimDefaultsState(state,message){
  return {attributes:result(state,message),sizeChart:result(state,message),package:result(state,message)};
}
export const skippedClaimDefaults=message=>claimDefaultsState('skipped',message);
export const reviewClaimDefaults=()=>claimDefaultsState('needs_review','自动填写结果待核对，未自动重试。');
function editResult(value,label,target,scope){
  const sameTarget=value?.detailId===target.detailId&&value?.shopId===target.shopId;
  if(!sameTarget||!['succeeded','unchanged'].includes(value?.state))return result('needs_review',label+'结果待核对，未自动重试。');
  const receipt=value.receipt;
  const acknowledged=value.confirmation==='api_receipt'&&value.state==='succeeded'&&receipt?.version===1&&
    receipt.api==='save_shop_collect_item_info'&&receipt.outcome==='acknowledged'&&receipt.result==='success'&&receipt.code==='success'&&
    receipt.detailId===target.detailId&&receipt.shopId===target.shopId&&receipt.accountScope===scope&&
    typeof receipt.operationId==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u.test(receipt.operationId)&&
    typeof receipt.ossMd5Hash==='string'&&/^[a-f0-9]{64}$/u.test(receipt.ossMd5Hash)&&
    typeof receipt.acknowledgedAt==='string'&&/^\d{4}-\d{2}-\d{2}T/u.test(receipt.acknowledgedAt)&&Number.isFinite(Date.parse(receipt.acknowledgedAt));
  if(acknowledged)return result('applied',label+'已保存到妙手。',{confirmation:'api_receipt'});
  // Legacy verified outcomes refer to an actual readback. A malformed API
  // receipt must not bypass validation by also asserting verified:true.
  if(value.verified===true&&value.confirmation!=='api_receipt')return result(value.state==='unchanged'?'unchanged':'applied',label+(value.state==='unchanged'?'已一致，无需修改。':'已应用并核验。'),{confirmation:'readback'});
  return result('needs_review',label+'结果待核对，未自动重试。');
}
const editFailure=(error,label)=>error?.code==='MIAOSHOU_EDIT_REVIEW'||error?.state==='needs_review'
  ?result('needs_review',label+'结果待核对，未自动重试。')
  :result('failed',error?.code==='MIAOSHOU_EDIT_STALE'?label+'未应用：商品资料已变化。':label+'未应用，请核对当前店铺的商品类目和配置。');

/** Run only once after a new claim has been committed and independently read back. */
export async function applyMiaoshouClaimDefaults({before,after,detailId,shopId,scope,guard,client,attributeTemplates,sizeCharts,productEdits,isLeaf}){
  if(!Array.isArray(before)||before.includes(shopId))return skippedClaimDefaults('未确认这是新认领，未自动覆盖现有商品。');
  const policy=singleShopPolicy(after);
  if(!policy.allowed||policy.shopId!==shopId)return skippedClaimDefaults('认领已完成，但商品不属于已核验的单一目标店铺，未自动修改。');
  const target={detailId,shopId},storeScope={accountScope:scope,shopId};
  const read=async()=>{await guard();const detail=await client.call('detail',{detailId:BigInt(detailId),shopId:BigInt(shopId)});await guard();return validateMiaoshouDetail(detail,target);};
  let detail;
  try{detail=await read();}
  catch{return claimDefaultsState('failed','无法核验认领后的商品与店铺，未自动修改。');}
  let categoryId;
  try{categoryId=miaoshouId(detail.shopCollectItemInfo.cid);}catch{}
  const initialChart=chartState(detail.shopCollectItemInfo);
  const initialPackage=packageState(detail.shopCollectItemInfo);
  const apply=async (changes,action='edit')=>{
    await guard();
    return productEdits.apply({
      detailId,shopIds:[shopId],action,
      changes:changes.attributes?{contextShopId:shopId,contextCategoryId:categoryId,...changes}:changes
    },{expectedSourceHash:miaoshouEditRevision(detail),expectedScope:scope});
  };
  let attributes,sizeChart,chartRule;
  try{chartRule=await sizeCharts.list(storeScope);}catch{sizeChart=result('failed','店铺尺码表配置未能读取，未修改商品尺码表。');}
  if(!sizeChart&&!chartRule?.sizeChartUrl)sizeChart=result('skipped','目标店铺未设置认领尺码表。');
  try{
    if(!categoryId||!isLeaf(categoryId))attributes=result('skipped','未核验为末级类目，未套用属性模板。');
    else{
      const library=await attributeTemplates.list({...storeScope,categoryId,scope:'category'});
      const template=library.defaultId?library.items.find(item=>item.id===library.defaultId):null;
      if(library.defaultId&&!template)attributes=result('failed','认领默认属性模板不存在，请重新设置。');
      else if(!template)attributes=result('skipped','此末级子类目未设置认领默认属性模板。');
      else attributes={...editResult(await apply({attributes:structuredClone(template.attributes)}),'属性模板',target,storeScope.accountScope),templateId:template.id,templateScope:'category'};
    }
  }catch(error){attributes=editFailure(error,'属性模板');}
  if(!sizeChart){
    if(attributes.state==='needs_review')sizeChart=result('skipped','属性写入结果待核对，未继续修改尺码表。');
    else try{
      if(attributes.state==='applied'){
        detail=await read();
        if(miaoshouId(detail.shopCollectItemInfo.cid)!==categoryId||chartState(detail.shopCollectItemInfo)!==initialChart)throw fail('MIAOSHOU_EDIT_STALE','商品类目或尺码表已变化。',409);
      }
      sizeChart=editResult(await apply({sizeChartUrl:chartRule.sizeChartUrl}),'尺码表',target,scope);
    }catch(error){sizeChart=editFailure(error,'尺码表');}
  }
  let packageOutcome;
  if(attributes.state==='needs_review'||sizeChart.state==='needs_review'){
    packageOutcome=result('skipped','前序保存结果待核对，未继续填写物流信息。');
  }else try{
    if(attributes.state==='applied'||sizeChart.state==='applied'){
      detail=await read();
      if(packageState(detail.shopCollectItemInfo)!==initialPackage)
        throw fail('MIAOSHOU_EDIT_STALE','商品物流信息已变化。',409);
    }
    const packageValues=randomMiaoshouPackage();
    packageOutcome=editResult(await apply(packageValues,'package'),'物流信息',target,scope);
    if(['applied','unchanged'].includes(packageOutcome.state))packageOutcome.packageValues=packageValues;
  }catch(error){packageOutcome=editFailure(error,'物流信息');}
  return {attributes,sizeChart,package:packageOutcome};
}
