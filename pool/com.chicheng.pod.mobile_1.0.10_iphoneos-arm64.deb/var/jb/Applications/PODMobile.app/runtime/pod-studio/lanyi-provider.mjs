import {inspectHostImage} from './host-materials.mjs';

export const LANYI_API_BASE_URL='https://lanyiapi.cc/v1';
export const LANYI_DEFAULT_IMAGE_MODEL='gpt-image-2';
const MAX_IMAGE_BYTES=25*1024*1024;
const MAX_BASE64_BYTES=Math.ceil(MAX_IMAGE_BYTES/3)*4;
const MAX_IMAGES=6;
const IMAGE_TIMEOUT_MS=10*60*1000;
const IMAGE_FORMATS=Object.freeze({'image/png':'png','image/jpeg':'jpg','image/webp':'webp'});
const EFFORTS=new Set(['none','minimal','low','medium','high','xhigh','max','ultra']);
const KEY_FORMAT=/^[\x21-\x7e]{1,4096}$/u;
const MODEL_FORMAT=/^[a-z0-9][a-z0-9._:/-]{0,159}$/iu;
const TEXT_MODEL=/^(?:gpt-[a-z0-9]|o[1-9](?:$|-)|codex(?:$|-))/iu;
const IMAGE_MODEL=/^gpt-image-[a-z0-9]/iu;
const NON_TEXT_MODEL=/(?:^|[._/-])(?:image|audio|video|realtime|transcribe|tts|embedding|moderation|dall-e|sora|whisper)(?:$|[._/-])/iu;
const PNG_SIGNATURE=Buffer.from([137,80,78,71,13,10,26,10]);

const error=(message,status,code)=>Object.assign(new Error(message),{status,code});
const badResponse=()=>error('蓝移 API 未返回有效结果。',502,'LANYI_RESPONSE');
const badImage=()=>error('蓝移 API 未返回有效图片。',502,'LANYI_IMAGE_RESPONSE');
const invalidImage=()=>error('蓝移 API 仅接收 25 MB 以内的 PNG、JPG 或 WebP 原图。',400,'LANYI_IMAGE_INPUT');
const modelId=value=>typeof value==='string'&&MODEL_FORMAT.test(value)&&!value.includes('://');

function requireKey(value){
  if(typeof value!=='string'||!KEY_FORMAT.test(value))throw error('请先在主机设置中填写蓝移 API Key。',401,'LANYI_AUTH');
  return value;
}

function statusError(status){
  if(status===401||status===403)return error('蓝移 API 授权失败，请检查主机 API Key 和模型权限。',status,'LANYI_AUTH');
  if(status===402||status===429)return error('蓝移 API 额度不足或请求频率受限，请核对账号后重试。',status,'LANYI_LIMIT');
  if(status===413)return error('蓝移 API 拒绝接收过大的请求。',413,'LANYI_IMAGE_LIMIT');
  if([400,404,415,422].includes(status))return error('蓝移 API 未接受本次请求，请核对模型及输入格式。',status,'LANYI_REQUEST');
  return error('蓝移 API 暂时无法完成请求，请稍后核对结果。',502,'LANYI_UNAVAILABLE');
}

function waitFor(promise,signal){
  if(signal.aborted){
    void promise.catch(()=>{});
    return Promise.reject(signal.reason);
  }
  let stop;
  const abort=new Promise((_,reject)=>{
    stop=()=>reject(signal.reason);
    signal.addEventListener('abort',stop,{once:true});
  });
  return Promise.race([promise,abort]).finally(()=>signal.removeEventListener('abort',stop));
}

async function readJson(response,limit,signal){
  const length=response.headers.get('content-length');
  if(length!==null&&/^\d+$/u.test(length)&&Number(length)>limit){
    void response.body?.cancel().catch(()=>{});
    throw badResponse();
  }
  const reader=response.body?.getReader();
  if(!reader)throw badResponse();
  const decoder=new TextDecoder('utf-8',{fatal:true}),parts=[];
  let bytes=0,complete=false;
  try{
    for(;;){
      const {done,value}=await waitFor(reader.read(),signal);
      if(done)break;
      bytes+=value.byteLength;
      if(bytes>limit)throw badResponse();
      parts.push(decoder.decode(value,{stream:true}));
    }
    parts.push(decoder.decode());
    complete=true;
    return JSON.parse(parts.join(''));
  }finally{
    if(!complete)void reader.cancel().catch(()=>{});
    reader.releaseLock();
  }
}

async function request(path,{apiKey,fetchImpl,method='GET',body,signal,timeout,limit,json=false}){
  signal?.throwIfAborted();
  const deadline=AbortSignal.timeout(timeout),current=signal?AbortSignal.any([signal,deadline]):deadline;
  let response;
  try{
    response=await waitFor(Promise.resolve().then(()=>{
      current.throwIfAborted();
      return fetchImpl(LANYI_API_BASE_URL+path,{
        method,headers:{Authorization:'Bearer '+apiKey,Accept:'application/json',...(json?{'Content-Type':'application/json'}:{})},
        ...(body===undefined?{}:{body}),redirect:'error',credentials:'omit',cache:'no-store',signal:current,
      });
    }),current);
  }catch{
    signal?.throwIfAborted();
    if(deadline.aborted)throw error('蓝移 API 请求超时，请先核对原任务结果。',504,'LANYI_TIMEOUT');
    throw error('无法连接蓝移 API，请检查主机网络。',502,'LANYI_NETWORK');
  }
  if(!response?.ok){
    void response?.body?.cancel().catch(()=>{});
    throw statusError(response?.status);
  }
  try{return await readJson(response,limit,current);}
  catch{
    signal?.throwIfAborted();
    if(deadline.aborted)throw error('蓝移 API 响应超时，请先核对原任务结果。',504,'LANYI_TIMEOUT');
    throw badResponse();
  }
}

function imageMime(bytes){
  if(bytes.subarray(0,8).equals(PNG_SIGNATURE))return 'image/png';
  if(bytes[0]===255&&bytes[1]===216)return 'image/jpeg';
  if(bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return 'image/webp';
  return '';
}

function sourceFile(image){
  const mimeType=image instanceof Blob?image.type:image?.mimeType;
  if(!Object.hasOwn(IMAGE_FORMATS,mimeType))throw invalidImage();
  if(image instanceof Blob){if(!image.size||image.size>MAX_IMAGE_BYTES)throw invalidImage();return image;}
  const bytes=image?.bytes;
  if(!(bytes instanceof Uint8Array)||!bytes.byteLength||bytes.byteLength>MAX_IMAGE_BYTES||imageMime(Buffer.from(bytes.buffer,bytes.byteOffset,bytes.byteLength))!==mimeType)throw invalidImage();
  return new Blob([bytes],{type:mimeType});
}

export async function generateLanyiImage({apiKey,prompt,images=[],model=LANYI_DEFAULT_IMAGE_MODEL,signal,fetchImpl=fetch}={}){
  requireKey(apiKey);
  signal?.throwIfAborted();
  if(typeof prompt!=='string'||!prompt.trim()||prompt.length>100000||!modelId(model))throw error('蓝移图像模型或提示词无效。',400,'LANYI_IMAGE_INPUT');
  if(!Array.isArray(images)||images.length>MAX_IMAGES)throw invalidImage();
  let body;
  const edit=images.length>0;
  if(edit){
    const originals=images.map(sourceFile);
    if(originals.reduce((total,image)=>total+image.size,0)>MAX_IMAGE_BYTES)throw invalidImage();
    body=new FormData();
    body.set('model',model);body.set('prompt',prompt);body.set('size','auto');body.set('quality','auto');
    for(const [index,original] of originals.entries())body.append('image',original,'source-'+(index+1)+'.'+IMAGE_FORMATS[original.type]);
  }else body=JSON.stringify({model,prompt,size:'auto',quality:'auto'});
  const result=await request(edit?'/images/edits':'/images/generations',{
    apiKey,fetchImpl,method:'POST',body,json:!edit,signal,timeout:IMAGE_TIMEOUT_MS,limit:MAX_BASE64_BYTES+128*1024,
  });
  const encoded=result?.data?.[0]?.b64_json;
  if(!Array.isArray(result?.data)||typeof encoded!=='string'||!encoded.length||encoded.length>MAX_BASE64_BYTES||
    encoded.length%4!==0||!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded))throw badImage();
  const bytes=Buffer.from(encoded,'base64'),mimeType=imageMime(bytes);
  if(!bytes.length||bytes.length>MAX_IMAGE_BYTES||!mimeType||bytes.toString('base64')!==encoded)throw badImage();
  try{await inspectHostImage(bytes);}catch{throw badImage();}
  signal?.throwIfAborted();
  return {bytes,mimeType};
}

function modelMetadata(row){
  const id=row.id;
  const supportedReasoningEfforts=Array.isArray(row.supportedReasoningEfforts)
    ?[...new Set(row.supportedReasoningEfforts.map(item=>typeof item==='string'?item:item?.reasoningEffort).filter(value=>EFFORTS.has(value)))].map(reasoningEffort=>({reasoningEffort}))
    :[];
  const defaultReasoningEffort=supportedReasoningEfforts.some(item=>item.reasoningEffort===row.defaultReasoningEffort)?row.defaultReasoningEffort:undefined;
  return {id,model:id,displayName:id,...(supportedReasoningEfforts.length?{supportedReasoningEfforts}:{}),
    ...(defaultReasoningEffort?{defaultReasoningEffort}:{})};
}

export function createLanyiProvider({apiKey,fetchImpl=fetch}={}){
  requireKey(apiKey);
  const nativeConfig=Object.freeze({
    model_provider:'pod_lanyi',
    'model_providers.pod_lanyi.name':'LanYi',
    'model_providers.pod_lanyi.base_url':LANYI_API_BASE_URL,
    'model_providers.pod_lanyi.env_key':'POD_LANYI_API_KEY',
    'model_providers.pod_lanyi.wire_api':'responses',
    'model_providers.pod_lanyi.requires_openai_auth':false,
  });
  const environment=Object.freeze({POD_LANYI_API_KEY:apiKey});
  let readingCatalog;
  function catalog({signal}={}){
    signal?.throwIfAborted();
    if(!readingCatalog){
      const pending=request('/models',{apiKey,fetchImpl,timeout:12000,limit:512*1024}).then(result=>{
        if(!Array.isArray(result?.data)||result.data.length>2048)throw badResponse();
        const entries=new Map();
        for(const row of result.data){
          const id=row?.id;
          if(modelId(id)&&id!==apiKey&&row.hidden!==true&&!entries.has(id))entries.set(id,row);
        }
        return [...entries.values()];
      });
      readingCatalog=pending;
      const reset=()=>{if(readingCatalog===pending)readingCatalog=undefined;};
      pending.then(reset,reset);
    }
    return signal?waitFor(readingCatalog,signal):readingCatalog;
  }
  async function listModels({signal}={}){
    const rows=await catalog({signal});
    return {data:rows.filter(({id})=>TEXT_MODEL.test(id)&&!NON_TEXT_MODEL.test(id)).map(modelMetadata),nextCursor:null};
  }
  async function listImageModels({signal}={}){
    const rows=await catalog({signal});
    return {data:rows.filter(({id})=>IMAGE_MODEL.test(id)).map(({id})=>({
      id,model:id,displayName:id,inputModalities:['text','image'],
    })),nextCursor:null};
  }
  return Object.freeze({nativeConfig,environment,listModels,listImageModels,generateImage:options=>generateLanyiImage({...options,apiKey,fetchImpl})});
}
