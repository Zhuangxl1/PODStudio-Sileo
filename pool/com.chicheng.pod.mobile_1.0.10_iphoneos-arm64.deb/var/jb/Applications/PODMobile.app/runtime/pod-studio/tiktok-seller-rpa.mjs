import { createHash, randomUUID } from 'node:crypto';
import { mkdir, realpath, writeFile } from 'node:fs/promises';
import { isAbsolute, join } from 'node:path';
import { connectTikTokBrowser, assertSellerUrl, validateSpoolFiles, findRecoveredSellerControl } from './tiktok-browser-driver.mjs';
import { listingSkuValue,listingWarehouseStocks } from './dist/tiktok-listing-model.js';
import { buildTikTokPublishingSalesPlan, tiktokSalesDimensionNamesMatch } from './dist/tiktok-publishing-sales-plan.js';
import { buildPartialCategoryDefinitionFields } from './tiktok-category-definition-fields.mjs';
import { buildObservedInputEvidence, observedInputEvidenceMatches, observedInputLabels, buildCategoryDefinitionInputDraftEvidence } from './dist/tiktok-input-evidence.js';
import { probeSupplementalComplianceFields, finalizeSupplementalComplianceFields } from './tiktok-supplemental-compliance-rpa.mjs';
import { attributeValueEntries,isCustomAttributeValue,attributeValueText,attributeNumberValueAllowed,attributeNumberValuesEqual } from './dist/tiktok-attribute-values.js';

export const SELLER_PROFILE_URL = 'https://seller.us.tiktokshopglobalselling.com/profile/seller-profile-v2?back_source=setting-shop&shop_region=US';
const CREATE_URL = 'https://seller.us.tiktokshopglobalselling.com/product/create?channel=manage&shop_region=US';
const clean = value => String(value ?? '').replace(/\s+/gu, ' ').replace(/^\*\s*/u, '').trim();
const same = (left, right) => clean(left).toLocaleLowerCase() === clean(right).toLocaleLowerCase();
const editable = item => ['input', 'textarea', 'select'].includes(item.tag) || ['combobox', 'textbox'].includes(item.role);
const categoryControl = item => /^(商品类目|产品类目|类目|Product category|Category)$/iu.test(clean(item.label));
const attributeControl = item => /^(?:关键属性|可选属性|Key attributes|Optional attributes)(?:\s*[（(]\s*\d+\s*[）)])?$/iu.test(clean(item.section));
const optionControl = item => ['option', 'treeitem', 'menuitem'].includes(item.role) && !item.disabled;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const abort = signal => { if (signal?.aborted) throw signal.reason || new Error('任务已取消。'); };
const fieldKey = (section, label, ordinal) => 'dom-' + createHash('sha256').update([section, label, ordinal].join('\0')).digest('hex').slice(0, 24);
const exactCategoryScope = (snapshot, categoryPath) => {
  const normalise = value => clean(value).replace(/\s+-\s+|\s*(?:>|›|»|\/|→)\s*/gu, ' > ');
  const categories = (snapshot.controls || []).filter(categoryControl);
  if (categories.length !== 1) return false;
  const expected = categoryPath.map(clean).join(' > '), texts = [categories[0].value, categories[0].text, ...(categories[0].selectedValues || [])].map(normalise);
  return texts.some(value => value === expected) && texts.every(value => !value.includes(' > ') || value === expected)
    && snapshot.categoryBusy !== true
    && !(snapshot.categoryPopupCount > 0) && !(snapshot.categoryColumns || []).length && !(snapshot.optionLists || []).length;
};
const definitionFieldsSignature = mapped => JSON.stringify({ fields: mapped.fields, groups: mapped.attributeGroups });
const assertReadSnapshotSafety = snapshot => {
  assertSellerUrl(snapshot.url);
  if (snapshot.securityChallenge?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
};

const observedDescriptor = field => ({ label: field.label, section: field.section, ordinal: field.ordinal,
  groupCount: field.groupCount, multiple: field.multiple, required: field.required, controlType: 'select' });
const observedSlotSignature = field => JSON.stringify([field.key, observedDescriptor(field)]);
const observedCandidate = field => field.optionsComplete === false && field.controlType === 'select' && field.groupCount === 1
  && !observedInputLabels.includes(field.label)
  && ['property_relation_ambiguous', 'mapped_property_kind_unverified'].includes(field.unavailableReason);
const attributeContextFingerprint = snapshot => createHash('sha256').update(JSON.stringify({
  fields: (snapshot.controls || []).filter(item => editable(item) && attributeControl(item))
    .map(item => [item.selector, item.label, item.section, item.tag, item.role, item.type, item.multiple, item.required, item.disabled,
      item.readOnly === true, item.value ?? null, item.selectedValues ?? null]),
  groups: (snapshot.attributeGroups || []).map(group => ['groupId', 'kind', 'expanded', 'fieldRowsVerified', 'scanComplete', 'truncated',
    'candidateFieldCount', 'candidateControlCount', 'labelledControlCount', 'normalisedControlCount', 'missingLabelCount', 'unknownControlCount', 'unresolvedCount'].map(key => group[key] ?? null))
})).digest('hex');
const observedScopeError = () => Object.assign(new Error('属性选项读取期间页面、店铺或属性上下文发生变化，请重新读取。'), { code: 'SELLER_OPTION_READ_SCOPE_CHANGED' });
const fingerprintValid = value => typeof value === 'string' && /^[a-f0-9]{64}$/u.test(value);
const observedProofTrue = ['ownerRevalidated', 'associationVerified', 'paneIdentityVerifiable', 'finiteGeometry', 'flowVerified', 'completeMounted', 'positionsComplete', 'emptyQueryVerified'];
const observedProofFalse = ['virtualMarker', 'ariaHidden', 'busy', 'countConflict', 'truncated'];
const observedProofZero = ['disabledRowCount', 'moreControlCount', 'unknownChildCount', 'unknownOptionControlCount', 'missingLabelCount', 'duplicateLabelCount', 'coverageGapCount', 'coverageOverlapCount'];
const observedProofOne = ['ownerCount', 'popupCount', 'innerListboxCount', 'scrollPaneCount'];
function validObservedCensus(value) {
  const count = value?.rowCount;
  return value?.accepted === true && value.complete === false && value.mountedOnly === true && value.coverageKind === 'complete-mounted-list'
    && Number.isSafeInteger(count) && count > 0 && count <= 1000
    && ['rowCount', 'normalisedOptionCount', 'selectableOptionCount'].every(key => value[key] === count)
    && observedProofTrue.every(key => value[key] === true) && observedProofFalse.every(key => value[key] === false)
    && observedProofZero.every(key => value[key] === 0) && observedProofOne.every(key => value[key] === 1)
    && (value.declaredTotal === null || value.declaredTotal === count)
    && ['schemaFingerprint', 'associationFingerprint', 'geometryFingerprint', 'documentFingerprint'].every(key => fingerprintValid(value[key]))
    && ['scrollTop', 'clientHeight', 'scrollHeight'].every(key => Number.isFinite(value[key]))
    && value.scrollTop >= -1 && value.clientHeight > 0 && value.scrollHeight >= value.clientHeight - 1
    && value.scrollTop <= value.scrollHeight - value.clientHeight + 2
    && value.atTop === (value.scrollTop <= 1) && value.atBottom === (value.scrollTop >= value.scrollHeight - value.clientHeight - 2)
    && Array.isArray(value.options) && value.options.length === count && Array.isArray(value.orderedLabels) && value.orderedLabels.length === count
    && new Set(value.orderedLabels).size === count && value.orderedLabels.every((label, index) => typeof label === 'string' && clean(label) === label && label.length > 0 && label.length <= 1024
      && value.options[index]?.label === label && value.options[index].value === label);
}
function observedOwner(snapshot, slot, selector) {
  const matches = (snapshot.controls || []).filter(item => editable(item) && attributeControl(item) && item.section === slot.section && item.label === slot.label);
  if (matches.length !== 1) return null;
  const owner = matches[0];
  return ['div', 'span'].includes(owner.tag) && owner.role === 'combobox' && owner.multiple === slot.multiple && owner.required === slot.required
    && owner.disabled === false && owner.readOnly !== true && typeof owner.selector === 'string' && owner.selector && (!selector || owner.selector === selector) ? owner : null;
}
function assertObservedScope(snapshot, context, { popup = false } = {}) {
  assertReadSnapshotSafety(snapshot);
  const actual = snapshot.identity || {}, expected = context.identity;
  if (snapshot.busy !== false || snapshot.securityChallenge?.detected !== false || !Array.isArray(snapshot.guidanceDialogs) || snapshot.guidanceDialogs.length
    || snapshot.modalCount > 0 || snapshot.unknownModalCount > 0
    || !exactCategoryScope(popup ? { ...snapshot, optionLists: [] } : snapshot, context.categoryPath)
    || ['shopId', 'shopName', 'region', 'idKind'].some(key => clean(actual[key]) && clean(expected[key]) && !same(actual[key], expected[key])))
    throw observedScopeError();
  if (attributeContextFingerprint(snapshot) !== context.attributeContext) throw observedScopeError();
}
function associatedObservedList(snapshot, owner) {
  const lists = snapshot.optionLists || [], ids = owner.listIds;
  if (lists.length !== 1 || !Array.isArray(ids) || !ids.length) return null;
  const list = lists[0];
  return ids.some(id => typeof id === 'string' && id && (list.relatedListIds || []).includes(id))
    && typeof list.selector === 'string' && list.selector && typeof list.containerSelector === 'string' && list.containerSelector
    && [list.top, list.height, list.scrollHeight].every(Number.isFinite) && list.height > 0 && list.top >= -1 && list.scrollHeight >= list.height - 1
    && list.busy === false ? list : null;
}

// A local proof is minted only for the complete, nonvirtual, native list that
// this unique real control exposes. It does not infer an API property or IDs.
// Keep this serial: a timed-out/aborted command must not race later cleanup or
// promote a late result into the current read.
export async function probeObservedOptionList(page, slot, context, { wait = sleep, signal, nowMs = () => Date.now(), onProgress = () => {} } = {}) {
  if (!observedCandidate(slot) || typeof page.readPublicOptionListCensus !== 'function' || typeof page.getDocumentFingerprint !== 'function'
    || typeof page.clickReadControl !== 'function' || !fingerprintValid(context.documentFingerprint)) return null;
  const deadline = nowMs() + 90000;
  const check = () => { abort(signal); if (nowMs() >= deadline) throw Object.assign(new Error('属性选项读取超时，本次结果未保存。'), { code: 'SELLER_OPTION_READ_TIMEOUT' }); };
  const fresh = async popup => { check(); const state = await page.snapshot(); check(); assertObservedScope(state, context, { popup }); return state; };
  const initial = await fresh(false), owner = observedOwner(initial, slot);
  if (!owner || owner.expanded === true || owner.expanded === 'true' || /(?:^|\s)core-select-open(?:\s|$)/u.test(owner.uiHints?.className || '')) return null;
  check(); const documentFingerprint = await page.getDocumentFingerprint(); check();
  if (documentFingerprint !== context.documentFingerprint) throw observedScopeError();
  await page.clickReadControl(owner.ref, 'attribute-trigger'); check();
  let proof = null, signature = '', phase = 'top', topStableSamples = 0, bottomStableSamples = 0, root = '', pane = '', associatedIds = '';
  let emptyPopupSamples = 0, openOwnerSamples = 0, frameRecovered = false;
  const ownerOpenWithoutList = (state, item) => !(state.optionLists || []).length && (item.expanded === true || item.expanded === 'true')
    && /(?:^|\s)core-select-open(?:\s|$)/u.test(item.uiHints?.className || '')
    && !(state.controls || []).some(control => ['option', 'treeitem', 'menuitem'].includes(control.role));
  for (let sample = 0; sample < 32; sample++) {
    const state = await fresh(true), actual = observedOwner(state, slot, owner.selector);
    if (!actual) throw observedScopeError();
    const list = associatedObservedList(state, actual);
    if (!list) {
      if ((state.optionLists || []).length) break;
      if (root || signature || topStableSamples || bottomStableSamples) break;
      emptyPopupSamples++; openOwnerSamples = ownerOpenWithoutList(state, actual) ? openOwnerSamples + 1 : 0;
      if (emptyPopupSamples >= 12) {
        // An observed open trigger can precede Chromium's painted popup. The
        // existing owned-page frame recovery only captures a frame; it never
        // clicks again, selects an option or changes a browser security setting.
        if (frameRecovered || openOwnerSamples < 3 || typeof page.recoverReadFrame !== 'function') break;
        const beforeFrame = await fresh(true), frameOwner = observedOwner(beforeFrame, slot, owner.selector);
        if (!frameOwner || !ownerOpenWithoutList(beforeFrame, frameOwner)) break;
        check(); await page.recoverReadFrame('attribute'); check();
        frameRecovered = true; emptyPopupSamples = 0; openOwnerSamples = 0;
      }
      await wait(150); continue;
    }
    const ids = JSON.stringify((actual.listIds || []).filter(id => (list.relatedListIds || []).includes(id)).sort());
    if (root && (root !== list.containerSelector || pane !== list.selector || associatedIds !== ids)) break;
    root = list.containerSelector; pane = list.selector; associatedIds = ids;
    check(); const census = await page.readPublicOptionListCensus(actual.ref); check();
    if (!validObservedCensus(census)) break;
    if (census.documentFingerprint !== context.documentFingerprint) throw observedScopeError();
    if (Math.abs(list.top - census.scrollTop) > 2 || Math.abs(list.height - census.clientHeight) > 2 || Math.abs(list.scrollHeight - census.scrollHeight) > 2) break;
    const current = JSON.stringify([census.orderedLabels, census.schemaFingerprint, census.associationFingerprint, census.geometryFingerprint,
      census.rowCount, census.normalisedOptionCount, census.selectableOptionCount, census.declaredTotal]);
    if (signature && signature !== current) break;
    signature = current;
    const scrollTo = async top => {
      // The census getter refreshes driver refs internally; derive the related
      // scroll pane again from a normal fresh snapshot immediately before use.
      const before = await fresh(true), nextOwner = observedOwner(before, slot, owner.selector), next = nextOwner && associatedObservedList(before, nextOwner);
      if (!next || next.containerSelector !== root || next.selector !== pane || JSON.stringify((nextOwner.listIds || []).filter(id => (next.relatedListIds || []).includes(id)).sort()) !== associatedIds
        || !(before.scrollables || []).some(item => item.selector === next.selector)) return false;
      check(); await page.scroll(next.selector, top); check(); await wait(100); return true;
    };
    if (phase === 'top') {
      if (!census.atTop) { if (topStableSamples || !await scrollTo(0)) break; continue; }
      topStableSamples++;
      if (topStableSamples >= 4) {
        phase = 'bottom';
        if (!census.atBottom && !await scrollTo(Math.max(0, census.scrollHeight - census.clientHeight))) break;
      }
    } else {
      if (!census.atBottom) break;
      bottomStableSamples++;
      if (bottomStableSamples >= 4) { proof = census; break; }
    }
    onProgress(census.rowCount); await wait(100);
  }
  // A settled rejected census may be cleaned up. Exceptions (including CDP
  // timeout/abort/security) instead terminate the owned page, with no follow-on
  // command and no cached proof.
  const beforeClose = await fresh(true), closeOwner = observedOwner(beforeClose, slot, owner.selector);
  if (!closeOwner) throw observedScopeError();
  if ((beforeClose.optionLists || []).length) {
    const closeList = associatedObservedList(beforeClose, closeOwner);
    if (!closeList || root && (closeList.containerSelector !== root || closeList.selector !== pane
      || JSON.stringify((closeOwner.listIds || []).filter(id => (closeList.relatedListIds || []).includes(id)).sort()) !== associatedIds)) throw observedScopeError();
  }
  check(); await page.press('Escape'); check();
  let closedSamples = 0;
  for (let sample = 0; sample < 20; sample++) {
    const closed = await fresh(true), currentOwner = observedOwner(closed, slot, owner.selector);
    if (!currentOwner) throw observedScopeError();
    const isClosed = !(closed.optionLists || []).length && currentOwner.expanded !== true && currentOwner.expanded !== 'true'
      && !/(?:^|\s)core-select-open(?:\s|$)/u.test(currentOwner.uiHints?.className || '')
      && !(closed.controls || []).some(item => ['option', 'treeitem', 'menuitem'].includes(item.role));
    closedSamples = isClosed ? closedSamples + 1 : 0;
    if (closedSamples >= 3) break;
    await wait(100);
  }
  if (closedSamples < 3) throw Object.assign(new Error('属性下拉菜单尚未确认关闭，本次读取已停止。'), { code: 'SELLER_OPTION_POPUP_NOT_CLOSED' });
  check(); const finalDocument = await page.getDocumentFingerprint(); check();
  if (finalDocument !== context.documentFingerprint) throw observedScopeError();
  if (!proof) return null;
  const evidence = { kind: 'observed-seller-option-list', version: 1, coverageKind: 'complete-mounted-list', categoryId: context.categoryId,
    fieldKey: slot.key, descriptor: observedDescriptor(slot), orderedLabels: [...proof.orderedLabels],
    stableSamples: Math.min(topStableSamples, bottomStableSamples), topStableSamples, bottomStableSamples,
    rowCount: proof.rowCount, normalisedOptionCount: proof.normalisedOptionCount, selectableOptionCount: proof.selectableOptionCount,
    declaredTotal: proof.declaredTotal, atTop: true, atBottom: true };
  for (const key of [...observedProofTrue, ...observedProofFalse, ...observedProofZero, ...observedProofOne]) evidence[key] = proof[key];
  return { slotSignature: observedSlotSignature(slot), attributeContext: context.attributeContext, documentFingerprint: context.documentFingerprint,
    field: { ...Object.fromEntries(Object.entries(slot).filter(([key]) => !['apiCategoryId', 'apiPropertyId', 'optionsEvidence', 'unavailableReason'].includes(key))),
      controlType: 'select', valueKind: 'dom-label', options: proof.orderedLabels.map(label => ({ value: label, label })), optionsComplete: true, optionsEvidence: evidence } };
}

// Rebuild from the original full field census; never shrink it to the fields
// that happened to yield a local list. Cache entries are local to one read.
export function mergeObservedOptionLists(mapped, snapshot, cache, documentFingerprint) {
  if (mapped?.partialFieldsVerified !== true || !Array.isArray(cache) || !cache.length) return mapped;
  const context = attributeContextFingerprint(snapshot);
  return { ...mapped, fields: mapped.fields.map(slot => {
    const matches = cache.filter(entry => observedCandidate(slot) && entry.slotSignature === observedSlotSignature(slot)
      && entry.attributeContext === context && entry.documentFingerprint === documentFingerprint);
    return matches.length === 1 && observedOwner(snapshot, slot) ? structuredClone(matches[0].field) : slot;
  }) };
}

const inputSlotSignature = slot => JSON.stringify([slot.key, slot.label, slot.section, slot.ordinal, slot.groupCount, slot.multiple, slot.required, slot.controlType, slot.apiCategoryId, slot.apiPropertyId]);
const inputCandidateSignature = candidate => JSON.stringify([candidate.kind, candidate.version, candidate.categoryId, candidate.propertyId, candidate.fieldKey,
  candidate.descriptor, candidate.controlTag, candidate.controlRole, candidate.apiFlags, candidate.responseComplete, candidate.scopeVerified,
  candidate.fieldAssociationVerified, candidate.valuesComplete, candidate.observedValueCount, candidate.declaredValueCount]);

// This observes a writable native entry only. It never types, opens a menu,
// creates a manufacturer or claims that a backend value has been committed.
export async function probeObservedInput(page, slot, candidate, context, { wait = sleep, signal, nowMs = () => Date.now() } = {}) {
  if (slot?.controlType !== 'text' || candidate?.fieldKey !== slot.key || candidate.categoryId !== context.categoryId
    || candidate.propertyId !== slot.apiPropertyId || slot.apiCategoryId !== context.categoryId
    || typeof page.readPublicInputCensus !== 'function' || typeof page.getDocumentFingerprint !== 'function' || !fingerprintValid(context.documentFingerprint)) return null;
  const deadline = nowMs() + 30000, samples = [];
  const check = () => { abort(signal); if (nowMs() >= deadline) throw Object.assign(new Error('输入控件核验超时，本次结果未保存。'), { code: 'SELLER_INPUT_READ_TIMEOUT' }); };
  const fresh = async () => { check(); const state = await page.snapshot(); check(); assertObservedScope(state, context); return state; };
  const initial = await fresh(), owner = observedOwner(initial, slot);
  if (!owner || owner.tag !== candidate.controlTag || owner.role !== candidate.controlRole || owner.expanded === true || owner.expanded === 'true'
    || /(?:^|\s)core-select-open(?:\s|$)/u.test(owner.uiHints?.className || '')) return null;
  check(); const startDocument = await page.getDocumentFingerprint(); check();
  if (startDocument !== context.documentFingerprint) throw observedScopeError();
  for (let sample = 0; sample < 3; sample++) {
    const state = await fresh(), current = observedOwner(state, slot, owner.selector);
    if (!current || current.tag !== candidate.controlTag || current.role !== candidate.controlRole || current.expanded === true || current.expanded === 'true'
      || /(?:^|\s)core-select-open(?:\s|$)/u.test(current.uiHints?.className || '')) throw observedScopeError();
    check(); const raw = await page.readPublicInputCensus(current.ref); check();
    if (raw?.accepted !== true) return null;
    if (raw.documentFingerprint !== context.documentFingerprint) throw observedScopeError();
    samples.push(raw); if (sample < 2) { await wait(100); check(); }
  }
  await fresh(); check(); const endDocument = await page.getDocumentFingerprint(); check();
  if (endDocument !== context.documentFingerprint) throw observedScopeError();
  const proof = buildObservedInputEvidence({ candidate, samples });
  const field = { ...slot, inputEvidence: proof.inputEvidence };
  if (proof.accepted !== true || !observedInputEvidenceMatches(field, context.categoryId)) return null;
  return { slotSignature: inputSlotSignature(slot), candidateSignature: inputCandidateSignature(candidate),
    attributeContext: context.attributeContext, documentFingerprint: context.documentFingerprint, field };
}

export function mergeObservedInputs(mapped, snapshot, cache, documentFingerprint) {
  if (mapped?.partialFieldsVerified !== true || !Array.isArray(cache) || !cache.length) return mapped;
  const context = attributeContextFingerprint(snapshot);
  return { ...mapped, fields: mapped.fields.map(slot => {
    const candidates = (mapped.inputCandidates || []).filter(candidate => candidate.fieldKey === slot.key);
    if (candidates.length !== 1) return slot;
    const candidate = candidates[0], matches = cache.filter(entry => entry.slotSignature === inputSlotSignature(slot)
      && entry.candidateSignature === inputCandidateSignature(candidate) && entry.attributeContext === context && entry.documentFingerprint === documentFingerprint);
    return matches.length === 1 && observedOwner(snapshot, slot) && observedInputEvidenceMatches(matches[0].field, candidate.categoryId) ? structuredClone(matches[0].field) : slot;
  }) };
}

// API-declared text drafts do not assert a native entry or a preset list. This
// is called only after the full mapping is stable and again on the independently
// verified final shop/category snapshot; any signature change discards the read.
export function mergeDefinitionInputDrafts(mapped, snapshot, documentFingerprint) {
  if (mapped?.partialFieldsVerified !== true || !fingerprintValid(documentFingerprint) || !Array.isArray(mapped.definitionInputDraftCandidates)) return mapped;
  return { ...mapped, fields: mapped.fields.map(slot => {
    const candidates = mapped.definitionInputDraftCandidates.filter(candidate => candidate.fieldKey === slot.key);
    if (candidates.length !== 1 || slot.controlType !== 'text' || slot.optionsComplete !== false || slot.options?.length !== 0) return slot;
    const candidate = candidates[0], owner = observedOwner(snapshot, slot);
    if (!owner || owner.tag !== candidate.controlTag || owner.role !== candidate.controlRole) return slot;
    const proof = buildCategoryDefinitionInputDraftEvidence({ candidate }), field = { ...slot, inputEvidence: proof.inputEvidence };
    return proof.accepted === true && observedInputEvidenceMatches(field, candidate.categoryId) ? field : slot;
  }) };
}

function safeDiagnostics(snapshot = {}, metadata = {}) {
  let hostname = clean(metadata.hostname);
  if (!hostname) try { hostname = new URL(snapshot.url).hostname; } catch { /* No page or a normal non-URL load state. */ }
  const pageTitle = clean(metadata.title || snapshot.title).replace(/(?:https?|wss?):\/\/\S+/giu, '[url]')
    .replace(/(?:token|secret|password|api[_ -]?key|cookie|authorization)\s*[:=]\s*\S+/giu, '[redacted]').slice(0, 160);
  return { pageTitle, hostname: /^[a-z0-9.-]{0,253}$/iu.test(hostname) ? hostname : '',
    categoryControlCount: (snapshot.controls || []).filter(categoryControl).length,
    shopIdFound: !!snapshot.identity?.shopId, shopNameFound: !!snapshot.identity?.shopName, regionFound: !!snapshot.identity?.region };
}
function failureReason(snapshot = {}, error, binding) {
  if (snapshot.securityChallenge?.detected || error?.code === 'SELLER_SECURITY_VERIFICATION') return 'security_verification_required';
  if (error?.code === 'SELLER_LOGIN_REQUIRED' || /登录|Log in|Sign in/iu.test(snapshot.title || '') && !snapshot.identity?.shopId) return 'login_required';
  if (error?.code === 'SELLER_IDENTITY_NOT_READY') return 'identity_not_ready';
  if (error?.code === 'SELLER_SHOP_MENU_BLOCKED') return 'shop_menu_blocked';
  if (error?.code === 'SELLER_PAGE_NOT_READY') return 'page_not_ready';
  if (error?.code === 'SELLER_GUIDANCE_BLOCKED') return 'product_guidance_blocked';
  if (error?.code === 'SELLER_CATEGORY_DISABLED') return 'category_unavailable';
  if (error?.code === 'SELLER_IDENTITY_MISMATCH') return 'identity_mismatch';
  if (error) return 'browser_read_failed';
  if(pairedProfileBinding(binding)&&snapshot.identity?.shopName&&snapshot.identity?.region)return compareShopIdentity(snapshot.identity,binding).length?'identity_mismatch':'category_read_incomplete';
  return !snapshot.identity?.shopId || !snapshot.identity?.shopName || !snapshot.identity?.region ? 'identity_missing' : 'category_read_incomplete';
}

export function sellerDescriptionText(value) {
  const source = String(value ?? '');
  if (!/<\/?(?:p|div|br|ul|ol|li|strong|b|em|i|u|span)\b/iu.test(source)) return source;
  return source.replace(/<(script|style|iframe)\b[^>]*>[\s\S]*?<\/\1\s*>/giu, '').replace(/<br\s*\/?>|<\/(?:p|div|li|ul|ol)\s*>/giu, '\n')
    .replace(/<[^>]*>/gu, '').replace(/&(?:amp|quot|apos|lt|gt|nbsp|#\d+|#x[\da-f]+);/giu, entity => {
      const body = entity.slice(1, -1).toLowerCase(), named = { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' };
      if (body[0] !== '#') return named[body];
      const number = body[1] === 'x' ? Number.parseInt(body.slice(2), 16) : Number.parseInt(body.slice(1), 10);
      return number > 0 && number <= 0x10ffff && !(number >= 0xd800 && number <= 0xdfff) ? String.fromCodePoint(number) : '';
    }).trim();
}

const pairedProfileBinding=binding=>!!binding&&binding.profileStatus==='ready'&&(binding.verificationStatus===undefined||binding.verificationStatus==='verified')&&typeof binding.environmentId==='string'&&binding.environmentId.length>0
  &&binding.mainCategory?.source==='seller-profile'&&typeof binding.mainCategory.label==='string'&&clean(binding.mainCategory.label)
  &&Array.isArray(binding.mainCategory.path)&&binding.mainCategory.path.length===1&&binding.mainCategory.path[0]===binding.mainCategory.label;
const pairedIdentityEvidence=(binding,actual)=>pairedProfileBinding(binding)&&actual?.shopName&&actual?.region&&!compareShopIdentity(actual,binding).length
  ?{version:1,source:'visible-product-page-paired-profile',environmentId:binding.environmentId,shopName:clean(actual.shopName),region:actual.region,
    shopCodeObserved:!!actual.shopId,shopMenuClosed:true,...(actual.shopId?{observedShopId:actual.shopId,...(actual.idKind?{observedIdKind:actual.idKind}:{})}:{})}:null;

export function compareShopIdentity(actual = {}, binding = {}) {
  const paired=pairedProfileBinding(binding);
  binding = binding?.identity || binding || {};
  const issues = [];
  const environmentProfile = binding.idKind === 'profile-environment';
  if (!actual.shopId && !environmentProfile && !paired) issues.push('页面没有可见店铺 ID，不能确认目标店铺。');
  if (!actual.shopName) issues.push('页面没有可见店铺名称。');
  if (!actual.region) issues.push('页面没有可核实的销售地区。');
  if (!environmentProfile && binding.shopId && (!paired || actual.shopId) && !same(actual.shopId, binding.shopId)) issues.push('当前浏览器店铺 ID 与绑定店铺不一致。');
  if (binding.shopName && !same(actual.shopName, binding.shopName)) issues.push('当前浏览器店铺名称与绑定店铺不一致。');
  if (binding.region && !same(actual.region, binding.region)) issues.push('当前浏览器销售地区与绑定店铺不一致。');
  if (!environmentProfile && binding.idKind && actual.idKind && binding.idKind !== actual.idKind) issues.push('当前店铺标识类型与绑定记录不一致。');
  return issues;
}

async function waitReady(page, wait, signal, observe = () => {}, nowMs = () => Date.now(), deadlineMs) {
  let guidanceEscapes = 0, guidanceCloses = 0, guidanceBlocked = false, guideFrameRecovered = false;
  let stable = 0, previous = '', guidanceFramesSinceAction = 0, closeStable = 0, previousClose = '', guideSamples = 0, guideStarted = null;
  const deadline = Number.isFinite(deadlineMs) ? deadlineMs : nowMs() + 60000;
  const pause = async ms => { abort(signal); const remaining = deadline - nowMs(); if (remaining > 0) await wait(Math.min(ms, remaining)); abort(signal); };
  for (let attempt = 0; attempt < 300 && nowMs() < deadline; attempt++) {
    abort(signal); const snapshot = await page.snapshot(); observe(snapshot); abort(signal);
    if (snapshot.loading && snapshot.url === 'about:blank') { await pause(250); continue; }
    assertSellerUrl(snapshot.url);
    if (snapshot.securityChallenge?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
    if (nowMs() >= deadline) break;
    const guidance = (snapshot.guidanceDialogs || []).filter(item => item.kind === 'image-to-draft');
    if (guidance.length) {
      guidanceBlocked = true;
      if (guideStarted === null) guideStarted = nowMs();
      if (++guideSamples > 150 || nowMs() - guideStarted >= 30000) break;
      stable = 0; previous = '';
      if (!guidanceEscapes++) { await page.press('Escape'); guidanceFramesSinceAction = 0; await pause(200); continue; }
      const closeRefs = [...new Set(guidance.flatMap(item => item.closeRefs || []))];
      const close = closeRefs.length === 1 ? snapshot.controls.find(item => item.ref === closeRefs[0] && !item.disabled) : null;
      if (!closeRefs.length && !guideFrameRecovered && page.recoverReadFrame) {
        guideFrameRecovered = true; await page.recoverReadFrame('guide'); await pause(150); continue;
      }
      const closeShape = close ? JSON.stringify([close.selector, close.bounds]) : '';
      closeStable = closeShape && closeShape === previousClose ? closeStable + 1 : 0; previousClose = closeShape;
      guidanceFramesSinceAction++;
      if (close && closeStable >= 2 && guidanceFramesSinceAction >= 5 && guidanceCloses < 4) {
        guidanceCloses++; guidanceFramesSinceAction = 0; closeStable = 0; previousClose = '';
        try { if (typeof page.dismissProductGuide === 'function') await page.dismissProductGuide(close.ref); else await page.click(close.ref); }
        catch (error) { if (!['SELLER_CONTROL_OBSCURED', 'SELLER_GUIDE_CLOSE_STALE'].includes(error.code)) throw error; }
        await pause(200); continue;
      }
      await pause(200); continue;
    }
    guidanceBlocked = false;
    if (!snapshot.busy && (snapshot.controls?.some(categoryControl) || /商品名称|Product name|Product title/iu.test(snapshot.text || ''))) {
      const shape = JSON.stringify({ controls: snapshot.controls?.map(item => [item.selector, item.label, item.role, item.bounds]), panes: snapshot.scrollables });
      stable = shape === previous ? stable + 1 : 0; previous = shape;
      if (stable >= 4) return snapshot;
    } else { stable = 0; previous = ''; }
    if (/登录|Log in|Sign in/iu.test(snapshot.title || '') && !snapshot.identity?.shopId) return snapshot;
    await pause(250);
  }
  throw Object.assign(new Error(guidanceBlocked ? '商品图片草稿引导尚未关闭，需要人工关闭后重试。' : '商品编辑页面未能载入，可能需要重新登录或人工处理验证。'), { code: guidanceBlocked ? 'SELLER_GUIDANCE_BLOCKED' : 'SELLER_PAGE_NOT_READY' });
}

const shopReadMessages = {
  login_required: '当前 AdsPower 环境需要重新登录 TikTok 后再同步商品草稿。',
  security_verification_required: '当前商品页需要安全验证，请在对应 AdsPower 环境完成人工验证后重试。',
  product_guidance_blocked: '商品页被“上传图片即可生成草稿”引导层遮挡，请在对应 AdsPower 环境关闭该引导后重试。',
  page_not_ready: '商品编辑页在等待期限内仍未就绪，请检查店铺网络和页面加载状态后重试。',
  identity_not_ready: '商品页的店铺名称或地区在等待期限内仍未完整显示，请等待页面加载完成后重试。',
  identity_missing: '当前商品页未完整显示可核验的店铺信息，请确认页面加载和登录状态后重试。',
  identity_mismatch: '当前商品页显示的店铺与已配对店铺不一致，已停止本次同步。',
  shop_menu_blocked: '店铺信息菜单仍遮挡商品页，请在对应 AdsPower 环境关闭菜单后重试。',
  not_official_page: '当前环境未能打开 TikTok 官方商品页，请检查该环境网络与登录状态后重试。',
  browser_read_failed: '读取 AdsPower 浏览器页面失败，请确认对应环境仍在运行并检查浏览器连接后重试。',
};
function shopReadFailure(snapshot, error, binding) {
  let reasonCode = failureReason(snapshot, error, binding);
  const diagnostics = safeDiagnostics(snapshot);
  if (diagnostics.hostname) try { assertSellerUrl('https://' + diagnostics.hostname + '/'); } catch { reasonCode = 'not_official_page'; }
  if (!Object.hasOwn(shopReadMessages, reasonCode)) reasonCode = 'browser_read_failed';
  return { reasonCode, diagnostics, issues: [shopReadMessages[reasonCode]] };
}
function observedShopConflict(actual, binding) {
  const expected = binding?.identity || binding || {};
  return !!(actual?.shopName && expected.shopName && !same(actual.shopName, expected.shopName)
    || actual?.region && expected.region && !same(actual.region, expected.region)
    || expected.idKind !== 'profile-environment' && actual?.shopId && expected.shopId && !same(actual.shopId, expected.shopId)
    || expected.idKind !== 'profile-environment' && actual?.shopId && actual.idKind && expected.idKind && actual.idKind !== expected.idKind);
}
/** Body readiness and identity hydration share one deadline. Never fill gaps from the saved binding. */
async function waitPairedShopIdentity(page, initial, wait, { signal, nowMs, deadline, binding, observe = () => {} }) {
  let snapshot = initial, stable = 0, previous = '';
  for (let sample = 0; sample < 300 && nowMs() < deadline; sample++) {
    abort(signal); observe(snapshot); assertReadSnapshotSafety(snapshot);
    if (/登录|Log in|Sign in/iu.test(snapshot.title || '') && !snapshot.identity?.shopId)
      throw Object.assign(new Error(shopReadMessages.login_required), { code: 'SELLER_LOGIN_REQUIRED' });
    if (observedShopConflict(snapshot.identity, binding))
      throw Object.assign(new Error(shopReadMessages.identity_mismatch), { code: 'SELLER_IDENTITY_MISMATCH' });
    if ((snapshot.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) {
      stable = 0; previous = '';
      snapshot = await waitReady(page, wait, signal, observe, nowMs, deadline);
      continue;
    }
    const shape = JSON.stringify(snapshot.identity || {});
    if (!snapshot.busy && !compareShopIdentity(snapshot.identity || {}, binding).length) {
      stable = shape === previous ? stable + 1 : 1;
      if (stable >= 3) return snapshot;
    } else stable = 0;
    previous = shape;
    const remaining = deadline - nowMs();
    if (remaining <= 0) break;
    await wait(Math.min(250, remaining)); abort(signal);
    snapshot = await page.snapshot();
  }
  throw Object.assign(new Error(shopReadMessages.identity_not_ready), { code: 'SELLER_IDENTITY_NOT_READY' });
}

async function waitProfileReady(page, wait, signal, observe, nowMs) {
  if (typeof page.profileSnapshot !== 'function') return waitReady(page, wait, signal, observe, nowMs);
  const deadline = nowMs() + 60000; let stable = 0, previous = '';
  for (let attempt = 0; attempt < 300 && nowMs() < deadline; attempt++) {
    abort(signal); const snapshot = await page.profileSnapshot(); observe(snapshot); abort(signal);
    if(snapshot.loading&&snapshot.url==='about:blank'){await wait(250);continue;}
    assertReadSnapshotSafety(snapshot);
    const path = new URL(snapshot.url);
    if (path.pathname !== '/profile/seller-profile-v2') throw new Error('店铺配对页面已跳转，请确认店铺登录。');
    if (/登录|Log in|Sign in/iu.test(snapshot.title || '')) throw Object.assign(new Error('请先登录对应店铺。'), { code: 'SELLER_LOGIN_REQUIRED' });
    const shape = JSON.stringify([snapshot.identity, snapshot.mainCategory]);
    if (snapshot.profileComplete === true && snapshot.identity?.shopName && snapshot.mainCategory?.label) {
      stable = shape === previous ? stable + 1 : 0;
      if (stable >= 3) return snapshot;
    } else stable = 0;
    previous = shape; await wait(250);
  }
  throw Object.assign(new Error('商家主页基础信息尚未完整载入，请确认登录和主营类目。'), { code: 'SELLER_PROFILE_NOT_READY' });
}

export async function readShopSnapshot(page, wait, supplied, retry = 0, attempts = { domOpens: 0 }, readiness = {}) {
  // Re-observe readiness immediately before opening the shop menu. Seller onboarding
  // can mount after the initial page text has already rendered.
  const nowMs = readiness.nowMs || (() => Date.now()), deadline = Number.isFinite(readiness.deadline) ? readiness.deadline : nowMs() + 60000;
  let before = await waitReady(page, wait, readiness.signal, readiness.observe, nowMs, deadline);
  if (pairedProfileBinding(readiness.binding)) before = await waitPairedShopIdentity(page, before, wait, { ...readiness, nowMs, deadline });
  const completeIdentity = !!(before.identity?.shopId && before.identity?.shopName && before.identity?.region);
  const menuIsOpen = state => state.shopIdentityMenuVisible === true || (state.shopMenuShells || []).some(item => item.containsShopName && item.hasIdentityMarker);
  const paired=pairedProfileBinding(readiness.binding);
  if(paired){
    assertReadSnapshotSafety(before);
    // A profile pair anchors the fixed AdsPower environment, while this owned
    // product page still has to show its genuine current name and region.
    // Never open the header merely to rediscover an optional visible code.
    if(compareShopIdentity(before.identity||{},readiness.binding).length)return before;
    const open=state=>menuIsOpen(state)||(state.shopPopoverState?.paintedCount||0)>0||state.shopPopoverState?.truncated===true;
    if(!open(before))return before;
    const expectedName=clean((readiness.binding.identity||readiness.binding).shopName);
    const closeCandidates=state=>(state.controls||[]).filter(item=>item.role==='button'&&!item.disabled&&(state.shopTriggers||[]).includes(item.ref)&&same(item.text||item.label,expectedName));
    const candidates=closeCandidates(before);
    if(candidates.length!==1||typeof page.closeObservedShopMenu!=='function')throw Object.assign(new Error('店铺信息菜单仍打开，但关闭入口不能唯一确认。'),{code:'SELLER_SHOP_MENU_BLOCKED'});
    await page.closeObservedShopMenu(candidates[0].ref);let closedStable=0;
    for(let sample=0;sample<20;sample++){
      abort(readiness.signal);await wait(150);const current=await page.snapshot();assertReadSnapshotSafety(current);
      if(compareShopIdentity(current.identity||{},readiness.binding).length)throw Object.assign(new Error('当前商品页店铺名称、地区或可见代码与已配对店铺不一致。'),{code:'SELLER_IDENTITY_MISMATCH'});
      closedStable=open(current)?0:closedStable+1;
      if(closedStable>=3)return current;
    }
    throw Object.assign(new Error('店铺信息菜单尚未确认关闭，未继续选择商品类目。'),{code:'SELLER_SHOP_MENU_BLOCKED'});
  }
  if (completeIdentity && !menuIsOpen(before)) return before;
  const shopCandidates = state => {
  const buttons = state.controls.filter(item => item.role === 'button' && !item.disabled);
  const explicit = buttons.filter(item => (state.shopTriggers || []).includes(item.ref));
  const candidates = explicit.length ? explicit : buttons.filter(item =>
    /^(店铺信息|店铺名称|店铺选择|当前店铺|Shop information|Shop name|Select shop|Current shop)$/iu.test(clean(item.label || item.text))
    || state.identity?.shopName && same(item.label || item.text, state.identity.shopName));
  // Nested nodes can both expose button semantics for the same visible capsule.
  // Collapse only equal-name aliases whose observed rectangles contain each other.
  return candidates.filter((item, index) => !candidates.some((other, otherIndex) => {
    if (item === other || !same(item.text || item.label, other.text || other.label)) return false;
    const a = other.bounds, b = item.bounds;
    if (!a || !b || ![a.x, a.y, a.width, a.height, b.x, b.y, b.width, b.height].every(Number.isFinite)) return false;
    const contains = a.x <= b.x + 1 && a.y <= b.y + 1 && a.x + a.width >= b.x + b.width - 1 && a.y + a.height >= b.y + b.height - 1;
    return contains && (a.width * a.height > b.width * b.height + 1 || otherIndex < index && Math.abs(a.width * a.height - b.width * b.height) <= 1);
  }));
  };
  const candidates = shopCandidates(before);
  if (candidates.length !== 1) {
    if (completeIdentity && menuIsOpen(before)) throw Object.assign(new Error('店铺信息菜单仍打开，但关闭入口不能唯一确认。'), { code: 'SELLER_SHOP_MENU_BLOCKED' });
    return before;
  }
  const noteMenu = (state, phase, sample) => page.noteShopMenuObservation?.({ phase, sample, identityFound: !!state.identity?.shopId, menuVisible: state.shopIdentityMenuVisible === true, shells: state.shopMenuShells || [], rawPopover: state.shopPopoverState });
  const noMenu = state => !state.identity?.shopId && !state.shopIdentityMenuVisible && !(state.shopMenuShells || []).some(item => item.containsShopName || item.hasIdentityMarker)
    && !(state.shopPopoverState?.paintedCount > 0 || state.shopPopoverState?.truncated) && !state.securityChallenge?.detected && !(state.guidanceDialogs || []).some(item => item.kind === 'image-to-draft');
  const openDom = async ref => { if (attempts.domOpens >= 2) return false; attempts.domOpens++; await page.openObservedShopMenu(ref); return true; };
  try {
    if (completeIdentity && menuIsOpen(before)) {
      if (!page.closeObservedShopMenu) throw Object.assign(new Error('店铺信息菜单仍打开，缺少受控关闭操作。'), { code: 'SELLER_SHOP_MENU_BLOCKED' });
      await page.closeObservedShopMenu(candidates[0].ref); let closedStable = 0;
      for (let sample = 0; sample < 20; sample++) {
        await wait(150); const state = await page.snapshot(); noteMenu(state, 'close', sample);
        closedStable = menuIsOpen(state) ? 0 : closedStable + 1;
        if (closedStable >= 3) return { ...state, identity: before.identity };
      }
      throw Object.assign(new Error('店铺信息已读取，但菜单尚未确认关闭，未继续操作商品控件。'), { code: 'SELLER_SHOP_MENU_BLOCKED' });
    }
    let expanded;
    if (page.openObservedShopMenu && /(?:^|\s)ub-triggerContent-[\w-]+(?:\s|$)/u.test(candidates[0].uiHints?.className || '')) {
      if (!await openDom(candidates[0].ref)) return before;
      await wait(150); expanded = await page.snapshot(); noteMenu(expanded, 'click', 0);
    } else if (page.hover && (before.shopTriggers || []).includes(candidates[0].ref)) {
      await page.hover(candidates[0].ref); await wait(200); expanded = await page.snapshot();
      noteMenu(expanded, 'hover', 0);
      for (let sample = 0; sample < 5 && !expanded.identity?.shopId && !expanded.shopIdentityMenuVisible && !(expanded.guidanceDialogs || []).some(item => item.kind === 'image-to-draft'); sample++) {
        await wait(150); expanded = await page.snapshot();
        noteMenu(expanded, 'hover', sample + 1);
      }
      if ((expanded.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) {
        if (retry >= 2) throw Object.assign(new Error('商品草稿引导反复遮挡店铺信息。'), { code: 'SELLER_GUIDANCE_BLOCKED' });
        return readShopSnapshot(page, wait, expanded, retry + 1, attempts, readiness);
      }
      const menuChanged = expanded.identity?.shopId || expanded.shopIdentityMenuVisible === true;
      if (!menuChanged) expanded = null;
    }
    if (!expanded) {
      const current = await page.snapshot();
      if ((current.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) {
        if (retry >= 2) throw Object.assign(new Error('商品草稿引导反复遮挡店铺信息。'), { code: 'SELLER_GUIDANCE_BLOCKED' });
        return readShopSnapshot(page, wait, current, retry + 1, attempts, readiness);
      }
      const fresh = shopCandidates(current).filter(item => same(item.text || item.label, candidates[0].text || candidates[0].label));
      if (fresh.length !== 1 || before.identity?.shopName && current.identity?.shopName && !same(before.identity.shopName, current.identity.shopName)) throw Object.assign(new Error('店铺菜单控件已经变化，未能重新唯一确认同一店铺入口。'), { code: 'SELLER_SHOP_TRIGGER_STALE' });
      const target = fresh[0];
      await page.click(target.ref); await wait(200); expanded = await page.snapshot();
      noteMenu(expanded, 'click', 0);
      if ((expanded.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) {
        if (retry >= 2) throw Object.assign(new Error('商品草稿引导反复遮挡店铺信息。'), { code: 'SELLER_GUIDANCE_BLOCKED' });
        return readShopSnapshot(page, wait, expanded, retry + 1, attempts, readiness);
      }
    }
    // The menu's visible identity details may arrive after its shell. Keep observing
    // that read-only menu rather than treating a first empty frame as a final result.
    for (let sample = 0; sample < 12; sample++) {
      if ((expanded.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) {
        if (retry >= 2) throw Object.assign(new Error('商品草稿引导反复遮挡店铺信息。'), { code: 'SELLER_GUIDANCE_BLOCKED' });
        return readShopSnapshot(page, wait, expanded, retry + 1, attempts, readiness);
      }
      if (expanded.identity?.shopId && expanded.identity?.region && (expanded.identity?.shopName || before.identity?.shopName)) break;
      await wait(150); expanded = await page.snapshot();
      noteMenu(expanded, 'poll', sample + 1);
    }
    // Only the already observed shop capsule may receive this one read-only
    // fallback, and only while no identity menu/shell has appeared after input.
    if (page.openObservedShopMenu && attempts.domOpens < 2 && noMenu(expanded)) {
      let stable = 0, previous = '', target;
      for (let sample = 0; sample < 10 && stable < 5; sample++) {
        await wait(150); expanded = await page.snapshot(); noteMenu(expanded, 'recovery_check', sample);
        if (!noMenu(expanded)) break;
        const fresh = shopCandidates(expanded).filter(item => (expanded.shopTriggers || []).includes(item.ref) && same(item.text || item.label, candidates[0].text || candidates[0].label));
        if (fresh.length !== 1 || before.identity?.shopName && expanded.identity?.shopName && !same(before.identity.shopName, expanded.identity.shopName)) break;
        target = fresh[0]; const shape = JSON.stringify([target.tag, target.text || target.label, target.bounds, target.uiHints?.className, expanded.shopPopoverState]);
        stable = shape === previous ? stable + 1 : 0; previous = shape;
      }
      if (stable >= 5 && noMenu(expanded) && target && await openDom(target.ref)) {
        for (let sample = 0; sample < 30; sample++) {
          await wait(150); expanded = await page.snapshot(); noteMenu(expanded, 'poll', sample + 13);
          if (expanded.identity?.shopId || expanded.securityChallenge?.detected || (expanded.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) break;
        }
      }
    }
    const identity = { ...before.identity };
    for (const key of ['shopId', 'shopName', 'region', 'idKind', 'regionSource']) if (expanded.identity?.[key]) identity[key] = expanded.identity[key];
    if (identity.shopId && !identity.shopName && (before.shopTriggers || []).includes(candidates[0].ref)) identity.shopName = clean(candidates[0].text || candidates[0].label);
    // Leave an incomplete read-only identity menu visible for the optional failure
    // screenshot. The entire owned tab is closed after diagnostics are saved.
    if (!identity.shopId || !identity.shopName || !identity.region) return { ...expanded, identity };
    if (page.closeObservedShopMenu) {
      let current = await page.snapshot();
      const isOpen = state => state.shopIdentityMenuVisible === true || (state.shopMenuShells || []).some(item => item.containsShopName && item.hasIdentityMarker);
      if (isOpen(current)) {
        const fresh = shopCandidates(current).filter(item => (current.shopTriggers || []).includes(item.ref) && same(item.text || item.label, candidates[0].text || candidates[0].label));
        if (fresh.length !== 1 || (current.guidanceDialogs || []).some(item => item.kind === 'image-to-draft')) throw Object.assign(new Error('店铺菜单关闭入口未能唯一确认。'), { code: 'SELLER_SHOP_MENU_BLOCKED' });
        await page.closeObservedShopMenu(fresh[0].ref);
        let closedStable = 0;
        for (let sample = 0; sample < 20; sample++) {
          await wait(150); current = await page.snapshot(); noteMenu(current, 'close', sample);
          closedStable = !isOpen(current) ? closedStable + 1 : 0;
          if (closedStable >= 3) return { ...current, identity };
        }
        throw Object.assign(new Error('店铺信息已读取，但菜单尚未确认关闭，未继续操作商品控件。'), { code: 'SELLER_SHOP_MENU_BLOCKED' });
      }
      return { ...current, identity };
    }
    await page.press('Escape'); await wait(75); return { ...await page.snapshot(), identity };
  } catch (error) {
    if (['SELLER_CONTROL_OBSCURED', 'SELLER_CONTROL_STALE', 'SELLER_SHOP_TRIGGER_STALE'].includes(error.code) && retry < 2) return readShopSnapshot(page, wait, undefined, retry + 1, attempts, readiness);
    throw error;
  }
}

async function closeReadPopup(page, kind, wait, signal) {
  if (!page.closeReadPopup) { await page.press('Escape'); await wait(75); return; }
  await page.closeReadPopup(kind); let stable = 0;
  for (let sample = 0; sample < 20; sample++) {
    abort(signal); const state = await page.snapshot();
    const open = kind === 'category' ? (state.categoryColumns || []).length > 0 : (state.optionLists || []).length > 0;
    stable = !open ? stable + 1 : 0;
    if (stable >= 3) return;
    await wait(100);
  }
  throw new Error('只读下拉菜单尚未确认关闭，未继续读取其他字段。');
}

export async function optionsFor(page, control, wait, signal, { keepIncompleteOpen = false, readOnly = false, onProgress = () => {}, emptyCustomMode, customSelectMode } = {}) {
  const maxOptionCount = 10000, optionLimitReason = '实际选项超过本次支持的10000项，未能证明完整。';
  if (Array.isArray(control.options)) {
    let previous = '', stable = 0, options = [];
    for (let step = 0; step < 12; step++) {
      abort(signal); const state = await page.snapshot(), actual = state.controls.find(item => item.selector === control.selector);
      if (!Array.isArray(actual?.options) || actual.disabled) return { options, complete: false, reason: '原生下拉控件已变化或不可用。' };
      options = [];
      for (const item of actual.options) if (item.value !== '' && clean(item.label)) {
        if (options.length >= maxOptionCount) return { options, complete: false, reason: optionLimitReason };
        options.push(item);
      }
      const fingerprint = JSON.stringify(options);
      onProgress(options.length);
      if (new Set(options.map(item => item.value)).size !== options.length) return { options, complete: false, reason: '原生下拉存在重复且无法区分的选项值。' };
      if (!state.busy && fingerprint === previous && options.length) stable++; else stable = 0;
      previous = fingerprint;
      if (stable >= 3) return { options, complete: true, evidence: { kind: 'native-select', stableSamples: stable + 1, optionCount: options.length } };
      await wait(200);
    }
    return { options, complete: false, reason: '原生下拉选项尚未静稳。' };
  }
  if(!readOnly&&['text','number'].includes(customSelectMode)){if(typeof page.openCustomSelectPopup!=='function')return {options:[],complete:false,reason:'自定义下拉缺少受信打开动作。'};await page.openCustomSelectPopup(control.ref);}
  else if (readOnly && page.clickReadControl) await page.clickReadControl(control.ref, 'attribute-trigger'); else await page.click(control.ref);
  await wait(200);
  const found = new Map(), seenAll = new Set(), positions = new Map(), keyPositions = new Map(), valueKeys = new Map(), availability = new Map(); let complete = false, reason = '下拉列表达到读取上限，未能证明完整。', stable = 0, previous = '', root = '', pane = '', listIdentity = '', visitedTop = false, requested, stalled = 0, moreClicks = 0, evidence, frameRecovered = false, stepBudget = 100;
  const absoluteStepLimit = 10000, settlingAllowance = 32;
  try {
    for (let step = 0; step < stepBudget && step < absoluteStepLimit; step++) {
      abort(signal); const snapshot = await page.snapshot();
      let lists = (snapshot.optionLists || []).filter(item => item.height > 0 && item.scrollHeight >= item.height - 2);
      if (control.listIds?.length) lists = lists.filter(item => control.listIds.includes(item.id) || control.listIds.some(id => item.containerSelector === '#' + id || item.relatedListIds?.includes(id)) || ['text','number'].includes(customSelectMode)&&item.customOwnerInstanceId===control.instanceId);
      if (lists.length !== 1) {
        if (!lists.length && !root && !frameRecovered && readOnly && page.recoverReadFrame) { frameRecovered = true; await page.recoverReadFrame('attribute'); await wait(150); continue; }
        if (!lists.length && !root && step < 12) { await wait(200); continue; }
        reason = lists.length ? '存在多个下拉列表，无法确定当前属性的选项容器。' : '没有可见且可验证的下拉列表容器。'; break;
      }
      const list = lists[0];
      if (![list.top, list.height, list.scrollHeight].every(Number.isFinite)) { reason = '下拉列表滚动尺寸不可验证。'; break; }
      if (root && root !== list.containerSelector) { reason = '下拉选项容器在读取过程中发生变化。'; break; }
      if (pane && pane !== list.selector) { reason = '下拉列表滚动区域在读取过程中发生变化。'; break; }
      const identity = JSON.stringify([list.id || '', [...(list.relatedListIds || [])].sort()]);
      if (listIdentity && listIdentity !== identity) { reason = '下拉列表身份在读取过程中发生变化。'; break; }
      root = list.containerSelector; pane = list.selector; listIdentity = identity;
      const traversalSteps = Math.ceil(Math.max(0, list.scrollHeight - list.height) / Math.max(10, list.height * .75));
      stepBudget = Math.min(absoluteStepLimit, Math.max(stepBudget, traversalSteps + settlingAllowance));
      if (list.moreControlCount > 1 || list.moreAmbiguous) { reason = '存在多个加载更多控件，不能确认选项读取完整。'; break; }
      if (list.busy || snapshot.busy) { reason = '下拉列表仍在加载，未能证明完整。'; stable = 0; previous = ''; await wait(200); continue; }
      if (list.countConflict) { reason = '下拉列表声明的选项总数相互冲突。'; break; }
      if (requested) {
        if (Math.abs(list.top - requested.from) < 1 && Math.abs(list.scrollHeight - requested.height) < 2) stalled++; else stalled = 0;
        requested = undefined;
        if (stalled >= 3) { reason = '下拉列表滚动未前进，不能确认遍历完成。'; break; }
      }
      if (!visitedTop) {
        if (list.top > 1) {
          if (!(snapshot.scrollables || []).some(item => item.selector === list.selector)) { reason = '下拉列表不能复位到顶部。'; break; }
          await page.scroll(list.selector, 0); await wait(200); continue;
        }
        visitedTop = true;
      }
      const current = snapshot.controls.filter(item => list.optionRefs.includes(item.ref) && ['option', 'treeitem', 'menuitem'].includes(item.role));
      const currentKeys = new Set(); let ambiguous = false, overOptionLimit = false;
      for (const item of current) {
        const label = clean(item.text || item.label), value = clean(item.value) || label;
        if (!label || /^(请选择|Select|No data|暂无数据)$/iu.test(label)) continue;
        const key = value + '\0' + label;
        if (!seenAll.has(key) && seenAll.size >= maxOptionCount) { overOptionLimit = true; reason = optionLimitReason; break; }
        const enabled = !item.disabled;
        if (availability.has(key) && availability.get(key) !== enabled) { reason = '选项可用状态在读取过程中发生变化，不能确认列表静稳。'; ambiguous = true; break; }
        availability.set(key, enabled);
        if (currentKeys.has(key)) ambiguous = true; currentKeys.add(key); seenAll.add(key);
        if (clean(item.value)) { if (valueKeys.has(value) && valueKeys.get(value) !== key) ambiguous = true; valueKeys.set(value, key); }
        if (Number.isInteger(item.posInSet) && item.posInSet > 0) {
          if (positions.has(item.posInSet) && positions.get(item.posInSet) !== key || keyPositions.has(key) && keyPositions.get(key) !== item.posInSet) ambiguous = true;
          positions.set(item.posInSet, key); keyPositions.set(key, item.posInSet);
        }
        if (!item.disabled) found.set(key, { value, label });
      }
      if (overOptionLimit) break;
      if (ambiguous) { if (!reason.startsWith('选项可用状态')) reason = '当前选项有无法区分的重复值。'; break; }
      onProgress(found.size);
      const bottom = Math.max(0, list.scrollHeight - list.height), atBottom = list.top >= bottom - 2;
      if (!atBottom) {
        stable = 0; previous = '';
        if (!(snapshot.scrollables || []).some(item => item.selector === list.selector)) { reason = '下拉列表有未显示的选项，但滚动容器不可操作。'; break; }
        const next = Math.min(bottom, list.top + Math.max(10, list.height * .75));
        requested = { from: list.top, height: list.scrollHeight }; await page.scroll(list.selector, next); await wait(200); continue;
      }
      if (list.moreRef) {
        stable = 0; previous = '';
        if (++moreClicks > 20) { reason = '加载更多选项达到本次读取上限。'; break; }
        await page.click(list.moreRef); await wait(250); continue;
      }
      const fingerprint = JSON.stringify({ keys: [...seenAll].sort(), visible: [...currentKeys].sort(), top: list.top, height: list.height, scrollHeight: list.scrollHeight, totalCount: list.totalCount ?? null });
      stable = fingerprint === previous ? stable + 1 : 0; previous = fingerprint;
      if (stable >= 3) {
        if (!found.size) {
          const actual=snapshot.controls.find(item=>item.selector===control.selector&&item.instanceId===control.instanceId);
          if(!readOnly&&['text','number'].includes(emptyCustomMode)&&typeof page.inspectCustomSelectPopup==='function'&&actual&&!seenAll.size&&!list.virtual&&!list.moreRef&&!list.countConflict&&(list.totalCount===null||list.totalCount===0)){
            const custom=await page.inspectCustomSelectPopup(actual.ref,emptyCustomMode);
            if(custom?.accepted===true&&custom.instanceId===control.instanceId){complete=true;reason='';evidence={kind:'source-empty-custom-select',stableSamples:stable+1,observedOptionCount:0};break;}
          }
          reason = '没有可用的实际选项。'; break;
        }
        if (Number.isInteger(list.totalCount) && list.totalCount > 0 && seenAll.size !== list.totalCount) { reason = '已遍历数量与可见声明的选项总数不一致。'; break; }
        if (positions.size && (positions.size !== seenAll.size || [...positions.keys()].sort((a, b) => a - b).some((position, index) => position !== index + 1))) { reason = '选项序号存在缺口或重复，不能确认完整。'; break; }
        if (list.virtual && bottom <= 2 && !Number.isInteger(list.totalCount)) { reason = '虚拟列表没有可验证的总数或滚动终点。'; break; }
        complete = true; reason = ''; evidence = { kind: list.virtual ? 'virtual-list' : 'visible-list', visitedTop, visitedBottom: true, stableSamples: stable + 1, observedOptionCount: seenAll.size, selectableOptionCount: found.size, declaredTotalCount: list.totalCount ?? null }; break;
      }
      await wait(200);
    }
  } finally { if (complete || !keepIncompleteOpen) { if (readOnly) await closeReadPopup(page, 'attribute', wait, signal); else if(['text','number'].includes(customSelectMode)){
    const state=await page.snapshot(),actual=state.controls.find(item=>item.selector===control.selector&&item.instanceId===control.instanceId);
    if((state.optionLists||[]).length){if(!actual||typeof page.closeCustomSelectPopup!=='function')throw Error('自定义下拉关闭方式或实际字段尚未确认。');const closed=await page.closeCustomSelectPopup(actual.ref,customSelectMode);if(closed?.accepted!==true||closed.closed!==true||closed.instanceId!==control.instanceId)throw Error('自定义下拉未确认关闭。');}
  }else { await page.press('Escape'); await wait(75); } } }
  return { options: [...found.values()], complete, reason, evidence };
}

async function expandAttributeSections(page, wait, signal, observe = () => {}, readOnly = false) {
  const isExpansion = item => item.role === 'button' && item.expanded !== 'true'
    && /^(?:展开(?:全部|所有|更多)?(?:商品)?属性|更多(?:商品)?属性|(?:展开)?可选属性(?:\s*[（(]?\d+[）)]?)?|显示选填属性|显示更多(?:属性)?|Show (?:more|all)(?: attributes)?|Optional attributes)$/iu.test(clean(item.text || item.label));
  const pagePanes = state => (state.scrollables || []).filter(item => item.kind === 'page' || item.selector === ':root');
  const reset = async () => {
    for (let step = 0; step < 20; step++) {
      abort(signal); const state = await page.snapshot(), pane = pagePanes(state).find(item => item.top > 1);
      if (!pane) return;
      await page.scroll(pane.selector, 0); await wait(150);
    }
    throw new Error('属性页面不能复位到顶部，无法确认读取完整。');
  };
  await reset();
  let stable = 0, previous = '', pending, stagnant = 0, clicks = 0, optionalPending = false;
  for (let step = 0; step < 180; step++) {
    abort(signal); const state = await page.snapshot();
    if (state.busy) { stable = 0; previous = ''; await wait(200); continue; }
    observe(state);
    if (optionalPending) {
      const ready = state.controls.some(item => editable(item) && clean(item.section) === '可选属性') || (state.attributeGroups || []).some(group => group.kind === '可选属性' && group.expanded === true && group.candidateControlCount > 0)
        || state.attributeGroupTotals?.['可选属性'] === 0;
      if (!ready) { await wait(200); continue; }
      optionalPending = false;
    }
    const shape = JSON.stringify({ controls: state.controls.map(item => [item.selector, item.label, item.expanded]), panes: pagePanes(state) });
    if (pending) {
      if (shape === pending) stagnant++; else stagnant = 0;
      pending = null;
      if (stagnant >= 3) throw new Error('可选属性没有确认展开，或属性页面滚动未前进。');
    }
    const button = state.controls.find(isExpansion);
    if (button) {
      if (button.disabled) throw new Error('可选属性展开按钮尚不可用。');
      if (++clicks > 30) throw new Error('可选属性展开达到读取上限，无法确认完整。');
      stable = 0; previous = ''; pending = shape;
      if (readOnly) {
        if (!page.clickReadControl || clean(button.text || button.label) !== '显示选填属性') throw new Error('尚未验证这个属性展开控件的只读操作，未执行通用点击。');
        optionalPending = true; await page.clickReadControl(button.ref, 'show-optional');
      } else await page.click(button.ref);
      await wait(200); continue;
    }
    const pane = pagePanes(state).find(item => item.top + item.height < item.scrollHeight - 2);
    if (pane) {
      stable = 0; previous = ''; pending = shape;
      await page.scroll(pane.selector, Math.min(pane.scrollHeight - pane.height, pane.top + Math.max(10, pane.height * .75))); await wait(200); continue;
    }
    stable = shape === previous ? stable + 1 : 0; previous = shape;
    if (stable >= 3) { await reset(); return; }
    await wait(200);
  }
  throw new Error(optionalPending ? '选填展开已触发，但真实可选属性分组或字段尚未确认就绪。' : '属性展开或页面加载达到读取上限，无法确认完整。');
}

async function selectPath(page, categoryPath, wait, signal, requireAttributes = false, nowMs = () => Date.now(), readIdentity = null, allowPrefix = false) {
  if (typeof categoryPath === 'string') categoryPath = categoryPath.split(/\s*>\s*/u).filter(Boolean);
  if (!Array.isArray(categoryPath) || !allowPrefix && !categoryPath.length || categoryPath.some(item => typeof item !== 'string' || !clean(item))) throw new Error('需要完整的实际类目路径。');
  let snapshot = await page.snapshot(), candidates = snapshot.controls.filter(categoryControl);
  if (!candidates.length) {
    const reset = new Set(), positions = new Set(); let stable = 0, previous = '';
    for (let step = 0; step < 100; step++) {
      abort(signal); snapshot = await page.snapshot();
      if (snapshot.busy) { await wait(200); continue; }
      candidates = snapshot.controls.filter(categoryControl); if (candidates.length) break;
      const panes = (snapshot.scrollables || []).filter(item => item.kind === 'page' || item.selector === ':root');
      const unreset = panes.find(item => item.top > 1 && !reset.has(item.selector));
      if (unreset) { reset.add(unreset.selector); await page.scroll(unreset.selector, 0); await wait(200); continue; }
      for (const pane of panes) reset.add(pane.selector);
      const pane = panes.find(item => item.top + item.height < item.scrollHeight - 2);
      if (pane) {
        const top = Math.min(pane.scrollHeight - pane.height, pane.top + Math.max(10, pane.height * .75)), key = pane.selector + '\0' + top;
        if (positions.has(key)) throw new Error('寻找类目时页面滚动未前进，无法确认商品类目控件。');
        positions.add(key); await page.scroll(pane.selector, top); await wait(200); continue;
      }
      const shape = JSON.stringify({ controls: snapshot.controls.map(item => [item.selector, item.label]), panes });
      stable = shape === previous ? stable + 1 : 0; previous = shape;
      if (stable >= 3) break; await wait(200);
    }
  }
  if (candidates.length !== 1) throw new Error('无法唯一确定商品类目控件。');
  const control = candidates[0];
  if (control.tag === 'select') {
    const expected = categoryPath.join(' > '), option = control.options?.find(item => same(item.label, expected));
    if (!option) throw new Error('实际类目控件中没有所选路径。');
    await page.choose(control.ref, option.value); await wait(250); return;
  }
  if (requireAttributes && page.clickReadControl) await page.clickReadControl(control.ref, 'category-trigger'); else await page.click(control.ref);
  await wait(150);
  for (const [level, label] of categoryPath.entries()) {
    let match, nativeMatch = false, columnFramePrepared = false, previous = '', stable = 0, frameRecovered = false; const positions = new Set(), started = Date.now();
    for (let step = 0; step < 150 && Date.now() - started < 30000; step++) {
      abort(signal); snapshot = await page.snapshot();
      if (snapshot.securityChallenge?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
      const columns = snapshot.categoryColumns || [], structured = columns.length > 0, current = columns.filter(item => item.level === level);
      if (current.length > 1) throw new Error('实际类目目录出现多个同层级列表，无法唯一选择。');
      const column = current[0];
      if ((structured ? !column?.optionRefs.length : !snapshot.controls.some(optionControl)) && !frameRecovered && requireAttributes && page.recoverReadFrame) { frameRecovered = true; await page.recoverReadFrame('category'); await wait(150); continue; }
      if (snapshot.categoryBusy || snapshot.busy || structured && (!column || column.busy || !column.optionRefs.length)) { stable = 0; previous = ''; await wait(200); continue; }
      const scopedOptions = snapshot.controls.filter(item => ['option', 'treeitem', 'menuitem'].includes(item.role) && (!structured || column.optionRefs.includes(item.ref)));
      const named = scopedOptions.filter(item => same(item.text || item.label, label));
      if (structured && named.length > 1) throw new Error('类目节点名称重复，无法唯一选择：' + label);
      if (structured && named.length === 1 && (named[0].disabled === true || /(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(String(named[0].uiHints?.className || '')))) {
        throw Object.assign(new Error('该店铺后台将此类目标为不可选，请检查后台类目可用状态。'), { code: 'SELLER_CATEGORY_DISABLED' });
      }
      const available = scopedOptions.filter(optionControl);
      const matches = available.filter(item => same(item.text || item.label, label));
      if (matches.length === 1) {
        const item = matches[0], native = requireAttributes && structured && typeof page.clickReadCategoryOptionNative === 'function'
          && typeof page.prepareReadCategoryColumnFrame === 'function' && item.tag === 'li' && item.categoryLevel === level
          && /(?:^|\s)core-cascader-list-item(?:\s|$)/u.test(item.uiHints?.className || '');
        if (columnFramePrepared && !native) throw Object.assign(new Error('类目列表在画面确认后发生变化，未改用其他点击方式。'), { code: 'SELLER_READ_CONTROL_STALE' });
        if (native) {
          assertReadSnapshotSafety(snapshot);
          if (snapshot.categoryPopupCount !== 1 || snapshot.shopIdentityMenuVisible === true || (snapshot.guidanceDialogs || []).length
            || snapshot.modalCount > 0 || snapshot.unknownModalCount > 0 || (snapshot.unknownModals || []).length
            || readIdentity && ['shopId', 'shopName', 'region', 'idKind'].some(key => clean(snapshot.identity?.[key]) && clean(readIdentity[key]) && !same(snapshot.identity[key], readIdentity[key])))
            throw Object.assign(new Error('类目读取期间店铺或弹层范围发生变化，未继续点击。'), { code: 'SELLER_READ_CONTROL_STALE' });
          if (!columnFramePrepared) {
            // A newly mounted Core column can still overlap its predecessor
            // until the owned page produces a frame. Do this once, then discard
            // every old ref and re-observe the target before native input.
            columnFramePrepared = true; const captured = await page.prepareReadCategoryColumnFrame(item.ref); abort(signal);
            if (captured !== true) throw Object.assign(new Error('本层类目画面未获得新的确认，请重新读取。'), { code: 'SELLER_READ_CONTROL_STALE' });
            await wait(150); continue;
          }
        }
        match = item; nativeMatch = native; break;
      }
      if (matches.length > 1) throw new Error('类目节点名称重复，无法唯一选择：' + label);
      const pane = (snapshot.scrollables || []).filter(item => item.selector !== ':root' && item.kind !== 'page' && (!structured || item.selector === column.selector)).find(item => item.top + item.height < item.scrollHeight - 2);
      if (pane) {
        const top = Math.min(pane.scrollHeight - pane.height, pane.top + Math.max(20, pane.height * .75)), position = pane.selector + '\0' + top;
        if (positions.has(position)) throw new Error('实际类目层级滚动没有前进，不能确认目标节点。');
        positions.add(position); await page.scroll(pane.selector, top); await wait(200); continue;
      }
      const shape = JSON.stringify(available.map(item => [item.selector, item.text || item.label]));
      stable = available.length && shape === previous ? stable + 1 : 0; previous = shape;
      if (stable >= 4) break; await wait(200);
    }
    if (!match) throw new Error('实际类目列表中未找到：' + label);
    if (nativeMatch) await page.clickReadCategoryOptionNative(match.ref);
    else if (requireAttributes && page.clickReadControl) await page.clickReadControl(match.ref, 'category-option'); else await page.click(match.ref);
    await wait(180);
  }
  if (allowPrefix) return await page.snapshot();
  if (!requireAttributes) { await page.press('Escape'); await wait(250); }
  let confirmed = false, stable = 0, previous = '', closedStable = 0; const started = nowMs(), budget = requireAttributes ? 60000 : 30000;
  for (let sample = 0; sample < (requireAttributes ? 300 : 150) && nowMs() - started < budget; sample++) {
    abort(signal); snapshot = await page.snapshot(); abort(signal); assertSellerUrl(snapshot.url);
    if (snapshot.securityChallenge?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
    if (nowMs() - started >= budget) break;
    const categoryTexts = [snapshot.text, ...snapshot.controls.filter(categoryControl).flatMap(item => [item.value, item.text, ...(item.selectedValues || [])])];
    const pathText = categoryPath.map(clean).join(' > '), normalisePath = value => clean(value).replace(/\s+-\s+|\s*(?:>|›|»|\/|→)\s*/gu, ' > ');
    confirmed = categoryTexts.some(value => normalisePath(value).includes(pathText));
    const attributesReady = !requireAttributes || (snapshot.attributeGroupHeadings || []).length > 0 || snapshot.controls.some(item => editable(item) && attributeControl(item));
    const popupClosed = !requireAttributes || !(snapshot.categoryPopupCount > 0) && !(snapshot.categoryColumns || []).length && !(snapshot.optionLists || []).length;
    closedStable = popupClosed ? closedStable + 1 : 0;
    const shape = JSON.stringify({ controls: snapshot.controls.map(item => [item.selector, item.label, item.role]), panes: snapshot.scrollables });
    stable = confirmed && attributesReady && (!requireAttributes || closedStable >= 3) && !snapshot.busy && !snapshot.categoryBusy ? shape === previous ? stable + 1 : 1 : 0; previous = shape;
    if (stable >= 3) return;
    await wait(Math.min(200, Math.max(0, budget - (nowMs() - started)))); abort(signal);
  }
  if (requireAttributes && closedStable < 3) throw new Error('类目菜单尚未确认自动关闭，未再次切换类目入口。');
  throw new Error(confirmed ? '类目已选择，但商品属性页面尚未确认载入，请重试。' : '页面未确认选中的类目。');
}

function mappedFields(product) {
  const profile = product.profile || {}, result = [
    { label: '商品名称', aliases: ['Product name', 'Product title'], value: product.name },
    { label: '商品描述', aliases: ['Product description', 'Description'], value: sellerDescriptionText(profile.description) },
    { label: '商品亮点', aliases: ['Product highlights'], value: profile.productHighlights },
    { label: '搜索关键词', aliases: ['Search keywords'], value: profile.searchKeywords },
    { label: '包裹重量', aliases: ['Package weight', '重量', 'Weight'], value: profile.weight },
    { label: '包裹长度', aliases: ['Package length', '长度', 'Length'], value: profile.length },
    { label: '包裹宽度', aliases: ['Package width', '宽度', 'Width'], value: profile.width },
    { label: '包裹高度', aliases: ['Package height', '高度', 'Height'], value: profile.height },
    { label: '品牌', aliases: ['Brand'], value: profile.brand },
    { label: '仓库', aliases: ['Warehouse'], value: profile.warehouse }
  ].filter(item => item.value !== undefined && item.value !== null && item.value !== '');
  if (!(product.variants || []).some(item => item.selected !== false)) {
    if (profile.price !== undefined && profile.price !== '') result.push({ label: '销售价格', aliases: ['售价', '零售价', 'Retail price', 'Price'], value: profile.price });
    if (profile.stock !== undefined && profile.stock !== '') result.push({ label: '库存', aliases: ['可售库存', '数量', 'Stock', 'Quantity'], value: profile.stock });
  }
  for (const item of product.fields || []) {
    if (!item || typeof item.label !== 'string' || item.value === undefined) throw new Error('类目字段映射无效。');
    result.push({ ...item, aliases: [] });
  }
  return result;
}

async function setCustomSelectField(page,mapping,owner,wait,signal,context){
  const rejected=reason=>({label:mapping.label,ok:false,reason});
  if(!context?.identity||!Array.isArray(context.categoryPath)||mapping.allowCustomInput!==true||!['text','number'].includes(mapping.customValueMode)||typeof page.openCustomSelectPopup!=='function'||typeof page.fillCustomSelectPopup!=='function'||typeof page.commitCustomSelectPopup!=='function'||typeof page.closeCustomSelectPopup!=='function'||typeof page.getDocumentFingerprint!=='function'||!owner.instanceId||owner.tag==='select')return rejected('当前页面尚无已确认的自定义下拉输入、添加与关闭方式，未写入该字段。');
  const entries=attributeValueEntries(mapping.value),custom=entries.filter(isCustomAttributeValue),presets=entries.filter(value=>!isCustomAttributeValue(value));
  if(!custom.length||entries.some(value=>!isCustomAttributeValue(value)&&typeof value!=='string')||custom.some(value=>!value.value.trim()||value.value!==value.value.trim()||value.value.length>4096||/[\u0000-\u001f\u007f]/u.test(value.value))||new Set(custom.map(value=>value.value.toLowerCase())).size!==custom.length)return rejected('自定义属性值格式无效。');
  const limits=mapping.customInputConstraints;
  if(!limits||limits.mode!==mapping.customValueMode||!Number.isSafeInteger(limits.maxLength)||limits.maxLength<1||limits.maxLength>4096||typeof limits.supportChinese!=='boolean'||limits.maxSelected!==null&&(!Number.isSafeInteger(limits.maxSelected)||limits.maxSelected<1)||custom.some(value=>value.value.length>limits.maxLength||!limits.supportChinese&&/[\u2E80-\u2E99\u2E9B-\u2EF3\u2F00-\u2FD5\u3005\u3007\u3021-\u3029\u3038-\u303B\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFA6D\uFA70-\uFAD9\u{16FE2}\u{16FE3}\u{16FF0}-\u{16FF6}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}]/u.test(value.value))||limits.maxSelected&&entries.length>limits.maxSelected
    ||limits.mode==='number'&&(limits.number?.valid!==true||custom.some(value=>!attributeNumberValueAllowed({uiProperties:{input_number:limits.number}},value.value)))||!Number.isSafeInteger(mapping.customPresetOptionCount)||mapping.customPresetOptionCount<0||mapping.customPresetOptionCount>10000||!Array.isArray(mapping.customPresetOptions)||mapping.customPresetOptions.length!==mapping.customPresetOptionCount)return rejected('自定义属性值未满足该字段的来源输入约束。');
  if(entries.length>1&&!owner.multiple)return rejected('此控件不是多选。');
  let fingerprint,initialAlerts;
  const accepted=[];
  try{
    fingerprint=await page.getDocumentFingerprint();if(!fingerprintValid(fingerprint))throw Error('无法确认自定义输入所属的当前商品页面。');
    const fresh=async()=>{
      abort(signal);const state=await page.snapshot();assertReadSnapshotSafety(state);
      const current=state.controls.filter(item=>item.selector===owner.selector);
      const peers=state.controls.filter(item=>editable(item)&&same(item.label,owner.label)&&same(item.section,owner.section));
      if(compareShopIdentity(state.identity||{},context.identity).length||!exactCategoryScope({...state,optionLists:[]},context.categoryPath)||state.securityChallenge?.detected!==false||state.shopIdentityMenuVisible===true||(state.guidanceDialogs||[]).length||state.modalCount>0||state.unknownModalCount>0||current.length!==1||peers.length!==1||current[0].instanceId!==owner.instanceId||current[0].disabled||current[0].readOnly===true||current[0].tag!==owner.tag||current[0].role!=='combobox'||current[0].multiple!==owner.multiple||!same(current[0].label,owner.label)||!same(current[0].section,owner.section)||await page.getDocumentFingerprint()!==fingerprint)throw Error('自定义输入期间页面、店铺、类目或实际字段已变化，未继续填写。');
      initialAlerts??=new Set(state.alerts||[]);
      if((state.alerts||[]).some(text=>!initialAlerts.has(text)&&/错误|无效|不合法|不支持|不允许|校验失败|验证失败|失败|敏感|违禁|违规|error|invalid|not allowed|unsupported/iu.test(text)))throw Error('页面未通过自定义属性值校验，未确认填写成功。');
      return {state,current:current[0]};
    };
    const associated=({state,current})=>{const lists=state.optionLists||[];return lists.length===1&&((current.listIds||[]).some(id=>(lists[0].relatedListIds||[]).includes(id))||lists[0].customOwnerInstanceId===owner.instanceId)?lists[0]:null;};
    const ensureOpen=async()=>{let value=await fresh();if((value.state.optionLists||[]).length){if(!associated(value))throw Error('下拉菜单不属于当前自定义字段。');return value;}await page.openCustomSelectPopup(value.current.ref);await wait(100);value=await fresh();if(!associated(value))throw Error('无法唯一确认当前字段的实际下拉菜单。');return value;};
    const currentlySelected=(current,group)=>(current.selectedValues||[]).some(value=>group.some(choice=>clean(value)===clean(choice)));
    const customMatches=(display,item)=>limits.mode==='number'?attributeNumberValuesEqual(display,item.value):clean(display)===clean(item.value);
    const sourceOptions=mapping.customPresetOptions;
    if(sourceOptions.some(option=>typeof option.value!=='string'||typeof option.label!=='string'||!option.label.trim()))throw Error('自定义字段的来源预设选项无效。');
    if(custom.some(value=>sourceOptions.some(option=>clean(option.label).toLowerCase()===clean(value.value).toLowerCase())))throw Error('自定义文字与实际预设选项重名，请选择对应预设选项。');
    const initial=await fresh();
    const requestedPresets=sourceOptions.filter(option=>presets.includes(option.value));
    if((initial.current.selectedValues||[]).some(display=>!requestedPresets.some(option=>[option.value,option.label].some(choice=>clean(choice)===clean(display)))&&!custom.some(item=>customMatches(display,item))))throw Error('当前字段包含本次未要求的已选值，未覆盖或添加其他值。');
    const read=await optionsFor(page,initial.current,wait,signal,{emptyCustomMode:mapping.customPresetOptionCount===0?limits.mode:undefined,customSelectMode:limits.mode});if(!read.complete)throw Error('自定义下拉的实际预设选项未读取完整。');await fresh();
    const sourceRows=sourceOptions.map(option=>{
      const exact=read.options.filter(row=>row.value===option.value&&same(row.label,option.label)),labels=read.options.filter(row=>same(row.label,option.label));
      return exact.length===1?exact[0]:read.options.some(row=>row.value===option.value)||labels.length!==1?null:labels[0];
    });
    const rowKey=row=>JSON.stringify([row.value,row.label]),sourceKeys=new Set(sourceRows.filter(Boolean).map(rowKey));
    if(sourceRows.some(row=>!row)||sourceKeys.size!==sourceOptions.length||read.options.some(row=>!sourceKeys.has(rowKey(row))&&(!(initial.current.selectedValues||[]).some(display=>clean(display)===clean(row.label))||!custom.some(item=>customMatches(row.label,item)))))throw Error('实际菜单含有无法核对的预设或已选自定义项。');
    if(presets.length){
      for(const preset of presets){
        const trusted=(mapping.fillOptions||[]).filter(option=>option.value===preset);if(trusted.length!==1)throw Error('自定义多选缺少预设选项的独立映射。');
        const exact=read.options.filter(option=>option.value===preset&&same(option.label,trusted[0].label)),labels=read.options.filter(option=>same(option.label,trusted[0].label));
        const actual=exact.length===1?exact[0]:read.options.some(option=>option.value===preset)||labels.length!==1?null:labels[0];if(!actual)throw Error('无法唯一核对自定义多选中的预设选项。');
        const group=read.options.filter(option=>same(option.label,actual.label)).length>1?[actual.value]:[actual.value,actual.label];accepted.push(group);
        if(currentlySelected((await fresh()).current,group))continue;
        let clicked=false;
        for(let step=0;step<60;step++){
          const value=await ensureOpen(),list=associated(value),matches=value.state.controls.filter(item=>list.optionRefs.includes(item.ref)&&optionControl(item)&&item.value===actual.value&&same(item.text||item.label,actual.label));
          if(matches.length>1)throw Error('预设选项在当前菜单中重名。');if(matches.length===1){await page.click(matches[0].ref);await wait(100);await fresh();clicked=true;break;}
          const pane=(value.state.scrollables||[]).find(item=>item.selector===list.selector&&item.top+item.height<item.scrollHeight-2);if(!pane)break;await page.scroll(pane.selector,Math.min(pane.scrollHeight-pane.height,pane.top+pane.height*.8));await wait(100);await fresh();
        }
        if(!clicked)throw Error('未找到当前字段的唯一预设选项。');
      }
    }
    for(const customValue of custom){
      const literal=customValue.value,customGroup=[literal];accepted.push(customGroup);
      const existing=((await fresh()).current.selectedValues||[]).filter(display=>customMatches(display,customValue));
      if(existing.length>1)throw Error('当前字段含有重复或数值等价的自定义项，未猜测覆盖。');
      if(existing.length===1){if(!customGroup.includes(existing[0]))customGroup.push(existing[0]);continue;}
      let value=await ensureOpen();
      const typed=await page.fillCustomSelectPopup(value.current.ref,literal,limits.mode);
      if(typed?.accepted!==true||typed.instanceId!==owner.instanceId||(limits.mode==='number'?!attributeNumberValuesEqual(typed.inputValue,literal)||!attributeNumberValueAllowed({uiProperties:{input_number:limits.number}},typed.inputValue):typed.inputValue!==literal))throw Error('实际下拉弹层输入未确认自定义值。');
      if(!customGroup.includes(typed.inputValue))customGroup.push(typed.inputValue);
      await wait(100);value=await fresh();if(!associated(value))throw Error('自定义添加按钮所属的弹层已变化。');
      // QHe creates through its Add button, not search results or Enter.
      const committed=await page.commitCustomSelectPopup(value.current.ref,typed);if(committed?.accepted!==true||committed.clicked!==true||committed.instanceId!==owner.instanceId)throw Error('自定义添加按钮未确认执行。');
      let created=0;
      for(let attempt=0;attempt<100;attempt++){
        await wait(200);value=await fresh();let pending=false;
        if((value.state.optionLists||[]).length){if(!associated(value))throw Error('自定义属性校验期间弹层所属字段已变化。');
          const status=await page.inspectCustomSelectPopup(value.current.ref,limits.mode);if(status?.accepted!==true||status.instanceId!==owner.instanceId||status.validationError)throw Error('页面未通过自定义属性值校验。');pending=status.pending===true;
        }
        if(limits.mode==='number'){
          const equivalent=(value.current.selectedValues||[]).filter(display=>attributeNumberValuesEqual(display,literal));
          if(equivalent.length===1&&!customGroup.includes(equivalent[0]))customGroup.push(equivalent[0]);
        }
        created=!pending&&!value.state.busy&&currentlySelected(value.current,customGroup)?created+1:0;if(created>=3)break;
      }
      if(created<3)throw Error('添加后页面未确认该自定义值，可能仍在校验或已被拒绝。');
    }
    let value=await fresh();if((value.state.optionLists||[]).length){if(!associated(value))throw Error('自定义下拉菜单所属字段已变化。');const closed=await page.closeCustomSelectPopup(value.current.ref,limits.mode);if(closed?.accepted!==true||closed.closed!==true||closed.instanceId!==owner.instanceId)throw Error('自定义下拉未确认关闭，未继续保存。');await wait(100);}
    let stable=0;
    for(let attempt=0;attempt<20;attempt++){value=await fresh();const valid=!value.state.busy&&!(value.state.optionLists||[]).length&&confirmsExactSelection(value.current,accepted);stable=valid?stable+1:0;if(stable>=3)return {label:mapping.label,selector:owner.selector,instanceId:owner.instanceId,observedLabel:owner.label,observedSection:owner.section,acceptedValues:accepted,multiple:owner.multiple,strictSelection:true,ok:true,reason:'',value:structuredClone(mapping.value)};await wait(100);}
    throw Error('页面没有确认全部自定义及预设选项，未确认填写成功。');
  }catch(error){return rejected(/页面|字段|下拉|自定义|预设|菜单|输入|选项/u.test(error.message)?error.message:'自定义属性填写尚未确认，请在店铺后台检查。');}
}

async function setField(page, mapping, wait, signal, {fillOnly=false,context}={}) {
  // Taxonomy IDs are not proven DOM values. A future explicit resolver must
  // establish that relation before these can use any menu or text operation.
  if (mapping.valueKind === 'api-id' && !fillOnly) return { label: mapping.label, ok: false, reason: 'API 属性编号尚未验证与当前页面选项的对应关系，暂不能自动填写。' };
  let snapshot = await page.snapshot(); const names = [mapping.label, ...(mapping.aliases || [])];
  const matchesFor = state => state.controls.filter(editable).filter(item => names.some(name => same(item.label, name)) && (!mapping.section || same(item.section, mapping.section)));
  let matches = matchesFor(snapshot);
  if (mapping.ordinal !== undefined) {
    if (!Number.isSafeInteger(mapping.ordinal) || mapping.ordinal < 1 || mapping.groupCount !== undefined && (!Number.isSafeInteger(mapping.groupCount) || mapping.groupCount < 1)) return { label: mapping.label, ok: false, reason: '字段序号或分组总数无效。' };
    const collected = new Map(); let recycled = false;
    try {
      await expandAttributeSections(page, wait, signal, state => {
        for (const item of matchesFor(state)) {
          const previous = collected.get(item.selector);
          if (previous?.control.fieldPosition && item.fieldPosition && (Math.abs(previous.control.fieldPosition.x - item.fieldPosition.x) > 2 || Math.abs(previous.control.fieldPosition.y - item.fieldPosition.y) > 2)) recycled = true;
          if (!previous) collected.set(item.selector, { control: item, panes: (state.scrollables || []).filter(pane => pane.kind === 'page' || pane.selector === ':root').map(pane => ({ selector: pane.selector, top: pane.top })) });
        }
      });
    } catch { return { label: mapping.label, ok: false, reason: '无法完整重读实际字段组，不能按序号猜测。' }; }
    if (recycled) return { label: mapping.label, ok: false, reason: '同名字段发生复用或位置变化，序号证据不稳定。' };
    const group = [...collected.values()];
    if (!group.length || mapping.ordinal > group.length || mapping.groupCount !== undefined && mapping.groupCount !== group.length || group.length > 1 && mapping.groupCount === undefined) return { label: mapping.label, ok: false, reason: '同名字段组数量与采集证据不一致或缺失。' };
    if (group.some(item => !same(item.control.section, group[0].control.section))) return { label: mapping.label, ok: false, reason: '同名字段跨分区，必须提供实际分区。' };
    const target = group[mapping.ordinal - 1];
    if (mapping.key?.startsWith('dom-') && mapping.key !== fieldKey(clean(target.control.section), clean(target.control.label), mapping.ordinal)) return { label: mapping.label, ok: false, reason: '字段序号与采集字段标识不一致。' };
    // The selector is observed locally, never accepted from the product payload.
    // Return to its real page position by reading each viewport again if needed.
    for (const pane of target.panes) {
      const state = await page.snapshot(), observed = (state.scrollables || []).find(item => item.selector === pane.selector);
      if (!observed || pane.top < 0 || pane.top > observed.scrollHeight - observed.height + 2) return { label: mapping.label, ok: false, reason: '目标字段的实际滚动位置已经变化。' };
      if (Math.abs(observed.top - pane.top) > 1) { await page.scroll(observed.selector, pane.top); await wait(150); }
    }
    snapshot = await page.snapshot();
    const fresh = matchesFor(snapshot).find(item => item.selector === target.control.selector);
    if (!fresh || target.control.fieldPosition && fresh.fieldPosition && (Math.abs(target.control.fieldPosition.x - fresh.fieldPosition.x) > 2 || Math.abs(target.control.fieldPosition.y - fresh.fieldPosition.y) > 2)) return { label: mapping.label, ok: false, reason: '目标同名字段未能在完整重读后唯一定位。' };
    matches = [fresh];
  }
  if (matches.length !== 1) return { label: mapping.label, ok: false, reason: matches.length ? '字段重名，请指定所属分区。' : '页面未找到对应控件。' };
  let control = matches[0], fieldSnapshot = snapshot;
  const reconfirm = (state, confirmAfterAction = false) => {
    const current=state.controls.filter(item=>item.selector===control.selector&&same(item.label,control.label)&&same(item.section,control.section)&&item.tag===control.tag&&item.role===control.role);
    if(current.length===1&&(!control.instanceId||current[0].instanceId===control.instanceId))return current[0];
    // Repeated ordinal fields keep their original, stronger group-position proof.
    if(mapping.ordinal!==undefined&&mapping.groupCount!==1)return undefined;
    try{return findRecoveredSellerControl(fieldSnapshot,state,control,{confirmAfterAction});}catch{return undefined;}
  };
  const entries=attributeValueEntries(mapping.value),values = entries.map(attributeValueText),hasCustom=entries.some(isCustomAttributeValue);
  if(entries.some(value=>value!==null&&typeof value==='object'&&!isCustomAttributeValue(value)))return {label:mapping.label,ok:false,reason:'类目属性值格式无效，未写入该字段。'};
  if (control.disabled) return { label: mapping.label, ok: false, reason: '控件不可用。' };
  if(mapping.expectedControlType!==undefined){
    const select=control.role==='combobox'||control.tag==='select',numeric=control.type==='number'||control.role==='spinbutton',textarea=control.tag==='textarea',textInput=!select&&!['checkbox','radio','file','hidden'].includes(control.type)&&(['input','textarea'].includes(control.tag)||control.role==='textbox'||control.isContentEditable===true);
    if(!['select','text'].includes(mapping.expectedControlType)||mapping.expectedControlType==='select'&&!select||mapping.expectedControlType==='text'&&!textInput
      ||mapping.expectedInputType==='number'&&!numeric||mapping.expectedInputType==='textarea'&&!textarea||mapping.expectedInputType==='text'&&(numeric||textarea))return {label:mapping.label,ok:false,reason:'实际页面控件类型与预置属性定义不一致，未写入该字段。'};
  }
  if(hasCustom)return fillOnly?setCustomSelectField(page,mapping,control,wait,signal,context):{label:mapping.label,ok:false,reason:'自定义属性仅供已保存商品的草稿填写，未执行发布。'};
  if (['checkbox', 'radio'].includes(control.type)) {
    if (typeof mapping.value !== 'boolean') return { label: mapping.label, ok: false, reason: '勾选控件需要明确的是／否值。' };
    if (control.checked !== mapping.value) await page.click(control.ref);
    await wait(100); const after=reconfirm(await page.snapshot(),true),checked=after?.checked;
    return { label: mapping.label, selector: after?.selector||control.selector, observedLabel: control.label, observedSection: control.section, expectedChecked: mapping.value, ok: checked === mapping.value, reason: checked === mapping.value ? '' : '页面没有确认勾选状态。' };
  }
  let accepted = values;
  if (control.role === 'combobox' || control.tag === 'select') {
    const { options, complete } = await optionsFor(page, control, wait, signal);
    if (!complete) return { label: mapping.label, ok: false, reason: '选项未读取完整。' };
    const chosen = values.map(value => {
      if(mapping.valueKind==='api-id'){
        const trusted=Array.isArray(mapping.fillOptions)?mapping.fillOptions.filter(option=>option.value===value):[];
        if(trusted.length!==1||!clean(trusted[0].label))return undefined;
        const exact=options.filter(option=>clean(option.value)===clean(value)&&same(option.label,trusted[0].label));
        if(exact.length===1)return exact[0];
        if(options.some(option=>clean(option.value)===clean(value)))return undefined;
        if(mapping.fillOptions.filter(option=>same(option.label,trusted[0].label)).length!==1)return undefined;
        const labels=options.filter(option=>same(option.label,trusted[0].label));return labels.length===1?labels[0]:undefined;
      }
      const exact = options.filter(item => clean(item.value) === clean(value));
      if (exact.length === 1) return exact[0];
      const labels = options.filter(item => same(item.label, value)); return labels.length === 1 ? labels[0] : undefined;
    });
    if (chosen.some(item => !item)) return { label: mapping.label, ok: false, reason: '填写值不在真实页面选项中，或同名选项无法唯一确定。' };
    if (values.length > 1 && !control.multiple) return { label: mapping.label, ok: false, reason: '此控件不是多选。' };
    accepted = chosen.map(item => options.filter(other => same(other.label, item.label)).length > 1 ? [item.value] : [item.value, item.label]);
    const currentState=await page.snapshot(),fresh=reconfirm(currentState);
    if (!fresh) return { label: mapping.label, ok: false, reason: '页面控件已变化。' };
    control=fresh;fieldSnapshot=currentState;
    if (fresh.tag === 'select') await page.choose(fresh.ref, fresh.multiple ? chosen.map(item => item.value) : chosen[0].value);
    else {
      await page.click(fresh.ref); await wait(100);
      for (const option of chosen) {
        let found;
        for (let step = 0; step < 60; step++) {
          abort(signal); const state = await page.snapshot();
          const available = state.controls.filter(optionControl), exact = available.filter(item => clean(item.value) === clean(option.value));
          const candidates = exact.length ? exact : available.filter(item => same(item.text || item.label, option.label));
          if (candidates.length === 1) { found = candidates[0]; break; }
          if (candidates.length > 1) break;
          const pane = (state.scrollables || []).filter(item => item.selector !== ':root' && item.kind !== 'page').find(item => item.top + item.height < item.scrollHeight - 2);
          if (!pane) break;
          await page.scroll(pane.selector, Math.min(pane.scrollHeight - pane.height, pane.top + pane.height * .8)); await wait(100);
        }
        if (!found) { await page.press('Escape'); return { label: mapping.label, ok: false, reason: '未能唯一选择真实选项。' }; }
        await page.click(found.ref); await wait(100);
      }
      await page.press('Escape');
    }
  } else await page.fill(control.ref, values.join('\n'));
  await wait(100);
  const after = reconfirm(await page.snapshot(),true);
  // A blank value after a custom widget action is uncertain, never evidence of success.
  const ok = same(after?.label, control.label) && same(after?.section, control.section) && confirms(after, accepted, control.multiple);
  return { label: mapping.label, selector: after?.selector||control.selector, observedLabel: control.label, observedSection: control.section, acceptedValues: accepted, multiple: control.multiple, ok, reason: ok ? '' : '页面未确认填写后的值。', value: mapping.value };
}

function expectedSkuPlan(product) {
  if(product.salesSpecifications){
    for(const variant of (product.variants||[]).filter(v=>v.selected!==false))for(const size of (product.sizes||[]).filter(size=>variant.enabledSizes===undefined||variant.enabledSizes.includes(size)))if(Object.values(listingWarehouseStocks({...product,profile:product.profile||{}},variant,size)).filter(value=>value!==''&&value!==null&&value!==undefined).length>1)throw Error('分仓库存需要逐仓库页面映射，不能合并写入总库存。');
    return buildTikTokPublishingSalesPlan(product);
  }
  // Old local callers use color/size rows. Never accept this shortcut for a
  // canonical product: its complete tuple always comes from the shared plan.
  const rows=[];
  if(Array.isArray(product.skuRows))for(const row of product.skuRows)rows.push({...row,values:[row.color,row.size]});
  else for(const variant of (product.variants||[]).filter(item=>item.selected!==false))for(const size of (product.sizes||[]).filter(size=>variant.enabledSizes===undefined||variant.enabledSizes.includes(size))){
    if(Object.values(variant.sizeOverrides?.[size]?.warehouseStocks||variant.warehouseStocks||product.profile?.warehouseStocks||{}).filter(value=>value!=='').length>1)throw Error('分仓库存需要逐仓库页面映射，不能合并写入总库存。');
    rows.push({values:[variant.colorEnglish||variant.color,size],price:listingSkuValue(product,variant,size,'price'),stock:listingSkuValue(product,variant,size,'stock'),sku:listingSkuValue(product,variant,size,'sku')});
  }
  return {legacy:true,dimensions:['Color','Size'].map((name,i)=>({key:'legacy-'+i,name,values:[...new Set(rows.map(row=>row.values[i]))].map((name,n)=>({key:'value-'+n,name}))})),rows};
}
const specificationKind=value=>/^(?:颜色|Color|Colour)$/iu.test(clean(value))?'color':/^(?:尺码|尺寸|Size|Specification)$/iu.test(clean(value))?'size':'';
const skuBusinessColumns={price:/^(销售价格|售价|零售价|Price|Retail price)$/iu,stock:/^(数量|库存|可售库存|Quantity|Stock|Inventory)$/iu,sku:/^(卖家\s*SKU|商家\s*SKU|Seller SKU|SKU)$/iu};
const skuSame=(plan,left,right)=>plan.legacy?same(left,right):clean(left)===clean(right);
const skuTuple=(plan,values)=>JSON.stringify(values.map(value=>plan.legacy?clean(value).toLowerCase():clean(value)));
function skuDecimal(value){
  if(!['string','number'].includes(typeof value))return null;
  const text=String(value).trim();if(!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/u.test(text))return null;
  const negative=text.startsWith('-'),[integer,fraction='']=text.replace(/^[+-]/u,'').split('.');
  const whole=integer.replace(/^0+/u,'')||'0',decimal=fraction.replace(/0+$/u,''),magnitude=whole+(decimal?'.'+decimal:'');
  return negative&&magnitude!=='0'?'-'+magnitude:magnitude;
}
function skuCellMatches(field,actual,expected){
  if(field==='sku')return typeof actual==='string'&&actual===String(expected);
  const left=skuDecimal(actual),right=skuDecimal(expected);return left!==null&&right!==null&&left===right;
}
function validateSkuPlan(plan){
  if(!Array.isArray(plan.dimensions)||plan.dimensions.length<1||plan.dimensions.length>3||!Array.isArray(plan.rows)||plan.rows.length>1000)throw Error('销售规格或 SKU 组合数量无效。');
  const names=new Set(),tuples=new Set();let total=1;
  for(const d of plan.dimensions){const name=clean(d.name);if(!name||names.has(name)||!Array.isArray(d.values)||!d.values.length)throw Error('销售规格名称或选项不完整或重复。');names.add(name);const values=d.values.map(v=>skuTuple(plan,[v.name]));if(values.some((v,i)=>!clean(d.values[i].name))||new Set(values).size!==values.length)throw Error('销售规格选项规范后不唯一。');total*=values.length;}
  for(const row of plan.rows){if(!Array.isArray(row.values)||row.values.length!==plan.dimensions.length||row.values.some((v,i)=>!clean(v)||!plan.dimensions[i].values.some(option=>skuSame(plan,option.name,v))))throw Error('保存的销售规格组合无效。');const key=skuTuple(plan,row.values);if(tuples.has(key))throw Error('保存的销售规格组合重复。');tuples.add(key);}
  if(plan.rows.length&&total!==plan.rows.length)throw Error('保存的销售规格组合不完整。');
  return tuples;
}
function groupMatches(plan,group,dimension){return plan.legacy?group.kind===specificationKind(dimension.name)||specificationKind(group.name)===specificationKind(dimension.name):tiktokSalesDimensionNamesMatch(group.name,dimension.name);}
function inspectSpecificationGroups(state,plan,tracked=new Map(),complete=false){
  if(state.specificationScopeIssues?.length)throw Error('销售规格分组或名称控件存在歧义，未继续添加或填写。');
  const groups=state.specificationGroups||[],ids=new Set(),byDimension=new Map();
  if(groups.length>plan.dimensions.length)throw Error('页面已有额外销售规格组，未删除或改写。');
  for(const group of groups){
    if(typeof group.groupId!=='string'||!group.groupId||ids.has(group.groupId))throw Error('销售规格组标识缺失或重复，未按页面顺序猜测。');ids.add(group.groupId);
    const dimensions=plan.dimensions.filter(d=>groupMatches(plan,group,d));
    if(dimensions.length>1)throw Error('销售规格名称存在歧义。');
    if(!dimensions.length){if(clean(group.name)||clean(group.kind)||(group.values||[]).some(clean))throw Error('页面已有其他销售规格或异名规格值，未覆盖现有内容。');continue;}
    const dimension=dimensions[0];if(byDimension.has(dimension.key))throw Error('销售规格存在多个同名组，未按页面顺序猜测。');
    if(tracked.has(dimension.key)&&tracked.get(dimension.key)!==group.groupId)throw Error('销售规格组在填写期间变化，未继续写入。');
    const values=group.values||[],keys=values.map(v=>skuTuple(plan,[v]));if(new Set(keys).size!==keys.length||values.some(value=>!dimension.values.some(expected=>skuSame(plan,value,expected.name))))throw Error('页面已有重复或其他销售规格值，未删除或改写。');
    if(complete&&(values.length!==dimension.values.length||dimension.values.some(v=>!values.some(actual=>skuSame(plan,actual,v.name)))))throw Error('页面销售规格值未完整确认。');
    byDimension.set(dimension.key,group);tracked.set(dimension.key,group.groupId);
  }
  if(complete&&byDimension.size!==plan.dimensions.length)throw Error('页面销售规格组未完整确认。');
  return byDimension;
}
function inspectSkuMatrix(state,plan,{complete=false,inputs=false}={}){
  const expected=new Set(plan.rows.map(row=>skuTuple(plan,row.values))),candidates=[];
  for(const table of state.tables||[]){
    const headers=table.headers||[],business=Object.fromEntries(Object.entries(skuBusinessColumns).map(([key,regex])=>[key,headers.flatMap((value,i)=>regex.test(clean(value))?[i]:[])]));
    const dimensions=plan.dimensions.map(d=>headers.flatMap((value,i)=>(plan.legacy?specificationKind(value)===specificationKind(d.name):tiktokSalesDimensionNamesMatch(value,d.name))?[i]:[]));
    if(!business.sku.length&&!dimensions.some(indices=>indices.length))continue;
    if(!business.sku.length&&!business.price.length&&!business.stock.length)continue;
    if(table.spanIssues?.length)throw Error('实际 SKU 表格的合并单元格边界不完整或存在歧义，未继续填写。');
    if(Object.values(business).some(indices=>indices.length>1)||dimensions.some(indices=>indices.length>1))throw Error('实际 SKU 表格列名重复，无法唯一确定规格或销售字段。');
    if(Object.values(business).some(indices=>indices.length!==1)||dimensions.some(indices=>indices.length!==1)){
      if(complete)throw Error('实际 SKU 表格缺少当前规格、价格、库存或卖家 SKU 列。');
      continue;
    }
    const indices={...Object.fromEntries(Object.entries(business).map(([key,values])=>[key,values[0]])),dimensions:dimensions.map(values=>values[0])};
    const all=[...Object.values(indices).filter(Number.isInteger),...indices.dimensions];if(new Set(all).size!==all.length)throw Error('SKU规格列与销售字段列身份重叠，未继续填写。');
    candidates.push({table,indices});
  }
  if(candidates.length>1)throw Error('页面出现多个 SKU 表格，未跨表或按行顺序猜测。');
  const result={rows:new Map(),indices:null,controls:new Map()};if(!candidates.length){if(complete)throw Error('实际 SKU 表格尚未完整出现，请先补全销售规格。');return result;}
  const {table,indices}=candidates[0];result.indices=indices;const selectors=new Set(),refs=new Set(),controls=new Map((state.controls||[]).map(control=>[control.ref,control]));
  for(const actual of table.rows||[]){
    const values=indices.dimensions.map(i=>actual.cells?.[i]?.text);
    if(values.some(value=>!clean(value))){if(complete)throw Error('实际 SKU 行没有完整可核对的规格值。');continue;}
    const key=skuTuple(plan,values);if(result.rows.has(key)||!expected.has(key))throw Error('新建页出现了重复或与保存结果不同的销售规格，未覆盖现有行。');result.rows.set(key,actual);
    if(inputs)for(const field of ['price','stock','sku']){
      const cellRefs=actual.cells?.[indices[field]]?.controls||[],control=cellRefs.length===1&&controls.get(cellRefs[0]);
      if(!control||control.disabled||control.readOnly||!['input','textarea'].includes(control.tag)||control.role==='combobox'||typeof control.selector!=='string'||!control.selector||refs.has(control.ref)||selectors.has(control.selector))throw Error('实际 SKU 单元格不是独立且可唯一填写的输入框。');
      refs.add(control.ref);selectors.add(control.selector);result.controls.set(key+'\0'+field,control);
    }
  }
  if(complete&&result.rows.size!==expected.size)throw Error('实际 SKU 表格中没有完整且唯一匹配的销售规格组合。');
  return result;
}
async function chooseSpecificationOption(page,control,option,wait,signal,verify=()=>{}){
  abort(signal);
  let state=await page.snapshot();verify(state);const fresh=state.controls.filter(item=>item.selector===control.selector);
  if(fresh.length!==1||fresh[0].disabled||fresh[0].readOnly||fresh[0].tag!==control.tag||fresh[0].role!==control.role)throw Error('销售规格选项控件在选择前已变化。');
  if(control.tag==='select'){await page.choose(fresh[0].ref,option.value);await wait(100);return;}
  await page.click(fresh[0].ref);await wait(100);
  state=await page.snapshot();verify(state);const choices=state.controls.filter(optionControl).filter(item=>clean(item.value)===clean(option.value)||same(item.text||item.label,option.label));
  if(choices.length!==1){await page.press('Escape');throw Error('销售规格选项没有唯一匹配，未继续填写。');}
  await page.click(choices[0].ref);await wait(100);await page.press('Escape');
}
async function ensureSkuSpecifications(page,product,wait,signal){
  const plan=expectedSkuPlan(product);if(!plan.rows.length)return [];validateSkuPlan(plan);
  const tracked=new Map();let state=await page.snapshot(),matrix=inspectSkuMatrix(state,plan);inspectSpecificationGroups(state,plan,tracked);
  if(plan.legacy&&matrix.rows.size===plan.rows.length)return [{label:'销售规格',ok:true,skuPlan:plan,skuGroupIds:[]}];
  for(const dimension of plan.dimensions){
    abort(signal);state=await page.snapshot();let groups=inspectSpecificationGroups(state,plan,tracked),group=groups.get(dimension.key);
    if(!group){
      let empty=(state.specificationGroups||[]).filter(group=>!clean(group.name)&&!clean(group.kind)&&group.nameRef);
      if(!empty.length){if(state.specificationAddRefs?.length!==1)throw Error('页面尚未出现唯一可添加的销售规格组。');await page.click(state.specificationAddRefs[0]);await wait(150);state=await page.snapshot();inspectSpecificationGroups(state,plan,tracked);empty=(state.specificationGroups||[]).filter(group=>!clean(group.name)&&!clean(group.kind)&&group.nameRef);}
      if(empty.length!==1)throw Error('新增销售规格的名称控件不能唯一确认。');
      const blank=empty[0],control=state.controls.find(item=>item.ref===blank.nameRef);if(!control||control.disabled||control.readOnly)throw Error('新增销售规格名称控件不可用。');
      if(blank.nameInputEditable===true&&['input','textarea'].includes(control.tag)&&['','text','search'].includes(control.type||'')){
        await page.fill(control.ref,dimension.name);await page.press('Tab');await wait(100);
      }else if(control.tag==='select'||control.role==='combobox'){
        const result=await optionsFor(page,control,wait,signal),options=result.options.filter(option=>plan.legacy?specificationKind(option.label)===specificationKind(dimension.name):tiktokSalesDimensionNamesMatch(option.label,dimension.name));
        if(!result.complete||options.length!==1)throw Error('销售规格名称没有唯一真实选项。');await chooseSpecificationOption(page,control,options[0],wait,signal,current=>{inspectSpecificationGroups(current,plan,tracked);if(!(current.specificationGroups||[]).some(group=>group.groupId===blank.groupId&&current.controls.find(item=>item.ref===group.nameRef)?.selector===control.selector))throw Error('销售规格名称控件所属组已变化。');});
      }else throw Error('销售规格名称不是已确认的可输入控件或真实选项。');
      state=await page.snapshot();groups=inspectSpecificationGroups(state,plan,tracked);group=groups.get(dimension.key);if(!group||group.groupId!==blank.groupId)throw Error('新增销售规格组名称或稳定标识未得到确认。');
    }
    const groupId=group.groupId;
    for(const option of dimension.values){
      abort(signal);state=await page.snapshot();inspectSkuMatrix(state,plan);group=inspectSpecificationGroups(state,plan,tracked).get(dimension.key);
      if(!group||group.groupId!==groupId)throw Error('销售规格组在填写期间变化，未继续写入。');
      if((group.values||[]).some(value=>skuSame(plan,value,option.name)))continue;
      const valueControls=()=> (group.valueRefs||[]).map(ref=>state.controls.find(item=>item.ref===ref)).filter(item=>item&&!item.disabled&&!item.readOnly),isEmpty=item=>!(item.selectedValues||[]).length&&!clean(item.value);
      let controls=valueControls(),empty=controls.filter(isEmpty);
      if(!empty.length&&group.addRefs?.length===1){await page.click(group.addRefs[0]);await wait(100);state=await page.snapshot();group=inspectSpecificationGroups(state,plan,tracked).get(dimension.key);if(!group||group.groupId!==groupId)throw Error('新增规格值后组标识变化。');controls=valueControls();empty=controls.filter(isEmpty);}
      if(empty.length!==1)throw Error('没有唯一空白销售规格值控件，未覆盖已有值。');
      const target=empty[0];
      if(target.tag==='select'||target.role==='combobox'&&!(group.textEntryRefs||[]).includes(target.ref)){
        const result=await optionsFor(page,target,wait,signal),options=result.options.filter(candidate=>skuSame(plan,candidate.label,option.name));
        if(!result.complete||options.length!==1)throw Error('销售规格值没有唯一真实选项。');await chooseSpecificationOption(page,target,options[0],wait,signal,current=>{const actual=inspectSpecificationGroups(current,plan,tracked).get(dimension.key);if(!actual||(actual.valueRefs||[]).every(ref=>current.controls.find(item=>item.ref===ref)?.selector!==target.selector))throw Error('销售规格值控件所属组已变化。');});
      }else if((group.textEntryRefs||[]).includes(target.ref)){
        if(typeof page.fillSpecification==='function')await page.fillSpecification(target.ref,option.name);else if(target.tag==='input')await page.fill(target.ref,option.name);else throw Error('销售规格输入方式尚未确认。');await wait(150);
      }else throw Error('销售规格值不是已确认的可输入控件。');
      const after=await page.snapshot(),confirmed=inspectSpecificationGroups(after,plan,tracked).get(dimension.key);if(!confirmed||(confirmed.values||[]).filter(value=>skuSame(plan,value,option.name)).length!==1)throw Error('页面没有唯一确认新增销售规格值。');
    }
  }
  for(let sample=0;sample<20;sample++){abort(signal);state=await page.snapshot();inspectSpecificationGroups(state,plan,tracked,true);matrix=inspectSkuMatrix(state,plan);if(matrix.rows.size===plan.rows.length){inspectSkuMatrix(state,plan,{complete:true});return [{label:'销售规格',ok:true,skuPlan:plan,skuGroupIds:[...tracked]}];}await wait(150);}
  throw Error('销售规格已填写，但页面尚未生成完整 SKU 矩阵。');
}
async function fillSkuTable(page,product,wait,signal){
  const plan=expectedSkuPlan(product);if(!plan.rows.length)return [];const checks=[],tracked=new Map();let requireGroups=!plan.legacy;
  try{validateSkuPlan(plan);const state=await page.snapshot();inspectSkuMatrix(state,plan,{complete:true,inputs:true});requireGroups||=!!state.specificationGroups?.length;if(requireGroups)inspectSpecificationGroups(state,plan,tracked,true);}catch(error){return [{label:'SKU 表格',ok:false,reason:error.message}];}
  checks.push({label:'SKU 表格',ok:true,skuPlan:plan,skuGroupIds:[...tracked]});
  for(const row of plan.rows){
    const title=row.values.map(clean).join(' / ');
    if(![...row.values,row.price,row.stock,row.sku].every(value=>value!==undefined&&value!==null&&value!=='')){checks.push({label:title,ok:false,reason:'SKU规格、价格、库存或卖家 SKU 缺失。'});continue;}
    for(const field of ['price','stock','sku']){
      abort(signal);let matrix;try{const state=await page.snapshot();if(requireGroups)inspectSpecificationGroups(state,plan,tracked,true);matrix=inspectSkuMatrix(state,plan,{complete:true,inputs:true});}catch(error){checks.push({label:title,ok:false,reason:error.message});return checks;}
      const control=matrix.controls.get(skuTuple(plan,row.values)+'\0'+field);await page.fill(control.ref,String(row[field]));await wait(100);
      const after=await page.snapshot();let current;
      try{if(requireGroups)inspectSpecificationGroups(after,plan,tracked,true);current=inspectSkuMatrix(after,plan,{complete:true,inputs:true}).controls.get(skuTuple(plan,row.values)+'\0'+field);}catch(error){checks.push({label:title+' '+field,ok:false,reason:error.message});return checks;}
      const actual=after.controls.find(item=>item.selector===control.selector),ok=current?.selector===control.selector&&skuCellMatches(field,actual?.value,row[field]);
      checks.push({label:title+' '+field,selector:control.selector,acceptedValues:[String(row[field])],skuIdentity:{values:[...row.values],field},ok,reason:ok?'':'SKU单元格没有确认填写值。'});
      if(!ok)return checks;
    }
  }
  return checks;
}

function confirms(control, acceptedValues, multiple = false) {
  const actual = [control?.value, control?.text, ...(control?.selectedValues || [])].map(clean).filter(Boolean);
  return acceptedValues.every(accepted => (Array.isArray(accepted) ? accepted : [accepted]).some(choice => actual.some(value => same(value, choice) || multiple && value.split(/[,，;；\n]/u).some(part => same(part, choice)))));
}
function confirmsExactSelection(control,acceptedValues){
  const actual=(control?.selectedValues||[]).map(clean).filter(Boolean);
  return actual.length===acceptedValues.length&&new Set(actual).size===actual.length&&acceptedValues.every(group=>actual.some(value=>group.some(choice=>clean(choice)===value)))&&actual.every(value=>acceptedValues.some(group=>group.some(choice=>clean(choice)===value)));
}
function changedChecks(state, checks) {
  const sales=checks.filter(item=>item.ok&&item.skuPlan),salesIssues=[];let matrix,plan;
  if(sales.length)try{
    plan=sales[0].skuPlan;matrix=inspectSkuMatrix(state,plan,{complete:true,inputs:true});
    const tracked=sales.find(item=>item.skuGroupIds?.length)?.skuGroupIds;
    if(!plan.legacy||tracked?.length)inspectSpecificationGroups(state,plan,new Map(tracked||[]),true);
    for(const item of checks.filter(item=>item.ok&&item.skuIdentity)){
      const current=matrix.controls.get(skuTuple(plan,item.skuIdentity.values)+'\0'+item.skuIdentity.field);
      if(!current||current.selector!==item.selector)salesIssues.push('SKU单元格归属在后续操作中发生变化：'+item.label);
    }
  }catch(error){salesIssues.push('销售规格在后续操作中发生变化：'+error.message);}
  return [...salesIssues,...checks.filter(item => item.ok && item.selector && (item.acceptedValues || typeof item.expectedChecked === 'boolean')).filter(item => {
    const actual = state.controls.find(control => control.selector === item.selector);
    if(item.skuIdentity)return !skuCellMatches(item.skuIdentity.field,actual?.value,item.acceptedValues[0]);
    if (item.observedLabel !== undefined && (!same(actual?.label, item.observedLabel) || !same(actual?.section, item.observedSection))) return true;
    if(item.strictSelection)return actual?.instanceId!==item.instanceId||!confirmsExactSelection(actual,item.acceptedValues);
    if (typeof item.expectedChecked === 'boolean') return actual?.checked !== item.expectedChecked;
    return !confirms(actual, item.acceptedValues, item.multiple);
  }).map(item => '填写值在后续操作中发生变化：' + item.label)];
}

function filesFor(product, refs) {
  const assets = new Map((product.assets || []).map(item => [item.id, item]));
  return (refs || []).map(ref => { const asset = assets.get(typeof ref === 'string' ? ref : ref?.id); if (!asset?.localPath) throw new Error('商品图片尚未准备成受控本地文件。'); return asset.localPath; });
}
async function uploadFiles(page, { label, aliases = [], files, assetRoot }, wait) {
  if (!files.length) return { label, ok: true, skipped: true };
  await validateSpoolFiles(assetRoot, files);
  const snapshot = await page.snapshot(), names = [label, ...aliases];
  const matches = snapshot.controls.filter(item => ['button', ''].includes(item.role) || item.type === 'file').filter(item => names.some(name => same(item.label || item.text, name)));
  if (matches.length !== 1) return { label, ok: false, reason: '无法唯一确定图片／视频上传控件。' };
  await page.upload(matches[0].ref, files, assetRoot); await wait(400);
  const after = await page.snapshot();
  if (after.alerts?.some(item => /失败|不支持|超出|error|failed|invalid/iu.test(item))) return { label, ok: false, reason: '平台拒绝上传，请检查页面提示。' };
  // Upload acknowledgement must be visible. A file input assignment alone is not enough.
  const basenames = files.map(item => item.split(/[\\/]/u).at(-1));
  const uploadedControl = after.controls.find(item => item.selector === matches[0].selector);
  const acknowledged = basenames.every(name => clean(after.text).includes(clean(name)))
    || uploadedControl?.uploadImageCount >= (matches[0].uploadImageCount || 0) + files.length;
  return { label, ok: acknowledged, reason: acknowledged ? '' : '页面未显示可核实的上传完成反馈。' };
}

export function extractPublishReceipt(snapshot) {
  const success = (snapshot.alerts || []).find(item => /(?:发布成功|提交成功|商品已提交|Product (?:published|created|submitted)|Successfully (?:published|created|submitted))/iu.test(item));
  if (!success) return null;
  const candidates = [snapshot.url, ...snapshot.controls.filter(item => item.href).map(item => item.href)];
  let productId = '', url = '';
  for (const candidate of candidates) {
    let parsed; try { assertSellerUrl(candidate); parsed = new URL(candidate); } catch { continue; }
    const match = parsed.pathname.match(/\/product\/(?:edit|detail|manage)\/(\d{8,30})(?:\/|$)/u)
      || parsed.pathname.match(/\/product\/(?:edit|detail|manage)$/u) && [null, parsed.searchParams.get('product_id') || parsed.searchParams.get('id')];
    if (match?.[1] && /^\d{8,30}$/u.test(match[1])) {
      productId = match[1]; const safe = new URL(parsed.origin + parsed.pathname);
      for (const key of ['product_id', 'id']) if (parsed.searchParams.has(key)) safe.searchParams.set(key, parsed.searchParams.get(key));
      url = safe.href; break;
    }
  }
  if (!productId) productId = clean(snapshot.text).match(/(?:Product\s*ID|商品\s*ID|商品编号)\s*[:：#]?\s*(\d{8,30})/iu)?.[1] || '';
  return productId ? { productId, url, message: success } : null;
}

const draftSaveSuccess = value => /(?:草稿(?:已)?保存成功|保存草稿成功|已保存(?:为|至|到)草稿(?:箱)?|(?:successfully\s+)?saved\s+as\s+(?:a\s+)?draft|draft\s+(?:was\s+)?saved(?:\s+successfully)?|successfully\s+saved\s+(?:the\s+)?draft)/iu.test(clean(value));
const draftSaveFailure = value => /失败|未通过|未保存|无法保存|未能保存|保存不了|保存未成功|未成功保存|error|fail(?:ed|ure)?|invalid|unsuccess|unable\s+to\s+save|(?:could\s+not|cannot|can't|couldn't)\s+save|(?:not|never)\s+(?:successfully\s+)?saved|wasn['’]t\s+(?:successfully\s+)?saved/iu.test(clean(value));
const draftSaveFailures = snapshot => [...new Set([...(snapshot.alerts || []), ...(Array.isArray(snapshot.alertEvidence) ? snapshot.alertEvidence.map(item => item?.text) : [])].map(clean).filter(draftSaveFailure))];
function validAlertEvidence(evidence, alerts) {
  if (!Array.isArray(evidence) || evidence.length > 100 || !Array.isArray(alerts)) return false;
  const ids = new Set(), texts = new Set(alerts.map(clean));
  for (const item of evidence) {
    if (!item || typeof item.instanceId !== 'string' || !item.instanceId || item.instanceId.length > 160 || ids.has(item.instanceId)
      || typeof item.text !== 'string' || !clean(item.text) || typeof item.isLeaf !== 'boolean' || !texts.has(clean(item.text))) return false;
    ids.add(item.instanceId);
  }
  return alerts.every(value => evidence.some(item => clean(item.text) === clean(value)));
}
/** Only a new leaf notification or a pending leaf becoming successful can acknowledge this save. */
export function extractDraftReceipt(snapshot, { beforeAlerts=[], beforeAlertEvidence, beforeAlertEvidenceComplete }={}) {
  if (draftSaveFailures(snapshot).length) return null;
  // Recreating an old success toast gives it a new DOM identity without proving
  // a new save. With that success already present, require manual verification.
  if (beforeAlerts.some(draftSaveSuccess)) return null;
  let success;
  if (snapshot.alertEvidence !== undefined || beforeAlertEvidence !== undefined) {
    if (snapshot.alertEvidenceComplete !== true || beforeAlertEvidenceComplete !== true
      || !validAlertEvidence(snapshot.alertEvidence, snapshot.alerts || []) || !validAlertEvidence(beforeAlertEvidence, beforeAlerts)) return null;
    const previous = new Map(beforeAlertEvidence.map(item => [item.instanceId, item]));
    success = snapshot.alertEvidence.find(item => {
      const prior = previous.get(item.instanceId);
      return item.isLeaf && draftSaveSuccess(item.text) && (!prior || prior.isLeaf && !draftSaveSuccess(prior.text));
    })?.text;
  } else {
    // String-only older adapters cannot prove that an existing success was replaced.
    // A changed aggregate container must never revive its old success substring.
    const previous = new Set(beforeAlerts.map(clean));
    success = (snapshot.alerts || []).map(clean).find(value => !previous.has(value) && draftSaveSuccess(value));
  }
  if(!success)return null;
  let draftId='',url='';
  for(const candidate of [snapshot.url,...(snapshot.controls||[]).filter(item=>item.href).map(item=>item.href)]){
    let parsed;try{assertSellerUrl(candidate);parsed=new URL(candidate);}catch{continue;}
    const queryId=parsed.searchParams.get('draft_id')||parsed.searchParams.get('product_id');
    const pathId=parsed.pathname.match(/\/product\/(?:edit|draft)\/(\d{8,30})(?:\/|$)/u)?.[1];
    const id=pathId||queryId;
    if(id&&/^\d{8,30}$/u.test(id)){
      draftId=id;const safe=new URL(parsed.origin+parsed.pathname);
      for(const key of ['draft_id','product_id'])if(parsed.searchParams.has(key))safe.searchParams.set(key,parsed.searchParams.get(key));
      url=safe.href;break;
    }
  }
  return {status:'draft_saved',draftSaved:true,submitted:false,saveAcknowledged:true,...(draftId?{draftId}:{}),...(url?{url}:{}),message:success,source:'visible-seller-dom'};
}

export function createTikTokSellerRpa({ connect = connectTikTokBrowser, assetRoot = '', diagnosticsRoot = '', onReadProgress, onCategoryDefinitionDiagnostic, wait = sleep, now = () => new Date().toISOString(), readinessNow = () => Date.now(), qaDesktopViewport = false } = {}) {
  const safeListBusy = snapshot => (snapshot.optionLists || []).slice(0, 3).map(list => ({ busy: list.busy === true, scanComplete: list.busyEvidence?.scanComplete === true,
    ...Object.fromEntries(['ariaBusyCount', 'progressbarCount', 'activeSpinnerCount', 'loadingTextCount', 'inactiveSpinnerCount', 'staticWrapperCount'].map(key => [key, Number.isSafeInteger(list.busyEvidence?.[key]) && list.busyEvidence[key] >= 0 ? list.busyEvidence[key] : null])) }));
  const diagnose = async (page, snapshot, operation, error, reasonCode, stageInfo = {}, binding) => {
    let metadata = {};
    const snapshotMetrics = typeof page?.performanceDiagnostics === 'function' ? page.performanceDiagnostics() : {};
    const rendererTimedOut = snapshotMetrics.failures > 0 && snapshotMetrics.lastMs >= 14000;
    try { if (page?.metadata && !rendererTimedOut) metadata = await page.metadata(); } catch { /* Diagnostic collection must never prevent cleanup. */ }
    const diagnostics = safeDiagnostics(snapshot, metadata), result = { reasonCode: snapshot.securityChallenge?.detected ? 'security_verification_required' : reasonCode || failureReason(snapshot, error, binding), diagnostics };
    if (diagnostics.hostname) try { assertSellerUrl('https://' + diagnostics.hostname + '/'); } catch { result.reasonCode = 'not_official_page'; }
    if (!diagnosticsRoot || !isAbsolute(diagnosticsRoot)) return result;
    try {
      await mkdir(diagnosticsRoot, { recursive: true, mode: 0o700 }); const root = await realpath(diagnosticsRoot), id = randomUUID();
      let structure = {};
      try { if (page?.structureDiagnostics && !rendererTimedOut) { assertSellerUrl('https://' + diagnostics.hostname + '/'); structure = await page.structureDiagnostics(); } } catch { /* Bounded optional inspection cannot replace the failure result. */ }
      let screenshotFile = null;
      try {
        assertSellerUrl('https://' + diagnostics.hostname + '/');
        if (page?.screenshot && !rendererTimedOut) {
          const bytes = await page.screenshot();
          if (Buffer.isBuffer(bytes) && bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) && bytes.length <= 20000000) {
            screenshotFile = id + '.png'; await writeFile(join(root, screenshotFile), bytes, { flag: 'wx', mode: 0o600 });
          }
        }
      } catch { /* Nonofficial pages and capture failures never produce a saved image. */ }
      let postScreenshotSnapshot = null, postScreenshotStructure = {};
      if (screenshotFile && !rendererTimedOut) {
        try {
          const afterCapture = await page.snapshot();
          postScreenshotSnapshot = { diagnostics: safeDiagnostics(afterCapture), categoryColumnCount: (afterCapture.categoryColumns || []).length, visibleOptionListCount: (afterCapture.optionLists || []).length,
            pageBusy: afterCapture.busy === true, optionListBusyEvidence: safeListBusy(afterCapture),
            shopPopoverState: afterCapture.shopPopoverState,
            categoryBusy: afterCapture.categoryBusy === true, securityVerification: afterCapture.securityChallenge?.detected === true, knownProductGuideCount: (afterCapture.guidanceDialogs || []).filter(item => item.kind === 'image-to-draft').length,
            guidanceCloseCounts: (afterCapture.guidanceDialogs || []).filter(item => item.kind === 'image-to-draft').slice(0, 10).map(item => (item.closeRefs || []).length) };
          if (page.structureDiagnostics) postScreenshotStructure = await page.structureDiagnostics();
        } catch { postScreenshotSnapshot = { readFailed: true }; }
      }
      const diagnosticRef = id + '.json';
      const controls = (snapshot.controls || []).map(item => ({ label: clean(item.label || (item.role === 'button' ? item.text : '')), tag: clean(item.tag), role: clean(item.role) }))
        .filter(item => item.label && item.label.length <= 120 && !/password|token|secret|cookie|API.?key|验证码|密钥|@|\b\d{7,}\b/iu.test(item.label)).slice(0, 120);
      const observation = { shopTriggerCount: (snapshot.shopTriggers || []).length, shopTriggerRefs: (snapshot.shopTriggers || []).filter(ref => /^\d{1,6}$/u.test(ref)),
        knownProductGuideCount: (snapshot.guidanceDialogs || []).filter(item => item.kind === 'image-to-draft').length,
        editableControlCount: (snapshot.controls || []).filter(editable).length, unlabelledEditableCount: (snapshot.controls || []).filter(item => editable(item) && !clean(item.label)).length,
        pageScrollableCount: (snapshot.scrollables || []).filter(item => item.kind === 'page').length, visibleOptionListCount: (snapshot.optionLists || []).length };
      observation.shopIdentityMenuVisible = snapshot.shopIdentityMenuVisible === true;
      observation.pageBusy = snapshot.busy === true; observation.optionListBusyEvidence = safeListBusy(snapshot);
      observation.marketParameter = snapshot.marketParameter === 'US' ? 'US' : '';
      observation.categoryColumnCount = (snapshot.categoryColumns || []).length; observation.categoryBusy = snapshot.categoryBusy === true;
      observation.attributeGroupHeadings = (snapshot.attributeGroupHeadings || []).filter(name => ['关键属性', '可选属性'].includes(name));
      observation.attributeGroupTotals = Object.fromEntries(Object.entries(snapshot.attributeGroupTotals || {}).filter(([name, count]) => ['关键属性', '可选属性'].includes(name) && Number.isSafeInteger(count) && count >= 0));
      observation.attributeGroups = (snapshot.attributeGroups || []).slice(0, 10).map(group => ({ kind: ['关键属性', '可选属性'].includes(group.kind) ? group.kind : '', expanded: group.expanded === true,
        scanComplete: group.scanComplete === true, fieldRowsVerified: group.fieldRowsVerified === true, candidateControlCount: Number.isSafeInteger(group.candidateControlCount) ? group.candidateControlCount : null,
        missingLabelCount: Number.isSafeInteger(group.missingLabelCount) ? group.missingLabelCount : null, unresolvedCount: Number.isSafeInteger(group.unresolvedCount) ? group.unresolvedCount : null }));
      observation.guidanceCloseCounts = (snapshot.guidanceDialogs || []).filter(item => item.kind === 'image-to-draft').slice(0, 10).map(item => (item.closeRefs || []).length);
      observation.securityVerification = snapshot.securityChallenge?.detected === true;
      const safeUi = value => {
        const text = clean(value); return text.length <= 180 && !/(?:https?|wss?):\/\/|password|token|secret|cookie|API.?key|验证码|密钥|@|\b\d{7,}\b/iu.test(text) ? text : '';
      };
      const rawControlStructure = structure.controlStructure || (snapshot.controls || []).filter(editable).map(item => ({ ...item, ...item.uiHints }));
      const controlStructure = rawControlStructure.slice(0, 120).map(item => ({ tag: clean(item.tag), role: clean(item.role), label: safeUi(item.label),
        placeholder: safeUi(item.placeholder), className: safeUi(item.className), formLabels: (item.formLabels || []).map(safeUi).filter(Boolean).slice(0, 4) }));
      const publicLabelAnchors = (structure.publicLabelAnchors || []).slice(0, 60).map(item => ({ label: safeUi(item.label), ancestors: (item.ancestors || []).slice(0, 6).map(ancestor => ({
        tag: safeUi(ancestor.tag), role: safeUi(ancestor.role), className: safeUi(ancestor.className), descendantControls: (ancestor.descendantControls || []).slice(0, 12).map(control => ({ tag: safeUi(control.tag), role: safeUi(control.role), className: safeUi(control.className) })) })) }));
      const visibleSelectStructure = (structure.visibleSelectStructure || []).slice(0, 80).map(item => ({ tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className) }));
      const categoryMenuStructure = (structure.categoryMenuStructure || []).slice(0, 180).map(item => ({ tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className), label: safeUi(item.label) })).filter(item => item.label);
      const loadingStructure = (structure.loadingStructure || []).slice(0, 80).map(item => ({ tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className),
        bounds: Object.fromEntries(['x', 'y', 'width', 'height'].filter(key => Number.isFinite(item.bounds?.[key])).map(key => [key, Math.round(item.bounds[key] * 100) / 100])) }));
      const attributeControlStructure = (structure.attributeControlStructure || []).slice(0, 160).map(item => ({ kind: safeUi(item.kind), tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className),
        ancestors: (item.ancestors || []).slice(0, 6).map(ancestor => ({ tag: safeUi(ancestor.tag), role: safeUi(ancestor.role), className: safeUi(ancestor.className) })) }));
      const safeGroupStructure = entries => (entries || []).slice(0, 10).map(group => ({ kind: ['关键属性', '可选属性'].includes(group.kind) ? group.kind : '', heading: ['关键属性', '可选属性', '选填', 'Key attributes', 'Optional attributes'].includes(group.heading) ? group.heading : '',
        tag: safeUi(group.tag), role: safeUi(group.role), className: safeUi(group.className), grids: (group.grids || []).slice(0, 10).map(grid => ({ tag: safeUi(grid.tag), role: safeUi(grid.role), className: safeUi(grid.className),
          directChildCount: Number.isSafeInteger(grid.directChildCount) ? grid.directChildCount : null, truncated: grid.truncated === true, rows: (grid.rows || []).slice(0, 100).map(row => ({ tag: safeUi(row.tag), role: safeUi(row.role), className: safeUi(row.className),
            childCount: Number.isSafeInteger(row.childCount) ? row.childCount : null, knownSelectCount: Number.isSafeInteger(row.knownSelectCount) ? row.knownSelectCount : null, nativeControlCount: Number.isSafeInteger(row.nativeControlCount) ? row.nativeControlCount : null, formSlotCount: Number.isSafeInteger(row.formSlotCount) ? row.formSlotCount : null, treeTruncated: row.treeTruncated === true,
            structureTree: (row.structureTree || []).slice(0, 35).map(node => ({ tag: safeUi(node.tag), role: safeUi(node.role), className: safeUi(node.className), parentIndex: Number.isSafeInteger(node.parentIndex) ? node.parentIndex : null, depth: Number.isSafeInteger(node.depth) ? node.depth : null, childCount: Number.isSafeInteger(node.childCount) ? node.childCount : null })) })) })) }));
      const safeBounds = item => Object.fromEntries(['x', 'y', 'width', 'height'].filter(key => Number.isFinite(item?.[key])).map(key => [key, Math.round(item[key] * 100) / 100]));
      const safeRawMenuNode = node => ({ tag: safeUi(node.tag), role: safeUi(node.role), className: safeUi(node.className), bounds: safeBounds(node.bounds), display: safeUi(node.display), visibility: safeUi(node.visibility), opacity: safeUi(node.opacity),
        ariaHidden: ['true', 'false'].includes(node.ariaHidden) ? node.ariaHidden : '', nearestAriaHidden: node.nearestAriaHidden === true, hidden: node.hidden === true, nearestHidden: node.nearestHidden === true,
        positiveChildRectCount: Number.isSafeInteger(node.positiveChildRectCount) ? node.positiveChildRectCount : null, visibleAccepted: node.visibleAccepted === true,
        rejectReason: ['', 'hidden-attribute', 'aria-hidden', 'zero-rectangle', 'display-none', 'visibility-hidden', 'opacity-zero', 'ancestor-style'].includes(node.rejectReason) ? node.rejectReason : '' });
      const safeRawMenuCensus = raw => ({ counts: Object.fromEntries(['corePopup', 'coreColumn', 'menuitem', 'broad'].map(key => [key, Number.isSafeInteger(raw?.counts?.[key]) ? raw.counts[key] : null])), candidates: (raw?.candidates || []).slice(0, 20).map(safeRawMenuNode) });
      const safeRawCategoryAnchors = entries => (entries || []).filter(item => ['所有类目', '家居用品'].includes(item.label)).slice(0, 20).map(item => ({ label: item.label, ancestors: (item.ancestors || []).slice(0, 6).map(safeRawMenuNode) }));
      const safeShopPopover = raw => ({ rawCount: Number.isSafeInteger(raw?.rawCount) ? raw.rawCount : null, paintedCount: Number.isSafeInteger(raw?.paintedCount) ? raw.paintedCount : null, truncated: raw?.truncated === true,
        candidates: (raw?.candidates || []).slice(0, 20).map(item => ({ ...safeRawMenuNode(item), painted: item.painted === true })) });
      const safeSurface = raw => ({ iframeCount: Number.isSafeInteger(raw?.iframeCount) ? raw.iframeCount : null,
        shadowRootHostCount: Number.isSafeInteger(raw?.shadowRootHostCount) ? raw.shadowRootHostCount : null,
        frameStructure: (raw?.frameStructure || []).slice(0, 20).map(item => ({ tag: safeUi(item.tag), className: safeUi(item.className), role: safeUi(item.role), officialHost: item.officialHost === true, sameOrigin: item.sameOrigin === true })),
        shadowRootHosts: (raw?.shadowRootHosts || []).slice(0, 20).map(item => ({ tag: safeUi(item.tag), className: safeUi(item.className), role: safeUi(item.role) })), examinedElements: Number.isSafeInteger(raw?.examinedElements) ? raw.examinedElements : null, shadowScanTruncated: raw?.shadowScanTruncated === true });
      observation.shopPopoverState = safeShopPopover(snapshot.shopPopoverState);
      const safeCorner = item => ({ tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className), ariaLabel: safeUi(item.ariaLabel), title: safeUi(item.title), ariaHidden: ['true', 'false'].includes(item.ariaHidden) ? item.ariaHidden : '', dataIcon: safeUi(item.dataIcon), cursor: safeUi(item.cursor), bounds: safeBounds(item.bounds) });
      const sanitizeGuidance = entries => (entries || []).slice(0, 10).map(item => ({ tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className), bounds: safeBounds(item.bounds),
        closeCandidates: (item.closeCandidates || []).slice(0, 60).map(candidate => ({ tag: safeUi(candidate.tag), role: safeUi(candidate.role), className: safeUi(candidate.className), bounds: safeBounds(candidate.bounds) })),
        cornerCandidates: (item.cornerCandidates || []).slice(0, 60).map(candidate => ({ ...safeCorner(candidate), parents: (candidate.parents || []).slice(0, 3).map(safeCorner) })),
        descendantNodeCount: Number.isSafeInteger(item.descendantNodeCount) ? item.descendantNodeCount : null,
        filterCounts: Object.fromEntries(['examined', 'notRendered', 'input', 'tooLarge', 'accepted'].map(key => [key, Number.isSafeInteger(item.filterCounts?.[key]) ? item.filterCounts[key] : null])), treeTruncated: item.treeTruncated === true,
        structureTree: (item.structureTree || []).slice(0, 300).map(node => ({ tag: safeUi(node.tag), role: safeUi(node.role), className: safeUi(node.className), parentIndex: Number.isSafeInteger(node.parentIndex) ? node.parentIndex : null,
          depth: Number.isSafeInteger(node.depth) ? node.depth : null, childCount: Number.isSafeInteger(node.childCount) ? node.childCount : null, bounds: safeBounds(node.bounds), display: safeUi(node.display), visibility: safeUi(node.visibility), opacity: safeUi(node.opacity),
          hidden: node.hidden === true, ariaHidden: ['true', 'false'].includes(node.ariaHidden) ? node.ariaHidden : '', shadowRootPresent: node.shadowRootPresent === true, iframePresent: node.iframePresent === true, dataIcon: safeUi(node.dataIcon) })) }));
      const guidanceStructure = sanitizeGuidance(structure.guidanceStructure);
      const postScreenshot = postScreenshotSnapshot ? { snapshot: { ...postScreenshotSnapshot, shopPopoverState: safeShopPopover(postScreenshotSnapshot.shopPopoverState) }, guidanceProbeVersion: [3, 4, 5, 6].includes(postScreenshotStructure.guidanceProbeVersion) ? postScreenshotStructure.guidanceProbeVersion : null,
        rawMenuCensus: safeRawMenuCensus(postScreenshotStructure.rawMenuCensus), rawCategoryAnchors: safeRawCategoryAnchors(postScreenshotStructure.rawCategoryAnchors),
        surfaceCensus: safeSurface(postScreenshotStructure.surfaceCensus),
        attributeGroupStructure: safeGroupStructure(postScreenshotStructure.attributeGroupStructure),
        guidanceStructure: sanitizeGuidance(postScreenshotStructure.guidanceStructure), categoryMenuStructure: (postScreenshotStructure.categoryMenuStructure || []).slice(0, 180).map(item => ({ tag: safeUi(item.tag), role: safeUi(item.role), className: safeUi(item.className), label: safeUi(item.label) })).filter(item => item.label),
        structureMetrics: postScreenshotStructure.structureMetrics || null } : null;
      const actionTrace = typeof page?.diagnosticsTrace === 'function' ? page.diagnosticsTrace() : [];
      let actionSummary = null;
      try { const driverDiagnostics = page?.getDiagnostics?.(); if (driverDiagnostics?.version === 1 && driverDiagnostics.actionSummary) actionSummary = structuredClone(driverDiagnostics.actionSummary); } catch { /* The fixed driver summary is optional and performs no page request. */ }
      const driverStage = new Set(['create_target', 'attach_target', 'Target.activateTarget', 'Page.enable', 'Page.bringToFront', 'Runtime.enable', 'Emulation.setDeviceMetricsOverride', 'Page.navigate']).has(error?.driverStage) ? error.driverStage : null;
      await writeFile(join(root, diagnosticRef), JSON.stringify({ version: 1, operation, observedAt: now(), ...result, screenshotFile, controls, observation, controlStructure, publicLabelAnchors, visibleSelectStructure, categoryMenuStructure, loadingStructure, attributeControlStructure, attributeGroupStructure: safeGroupStructure(structure.attributeGroupStructure), guidanceStructure,
        guidanceProbeVersion: [3, 4, 5, 6].includes(structure.guidanceProbeVersion) ? structure.guidanceProbeVersion : null, rawMenuCensus: safeRawMenuCensus(structure.rawMenuCensus), rawCategoryAnchors: safeRawCategoryAnchors(structure.rawCategoryAnchors), surfaceCensus: safeSurface(structure.surfaceCensus),
        structureMetrics: structure.structureMetrics || null, postScreenshot, snapshotMetrics, ...stageInfo, driverStage, actionTrace, actionSummary }, null, 2), { flag: 'wx', mode: 0o600 });
      result.diagnosticRef = diagnosticRef;
    } catch { /* Optional local diagnostics must not replace the original result. */ }
    return result;
  };
  const withPage = async ({ connection, binding, environment, signal, diagnosticOperation, preserveFilledPage=false, profile=false, onSnapshot, onReadFailure }, action) => {
    let browser, page, retained=false, profileRead=false, lastSnapshot = {}, stage = 'connect'; const stages = [];
    const observe = snapshot => { lastSnapshot = snapshot; onSnapshot?.(snapshot); };
    const runStage = async (name, operation) => {
      stage = name; const started = Date.now(); let ok = false;
      try { const value = await operation(); ok = true; return value; }
      finally { stages.push({ stage: name, elapsedMs: Date.now() - started, ok }); }
    };
    try {
      abort(signal); browser = await runStage('connect', () => connect(connection));
      page = await runStage('new_page', () => browser.newPage(assertSellerUrl(profile ? SELLER_PROFILE_URL : binding?.sellerUrl || environment?.sellerUrl || CREATE_URL), { qaDesktopViewport: qaDesktopViewport === true && ['inspect', 'readCategory'].includes(diagnosticOperation) }));
      profileRead=profile&&typeof page.profileSnapshot==='function';
      const deadline = readinessNow() + 60000;
      const loaded = await runStage('wait_ready', () => (profile ? waitProfileReady : waitReady)(page, wait, signal, observe, readinessNow, deadline));
      const snapshot = profile && loaded.profileSource === 'seller-profile' ? loaded : await runStage('read_shop_identity', () => readShopSnapshot(page, wait, loaded, 0, undefined, { signal, nowMs: readinessNow, binding, deadline, observe }));
      lastSnapshot = snapshot; const result = await runStage('operation', () => action(page, snapshot));
      if(!profile&&pairedProfileBinding(binding)){
        const observed=result.identity||snapshot.identity,evidence=pairedIdentityEvidence(binding,observed);
        if(evidence)result.pairedIdentityEvidence=evidence;
      }
      if (diagnosticOperation && !profileRead && result.status !== 'ready') {
        try { lastSnapshot = await page.snapshot(); } catch { /* Keep the most recent successfully read page. */ }
        Object.assign(result, await diagnose(page, lastSnapshot, diagnosticOperation, null, result.reasonCode, { stage, stages }, binding));
        if (diagnosticOperation === 'readCategory' && ['security_verification_required', 'not_official_page'].includes(result.reasonCode)) {
          result.fields = []; result.attributeGroups = []; delete result.attributeReadEvidence;
        }
      }
      if(preserveFilledPage&&(['filled','draft_saved','draft_unknown'].includes(result.status)||['needs_input','needs_review'].includes(result.status)&&result.checks?.length)){
        await page.detach?.();retained=true;result.pageRetained=true;
        if(result.receipt)result.receipt.pageRetained=true;
      }
      return result;
    } catch (error) {
      onReadFailure?.(shopReadFailure(lastSnapshot, error, binding));
      if (diagnosticOperation && !profileRead) {
        try { if (page && !signal?.aborted && !/超时/u.test(error.message || '')) lastSnapshot = await page.snapshot(); } catch { /* Metadata remains available on owned redirects. */ }
        error.rpaDiagnostics = await diagnose(page, lastSnapshot, diagnosticOperation, error, undefined, { stage, stages }, binding);
      }
      throw error;
    } finally { try { if(!retained)await page?.close(); } finally { await browser?.close(); } }
  };
  const readCategoriesOnPage=async(page,initial,binding,parentPath,signal)=>{
        const issues=compareShopIdentity(initial.identity||{},binding);
        if(issues.length)return {status:'needs_review',complete:false,identity:initial.identity,parentPath,nodes:[],issues,reasonCode:'identity_missing'};
        await selectPath(page,parentPath,wait,signal,true,readinessNow,initial.identity,true);
        const found=new Map();let previous='',stable=0,visitedTop=false,lastTop=-1,stalled=0;
        for(let step=0;step<300;step++){
          abort(signal);const state=await page.snapshot();assertSellerUrl(state.url);assertReadSnapshotSafety(state);
          if(state.securityChallenge?.detected)throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'),{code:'SELLER_SECURITY_VERIFICATION'});
          if(state.identity?.shopId&&compareShopIdentity(state.identity,binding).length)throw new Error('读取期间店铺身份发生变化。');
          if(state.busy||state.categoryBusy){await wait(150);continue;}
          const columns=(state.categoryColumns||[]).filter(column=>column.level===parentPath.length);
          if(!columns.length){
            if(parentPath.length&&exactCategoryScope(state,parentPath)&&!(state.categoryColumns||[]).length){
              if(++stable>=3){const after=await readShopSnapshot(page,wait,undefined,0,undefined,{signal,nowMs:readinessNow,binding});if(compareShopIdentity(after.identity,binding).length)throw new Error('读取后店铺身份核对失败。');return {status:'ready',complete:true,identity:after.identity,parentPath,leaf:true,nodes:[],source:'live-shop-category-menu'};}
            }else stable=0;
            await wait(150);continue;
          }
          if(columns.length!==1)throw new Error('类目列表不能唯一确定。');
          const column=columns[0],pane=(state.scrollables||[]).find(item=>item.selector===column.selector);
          if(column.busy){await wait(150);continue;}
          if(pane&&!visitedTop&&pane.top>1){await page.scroll(pane.selector,0);await wait(150);continue;}visitedTop=true;
          const frameLabels=new Set();for(const node of state.controls.filter(item=>column.optionRefs.includes(item.ref))){
            const label=clean(node.text||node.label);if(!label||label.length>160)continue;
            if(frameLabels.has(label))throw new Error('类目节点名称重复，无法唯一确定。');frameLabels.add(label);
            const disabled=node.disabled===true||/(?:^|\s)core-cascader-list-item-disabled(?:\s|$)/u.test(node.uiHints?.className||'');
            if(found.has(label)&&found.get(label).disabled!==disabled)throw new Error('类目可用状态发生变化。');
            found.set(label,{label,path:[...parentPath,label],disabled});if(found.size>2000)throw new Error('类目数量超过单层读取范围。');
          }
          if(pane&&pane.top+pane.height<pane.scrollHeight-2){
            if(pane.top===lastTop){if(++stalled>2)throw new Error('类目滚动未前进。');}else stalled=0;
            lastTop=pane.top;await page.scroll(pane.selector,Math.min(pane.scrollHeight-pane.height,pane.top+Math.max(20,pane.height*.75)));stable=0;await wait(150);continue;
          }
          const shape=JSON.stringify([...found.values()]);stable=shape===previous?stable+1:0;previous=shape;
          if(stable>=3&&found.size){
            await closeReadPopup(page,'category',wait,signal);
            const after=await readShopSnapshot(page,wait,undefined,0,undefined,{signal,nowMs:readinessNow,binding});if(compareShopIdentity(after.identity,binding).length)throw new Error('读取后店铺身份核对失败。');
            return {status:'ready',complete:true,identity:initial.identity,parentPath,leaf:false,nodes:[...found.values()],source:'live-shop-category-menu'};
          }
          await wait(150);
        }
        return {status:'needs_review',complete:false,identity:initial.identity,parentPath,nodes:[...found.values()],issues:['类目目录尚未完整载入，请重新读取。']};
  };
  return {
    async inspect({ environment, connection, signal } = {}) {
      try { return await withPage({ environment, connection, signal, diagnosticOperation: 'inspect', profile:true }, async (_page, snapshot) => {
        const identity = snapshot.identity || {};
        if (snapshot.profileSource === 'seller-profile') {
          const issues = [];
          if (!identity.shopName || !identity.region) issues.push('商家主页缺少可核实的店铺名称或地区。');
          if (!snapshot.profileComplete || !snapshot.mainCategory?.label) issues.push('商家主页缺少主营类目。');
          return {status:issues.length?'needs_review':'ready',complete:issues.length===0,identity,mainCategory:{...snapshot.mainCategory,profileUrl:SELLER_PROFILE_URL},profileSource:'seller-profile',capabilities:{readCategory:true,publish:false,saveDraft:true},issues};
        }
        const issues = compareShopIdentity(identity);
        return { status: issues.length ? 'needs_review' : 'ready', identity, capabilities: { readCategory: snapshot.controls.some(categoryControl), publish: snapshot.controls.some(item => /^(发布|提交审核|Publish|Submit for review)$/iu.test(clean(item.label || item.text))) }, issues };
      }); } catch (error) { return { status: 'needs_review', identity: { shopId: '', shopName: '', region: '' }, capabilities: { readCategory: false, publish: false }, issues: ['无法确认商家页面，请检查登录状态和商品编辑入口。'], ...(error.rpaDiagnostics || { reasonCode: error.code==='SELLER_SECURITY_VERIFICATION'?'security_verification_required':error.code==='SELLER_PROFILE_NOT_READY'?'profile_not_ready':error.code==='SELLER_LOGIN_REQUIRED'?'login_required':'browser_read_failed', diagnostics: safeDiagnostics() }) }; }
    },
    async verifyShop({environment,connection,binding,signal}={}) {
      let lastSnapshot = {}, readFailure;
      try { return await withPage({environment,connection,binding,signal,onSnapshot:snapshot=>{lastSnapshot=snapshot;},onReadFailure:value=>{readFailure=value;}},async(_page,snapshot)=>{
        const identity=snapshot.identity||{},issues=compareShopIdentity(identity,binding);
        return {status:issues.length?'needs_review':'ready',identity,issues,...(issues.length?shopReadFailure(snapshot,null,binding):{})};
      }); } catch(error) { return {status:'needs_review',identity:{},...(readFailure||shopReadFailure(lastSnapshot,error,binding))}; }
    },
    async readCategories({ connection, binding, parentPath = [], signal } = {}) {
      if (!Array.isArray(parentPath) || parentPath.length > 9 || parentPath.some(value => typeof value !== 'string' || !value.trim() || value.length > 160)) throw new Error('类目路径无效。');
      try { return await withPage({connection,binding,signal,diagnosticOperation:'readCategories'}, async(page,initial)=>readCategoriesOnPage(page,initial,binding,parentPath,signal)
      ); }catch(error){return {status:'needs_review',complete:false,parentPath,nodes:[],issues:[error.message],...(error.rpaDiagnostics||{reasonCode:'browser_read_failed'})};}
    },
    async readCategoryTree({connection,binding,cachedCatalogs=[],maxBranches=20,signal}={}) {
      const main=binding?.mainCategory,label=clean(typeof main==='string'?main:main?.label),root=[label];
      if(!label||label.length>160||!Number.isSafeInteger(maxBranches)||maxBranches<1||maxBranches>100)return {status:'needs_review',complete:false,catalogs:[],issues:['店铺主营类目或同步批次数量无效。']};
      const cached=new Map();
      for(const item of cachedCatalogs){
        const path=item?.parentPath,nodes=item?.nodes;
        const valid=item?.complete===true&&Array.isArray(path)&&path.length>0&&path.length<=9&&path[0]===label&&path.every(part=>typeof part==='string'&&clean(part)===part&&part.length>0&&part.length<=160)
          &&Array.isArray(nodes)&&typeof item.leaf==='boolean'&&(item.leaf?nodes.length===0:nodes.length>0)
          &&nodes.every(node=>typeof node?.label==='string'&&clean(node.label)===node.label&&node.label.length>0&&node.label.length<=160&&typeof node.disabled==='boolean'&&Array.isArray(node.path)&&JSON.stringify(node.path)===JSON.stringify([...path,node.label]))
          &&new Set(nodes.map(node=>node.label)).size===nodes.length;
        if(valid)cached.set(JSON.stringify(path),item);
      }
      let completed=0;const catalogs=[],queue=[root],seen=new Set();
      try{return await withPage({connection,binding,signal},async(page,initial)=>{
        const identityIssues=compareShopIdentity(initial.identity||{},binding);
        if(identityIssues.length)return {status:'needs_review',complete:false,identity:initial.identity,mainCategory:main,catalogs:[],issues:identityIssues};
        while(queue.length){
          abort(signal);const path=queue.shift(),key=JSON.stringify(path);if(seen.has(key))continue;seen.add(key);
          if(path.length>9)return {status:'needs_review',complete:false,identity:initial.identity,mainCategory:main,catalogs,issues:['类目深度超过受支持范围，未标记完整。']};
          let branch=cached.get(key);
          if(!branch){
            if(completed>=maxBranches){queue.unshift(path);break;}
            branch=await readCategoriesOnPage(page,initial,binding,path,signal);completed++;
            const result={...branch,parentPath:[...path]};catalogs.push(result);
            if(branch.status!=='ready'||branch.complete!==true)return {status:'needs_review',complete:false,identity:initial.identity,mainCategory:main,catalogs,issues:branch.issues||['类目分支读取未完成。']};
          }
          if(!branch.leaf)for(const node of branch.nodes||[]){
            if(node.disabled===true)continue;
            if(!Array.isArray(node.path)||node.path.length!==path.length+1||node.path.slice(0,-1).some((part,index)=>part!==path[index])||node.path[0]!==label)return {status:'needs_review',complete:false,identity:initial.identity,mainCategory:main,catalogs,issues:['类目子分支路径不匹配。']};
            queue.push([...node.path]);
          }
        }
        const complete=queue.length===0;
        return {status:complete?'ready':'syncing',complete,identity:initial.identity,mainCategory:main,catalogs,branchesRead:completed,pendingBranches:queue.length,issues:[]};
      });}catch(error){return {status:'needs_review',complete:false,mainCategory:main,catalogs,issues:[error.message]};}
    },
    async readCategory({ connection, binding, categoryPath, signal } = {}) {
      if (typeof categoryPath === 'string') categoryPath = categoryPath.split(/\s*>\s*/u).filter(Boolean);
      const fields = [], issues = []; let lastOptionProgress = -Infinity;
      const progress = (phase, label = '', optionsCount = 0) => {
        if (typeof onReadProgress !== 'function') return;
        if (phase === 'options_progress' && Date.now() - lastOptionProgress < 1000) return;
        if (phase === 'options_progress') lastOptionProgress = Date.now();
        const text = clean(label), safeLabel = text.length <= 100 && !/https?:|wss?:|password|token|secret|cookie|API.?key|@|\b\d{7,}\b/iu.test(text) ? text : '';
        const event = { phase, fieldCount: fields.length, label: safeLabel, optionsCount: Number.isSafeInteger(optionsCount) && optionsCount >= 0 ? Math.min(optionsCount, 100000) : 0 };
        try { Promise.resolve(onReadProgress(event)).catch(() => {}); } catch { /* QA observation cannot change the read outcome. */ }
      };
      progress('starting');
      try { return await withPage({ connection, binding, signal, diagnosticOperation: 'readCategory' }, async (page, initial) => {
        const identity = initial.identity || {}, identityIssues = compareShopIdentity(identity, binding);
        if (identityIssues.length) { progress('read_incomplete'); return { status: 'needs_review', complete: false, identity, categoryPath, fields, issues: identityIssues, reasonCode: !identity.shopId || !identity.shopName || !identity.region ? failureReason(initial,undefined,binding) : 'identity_mismatch' }; }
        progress('identity_verified');
        if (typeof page.beginCategoryDefinitionRead === 'function') await page.beginCategoryDefinitionRead();
        await selectPath(page, categoryPath, wait, signal, true, readinessNow, identity);
        progress('category_selected');
        await expandAttributeSections(page, wait, signal, () => {}, true);
        progress('attributes_expanded');
        if (typeof page.readCategoryDefinition === 'function') {
          abort(signal);
          const definition = await page.readCategoryDefinition();
          abort(signal);
          let mapped, definitionSnapshot, previous = '', stable = 0;
          if (definition?.accepted === true) for (let sample = 0; sample < 5; sample++) {
            abort(signal); const current = await page.snapshot(); assertSellerUrl(current.url);
            definitionSnapshot = current;
            if (current.securityChallenge?.detected) throw Object.assign(new Error('页面存在安全验证，需要人工完成后再重试。'), { code: 'SELLER_SECURITY_VERIFICATION' });
            mapped = buildPartialCategoryDefinitionFields({ definition, snapshot: current, scopeVerified: exactCategoryScope(current, categoryPath) });
            if (!mapped.accepted && (!mapped.partialFieldsVerified || sample === 0)) {
              if (typeof onCategoryDefinitionDiagnostic === 'function' && mapped.diagnostics) {
                try { Promise.resolve(onCategoryDefinitionDiagnostic(structuredClone(mapped.diagnostics))).catch(() => {}); } catch { /* Optional QA evidence cannot change the read result. */ }
              }
            }
            if (!mapped.partialFieldsVerified) break;
            const signature = definitionFieldsSignature(mapped);
            stable = signature === previous ? stable + 1 : 1; previous = signature;
            if (stable >= 3) break;
            await wait(100);
          }
          if (mapped?.partialFieldsVerified && stable >= 3) {
            const observedCache = [], inputCache = [], inputCandidates = mapped.inputCandidates || []; let observedContext = null, supplementalCache = null, supplementalComplianceFields = [];
            const canReadLists = mapped.fields.some(observedCandidate) && typeof page.readPublicOptionListCensus === 'function';
            const canReadInputs = inputCandidates.length > 0 && typeof page.readPublicInputCensus === 'function';
            const canReadDefinitionDrafts = (mapped.definitionInputDraftCandidates || []).length > 0;
            const canReadCompliance = typeof page.readPublicComplianceFieldCensus === 'function';
            if ((canReadLists || canReadInputs || canReadDefinitionDrafts || canReadCompliance) && typeof page.getDocumentFingerprint === 'function') {
              abort(signal); const documentFingerprint = await page.getDocumentFingerprint(); abort(signal);
              if (fingerprintValid(documentFingerprint)) {
                observedContext = { identity, categoryPath, categoryId: definition.categoryId,
                  attributeContext: attributeContextFingerprint(definitionSnapshot), documentFingerprint };
                for (const slot of canReadLists ? mapped.fields.filter(observedCandidate) : []) {
                  progress('field_started', slot.label);
                  const entry = await probeObservedOptionList(page, slot, observedContext, { wait, signal, nowMs: readinessNow,
                    onProgress: count => progress('options_progress', slot.label, count) });
                  if (entry) observedCache.push(entry);
                }
                for (const candidate of canReadInputs ? inputCandidates : []) {
                  const slot = mapped.fields.find(field => field.key === candidate.fieldKey); if (!slot) continue;
                  progress('field_started', slot.label);
                  const entry = await probeObservedInput(page, slot, candidate, observedContext, { wait, signal, nowMs: readinessNow });
                  if (entry) inputCache.push(entry);
                }
                if (canReadCompliance) supplementalCache = await probeSupplementalComplianceFields(page, { definition, context: observedContext,
                  assertScope: assertObservedScope, contextFingerprint: attributeContextFingerprint, wait, signal, nowMs: readinessNow });
                // A second stable full-census observation includes only proofs
                // established in this same document and attribute context.
                stable = 0; previous = '';
                for (let sample = 0; sample < 5; sample++) {
                  abort(signal); const current = await page.snapshot(); assertObservedScope(current, observedContext);
                  const base = mergeDefinitionInputDrafts(buildPartialCategoryDefinitionFields({ definition, snapshot: current, scopeVerified: exactCategoryScope(current, categoryPath) }), current, documentFingerprint);
                  mapped = mergeObservedInputs(mergeObservedOptionLists(base, current, observedCache, documentFingerprint), current, inputCache, documentFingerprint);
                  if (!mapped.partialFieldsVerified) break;
                  const signature = definitionFieldsSignature(mapped);
                  stable = signature === previous ? stable + 1 : 1; previous = signature;
                  if (stable >= 3) break;
                  await wait(100);
                }
              }
            }
            if (supplementalCache) {
              // Supplemental controls have their own census. Verify full shop
              // identity before revalidating those controls, then independently
              // repeat identity, category, epoch and the primary mapper below.
              const beforeSupplemental = await readShopSnapshot(page, wait, undefined, 0, undefined, { signal, nowMs: readinessNow, binding });
              assertObservedScope(beforeSupplemental, observedContext);
              if (compareShopIdentity(beforeSupplemental.identity || {}, binding).length) throw observedScopeError();
              supplementalComplianceFields = await finalizeSupplementalComplianceFields(page, supplementalCache, { definition, context: observedContext,
                assertScope: assertObservedScope, contextFingerprint: attributeContextFingerprint, wait, signal, nowMs: readinessNow });
            }
            const after = await readShopSnapshot(page, wait, undefined, 0, undefined, { signal, nowMs: readinessNow, binding });
            assertReadSnapshotSafety(after);
            const afterIssues = compareShopIdentity(after.identity || {}, binding);
            const finalBase = buildPartialCategoryDefinitionFields({ definition, snapshot: after, scopeVerified: exactCategoryScope(after, categoryPath) });
            let finalDocument = '';
            if (observedContext) {
              assertObservedScope(after, observedContext);
              abort(signal); finalDocument = await page.getDocumentFingerprint(); abort(signal);
              if (finalDocument !== observedContext.documentFingerprint) throw observedScopeError();
            }
            const finalMapped = mergeObservedInputs(mergeObservedOptionLists(mergeDefinitionInputDrafts(finalBase, after, finalDocument), after, observedCache, finalDocument), after, inputCache, finalDocument);
            const finalMappingVerified = stable >= 3 && finalMapped.partialFieldsVerified === true && definitionFieldsSignature(finalMapped) === previous;
            if (!finalMappingVerified) afterIssues.push('读取结束时类目或属性结构已变化，请重新读取。');
            if (!mapped.accepted) {
              issues.push('部分属性对应关系尚未核验，已保留独立核验完整的字段。（category_definition_unverified；' + mapped.reason + '）');
              progress('category_definition_rejected', mapped.reason);
            }
            issues.push(...afterIssues);
            if (!afterIssues.length) fields.push(...mapped.fields);
            for (const field of fields) if (field.optionsComplete === true) progress('field_complete', field.label, field.options.length);
            const complete = mapped.accepted && !fields.some(field => field.valueKind === 'dom-label' || field.inputEvidence !== undefined) && !supplementalComplianceFields.length && !afterIssues.length;
            progress(complete ? 'read_complete' : 'read_incomplete');
            const reasonCode = afterIssues.length && compareShopIdentity(after.identity || {}, binding).length
              ? !after.identity?.shopId || !after.identity?.shopName || !after.identity?.region ? 'identity_missing' : 'identity_mismatch'
              : 'category_read_incomplete';
            return { status: complete ? 'ready' : 'needs_review', complete, ...(!complete ? { reasonCode } : {}), identity, categoryPath: [...categoryPath], fields,
              attributeGroups: afterIssues.length ? [] : mapped.attributeGroups,
              ...(!afterIssues.length && supplementalComplianceFields.length ? { supplementalComplianceFields } : {}),
              ...(!afterIssues.length ? { attributeReadEvidence: { version: 1, kind: 'observed-category-definition-fields', scopeVerified: true, responseComplete: true,
                definitionRowsComplete: true, stableSamples: stable, identityVerified: true, categoryPathVerified: true, fieldUniverseComplete: true, categoryId: definition.categoryId } } : {}),
              issues, observedAt: now(), source: 'visible-seller-dom-and-category-api' };
          }
          if (definition?.accepted === true) {
            // Once a real definition has exposed an unresolved association, a
            // label-keyed DOM union cannot prove its full API-ID universe. Keep
            // the verified census and stop before a long, unusable enumeration.
            const allowed = new Set(['scope_unverified', 'snapshot_not_ready', 'definition_unverified', 'attribute_controls_invalid', 'attribute_descriptor_invalid',
              'attribute_relation_ambiguous', 'attribute_census_incomplete', 'property_relation_unverified', 'property_relation_ambiguous',
              'mapped_property_unverified', 'required_mismatch', 'mapped_options_incomplete', 'mapped_property_kind_unverified', 'no_enum_attributes']);
            const reason = mapped?.partialFieldsVerified ? 'category_mapping_unstable' : allowed.has(mapped?.reason) ? mapped.reason : 'category_definition_unverified';
            issues.push('类目定义与实际属性的对应关系尚未核验，不能确认选项编号完整。（category_definition_unverified；' + reason + '）');
            progress('category_definition_rejected', reason);
            const after = await readShopSnapshot(page, wait, undefined, 0, undefined, { signal, nowMs: readinessNow, binding }); assertReadSnapshotSafety(after);
            const afterIssues = compareShopIdentity(after.identity || {}, binding);
            issues.push(...afterIssues); progress('read_incomplete');
            const reasonCode = afterIssues.length ? !after.identity?.shopId || !after.identity?.shopName || !after.identity?.region ? 'identity_missing' : 'identity_mismatch' : 'category_read_incomplete';
            return { status: 'needs_review', complete: false, reasonCode, identity, categoryPath: [...categoryPath], fields,
              attributeGroups: (definitionSnapshot?.attributeGroups || []).map(group => ({ ...group, capturedControlCount: 0 })),
              issues, observedAt: now(), source: 'visible-seller-dom-and-category-api' };
          }
          progress('category_definition_fallback', mapped?.reason || definition?.reason || 'category_definition_unverified');
        }
        const captured = new Set(), ordinals = new Map(), pagePositions = new Set();
        const captureId = item => [item.selector, item.section, item.label, item.role, item.type].join('\0');
        let bottomStable = 0, previousBottom = '';
        for (let round = 0; round < 50; round++) {
          abort(signal); let snapshot = await page.snapshot();
          if (snapshot.busy) { bottomStable = 0; previousBottom = ''; await wait(200); if (round === 49) issues.push('属性页面仍在加载，未能确认读取完整。'); continue; }
          const next = snapshot.controls.find(item => editable(item) && attributeControl(item) && clean(item.label) && !categoryControl(item) && !captured.has(captureId(item)));
          if (next) {
            bottomStable = 0; previousBottom = ''; captured.add(captureId(next)); const label = clean(next.label), section = clean(next.section), ordinalKey = section + '\0' + label;
            const ordinal = (ordinals.get(ordinalKey) || 0) + 1; ordinals.set(ordinalKey, ordinal);
            progress('field_started', label);
            let result = { options: [], complete: true };
            if (next.role === 'combobox' || next.tag === 'select') result = next.disabled ? { options: [], complete: false } : await optionsFor(page, next, wait, signal, { keepIncompleteOpen: true, readOnly: true, onProgress: count => progress('options_progress', label, count) });
            if (!result.complete) issues.push('选项未能完整读取：' + label + (result.reason ? '（' + result.reason + '）' : ''));
            fields.push({ key: fieldKey(section, label, ordinal), label, section, ordinal, options: result.options, optionsComplete: result.complete, ...(result.evidence ? { optionsEvidence: result.evidence } : {}), multiple: next.multiple === true, required: next.required === true, controlType: next.role === 'combobox' || next.tag === 'select' ? 'select' : next.type || next.role || next.tag });
            progress(result.complete ? 'field_complete' : 'read_incomplete', label, result.options.length);
            if (!result.complete) return { status: 'needs_review', complete: false, reasonCode: 'category_read_incomplete', identity, categoryPath: [...categoryPath], fields, attributeGroups: (snapshot.attributeGroups || []).map(group => ({ ...group, capturedControlCount: fields.filter(field => field.section === group.kind).length })), issues, observedAt: now(), source: 'visible-seller-dom' };
            if (fields.length >= 700) { issues.push('页面字段超过本次读取范围，请人工确认。'); break; }
            // Revisit the current viewport after every popup; its DOM references can change.
            round--; continue;
          }
          snapshot = await page.snapshot(); const pane = (snapshot.scrollables || []).find(item => item.kind === 'page' && item.top + item.height < item.scrollHeight - 2 || item.selector === ':root' && item.top + item.height < item.scrollHeight - 2);
          if (!pane || pane.top + pane.height >= pane.scrollHeight - 2) {
            const fingerprint = JSON.stringify({ controls: snapshot.controls.map(captureId), panes: snapshot.scrollables, busy: snapshot.busy });
            bottomStable = !snapshot.busy && fingerprint === previousBottom ? bottomStable + 1 : 0; previousBottom = fingerprint;
            if (bottomStable >= 3) break;
            await wait(200); if (round === 49) issues.push('属性页面底部没有确认稳定，未能完整读取。'); continue;
          }
          bottomStable = 0; previousBottom = '';
          const top = Math.min(pane.scrollHeight - pane.height, pane.top + pane.height * .75);
          const positionKey = pane.selector + '\0' + top;
          if (pagePositions.has(positionKey)) { issues.push('页面滚动重复，属性列表可能不完整。'); break; }
          pagePositions.add(positionKey); await page.scroll(pane.selector, top); await wait(150);
          if (round === 49) issues.push('页面属性超过本次读取范围，请人工确认。');
        }
        for (const field of fields) field.groupCount = ordinals.get(field.section + '\0' + field.label) || 0;
        const finalGroups = await page.snapshot();
        const attributeGroups = (finalGroups.attributeGroups || []).map(group => ({ ...group, capturedControlCount: fields.filter(field => field.section === group.kind).length }));
        for (const group of attributeGroups) if (group.scanComplete !== true || group.truncated || group.unresolvedCount || group.candidateControlCount !== group.capturedControlCount) issues.push(group.kind + '字段候选结构尚未完整验证，不能确认读取完整。');
        if (attributeGroups.length && !attributeGroups.some(group => group.kind === '可选属性' && group.expanded === true)) issues.push('尚未确认真实可选属性分组展开与候选全集。');
        if (!fields.length) issues.push('没有读取到真实关键/可选商品属性分组，普通文本字段不能代替类目属性。');
        const selects = fields.filter(field => field.controlType === 'select');
        if (!selects.some(field => field.optionsComplete === true && field.options.length > 0)) issues.push('尚未完整读取到真实属性下拉选项，不能确认类目属性完整。');
        for (const field of selects) if (field.optionsComplete !== true || !field.options.length) issues.push('真实属性下拉仍无完整选项：' + field.label);
        for (const name of finalGroups.attributeGroupHeadings || []) {
          const groupFields = fields.filter(field => clean(field.section).startsWith(name)), total = finalGroups.attributeGroupTotals?.[name];
          if (!groupFields.length && total !== 0) issues.push('尚未确认' + name + '完整展开与读取。');
          if (Number.isSafeInteger(total) && total >= 0 && groupFields.length !== total) issues.push(name + '实际读取数量与页面声明总数不一致。');
        }
        const after = await readShopSnapshot(page, wait, undefined, 0, undefined, { signal, nowMs: readinessNow, binding }); assertReadSnapshotSafety(after);
        const afterIssues = compareShopIdentity(after.identity || {}, binding); issues.push(...afterIssues);
        const reasonCode = afterIssues.length ? !after.identity?.shopId || !after.identity?.shopName || !after.identity?.region ? 'identity_missing' : 'identity_mismatch' : 'category_read_incomplete';
        progress(issues.length ? 'read_incomplete' : 'read_complete');
        return { status: issues.length ? 'needs_review' : 'ready', complete: issues.length === 0, ...(issues.length ? { reasonCode } : {}), identity, categoryPath: [...categoryPath], fields, attributeGroups, issues, observedAt: now(), source: 'visible-seller-dom' };
      }); } catch (error) { progress('read_incomplete'); return { status: 'needs_review', complete: false, categoryPath, fields, issues: [...issues, /https?:\/\/|wss?:\/\/|token|secret|password|cookie/iu.test(error.message) ? '商家页面读取失败，请查看本机诊断。' : error.message], ...(error.rpaDiagnostics || { reasonCode: failureReason({}, error), diagnostics: safeDiagnostics() }) }; }
    },
    async saveDraft(input={}) { return this.publish({...input,mode:'save_draft'}); },
    async fillDraft(input={}) { return this.publish({...input,mode:'fill_draft'}); },
    async publish({ connection, binding, product = {}, onPhase = () => {}, signal, mode='publish' } = {}) {
      const saveDraft=mode==='save_draft',fillOnly=mode==='fill_draft'||saveDraft;
      if(!['publish','fill_draft','save_draft'].includes(mode))return {status:'needs_review',issues:['商品操作类型无效。'],checks:[],receipt:null};
      // Duplicate platform labels remain separate in the packaged catalog. The
      // current DOM adapter has no independently observed category-ID mapping;
      // one mounted label must not silently select a different same-name node.
      if(Array.isArray(product.identityPath)){
        const displayed=Array.isArray(product.categoryPath)?product.categoryPath:String(product.categoryPath||'').split(/\s*>\s*/u);
        if(product.identityPath.length!==displayed.length||product.identityPath.some((part,index)=>clean(part)!==clean(displayed[index])))return {status:'needs_review',issues:['该类目含同名节点，当前后台尚无可核对的类目编号映射，未填写或保存商品。请在店铺后台按类目编号确认。'],checks:[],receipt:null};
      }
      if (binding?.identity) binding = { ...binding, ...binding.identity };
      let submitted = false,draftSaveClicked=false,firstFailureDiagnostics; const checks = [];
      let currentPage;
      let diagnostics={phase:'verifying-shop',field:'商品核对',operation:'verify',recoveryAttempts:0,dispatchState:'not_dispatched',draftSaveAttempted:false};
      const recoveryCount=()=>{const count=currentPage?.getWriteDiagnostics?.().recoveryAttempts;return Number.isSafeInteger(count)?Math.max(diagnostics.recoveryAttempts,Math.max(0,Math.min(2,count))):diagnostics.recoveryAttempts;};
      const phase=async(name,field,operation)=>{diagnostics={phase:name,field,operation,recoveryAttempts:recoveryCount(),dispatchState:'not_dispatched',draftSaveAttempted:draftSaveClicked||name==='saving_draft'};await onPhase(name,{diagnostics:{...diagnostics}});};
      const fieldName=field=>/^(?:商品名称|产品名称|Product name|Product title|Title)$/iu.test(clean(field.label))?'商品名称':/^(?:商品描述|产品描述|描述|Product description|Description)$/iu.test(clean(field.label))?'商品描述':/^(?:搜索关键词|Search keywords|Keywords)$/iu.test(clean(field.label))?'搜索关键词':/^(?:商品亮点|Product highlights|Highlights)$/iu.test(clean(field.label))?'商品亮点':'类目属性';
      try { const result=await withPage({ connection, binding, signal, preserveFilledPage:fillOnly }, async (page, initial) => {
        currentPage=page;
        const identityIssues = compareShopIdentity(initial.identity || {}, binding);
        if (!binding?.shopId || !binding?.region) identityIssues.push('目标店铺还没有有效的 ID 和地区绑定。');
        if (identityIssues.length) return { status: 'needs_review', issues: identityIssues, receipt: null };
        await phase('reading_category','商品类目','select'); const categoryPath = product.categoryPath || product.profile?.categoryPath || product.profile?.category; const frozenCategoryPath=Array.isArray(categoryPath)?categoryPath.map(clean):String(categoryPath||'').split(/\s*>\s*/u).map(clean);
        await selectPath(page, categoryPath, wait, signal);
        await expandAttributeSections(page, wait, signal);
        await phase('filling_product','商品名称','fill');
        for (const field of mappedFields(product)) { abort(signal); await phase('filling_product',fieldName(field),'fill'); checks.push(await setField(page, field, wait, signal,{fillOnly,context:{identity:binding,categoryPath:frozenCategoryPath}})); }
        const categoryAttributes = product.profile?.categoryAttributes || {};
        const missingAttributeMappings = Object.keys(categoryAttributes).filter(key => !(product.fields || []).some(item => item.key === key));
        if (missingAttributeMappings.length) checks.push({ label: '类目属性', ok: false, reason: '部分属性缺少真实页面字段映射。', keys: missingAttributeMappings });
        for (const dictionary of ['properties', 'qualifications']) {
          const missing = Object.entries(product.profile?.[dictionary] || {}).filter(([, value]) => value !== '' && value !== null && value !== undefined).filter(([key]) => !(product.fields || []).some(item => item.key === key || item.sourcePath === 'profile.' + dictionary + '.' + key));
          if (missing.length) checks.push({ label: dictionary === 'properties' ? '商品属性／合规声明' : '商品资质', ok: false, reason: '部分已填写值没有真实页面字段映射，不能忽略。', keys: missing.map(([key]) => key) });
        }
        if (product.profile?.scheduleEnabled === true && !(product.fields || []).some(item => item.sourcePath === 'profile.scheduleEnabled') || product.profile?.scheduledAt && product.profile?.scheduleEnabled === true && !(product.fields || []).some(item => item.sourcePath === 'profile.scheduledAt')) checks.push({ label: '定时发布', ok: false, reason: '定时设置没有真实页面字段映射，不能改成立即发布。' });
        for (const key of ['specialProductListingType', 'gtinType', 'gtinCode', 'listPrice', 'auctionStartingPrice']) if (product.profile?.[key] !== '' && product.profile?.[key] !== undefined && !(product.fields || []).some(item => item.sourcePath === 'profile.' + key)) checks.push({ label: key, ok: false, reason: '已填写设置没有真实页面字段映射。' });
        await phase('uploading_images','商品图片','upload');
        for (const config of [
          { label: '商品图片', aliases: ['上传商品图片', '上传主图', 'Product images', 'Upload images'], files: filesFor(product, product.gallery) },
          { label: '详情图片', aliases: ['详情图', 'Description images'], files: filesFor(product, product.details) },
          { label: '尺码表', aliases: ['上传尺码表', 'Size chart'], files: product.sizeChart ? filesFor(product, [product.sizeChart]) : [] },
          { label: '视频', aliases: ['上传视频', 'Video', 'Upload video'], files: product.video?.localPath ? [product.video.localPath] : [] }
        ]) { abort(signal); await phase('uploading_images',config.label==='详情图片'?'详情图':config.label,'upload'); checks.push(await uploadFiles(page, { ...config, assetRoot }, wait)); }
        // Existing SKU data may only be applied to uniquely labelled visible cells.
        // No assumed row order or guessed platform attribute IDs are accepted.
        await phase('filling_skus','销售规格','fill');
        for (const row of product.skuFields || []) { abort(signal); checks.push(await setField(page, row, wait, signal)); }
        if (!product.skuFields?.length) {
          let specificationsReady=true;
          if(fillOnly)try{checks.push(...await ensureSkuSpecifications(page,product,wait,signal));}catch(error){specificationsReady=false;checks.push({label:'销售规格',ok:false,reason:error.message});
            if(['SELLER_CONTROL_STALE','SELLER_CONTROL_AMBIGUOUS','SELLER_CONTROL_OBSCURED'].includes(error?.code))firstFailureDiagnostics={...diagnostics,phase:'filling_skus',field:'销售规格',code:error.code,recoveryAttempts:Math.max(recoveryCount(),Math.min(2,Math.max(0,Number.isSafeInteger(error.diagnostics?.recoveryAttempts)?error.diagnostics.recoveryAttempts:0))),dispatchState:['not_dispatched','dispatched','unknown'].includes(error.diagnostics?.dispatchState)?error.diagnostics.dispatchState:'unknown'};
          }
          if(specificationsReady)checks.push(...await fillSkuTable(page,product,wait,signal));
        }
        await phase('checking_product','商品核对','check'); let state = await readShopSnapshot(page, wait, undefined, 0, undefined, { signal, nowMs: readinessNow, binding });
        const issues = compareShopIdentity(state.identity || {}, binding);
        if(fillOnly&&!exactCategoryScope(state,frozenCategoryPath))issues.push('当前商品类目与保存任务不一致，未确认填写完成。');
        for (const item of state.controls.filter(item => editable(item) && item.required && !item.disabled)) {
          const missing = item.type === 'checkbox' ? !item.checked : item.type === 'radio' ? !state.controls.some(other => other.type === 'radio' && other.name && other.name === item.name && other.checked) : !clean(item.value || item.text) && !(item.selectedValues || []).length;
          if (missing) issues.push('必填项为空：' + (item.label || '未命名控件'));
        }
        for (const message of state.alerts || []) if (/必填|不能为空|请选择|error|required|invalid/iu.test(message)) issues.push(message);
        issues.push(...checks.filter(item => !item.ok).map(item => item.label + '：' + item.reason), ...changedChecks(state, checks));
        if (!clean(product.name)) issues.push('商品名称为空。');
        if (!(product.gallery || []).length) issues.push('没有准备商品主图。');
        if (issues.length) return { status: 'needs_input', issues, checks, receipt: null };
        if(fillOnly){
          abort(signal);
          const checked=await readShopSnapshot(page,wait,undefined,0,undefined,{signal,nowMs:readinessNow,binding});
          const changed=[...compareShopIdentity(checked.identity||{},binding),...changedChecks(checked,checks)];
          if(!exactCategoryScope(checked,frozenCategoryPath))changed.push('填写后商品类目已变化，未确认填写完成。');
          if(changed.length)return {status:'needs_review',issues:changed,checks,receipt:null};
          if(saveDraft){
            if((Object.hasOwn(checked,'alertEvidence')||Object.hasOwn(checked,'alertEvidenceComplete'))&&(checked.alertEvidenceComplete!==true||!validAlertEvidence(checked.alertEvidence,checked.alerts||[])))return {status:'needs_review',issues:['保存前的页面提示实例证据不完整，未点击保存草稿。'],checks,receipt:null};
            const savers=(checked.controls||[]).filter(item=>item.role==='button'&&!item.disabled&&/^(?:保存草稿|保存为草稿|存为草稿|另存为草稿|Save draft|Save as draft)$/iu.test(clean(item.label||item.text)));
            if(savers.length!==1)return {status:'needs_review',issues:['无法唯一确定保存草稿按钮，未执行保存或发布。'],checks,receipt:null};
            const beforeAlerts=[...(checked.alerts||[])],beforeAlertEvidence=Array.isArray(checked.alertEvidence)?checked.alertEvidence.map(item=>({...item})):undefined,beforeAlertEvidenceComplete=checked.alertEvidenceComplete;
            await phase('saving_draft','保存草稿','save_draft');abort(signal);draftSaveClicked=true;await page.click(savers[0].ref);diagnostics.dispatchState='dispatched';
            for(let attempt=0;attempt<60;attempt++){
              const after=await page.snapshot();assertReadSnapshotSafety(after);
              if(['shopName','region'].some(key=>clean(after.identity?.[key])&&clean(binding[key])&&!same(after.identity[key],binding[key]))||binding.idKind!=='profile-environment'&&clean(after.identity?.shopId)&&clean(binding.shopId)&&(!same(after.identity.shopId,binding.shopId)||binding.idKind&&after.identity.idKind&&binding.idKind!==after.identity.idKind))return {status:'draft_unknown',issues:['保存草稿后店铺身份发生变化，请人工核实。'],checks,receipt:null};
              const failed=draftSaveFailures(after);if(failed.length)return {status:'draft_unknown',issues:failed,checks,receipt:null};
              const receipt=extractDraftReceipt(after,{beforeAlerts,beforeAlertEvidence,beforeAlertEvidenceComplete});
              if(receipt){await phase('draft_saved','保存草稿','save_draft');return {status:'draft_saved',issues:[],checks,receipt:{...receipt,shopId:binding.shopId,region:binding.region,categoryPath:[...frozenCategoryPath],savedAt:now()}};}
              // A save already sent must never be repeated on cancellation.
              await wait(250);
            }
            return {status:'draft_unknown',issues:['已点击保存草稿，但尚未取得平台成功回执；请到对应店铺草稿箱核实，未执行发布。'],checks,receipt:null};
          }
          await phase('filled','商品核对','check');
          return {status:'filled',issues:[],checks,receipt:{status:'filled',shopId:binding.shopId,region:binding.region,categoryPath:[...frozenCategoryPath],submitted:false,checkedAt:now(),source:'visible-seller-dom'}};
        }
        if (product._publishAuthorized !== true) return { status: 'needs_review', issues: ['商品已填写并核对，但本任务没有用户提交授权。'], checks, receipt: null };
        abort(signal);
        // Identity and critical values are checked again immediately before the one irreversible click.
        state = await readShopSnapshot(page, wait, undefined, 0, undefined, { signal, nowMs: readinessNow, binding }); const finalIdentityIssues = [...compareShopIdentity(state.identity || {}, binding), ...changedChecks(state, checks)];
        if (finalIdentityIssues.length) return { status: 'needs_review', issues: finalIdentityIssues, checks, receipt: null };
        const submitters = state.controls.filter(item => item.role === 'button' && !item.disabled && /^(发布|提交审核|Publish|Submit for review)$/iu.test(clean(item.label || item.text)));
        if (submitters.length !== 1) return { status: 'needs_review', issues: ['无法唯一确定最终发布按钮。'], checks, receipt: null };
        await phase('submitting','发布商品','publish'); abort(signal); submitted = true; await page.click(submitters[0].ref);diagnostics.dispatchState='dispatched';
        for (let attempt = 0; attempt < 60; attempt++) {
          // Cancellation after the click cannot turn an uncertain external write into a retryable failure.
          const after = await page.snapshot(), receipt = extractPublishReceipt(after);
          if (receipt) return { status: 'published', productId: receipt.productId, url: receipt.url, receipt: { ...receipt, shopId: binding.shopId, region: binding.region, submittedAt: now(), source: 'visible-seller-dom' }, checks };
          if ((after.alerts || []).some(message => /失败|未通过|error|failed|invalid/iu.test(message))) return { status: 'submitted_unknown', issues: after.alerts, checks, receipt: null };
          await wait(250);
        }
        return { status: 'submitted_unknown', issues: ['已点击提交，但尚未取得发布成功提示及商品 ID；请到店铺后台核实后再操作。'], checks, receipt: null };
      }); return {...result,diagnostics:{...(firstFailureDiagnostics||diagnostics),recoveryAttempts:Math.max(firstFailureDiagnostics?.recoveryAttempts||0,recoveryCount()),draftSaveAttempted:draftSaveClicked}};
      } catch (error) {
        const detail=error?.diagnostics||{},codes=['SELLER_CONTROL_STALE','SELLER_CONTROL_AMBIGUOUS','SELLER_CONTROL_OBSCURED','SELLER_ACTION_UNCONFIRMED'],code=codes.includes(error?.code)?error.code:codes.includes(detail.code)?detail.code:signal?.aborted?'SELLER_CANCELLED':'SELLER_OPERATION_FAILED';
        diagnostics={...diagnostics,code,recoveryAttempts:Math.max(recoveryCount(),Number.isSafeInteger(detail.recoveryAttempts)?Math.max(0,Math.min(2,detail.recoveryAttempts)):0),dispatchState:['not_dispatched','dispatched','unknown'].includes(detail.dispatchState)?detail.dispatchState:'unknown',draftSaveAttempted:draftSaveClicked};
        return { status: submitted ? 'submitted_unknown' : draftSaveClicked ? 'draft_unknown' : signal?.aborted ? 'cancelled' : 'needs_review', issues: [error.message], checks, receipt: null,diagnostics };
      }
    }
  };
}
