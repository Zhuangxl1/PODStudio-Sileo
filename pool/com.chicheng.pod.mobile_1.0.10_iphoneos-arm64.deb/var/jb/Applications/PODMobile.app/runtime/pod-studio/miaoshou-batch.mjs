import {randomUUID} from 'node:crypto';
import {randomMiaoshouPackage} from './dist/miaoshou-package-defaults.js';
import {miaoshouId,singleShopPolicy} from './dist/miaoshou-policy.js';
import {sanitizeMiaoshouValue} from './miaoshou-client.mjs';
const fail=(message,code)=>Object.assign(new Error(message),{status:409,...(code?{code}:{})});
const editActions=new Set(['edit','size-chart','package','category','warehouse']);
const revisionActions=new Set(['category','warehouse']);
const reviewCodes=new Set(['ACTION_REVIEW_REQUIRED','EDIT_REVIEW_REQUIRED','VERIFY_FAILED','REMOTE_UNCERTAIN','MIAOSHOU_EDIT_REVIEW']);
const saveResultMetadata=result=>{
  if(!result||typeof result!=='object')return {};
  const data={};
  if(typeof result.shopId==='string'&&/^[1-9]\d{0,24}$/u.test(result.shopId))data.shopId=result.shopId;
  if(typeof result.verified==='boolean')data.verified=result.verified;
  if(typeof result.revision==='string'&&/^[a-f0-9]{64}$/u.test(result.revision))data.revision=result.revision;
  if(['api_receipt','readback'].includes(result.confirmation))data.confirmation=result.confirmation;
  if(result.receipt&&typeof result.receipt==='object'){
    const keys=['version','operationId','detailId','shopId','api','outcome','result','code','ossMd5Hash','acknowledgedAt'];
    data.receipt=Object.fromEntries(keys.filter(key=>Object.hasOwn(result.receipt,key)).map(key=>[key,result.receipt[key]]));
  }
  if(result.fieldReview&&typeof result.fieldReview==='object')data.fieldReview=structuredClone(result.fieldReview);
  for(const key of ['localReceiptWarning','localRefreshWarning'])if(typeof result[key]==='string')data[key]=sanitizeMiaoshouValue(result[key],[],350);
  return data;
};
const saveErrorMetadata=error=>{
  const data={};
  for(const key of ['code','remoteCode'])if(typeof error?.[key]==='string'&&/^[a-zA-Z][a-zA-Z0-9_.-]{0,79}$/u.test(error[key]))data[key]=error[key];
  if(Number.isInteger(error?.httpStatus)&&error.httpStatus>=100&&error.httpStatus<=599)data.httpStatus=error.httpStatus;
  if(typeof error?.remoteMessage==='string')data.remoteMessage=sanitizeMiaoshouValue(error.remoteMessage,[],350);
  if(typeof error?.definitive==='boolean')data.definitive=error.definitive;
  return data;
};

/** Batch tickets bind one explicit selection to one account and one background job. */
export function createMiaoshouBatch({getRecords,getShops,accountScope,getContextId=()=>undefined,assertOpen=()=>{},acquire=()=>()=>{},validateChanges=()=>{},execute,executeBatch,verify,now=Date.now}={}){
  const tickets=new Map(),jobs=new Map(),queue=[];
  let closed=false,work=null,running=null;
  const open=()=>{if(closed)throw fail('批量任务已停止。');assertOpen();};
  const publicJob=job=>({id:job.id,status:job.status,total:job.items.length,done:job.results.length,results:structuredClone(job.results)});
  const singleEdit=task=>task.expectedSourceHash!==undefined;
  const receiptJob=(ticket,scope)=>[...jobs.values()].find(job=>job.receiptTicket===ticket&&job.scope===scope);
  const isSaving=(detailId,{scope,contextId}={})=>[running,...queue].some(entry=>entry&&entry.job.status!=='complete'&&
    (scope===undefined||entry.task.scope===scope)&&(contextId===undefined||entry.task.contextId===undefined||entry.task.contextId===contextId)&&
    entry.task.items.some((item,index)=>index>=entry.job.results.length&&item.eligible&&item.detailId===detailId));
  function checkContext(expected,actual){
    if(expected!==undefined&&(actual!==expected||getContextId()!==expected))throw fail('妙手连接已变化，请重新读取当前商品。','CONTEXT_CHANGED');
  }
  async function checkJob(job,contextId){
    open();
    const scope=await accountScope();
    open();
    if(!job||job.scope!==scope)throw fail('批量任务不存在或不属于当前妙手账号。','MIAOSHOU_BATCH_RECEIPT_UNKNOWN');
    checkContext(job.contextId,contextId);
    return job;
  }
  function pruneCompletedJobs(){
    while(jobs.size>100){
      const completed=[...jobs.values()].find(entry=>entry.status==='complete'&&!entry.reviewWork);
      if(!completed)break;
      jobs.delete(completed.id);
    }
  }
  async function run({task,job}){
    job.status='running';
    if(task.action==='delete'&&typeof executeBatch==='function'){
      // The existing deletion endpoint accepts detailIds; keep each request
      // small and preserve one explicit result for every selected product.
      for(let offset=0;offset<task.items.length;offset+=20){
        const group=task.items.slice(offset,offset+20),eligible=group.filter(item=>item.eligible);
        let results=[];
        if(eligible.length)try{
          open();checkContext(task.contextId,task.contextId);
          if(await accountScope()!==task.scope)throw fail('妙手账号已变化，未继续删除。','CONTEXT_CHANGED');
          const response=await executeBatch('delete',eligible,{expectedScope:task.scope,expectedContextId:task.contextId});
          const ids=new Set(eligible.map(item=>item.detailId));
          if(!Array.isArray(response)||response.length!==ids.size||new Set(response.map(item=>item?.detailId)).size!==ids.size||
            response.some(item=>!ids.has(item?.detailId)||!['succeeded','failed','needs_review','unchanged'].includes(item.state)))
            throw fail('删除已提交，但逐项回执不完整，请查询原任务。','REMOTE_UNCERTAIN');
          results=response.map(item=>({detailId:item.detailId,state:item.state,message:sanitizeMiaoshouValue(item.message||'删除结果需要核对。',[],500),...saveErrorMetadata(item)}));
        }catch(error){
          results=eligible.map(item=>({detailId:item.detailId,state:reviewCodes.has(error.code)||error.needsReview?'needs_review':'failed',message:sanitizeMiaoshouValue(error.message||'删除未完成。',[],500),...saveErrorMetadata(error)}));
        }
        const byId=new Map(results.map(item=>[item.detailId,item]));
        for(const item of group)job.results.push(item.eligible?byId.get(item.detailId):{detailId:item.detailId,state:'failed',message:item.error});
      }
      job.status='complete';task.state='complete';pruneCompletedJobs();return;
    }
    for(const item of task.items){
      if(!item.eligible){job.results.push({detailId:item.detailId,state:'failed',message:item.error});continue;}
      try{
        open();
        if(singleEdit(task)||revisionActions.has(task.action)){
          if(await accountScope()!==task.scope)throw fail('妙手账号已变化，请重新提交商品修改。','CONTEXT_CHANGED');
          open();
          checkContext(task.contextId,task.contextId);
          const current=singleShopPolicy(getRecords().get(item.detailId)?.shopIds);
          if(!current.allowed||current.shopId!==singleShopPolicy(item.shopIds).shopId)
            throw fail('商品或关联店铺已变化，请重新读取后再保存。','MIAOSHOU_EDIT_STALE');
        }
        const changes=task.action==='warehouse'?{warehouseId:item.warehouseId}:item.packageValues??task.changes;
        const options={shopId:task.shopId,changes,...(task.directCategory?{directCategory:true}:{})};
        if(singleEdit(task)||revisionActions.has(task.action))Object.assign(options,{expectedSourceHash:task.expectedSourceHash??item.sourceRevision,expectedScope:task.scope});
        const result=await execute(task.action,item,options);
        job.results.push({detailId:item.detailId,state:['unchanged','needs_review'].includes(result?.state)?result.state:'succeeded',message:result?.message||(editActions.has(task.action)?'已保存到妙手采集箱。':'已完成并核验'),...(editActions.has(task.action)?saveResultMetadata(result):{}),...(task.action==='claim'&&result?.claimDefaults?{claimDefaults:structuredClone(result.claimDefaults)}:{})});
      }catch(error){
        const needsReview=reviewCodes.has(error.code)||error.needsReview;
        if(singleEdit(task)&&error.code==='MIAOSHOU_EDIT_REVIEW'&&typeof error.data?.operationId==='string')
          job.reviewInput={operationId:error.data.operationId,item,changes:task.changes};
        job.results.push({detailId:item.detailId,state:needsReview?'needs_review':'failed',message:sanitizeMiaoshouValue(error.message||'操作未完成，请核对。',[],500),...saveErrorMetadata(error)});
      }
    }
    job.status='complete';
    task.state='complete';
    pruneCompletedJobs();
  }
  return {
    async prepare(input,{expectedSourceHash,expectedContextId,reviewCategory,reviewWarehouse,directCategory=false}={}){
      open();if(!input||!['claim','delete',...editActions].includes(input.action)||!Array.isArray(input.detailIds)||!input.detailIds.length||input.detailIds.length>200)throw fail('请选择1至200条链接和有效的批量操作。');
      const ids=input.detailIds.map(miaoshouId);if(new Set(ids).size!==ids.length)throw fail('批量选择中存在重复链接。');
      if(expectedSourceHash!==undefined&&(input.action!=='edit'||ids.length!==1||typeof expectedSourceHash!=='string'||!/^[a-f0-9]{64}$/u.test(expectedSourceHash)))throw fail('单品编辑的原件版本无效，请重新读取。');
      if(expectedContextId!==undefined&&(typeof expectedContextId!=='string'||expectedContextId!==getContextId()))throw Object.assign(fail('妙手连接已变化，请重新读取当前商品。'),{code:'CONTEXT_CHANGED'});
      if(input.action==='category'&&(typeof reviewCategory!=='function'||!expectedContextId))throw fail('请先读取当前妙手连接并核对目标类目。');
      if(input.action==='warehouse'&&(typeof reviewWarehouse!=='function'||!expectedContextId))throw fail('请先读取当前妙手连接和店铺仓库。');
      if(Object.keys(input).some(k=>!['action','detailIds','shopId','changes'].includes(k)))throw fail('批量操作参数无效。');
      const scope=await accountScope();open();let shop;
      if(input.action==='claim'){const shopId=miaoshouId(input.shopId);shop=(await getShops()).find(s=>s.id===shopId);if(!shop)throw fail('请选择当前妙手账号的目标店铺。');}
      const changes=structuredClone(input.changes||{});
      if(!changes||typeof changes!=='object'||Array.isArray(changes))throw fail('批量编辑字段无效。');
      if(input.action==='edit'&&!Object.keys(changes).length)throw fail('请勾选要修改的字段。');
      if(input.action==='size-chart'&&(Object.keys(changes).length!==1||typeof changes.sizeChartUrl!=='string'))throw fail('请先上传尺码图。');
      if(['claim','delete','package'].includes(input.action)&&Object.keys(changes).length)throw fail('该批量操作不接受额外编辑字段。');
      if(editActions.has(input.action)&&input.action!=='warehouse')validateChanges({action:input.action,changes});
      const records=getRecords(),items=ids.map(detailId=>{const row=records.get(detailId),policy=singleShopPolicy(row?.shopIds),eligible=Boolean(row)&&(!editActions.has(input.action)||policy.allowed);return {detailId,title:row?.title||'',sourceTitle:row?.sourceTitle??row?.title??'',shopIds:row?.shopIds,shopName:shop?.name||'',eligible,...(!eligible?{error:row?policy.message:'该链接已不在本地列表，请同步后重试。'}:{})};});
      if(input.action==='package')for(const item of items)if(item.eligible)item.packageValues=randomMiaoshouPackage();
      if(input.action==='category')for(const item of items){
        if(!item.eligible)continue;
        const reviewed=await reviewCategory(item,changes.categoryId);
        Object.assign(item,reviewed);
      }
      if(input.action==='warehouse'){
        if(Object.keys(changes).length!==1||!Array.isArray(changes.warehouses)||!changes.warehouses.length||changes.warehouses.length>ids.length)
          throw fail('请至少选择一个店铺的目标仓库。');
        const selectedShops=new Set(items.filter(item=>item.eligible).map(item=>singleShopPolicy(item.shopIds).shopId));
        const choices=new Map();
        for(const value of changes.warehouses){
          if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2||
            typeof value.shopId!=='string'||typeof value.warehouseId!=='string')throw fail('批量仓库参数无效。');
          const shopId=miaoshouId(value.shopId),warehouseId=miaoshouId(value.warehouseId);
          if(!selectedShops.has(shopId)||choices.has(shopId))throw fail('所选仓库与商品认领店铺不匹配。');
          choices.set(shopId,warehouseId);
        }
        for(const item of items){
          if(!item.eligible)continue;
          const shopId=singleShopPolicy(item.shopIds).shopId;
          Object.assign(item,await reviewWarehouse(item,shopId,choices.get(shopId)));
        }
      }
      open();for(const [id,t]of tickets)if(t.expires<now())tickets.delete(id);if(tickets.size>=200)throw fail('待确认批量操作较多，请先完成已有操作。');
      const ticket=randomUUID();tickets.set(ticket,{scope,action:input.action,shopId:shop?.id,changes,items:structuredClone(items),expires:now()+300000,state:'ready',directCategory:directCategory===true&&input.action==='category'});
      if(expectedSourceHash!==undefined)tickets.get(ticket).expectedSourceHash=expectedSourceHash;
      if(expectedContextId!==undefined)tickets.get(ticket).contextId=expectedContextId;
      return {ticket,total:items.length,items:items.map(({sourceRevision,...item})=>item),summary:input.action==='package'?'请逐项核对重量和尺寸，COD 保留当前设置。':'仅处理已选择并确认的链接'};
    },
    async commit(input){
      open();const task=tickets.get(input?.ticket);if(input?.confirmed!==true||!task||!['ready','canceled'].includes(task.state)||task.expires<now())throw fail('批量确认已失效或已提交，请重新核对。');
      checkContext(task.contextId,input.contextId);
      if(await accountScope()!==task.scope)throw fail('妙手账号已变化，请重新确认批量操作。');
      open();
      checkContext(task.contextId,input.contextId);
      if(task.state==='canceled')throw fail('本次保存已取消，商品草稿仍保留在本机。','MIAOSHOU_EDIT_CANCELED');
      if(task.state!=='ready'||task.expires<now())throw fail('批量确认已失效或已提交，请重新核对。');
      if(work&&!singleEdit(task))throw fail('已有批量任务正在执行，请完成后再提交。');
      if(singleEdit(task)){
        const {detailId}=task.items[0];
        if(isSaving(detailId,{scope:task.scope,contextId:task.contextId}))throw fail('该商品已在保存队列中，请先查询保存结果。','MIAOSHOU_EDIT_BUSY');
        if(queue.length>=32)throw fail('商品保存队列已满，请稍后提交。','MIAOSHOU_EDIT_QUEUE_FULL');
      }
      const release=work?null:acquire();
      task.state='queued';
      const job={id:randomUUID(),scope:task.scope,contextId:task.contextId,status:'queued',items:task.items,results:[],editorSave:singleEdit(task)};
      job.receiptTicket=input.ticket;
      jobs.set(job.id,job);
      queue.push({task,job});
      if(release)work=Promise.resolve().then(async()=>{
        try{
          while(queue.length){
            running=queue.shift();
            await run(running);
          }
        }finally{running=null;work=null;release();}
      });
      return {jobId:job.id};
    },
    async status({jobId,contextId}={}){return publicJob(await checkJob(jobs.get(jobId),contextId));},
    isSaving,
    async cancelEdit({ticket,contextId}){
      open();
      const scope=await accountScope();open();
      const task=tickets.get(ticket),job=receiptJob(ticket,scope);
      if(job?.editorSave&&job.contextId!==undefined){
        checkContext(job.contextId,contextId);
        if(job.status==='complete')return {state:job.results[0]?.state==='canceled'?'canceled':'complete',jobId:job.id};
        const index=queue.findIndex(entry=>entry.job===job);
        if(job.status!=='queued'||index<0)return {state:'running',jobId:job.id};
        const [entry]=queue.splice(index,1);
        entry.task.state='canceled';
        job.status='complete';
        job.results.push({detailId:job.items[0].detailId,state:'canceled',message:'本次保存已取消，商品草稿仍保留在本机。'});
        pruneCompletedJobs();
        return {state:'canceled',jobId:job.id};
      }
      if(!task||task.scope!==scope||task.contextId===undefined||!singleEdit(task)||task.expires<now())return {state:'unknown'};
      checkContext(task.contextId,contextId);
      if(!['ready','canceled'].includes(task.state))return {state:'unknown'};
      task.state='canceled';
      return {state:'canceled'};
    },
    async find({ticket,contextId}={}){
      open();
      const scope=await accountScope();
      open();
      const job=typeof ticket==='string'&&receiptJob(ticket,scope);
      if(!job)throw fail('尚未找到本次保存的提交回执，请继续核对，勿重复提交。','MIAOSHOU_BATCH_RECEIPT_UNKNOWN');
      checkContext(job.contextId,contextId);
      return {jobId:job.id};
    },
    async review({jobId,contextId}={}){
      const job=await checkJob(jobs.get(jobId),contextId);
      if(job.status!=='complete'||!job.reviewInput||typeof verify!=='function')return publicJob(job);
      if(isSaving(job.reviewInput.item.detailId,{scope:job.scope,contextId:job.contextId}))return publicJob(job);
      if(!job.reviewWork){
        const input=job.reviewInput;
        job.reviewWork=(async()=>{
          const result=await verify({...input,scope:job.scope,contextId:job.contextId});
          await checkJob(job,contextId);
          if(result?.confirmation!=='api_receipt'&&result?.verified!==true)return;
          job.results[0]={detailId:input.item.detailId,state:'succeeded',message:result.confirmation==='api_receipt'?'已保存到妙手采集箱。':'已读取妙手，指定修改内容已一致。',...saveResultMetadata(result)};
          delete job.reviewInput;
        })().finally(()=>{delete job.reviewWork;});
      }
      await job.reviewWork;
      return publicJob(job);
    },
    reset(){if(work)throw fail('批量任务正在执行，不能重置。');tickets.clear();},
    async close(){closed=true;if(work)await work;await Promise.allSettled([...jobs.values()].map(job=>job.reviewWork).filter(Boolean));}
  };
}
