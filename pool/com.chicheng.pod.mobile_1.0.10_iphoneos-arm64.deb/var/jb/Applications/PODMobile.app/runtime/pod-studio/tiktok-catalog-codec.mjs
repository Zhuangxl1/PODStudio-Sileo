import {readFileSync,lstatSync,mkdirSync,writeFileSync,renameSync,unlinkSync,readdirSync,openSync,closeSync,readSync,writeSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash,randomBytes} from 'node:crypto';
import {brotliCompressSync,brotliDecompressSync,constants} from 'node:zlib';

const MAX=32*1024*1024,MAX_NODES=2000000,MAX_DEPTH=48,MAX_REFS=20000,MIN_ARRAY=1024;
const FORMAT='tiktok-leaf-arrayrefs-v1',ENCODING='br-json-arrayrefs-v1',REF='$podCatalogArray';
const MAX_PACK=256*1024*1024,MAX_INDEX=4*1024*1024;
const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/u.test(v);
const sha=v=>createHash('sha256').update(v).digest('hex');
const exact=(v,keys)=>plain(v)&&Object.keys(v).length===keys.length&&Object.keys(v).every(k=>keys.includes(k));
const bounded=(v,max=MAX)=>Number.isSafeInteger(v)&&v>0&&v<=max;
const compressedBound=(raw,stored)=>bounded(raw,MAX+256)&&bounded(stored,MAX+256)&&stored<=raw+Math.ceil(raw/4096)+256;
const fail=()=>Object.assign(new Error('内置类目压缩分片缺失、损坏、越界或包含非法引用。'),{code:'PUBLISH_CATALOG_INCOMPLETE',status:409});
const zip=bytes=>brotliCompressSync(bytes,{params:{[constants.BROTLI_PARAM_QUALITY]:6,[constants.BROTLI_PARAM_MODE]:constants.BROTLI_MODE_TEXT}});

function folder(root,name,{create=false}={}){const directory=resolve(root),target=join(directory,name);if(create)mkdirSync(directory,{recursive:true});const info=lstatSync(directory);if(!info.isDirectory()||info.isSymbolicLink())throw fail();if(create)mkdirSync(target,{recursive:true});const child=lstatSync(target);if(!child.isDirectory()||child.isSymbolicLink())throw fail();return target;}
function fileBytes(path,size){const info=lstatSync(path);if(!info.isFile()||info.isSymbolicLink()||info.size!==size)throw fail();return readFileSync(path);}
function atomic(path,bytes){const temporary=path+'.'+randomBytes(8).toString('hex')+'.tmp';try{writeFileSync(temporary,bytes,{flag:'wx'});renameSync(temporary,path);}finally{try{unlinkSync(temporary);}catch(error){if(error.code!=='ENOENT')throw error;}}}
function unzip(bytes,length){if(!bounded(length,MAX+256)||!compressedBound(length,bytes.length))throw fail();let result;try{result=brotliDecompressSync(bytes,{maxOutputLength:length,info:true});}catch{throw fail();}if(result.buffer.length!==length||result.engine.bytesWritten!==bytes.length)throw fail();return result.buffer;}
function step(budget,depth){if(++budget.nodes>MAX_NODES||depth>MAX_DEPTH)throw fail();}
function rawJsonSafe(value,budget,depth=0){step(budget,depth);if(Array.isArray(value)){for(const v of value)rawJsonSafe(v,budget,depth+1);}else if(plain(value)){if(Object.hasOwn(value,REF))throw fail();for(const v of Object.values(value))rawJsonSafe(v,budget,depth+1);}else if(!(value===null||typeof value==='boolean'||typeof value==='string'||typeof value==='number'&&Number.isFinite(value)))throw fail();}
function exists(path){try{lstatSync(path);return true;}catch(error){if(error.code==='ENOENT')return false;throw error;}}
function shardIndex(root,prefix){
  const directory=folder(root,'blob-packs'),file=join(directory,prefix+'.index.json'),info=lstatSync(file);if(!info.isFile()||info.isSymbolicLink()||!bounded(info.size,MAX_INDEX))throw fail();let index;try{index=JSON.parse(readFileSync(file,'utf8'));}catch{throw fail();}
  if(!exact(index,['version','encoding','prefix','packBytes','packSha256','entries'])||index.version!==1||index.encoding!=='br-array-pack-v1'||index.prefix!==prefix||!bounded(index.packBytes,MAX_PACK)||!hash(index.packSha256)||!Array.isArray(index.entries)||!index.entries.length||index.entries.length>20000)throw fail();
  const seen=new Set();let position=0;for(const p of index.entries){if(!exact(p,['sha256','bytes','storedSha256','storedBytes','offset'])||!hash(p.sha256)||!p.sha256.startsWith(prefix)||seen.has(p.sha256)||!hash(p.storedSha256)||!bounded(p.bytes)||p.bytes<MIN_ARRAY||!compressedBound(p.bytes,p.storedBytes)||p.offset!==position)throw fail();seen.add(p.sha256);position+=p.storedBytes;}if(position!==index.packBytes)throw fail();
  const pack=join(directory,prefix+'.pack'),packInfo=lstatSync(pack);if(!packInfo.isFile()||packInfo.isSymbolicLink()||packInfo.size!==index.packBytes)throw fail();return {index,pack};
}
function blobDisk(root,proof){const loose=join(resolve(root),'blobs',proof.sha256+'.json.br');if(exists(loose)){folder(root,'blobs');return fileBytes(loose,proof.storedBytes);}
  const {index,pack}=shardIndex(root,proof.sha256.slice(0,2)),p=index.entries.find(e=>e.sha256===proof.sha256);if(!p||['bytes','storedSha256','storedBytes'].some(k=>p[k]!==proof[k]))throw fail();
  const bytes=Buffer.allocUnsafe(p.storedBytes),fd=openSync(pack,'r');try{let offset=0;while(offset<bytes.length){const n=readSync(fd,bytes,offset,bytes.length-offset,p.offset+offset);if(!n)throw fail();offset+=n;}}finally{closeSync(fd);}return bytes;
}

export function catalogStorageValid(storage,entry){
  return exact(storage,['encoding','file','sha256','bytes','descriptorBytes','blobCount','blobExpandedBytes','blobStoredBytes'])&&storage.encoding===ENCODING&&hash(storage.sha256)&&storage.file==='packed/'+storage.sha256+'.json.br'
    &&bounded(storage.bytes,MAX+256)&&bounded(storage.descriptorBytes,Math.min(MAX+256,(entry?.bytes||MAX)+256))&&compressedBound(storage.descriptorBytes,storage.bytes)&&Number.isSafeInteger(storage.blobCount)&&storage.blobCount>=0&&storage.blobCount<=MAX_REFS
    &&Number.isSafeInteger(storage.blobExpandedBytes)&&storage.blobExpandedBytes>=0&&storage.blobExpandedBytes<=(entry?.bytes||MAX)&&Number.isSafeInteger(storage.blobStoredBytes)&&storage.blobStoredBytes>=0&&storage.blobStoredBytes<=MAX*2;
}

/** A storage codec only. The caller must strictly validate the public leaf. */
export function writePackedCatalogLeaf({root,leaf,bytes=Buffer.from(JSON.stringify(leaf))}={}){
  if(!bounded(bytes.length))throw fail();rawJsonSafe(leaf,{nodes:0});
  const blobs=new Map(),budget={nodes:0};
  function arrayBlob(raw){const digest=sha(raw),old=blobs.get(digest);if(old)return old;const directory=folder(root,'blobs',{create:true}),target=join(directory,digest+'.json.br');let compressed;
    try{const info=lstatSync(target);if(!info.isFile()||info.isSymbolicLink()||!bounded(info.size,MAX+256))throw fail();compressed=readFileSync(target);const restored=unzip(compressed,raw.length);if(sha(restored)!==digest)throw fail();}
    catch(error){if(error.code!=='ENOENT')throw error;compressed=zip(raw);atomic(target,compressed);}
    const proof={sha256:digest,bytes:raw.length,storedSha256:sha(compressed),storedBytes:compressed.length};blobs.set(digest,proof);return proof;
  }
  function encode(value,depth=0){step(budget,depth);if(Array.isArray(value)){let nested=false;const items=value.map(v=>{const result=encode(v,depth+1);nested||=result.packed;return result.value;});
      if(!nested){const raw=Buffer.from(JSON.stringify(value));if(raw.length>=MIN_ARRAY){if(blobs.size>=MAX_REFS)throw fail();return {value:{[REF]:arrayBlob(raw)},packed:true};}}
      return {value:items,packed:nested};}
    if(plain(value)){let nested=false;const entries=Object.entries(value).map(([k,v])=>{const result=encode(v,depth+1);nested||=result.packed;return [k,result.value];});return {value:Object.fromEntries(entries),packed:nested};}
    return {value,packed:false};
  }
  const descriptor=Buffer.from(JSON.stringify({format:FORMAT,tree:encode(leaf).value}));if(!bounded(descriptor.length,MAX+256))throw fail();const compressed=zip(descriptor),digest=sha(compressed),directory=folder(root,'packed',{create:true}),target=join(directory,digest+'.json.br');
  try{const old=fileBytes(target,compressed.length);if(sha(old)!==digest)throw fail();}catch(error){if(error.code!=='ENOENT')throw error;atomic(target,compressed);}
  const storage={encoding:ENCODING,file:'packed/'+digest+'.json.br',sha256:digest,bytes:compressed.length,descriptorBytes:descriptor.length,blobCount:blobs.size,blobExpandedBytes:[...blobs.values()].reduce((n,b)=>n+b.bytes,0),blobStoredBytes:[...blobs.values()].reduce((n,b)=>n+b.storedBytes,0)};
  if(!catalogStorageValid(storage,{bytes:bytes.length}))throw fail();return storage;
}

/** Flat array blobs cannot contain references, so reference cycles are impossible. */
export function readPackedCatalogLeaf({root,entry,onBlob}={}){
  const storage=entry?.storage;if(!bounded(entry?.bytes)||!hash(entry.sha256)||!catalogStorageValid(storage,entry))throw fail();
  const directory=folder(root,'packed'),compressed=fileBytes(join(directory,storage.sha256+'.json.br'),storage.bytes);if(sha(compressed)!==storage.sha256)throw fail();
  let descriptor;try{descriptor=JSON.parse(unzip(compressed,storage.descriptorBytes).toString('utf8'));}catch{throw fail();}if(!exact(descriptor,['format','tree'])||descriptor.format!==FORMAT)throw fail();
  const found=new Map(),budget={nodes:0},rawBudget={nodes:0};let expandedBytes=0,storedReadBytes=0,refCount=0;
  function decode(value,depth=0){step(budget,depth);if(Array.isArray(value))return value.map(v=>decode(v,depth+1));if(plain(value)){
      if(Object.hasOwn(value,REF)){if(!exact(value,[REF])||++refCount>MAX_REFS)throw fail();const p=value[REF];if(!exact(p,['sha256','bytes','storedSha256','storedBytes'])||!hash(p.sha256)||!hash(p.storedSha256)||!bounded(p.bytes)||p.bytes<MIN_ARRAY||!compressedBound(p.bytes,p.storedBytes)||(expandedBytes+=p.bytes)>entry.bytes)throw fail();
        let text=found.get(p.sha256)?.text;if(text===undefined){if((storedReadBytes+=p.storedBytes)>storage.blobStoredBytes||storedReadBytes>MAX*2||found.size>=storage.blobCount)throw fail();const disk=blobDisk(root,p);if(sha(disk)!==p.storedSha256)throw fail();const raw=unzip(disk,p.bytes);if(sha(raw)!==p.sha256)throw fail();text=raw.toString('utf8');found.set(p.sha256,{text,proof:p});onBlob?.({...p});}else if(JSON.stringify(found.get(p.sha256).proof)!==JSON.stringify(p))throw fail();
        let array;try{array=JSON.parse(text);}catch{throw fail();}if(!Array.isArray(array))throw fail();rawJsonSafe(array,rawBudget,depth+1);return array;
      }
      return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,decode(v,depth+1)]));
    }return value;
  }
  const leaf=decode(descriptor.tree),expanded=Buffer.from(JSON.stringify(leaf));if(expanded.length!==entry.bytes||sha(expanded)!==entry.sha256||found.size!==storage.blobCount||[...found.values()].reduce((n,b)=>n+b.proof.bytes,0)!==storage.blobExpandedBytes||[...found.values()].reduce((n,b)=>n+b.proof.storedBytes,0)!==storage.blobStoredBytes)throw fail();return leaf;
}

/** Finalize to a new directory. No source files are removed or overwritten. */
export function packCatalogBlobShards({sourceRoot,outputRoot,entries}={}){
  if(!Array.isArray(entries)||entries.length>20000||resolve(sourceRoot).toLowerCase()===resolve(outputRoot).toLowerCase())throw fail();const target=resolve(outputRoot),packDir=join(target,'blob-packs');if(exists(packDir))throw fail();folder(target,'blob-packs',{create:true});const refs=new Map();
  for(const entry of entries){if(entry.storage){readPackedCatalogLeaf({root:sourceRoot,entry,onBlob:p=>{const old=refs.get(p.sha256);if(old&&JSON.stringify(old)!==JSON.stringify(p))throw fail();refs.set(p.sha256,p);}});const disk=fileBytes(join(folder(sourceRoot,'packed'),entry.storage.sha256+'.json.br'),entry.storage.bytes);if(sha(disk)!==entry.storage.sha256)throw fail();const out=join(folder(target,'packed',{create:true}),entry.storage.sha256+'.json.br');if(!exists(out))writeFileSync(out,disk,{flag:'wx'});}
    else{if(!hash(entry.sha256)||entry.file!=='leaves/'+entry.sha256+'.json'||!bounded(entry.bytes))throw fail();const disk=fileBytes(join(folder(sourceRoot,'leaves'),entry.sha256+'.json'),entry.bytes);if(sha(disk)!==entry.sha256)throw fail();writeFileSync(join(folder(target,'leaves',{create:true}),entry.sha256+'.json'),disk,{flag:'wx'});}}
  const groups=new Map();for(const p of [...refs.values()].sort((a,b)=>a.sha256.localeCompare(b.sha256))){const prefix=p.sha256.slice(0,2),list=groups.get(prefix)||[];list.push(p);groups.set(prefix,list);}
  let totalBytes=0;for(const [prefix,list]of groups){const pack=join(packDir,prefix+'.pack'),fd=openSync(pack,'wx'),digest=createHash('sha256'),indexEntries=[];let position=0;try{for(const p of list){const disk=blobDisk(sourceRoot,p);if(sha(disk)!==p.storedSha256||position+disk.length>MAX_PACK)throw fail();let offset=0;while(offset<disk.length){const n=writeSync(fd,disk,offset,disk.length-offset);if(!n)throw fail();offset+=n;}digest.update(disk);indexEntries.push({...p,offset:position});position+=disk.length;}}finally{closeSync(fd);}
    const index={version:1,encoding:'br-array-pack-v1',prefix,packBytes:position,packSha256:digest.digest('hex'),entries:indexEntries},bytes=Buffer.from(JSON.stringify(index));if(bytes.length>MAX_INDEX)throw fail();writeFileSync(join(packDir,prefix+'.index.json'),bytes,{flag:'wx'});totalBytes+=position+bytes.length;}
  return {leafCount:entries.length,blobCount:refs.size,shards:groups.size,blobStoreFiles:groups.size*2,blobStoreBytes:totalBytes};
}

/** Verify all files in the dictionary store, including unreferenced additions. */
export function verifyCatalogBlobStore({root,expectedRefs=new Map()}={}){
  const directory=resolve(root),loose=exists(join(directory,'blobs')),packed=exists(join(directory,'blob-packs'));if(loose&&packed)throw fail();
  if(packed){const files=readdirSync(folder(root,'blob-packs')),prefixes=files.filter(n=>/^[a-f0-9]{2}\.index\.json$/u.test(n)).map(n=>n.slice(0,2));if(files.length!==prefixes.length*2||files.some(n=>!/^[a-f0-9]{2}\.(?:index\.json|pack)$/u.test(n)))throw fail();const seen=new Set();let bytes=0;
    for(const prefix of prefixes){const {index,pack}=shardIndex(root,prefix),digest=createHash('sha256'),fd=openSync(pack,'r'),buffer=Buffer.allocUnsafe(1024*1024);try{for(;;){const n=readSync(fd,buffer,0,buffer.length,null);if(!n)break;digest.update(buffer.subarray(0,n));}}finally{closeSync(fd);}if(digest.digest('hex')!==index.packSha256)throw fail();bytes+=index.packBytes;for(const p of index.entries){const expected=expectedRefs.get(p.sha256);if(!expected||['bytes','storedSha256','storedBytes'].some(k=>p[k]!==expected[k])||seen.has(p.sha256))throw fail();seen.add(p.sha256);}}
    if(seen.size!==expectedRefs.size)throw fail();return {encoding:'br-array-pack-v1',blobCount:seen.size,files:files.length,bytes};
  }
  if(loose){const files=readdirSync(folder(root,'blobs'));if(files.length!==expectedRefs.size||files.some(n=>!/^[a-f0-9]{64}\.json\.br$/u.test(n)||!expectedRefs.has(n.slice(0,64))))throw fail();return {encoding:'loose-br-arrays',blobCount:files.length,files:files.length};}
  if(expectedRefs.size)throw fail();return {encoding:'none',blobCount:0,files:0};
}
