import {mkdir,lstat} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {normalizeReferencePlacement} from './dist/fission-reference-layout.js';

export const DESIGN_LEARNING_VERSION=1;
const POSITIONS=['front','back','leftUpper'];
const PLACEMENTS={front:['front'],back:['back'],leftUpper:['leftUpper'],'front-back':['front','back'],'leftUpper-back':['leftUpper','back']};
const BASE=id=>id==='leftUpper'?'front':id==='leftUpper-back'?'front-back':id;
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const fail=message=>{throw new Error(message);};
const text=(value,max=200)=>typeof value==='string'&&value.trim()&&value.length<=max&&!/[\u0000-\u001f\u007f]/u.test(value)?value.trim():fail('学习记录标识无效。');
const hash=value=>typeof value==='string'&&/^[a-f0-9]{64}$/i.test(value)?value.toLowerCase():fail('学习记录原件摘要无效。');
const keys=(value,allowed)=>{if(!plain(value)||Object.keys(value).some(key=>!allowed.includes(key)))fail('学习记录参数不允许。');};
const optionalId=value=>value===undefined?undefined:text(value,200);
const finiteMs=value=>value===undefined?undefined:Number.isFinite(value)&&value>=0&&value<=7*24*60*60*1000?Math.round(value):fail('学习耗时无效。');
const stable=value=>JSON.stringify(value);
const digest=value=>createHash('sha256').update(stable(value)).digest('hex');
export const learningSampleId=(attemptId,mediaId,resultSha256)=>'learning-'+digest([attemptId,mediaId,resultSha256]);

export function normalizeLearningScope({targetFamilyKey,target}={}){
  let family;
  if(targetFamilyKey!==undefined){
    if(typeof targetFamilyKey!=='string'||targetFamilyKey.length>1000)fail('学习目标模板分组无效。');
    try{family=JSON.parse(targetFamilyKey);}catch{fail('学习目标模板分组无效。');}
    if(!Array.isArray(family)||family.length!==3||!PLACEMENTS[family[2]])fail('学习目标模板分组无效。');
    family={shop:text(family[0]),style:text(family[1]),placementId:family[2],baseType:BASE(family[2])};
  }
  if(target!==undefined){
    keys(target,['shop','style','placementId','baseType']);
    const shop=text(target.shop),style=text(target.style);
    const placementId=target.placementId;
    if(placementId!==undefined&&!PLACEMENTS[placementId])fail('学习目标印花位置无效。');
    const baseType=target.baseType??(placementId?BASE(placementId):undefined);
    if(baseType!==undefined&&!['front','back','front-back'].includes(baseType)||placementId&&BASE(placementId)!==baseType)fail('学习目标展示面不一致。');
    const candidate={shop,style,...(placementId?{placementId}:{}),...(baseType?{baseType}:{})};
    if(family&&Object.entries(candidate).some(([key,value])=>family[key]!==value))fail('学习目标模板分组与店铺款式不一致。');
    family||=candidate;
  }
  return family||null;
}
export function learningScopeKey(scope){return scope?.shop&&scope?.style&&scope?.baseType?stable([scope.shop,scope.style,scope.placementId||'',scope.baseType]):null;}
function regionIdentity(region,regionMode){
  const mode=regionMode??(region===undefined?'automatic':'selected');
  if(!['automatic','selected'].includes(mode))fail('学习裁剪模式无效。');
  if(mode==='automatic')return {regionMode:mode,region:null,regionKey:'automatic'};
  keys(region,['x','y','width','height']);
  if(Object.keys(region).length!==4||Object.values(region).some(value=>!Number.isFinite(value)||value<0||value>1)||!region.width||!region.height||region.x+region.width>1+1e-9||region.y+region.height>1+1e-9)fail('学习裁剪范围无效。');
  const normalized=Object.fromEntries(['x','y','width','height'].map(key=>[key,region[key]]));
  return {regionMode:mode,region:normalized,regionKey:stable(normalized)};
}
function identity(input){
  const operation=input.operation;
  if(!['extraction','reference-placement','fission'].includes(operation))fail('学习操作类型无效。');
  const mode=input.mode??(operation==='fission'?'standard':'faithful');
  if(!(operation==='fission'?['standard','similarity']:['faithful','reference_reconstruction']).includes(mode))fail('学习操作模式无效。');
  const scope=normalizeLearningScope(input);
  return {operation,mode,scope,scopeKey:learningScopeKey(scope),sourceSha256:hash(input.sourceSha256),policyVersion:text(input.policyVersion,80),
    ...regionIdentity(input.region,input.regionMode)};
}
const emptyGuidance=()=>({matchedBy:'none',examples:[],sampleCount:0});
const safePublic=row=>({id:row.id,learningId:row.id,attemptId:row.attempt_id,operation:row.operation,status:row.status,
  qualityConfirmed:row.quality_confirmed===1,position:row.corrected_position||row.position||null,
  sourcePosition:row.position||null,targetPosition:row.target_position||null,
  scope:row.scope_json?JSON.parse(row.scope_json):null,createdAt:row.created_at,updatedAt:row.updated_at,
  durationMs:row.duration_ms??null,revision:row.revision,feedbackRevision:row.revision,reportedOutcome:row.outcome_status||null});

/** Dedicated local experience database. It never reads templates, credentials or images. */
export function createDesignLearningStore({root,now=Date.now}={}){
  if(typeof root!=='string'||!root)throw new Error('学习库目录未配置。');
  const directory=resolve(root),file=join(directory,'experience.sqlite');
  let db,opening,closed=false,error;
  const feedbackQueues=new Map(),feedbackOrder=new Map();let ingress=0;
  const stamp=()=>new Date(now()).toISOString();
  async function ready(){
    if(closed)return false;if(db)return true;if(opening)return opening;
    opening=(async()=>{
      try{
        await mkdir(directory,{recursive:true});const info=await lstat(directory);if(!info.isDirectory()||info.isSymbolicLink())throw new Error('invalid learning directory');
        try{if((await lstat(file)).isSymbolicLink())throw new Error('invalid learning file');}catch(e){if(e.code!=='ENOENT')throw e;}
        const {DatabaseSync}=await import('./mobile-sqlite.mjs');db=new DatabaseSync(file);
        const existingMeta=db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='learning_meta'").get();
        if(existingMeta&&db.prepare('SELECT version FROM learning_meta').get()?.version!==1)throw new Error('unsupported learning schema');
        db.exec(`PRAGMA journal_mode=WAL; PRAGMA busy_timeout=50; PRAGMA foreign_keys=ON;
          CREATE TABLE IF NOT EXISTS learning_meta(version INTEGER NOT NULL);
          INSERT INTO learning_meta(version) SELECT 1 WHERE NOT EXISTS(SELECT 1 FROM learning_meta);
          CREATE TABLE IF NOT EXISTS attempts(id TEXT PRIMARY KEY,source_sha TEXT NOT NULL,source_media_id TEXT NOT NULL,operation TEXT NOT NULL,mode TEXT NOT NULL,scope_json TEXT,scope_key TEXT,policy TEXT NOT NULL,region_key TEXT NOT NULL,region_json TEXT,region_mode TEXT NOT NULL,task_id TEXT,thread_id TEXT,turn_id TEXT,status TEXT NOT NULL DEFAULT 'started',duration_ms INTEGER,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,hit_count INTEGER NOT NULL DEFAULT 0);
          CREATE TABLE IF NOT EXISTS samples(id TEXT PRIMARY KEY,attempt_id TEXT NOT NULL REFERENCES attempts(id),media_id TEXT NOT NULL,result_sha TEXT NOT NULL,source_sha TEXT NOT NULL,operation TEXT NOT NULL,mode TEXT NOT NULL,scope_json TEXT,scope_key TEXT,policy TEXT NOT NULL,region_key TEXT NOT NULL,region_mode TEXT NOT NULL,position TEXT,corrected_position TEXT,target_position TEXT,placement_json TEXT,status TEXT NOT NULL DEFAULT 'pending',quality_confirmed INTEGER NOT NULL DEFAULT 0,correction_kind TEXT,outcome_status TEXT,design_ids_json TEXT,duration_ms INTEGER,revision INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
          CREATE INDEX IF NOT EXISTS learning_lookup ON samples(scope_key,operation,mode,policy,region_key,status,source_sha);
          CREATE INDEX IF NOT EXISTS learning_recent ON samples(updated_at DESC,id DESC);
          CREATE TABLE IF NOT EXISTS learning_events(seq INTEGER PRIMARY KEY AUTOINCREMENT,sample_id TEXT,attempt_id TEXT NOT NULL,type TEXT NOT NULL,revision INTEGER,payload_json TEXT NOT NULL,created_at TEXT NOT NULL);`);
        if(db.prepare('SELECT version FROM learning_meta').get()?.version!==1)throw new Error('unsupported learning schema');
        error=null;return true;
      }catch{try{db?.close();}catch{}db=undefined;error='学习记录暂不可用，设计操作仍可继续。';return false;}
      finally{opening=null;}
    })();return opening;
  }
  const transaction=run=>{db.exec('BEGIN IMMEDIATE');try{const value=run();db.exec('COMMIT');return value;}catch(e){try{db.exec('ROLLBACK');}catch{}throw e;}};
  const event=(attemptId,sampleId,type,revision,payload)=>db.prepare('INSERT INTO learning_events(sample_id,attempt_id,type,revision,payload_json,created_at) VALUES(?,?,?,?,?,?)').run(sampleId??null,attemptId,type,revision??null,stable(payload),stamp());
  async function begin(input){
    const value=identity(input),id=optionalId(input.attemptId)||'learning-attempt-'+randomUUID(),sourceMediaId=text(input.sourceMediaId);
    if(!await ready())return {available:false,attemptId:id,guidance:emptyGuidance(),message:error};
    const old=db.prepare('SELECT * FROM attempts WHERE id=?').get(id);
    if(old){if(old.source_sha!==value.sourceSha256||old.scope_key!==value.scopeKey||old.mode!==value.mode||old.region_key!==value.regionKey||old.policy!==value.policyVersion||old.operation!==value.operation)fail('学习尝试标识已用于不同来源或操作。');return {available:true,attemptId:id};}
    db.prepare('INSERT INTO attempts(id,source_sha,source_media_id,operation,mode,scope_json,scope_key,policy,region_key,region_json,region_mode,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,value.sourceSha256,sourceMediaId,value.operation,value.mode,value.scope?stable(value.scope):null,value.scopeKey,value.policyVersion,value.regionKey,value.region?stable(value.region):null,value.regionMode,stamp(),stamp());
    event(id,null,'attempt',null,{operation:value.operation,mode:value.mode});return {available:true,attemptId:id};
  }
  async function bind(attemptId,{taskId,threadId,turnId}={}){
    text(attemptId);for(const value of [taskId,threadId,turnId])if(value!==undefined)text(value);
    if(!await ready())return false;
    const row=db.prepare('SELECT task_id,thread_id,turn_id FROM attempts WHERE id=?').get(attemptId);if(!row)fail('学习尝试不存在。');
    for(const [key,value] of [['task_id',taskId],['thread_id',threadId],['turn_id',turnId]])if(row[key]!==null&&value!==undefined&&row[key]!==value)fail('学习尝试已经绑定其他原始任务。');
    db.prepare('UPDATE attempts SET task_id=COALESCE(?,task_id),thread_id=COALESCE(?,thread_id),turn_id=COALESCE(?,turn_id),updated_at=? WHERE id=?').run(taskId??null,threadId??null,turnId??null,stamp(),attemptId);return true;
  }
  async function finish(attemptId,{status,durationMs}={}){
    text(attemptId);if(!['completed','failed','canceled'].includes(status))fail('学习任务状态无效。');finiteMs(durationMs);
    if(!await ready())return false;const row=db.prepare('SELECT status FROM attempts WHERE id=?').get(attemptId);if(!row)fail('学习尝试不存在。');if(row.status===status)return true;db.prepare('UPDATE attempts SET status=?,duration_ms=?,updated_at=? WHERE id=?').run(status,durationMs??null,stamp(),attemptId);event(attemptId,null,'finished',null,{status,durationMs:durationMs??null});return true;
  }
  async function observe(input){
    const attemptId=text(input.attemptId),mediaId=text(input.mediaId),resultSha256=hash(input.resultSha256),durationMs=finiteMs(input.durationMs);
    const position=input.position===undefined||input.position==='auto'?null:POSITIONS.includes(input.position)?input.position:fail('学习来源位置无效。');
    const placement=input.referencePlacement===undefined?undefined:normalizeReferencePlacement(input.referencePlacement,{position:position||undefined,required:true});
    if(!await ready())return {available:false,message:error};
    const a=db.prepare('SELECT * FROM attempts WHERE id=?').get(attemptId);if(!a)fail('学习尝试不存在。');
    const id=learningSampleId(attemptId,mediaId,resultSha256);
    const existing=db.prepare('SELECT * FROM samples WHERE id=?').get(id);
    if(existing){
      // Native registration may add source position/layout later, but never undo human feedback.
      db.prepare('UPDATE samples SET position=COALESCE(position,?),placement_json=COALESCE(placement_json,?),duration_ms=COALESCE(duration_ms,?),updated_at=? WHERE id=?').run(position,placement?stable(placement):null,durationMs??null,stamp(),id);
    }else transaction(()=>{
      db.prepare('INSERT INTO samples(id,attempt_id,media_id,result_sha,source_sha,operation,mode,scope_json,scope_key,policy,region_key,region_mode,position,placement_json,duration_ms,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(id,attemptId,mediaId,resultSha256,a.source_sha,a.operation,a.mode,a.scope_json,a.scope_key,a.policy,a.region_key,a.region_mode,position,placement?stable(placement):null,durationMs??null,stamp(),stamp());
      event(attemptId,id,'observed',1,{position,hasReferencePlacement:!!placement});
    });
    return {available:true,...safePublic(db.prepare('SELECT * FROM samples WHERE id=?').get(id))};
  }
  async function outcome(sampleId,{status,designIds=[]}={}){
    text(sampleId);if(!['saved','failed'].includes(status)||!Array.isArray(designIds)||designIds.length>1000)fail('套图学习回执无效。');const ids=[...new Set(designIds.map(value=>text(value,160)))];
    if(!await ready())return {available:false,message:error};const row=db.prepare('SELECT * FROM samples WHERE id=?').get(sampleId);if(!row)fail('学习结果不存在。');
    if(row.outcome_status!==status||row.design_ids_json!==stable(ids))transaction(()=>{db.prepare('UPDATE samples SET outcome_status=?,design_ids_json=?,updated_at=? WHERE id=?').run(status,stable(ids),stamp(),sampleId);event(row.attempt_id,sampleId,'reported_mockup',row.revision,{status,designIds:ids});});
    return {available:true,...safePublic(db.prepare('SELECT * FROM samples WHERE id=?').get(sampleId))};
  }
  async function applyFeedback(sampleId,input,order,after){
    if(after)await after;
    text(sampleId);keys(input,['verdict','position','targetPosition','referencePlacement','correctionKind','expectedRevision']);
    if(!['confirmed','rejected','corrected'].includes(input.verdict))fail('学习反馈无效。');
    if(input.position!==undefined&&!POSITIONS.includes(input.position)||input.targetPosition!==undefined&&!POSITIONS.includes(input.targetPosition))fail('学习反馈位置无效。');
    if(input.verdict==='corrected'&&!['source-position','target-position','reference-placement'].includes(input.correctionKind))fail('请明确学习纠正的是来源位置、投放位置或参考范围。');
    if(input.verdict!=='corrected'&&input.correctionKind!==undefined)fail('学习反馈类型不一致。');
    if(input.expectedRevision!==undefined&&(!Number.isSafeInteger(input.expectedRevision)||input.expectedRevision<1))fail('学习反馈版本无效。');
    if(!await ready())return {available:false,message:error};const row=db.prepare('SELECT * FROM samples WHERE id=?').get(sampleId);if(!row)fail('学习结果不存在。');
    if(feedbackOrder.get(sampleId)!==order){event(row.attempt_id,sampleId,'feedback_superseded',row.revision,{verdict:input.verdict});return {available:true,superseded:true,...safePublic(row)};}
    if(input.expectedRevision!==undefined&&row.revision!==input.expectedRevision){const e=new Error('学习记录已变化，请刷新后重试。');e.status=409;throw e;}
    const scope=row.scope_json?JSON.parse(row.scope_json):null;
    if(input.targetPosition!==undefined){const allowed=PLACEMENTS[scope?.placementId]||(scope?.baseType==='front'?['front','leftUpper']:scope?.baseType==='back'?['back']:scope?.baseType==='front-back'?POSITIONS:[]);if(!allowed.includes(input.targetPosition))fail('纠正的投放位置不在已选模板范围内。');}
    const sourcePosition=input.correctionKind==='source-position'?input.position:row.corrected_position||row.position;
    if(input.correctionKind==='source-position'&&!input.position||input.correctionKind==='target-position'&&!input.targetPosition||input.correctionKind==='reference-placement'&&!input.referencePlacement)fail('学习纠正内容不完整。');
    if(input.verdict==='confirmed'&&input.position!==undefined&&row.position&&input.position!==row.position)fail('请用位置纠正操作记录来源位置差异。');
    const placement=input.referencePlacement===undefined?undefined:normalizeReferencePlacement(input.referencePlacement,{position:sourcePosition||undefined,required:true});
    const changedPosition=input.correctionKind==='source-position'?input.position:row.corrected_position;
    const targetPosition=input.correctionKind==='target-position'?input.targetPosition:row.target_position;
    const placementJSON=placement?stable(placement):row.placement_json;
    const quality=input.verdict==='confirmed'?1:0,revision=row.revision+1;
    if(row.status===input.verdict&&row.corrected_position===(changedPosition??null)&&row.target_position===(targetPosition??null)&&row.placement_json===(placementJSON??null)&&row.correction_kind===(input.correctionKind??null)&&row.quality_confirmed===quality)return {available:true,...safePublic(row)};
    transaction(()=>{
      db.prepare('UPDATE samples SET status=?,quality_confirmed=?,corrected_position=?,target_position=?,placement_json=?,correction_kind=?,revision=?,updated_at=? WHERE id=?').run(input.verdict,quality,changedPosition??null,targetPosition??null,placementJSON??null,input.correctionKind??null,revision,stamp(),sampleId);
      event(row.attempt_id,sampleId,'human_feedback',revision,{verdict:input.verdict,correctionKind:input.correctionKind??null,position:input.position??null,targetPosition:input.targetPosition??null,hasReferencePlacement:!!placement});
    });return {available:true,...safePublic(db.prepare('SELECT * FROM samples WHERE id=?').get(sampleId))};
  }
  function feedback(sampleId,input,{after}={}){
    text(sampleId);const captured=structuredClone(input),order=++ingress;feedbackOrder.set(sampleId,order);
    const previous=feedbackQueues.get(sampleId)||Promise.resolve();
    const work=previous.catch(()=>{}).then(()=>applyFeedback(sampleId,captured,order,after));feedbackQueues.set(sampleId,work);
    void work.finally(()=>{if(feedbackQueues.get(sampleId)===work)feedbackQueues.delete(sampleId);}).catch(()=>{});return work;
  }
  async function lookup(input){
    const value=identity(input);if(!await ready()||!value.scopeKey)return emptyGuidance();
    const position=input.position;if(position!==undefined&&position!=='auto'&&!POSITIONS.includes(position))fail('学习查询位置无效。');
    const args=[value.scopeKey,value.operation,value.mode,value.policyVersion,value.regionKey];
    const base=`scope_key=? AND operation=? AND mode=? AND policy=? AND region_key=? AND (status='confirmed' OR (status='corrected' AND correction_kind IN ('source-position','reference-placement')))`;
    let rows=db.prepare(`SELECT * FROM samples WHERE ${base} AND source_sha=? ORDER BY updated_at DESC,id DESC LIMIT 30`).all(...args,value.sourceSha256),matchedBy='exact_source';
    const filter=values=>values.filter(row=>!position||position==='auto'||(row.corrected_position||row.position)===position);
    rows=filter(rows);
    if(!rows.length&&value.regionMode==='automatic'){
      rows=filter(db.prepare(`SELECT * FROM samples WHERE ${base} AND source_sha<>? AND placement_json IS NOT NULL ORDER BY updated_at DESC,id DESC LIMIT 30`).all(...args,value.sourceSha256));matchedBy='same_template';
    }
    const examples=[];
    for(const row of rows){
      const actualPosition=row.corrected_position||row.position;if(!POSITIONS.includes(actualPosition))continue;
      const example={id:row.id,position:actualPosition,qualityConfirmed:row.quality_confirmed===1,revision:row.revision};
      if(row.placement_json&&(row.quality_confirmed===1||row.correction_kind==='reference-placement')){
        const placement=JSON.parse(row.placement_json);
        if(placement.position===actualPosition){
          if(matchedBy==='exact_source')example.referencePlacement=placement;
          else {const b=placement.garmentBox,p=placement.printBox;example.relativePrintBox={x:(p.x-b.x)/b.width,y:(p.y-b.y)/b.height,width:p.width/b.width,height:p.height/b.height};}
        }else if(matchedBy==='same_template')continue;
      }else if(matchedBy==='same_template')continue;
      examples.push(example);if(examples.length===3)break;
    }
    if(!examples.length)return emptyGuidance();
    if(input.attemptId){text(input.attemptId);db.prepare('UPDATE attempts SET hit_count=hit_count+1 WHERE id=?').run(input.attemptId);event(input.attemptId,null,'guidance_hit',null,{matchedBy,examples:examples.map(item=>item.id)});}
    return {matchedBy,examples,sampleCount:examples.length,advisoryOnly:true};
  }
  async function status(){
    if(!await ready())return {available:false,summary:{attempts:0,confirmed:0,corrected:0,rejected:0,hits:0},recent:[],message:error};
    const a=db.prepare('SELECT COUNT(*) attempts,COALESCE(SUM(hit_count),0) hits,AVG(duration_ms) averageDurationMs FROM attempts').get();
    const s=db.prepare("SELECT COALESCE(SUM(status='confirmed'),0) confirmed,COALESCE(SUM(status='corrected'),0) corrected,COALESCE(SUM(status='rejected'),0) rejected FROM samples").get();
    const last=db.prepare('SELECT duration_ms FROM attempts WHERE duration_ms IS NOT NULL ORDER BY updated_at DESC LIMIT 1').get();
    return {available:true,version:1,summary:{...a,...s,averageDurationMs:a.averageDurationMs===null?null:Math.round(a.averageDurationMs),lastDurationMs:last?.duration_ms??null},recent:db.prepare('SELECT * FROM samples ORDER BY updated_at DESC,id DESC LIMIT 20').all().map(safePublic)};
  }
  async function close(){closed=true;if(opening)await opening;try{db?.close();}catch{}db=undefined;}
  return {ready,begin,bind,finish,observe,outcome,feedback,lookup,status,close};
}
