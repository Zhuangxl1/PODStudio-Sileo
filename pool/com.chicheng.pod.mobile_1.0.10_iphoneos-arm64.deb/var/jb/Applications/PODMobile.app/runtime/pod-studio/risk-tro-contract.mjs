import {utcMonthName} from './mobile-date.mjs';
import {TRO_RISK_MATCH_VERSION,sameTroRiskMatch,sameTroOperativeScope} from './dist/tro-risk-match.js';
// Research evidence is separate from the visual screen and never legal clearance.
export function troWindow(now=Date.now(),years=3){
 const end=new Date(now),start=new Date(now),month=start.getUTCMonth();start.setUTCFullYear(start.getUTCFullYear()-years);if(start.getUTCMonth()!==month)start.setUTCDate(0);
 return {from:start.toISOString().slice(0,10),to:end.toISOString().slice(0,10)};
}
export function sourceURL(value){try{const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.port||!u.hostname.includes('.')||/^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/u.test(u.hostname))return '';if(!(u.hostname==='www.courtlistener.com'||u.hostname==='courtlistener.com'||u.hostname==='www.govinfo.gov'||u.hostname==='govinfo.gov'||u.hostname.endsWith('.uscourts.gov')))return '';if(u.hostname.endsWith('courtlistener.com')&&!/^\/(docket|recap|opinion)\//u.test(u.pathname))return '';if(u.hostname.endsWith('govinfo.gov')&&!/^\/(app\/details|content\/pkg)\/USCOURTS-/u.test(u.pathname))return '';u.search='';u.hash='';return u.href;}catch{return '';}}
const exactQuery=(query,subject)=>{const q=query.toLowerCase(),s=subject.toLowerCase();let i=q.indexOf(s);while(i>=0){if(!/[0-9A-Za-z\xAA\xB2\xB3\xB5\xB9\xBA\xBC-\xBE\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0558\u0559\u0560-\u0588\u058B\u058C\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u0660-\u0669\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07C0-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0966-\u096F\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09F9\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AE6-\u0AEF\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B6F\u0B71-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0BE6-\u0BF2\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C78-\u0C7E\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D58-\u0D61\u0D66-\u0D78\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DE6-\u0DEF\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F20-\u0F33\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F-\u1049\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u1090-\u1099\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1369-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u17E0-\u17E9\u17F0-\u17F9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A20-\u1A54\u1A80-\u1A89\u1A90-\u1A99\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B50-\u1B59\u1B83-\u1BA0\u1BAE-\u1BE5\u1C00-\u1C23\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2070\u2071\u2074-\u2079\u207F-\u2089\u208F-\u209F\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2150-\u2189\u2460-\u249B\u24EA-\u24FF\u2776-\u2793\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2CFD\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3192-\u3195\u31A0-\u31BF\u31F0-\u31FF\u3220-\u3229\u3248-\u324F\u3251-\u325F\u3280-\u3289\u32B1-\u32BF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DD\uA7E2\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA830-\uA835\uA840-\uA873\uA882-\uA8B3\uA8D0-\uA8D9\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA900-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF-\uA9D9\uA9E0-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB6C\uAB6D\uAB70-\uABE2\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC\u{10000}-\u{1000B}\u{1000D}-\u{10026}\u{10028}-\u{1003A}\u{1003C}\u{1003D}\u{1003F}-\u{1004D}\u{10050}-\u{1005D}\u{10080}-\u{100FA}\u{10107}-\u{10133}\u{10140}-\u{10178}\u{1018A}\u{1018B}\u{10280}-\u{1029C}\u{102A0}-\u{102D0}\u{102E1}-\u{102FB}\u{10300}-\u{10323}\u{1032D}-\u{1034A}\u{10350}-\u{10375}\u{10380}-\u{1039D}\u{103A0}-\u{103C3}\u{103C8}-\u{103CF}\u{103D1}-\u{103D5}\u{10400}-\u{1049D}\u{104A0}-\u{104A9}\u{104B0}-\u{104D3}\u{104D8}-\u{104FB}\u{10500}-\u{10527}\u{10530}-\u{10563}\u{10570}-\u{1057A}\u{1057C}-\u{1058A}\u{1058C}-\u{10592}\u{10594}\u{10595}\u{10597}-\u{105A1}\u{105A3}-\u{105B1}\u{105B3}-\u{105B9}\u{105BB}\u{105BC}\u{105C0}-\u{105F3}\u{10600}-\u{10736}\u{10740}-\u{10755}\u{10760}-\u{10767}\u{10780}-\u{10785}\u{10787}-\u{107B0}\u{107B2}-\u{107BF}\u{10800}-\u{10805}\u{10808}\u{1080A}-\u{10835}\u{10837}\u{10838}\u{1083C}\u{1083F}-\u{10855}\u{10858}-\u{10876}\u{10879}-\u{1089E}\u{108A7}-\u{108AF}\u{108E0}-\u{108F2}\u{108F4}\u{108F5}\u{108FB}-\u{1091B}\u{10920}-\u{10939}\u{10940}-\u{10959}\u{10980}-\u{109B7}\u{109BC}-\u{109CF}\u{109D2}-\u{10A00}\u{10A10}-\u{10A13}\u{10A15}-\u{10A17}\u{10A19}-\u{10A35}\u{10A40}-\u{10A48}\u{10A60}-\u{10A7E}\u{10A80}-\u{10A9F}\u{10AC0}-\u{10AC7}\u{10AC9}-\u{10AE4}\u{10AEB}-\u{10AEF}\u{10B00}-\u{10B35}\u{10B40}-\u{10B55}\u{10B58}-\u{10B72}\u{10B78}-\u{10B91}\u{10BA9}-\u{10BAF}\u{10C00}-\u{10C48}\u{10C80}-\u{10CB2}\u{10CC0}-\u{10CF2}\u{10CFA}-\u{10D23}\u{10D30}-\u{10D39}\u{10D40}-\u{10D65}\u{10D6F}-\u{10D85}\u{10E60}-\u{10E7E}\u{10E80}-\u{10EA9}\u{10EB0}\u{10EB1}\u{10EC2}-\u{10EC7}\u{10ED9}-\u{10EEE}\u{10F00}-\u{10F27}\u{10F30}-\u{10F45}\u{10F51}-\u{10F54}\u{10F70}-\u{10F81}\u{10FB0}-\u{10FCB}\u{10FE0}-\u{10FF6}\u{11003}-\u{11037}\u{11052}-\u{1106F}\u{11071}\u{11072}\u{11075}\u{11083}-\u{110AF}\u{110D0}-\u{110E8}\u{110F0}-\u{110F9}\u{11103}-\u{11126}\u{11136}-\u{1113F}\u{11144}\u{11147}\u{11150}-\u{11172}\u{11176}\u{11183}-\u{111B2}\u{111C1}-\u{111C4}\u{111D0}-\u{111DA}\u{111DC}\u{111E1}-\u{111F4}\u{11200}-\u{11211}\u{11213}-\u{1122B}\u{1123F}\u{11240}\u{11280}-\u{11286}\u{11288}\u{1128A}-\u{1128D}\u{1128F}-\u{1129D}\u{1129F}-\u{112A8}\u{112B0}-\u{112DE}\u{112F0}-\u{112F9}\u{11305}-\u{1130C}\u{1130F}\u{11310}\u{11313}-\u{11328}\u{1132A}-\u{11330}\u{11332}\u{11333}\u{11335}-\u{11339}\u{1133D}\u{11350}\u{1135D}-\u{11361}\u{11380}-\u{11389}\u{1138B}\u{1138E}\u{11390}-\u{113B5}\u{113B7}\u{113D1}\u{113D3}\u{11400}-\u{11434}\u{11447}-\u{1144A}\u{11450}-\u{11459}\u{1145F}-\u{11461}\u{11480}-\u{114AF}\u{114C4}\u{114C5}\u{114C7}\u{114D0}-\u{114D9}\u{11580}-\u{115AE}\u{115D8}-\u{115DB}\u{11600}-\u{1162F}\u{11644}\u{11650}-\u{11659}\u{11680}-\u{116AA}\u{116B8}\u{116C0}-\u{116C9}\u{116D0}-\u{116E3}\u{11700}-\u{1171A}\u{11730}-\u{1173B}\u{11740}-\u{11746}\u{11800}-\u{1182B}\u{118A0}-\u{118F2}\u{118FF}-\u{11906}\u{11909}\u{1190C}-\u{11913}\u{11915}\u{11916}\u{11918}-\u{1192F}\u{1193F}\u{11941}\u{11950}-\u{11959}\u{119A0}-\u{119A7}\u{119AA}-\u{119D0}\u{119E1}\u{119E3}\u{11A00}\u{11A0B}-\u{11A32}\u{11A3A}\u{11A50}\u{11A5C}-\u{11A89}\u{11A9D}\u{11AB0}-\u{11AF8}\u{11B0A}\u{11BC0}-\u{11BE0}\u{11BF0}-\u{11BF9}\u{11C00}-\u{11C08}\u{11C0A}-\u{11C2E}\u{11C40}\u{11C50}-\u{11C6C}\u{11C72}-\u{11C8F}\u{11D00}-\u{11D06}\u{11D08}\u{11D09}\u{11D0B}-\u{11D30}\u{11D46}\u{11D50}-\u{11D59}\u{11D60}-\u{11D65}\u{11D67}\u{11D68}\u{11D6A}-\u{11D89}\u{11D98}\u{11DA0}-\u{11DA9}\u{11DB0}-\u{11DDB}\u{11DE0}-\u{11DE9}\u{11DF1}\u{11EE0}-\u{11EF2}\u{11F02}\u{11F04}-\u{11F10}\u{11F12}-\u{11F33}\u{11F50}-\u{11F59}\u{11FB0}\u{11FC0}-\u{11FD4}\u{12000}-\u{12399}\u{12400}-\u{1246F}\u{12475}-\u{12543}\u{12550}-\u{12686}\u{12F90}-\u{12FF0}\u{13000}-\u{1342F}\u{13441}-\u{13446}\u{13460}-\u{143FA}\u{14400}-\u{14646}\u{16100}-\u{1611D}\u{16130}-\u{16139}\u{16800}-\u{16A38}\u{16A40}-\u{16A5E}\u{16A60}-\u{16A69}\u{16A70}-\u{16ABE}\u{16AC0}-\u{16AC9}\u{16AD0}-\u{16AED}\u{16B00}-\u{16B2F}\u{16B40}-\u{16B43}\u{16B50}-\u{16B59}\u{16B5B}-\u{16B61}\u{16B63}-\u{16B77}\u{16B7D}-\u{16B8F}\u{16D40}-\u{16D6C}\u{16D70}-\u{16D79}\u{16E40}-\u{16E96}\u{16EA0}-\u{16EB8}\u{16EBB}-\u{16ED3}\u{16F00}-\u{16F4A}\u{16F50}\u{16F93}-\u{16F9F}\u{16FE0}\u{16FE1}\u{16FE3}\u{16FF2}-\u{16FF6}\u{17000}-\u{18CDA}\u{18CFF}-\u{18D20}\u{18D80}-\u{18DF2}\u{18E00}-\u{19191}\u{191A0}-\u{191D2}\u{1AFF0}-\u{1AFF3}\u{1AFF5}-\u{1AFFB}\u{1AFFD}\u{1AFFE}\u{1B000}-\u{1B128}\u{1B132}\u{1B150}-\u{1B152}\u{1B155}\u{1B164}-\u{1B168}\u{1B170}-\u{1B2FB}\u{1BC00}-\u{1BC6A}\u{1BC70}-\u{1BC7C}\u{1BC80}-\u{1BC88}\u{1BC90}-\u{1BC99}\u{1CCF0}-\u{1CCF9}\u{1D2C0}-\u{1D2D3}\u{1D2E0}-\u{1D2F3}\u{1D360}-\u{1D378}\u{1D400}-\u{1D454}\u{1D456}-\u{1D49C}\u{1D49E}\u{1D49F}\u{1D4A2}\u{1D4A5}\u{1D4A6}\u{1D4A9}-\u{1D4AC}\u{1D4AE}-\u{1D4B9}\u{1D4BB}\u{1D4BD}-\u{1D4C3}\u{1D4C5}-\u{1D505}\u{1D507}-\u{1D50A}\u{1D50D}-\u{1D514}\u{1D516}-\u{1D51C}\u{1D51E}-\u{1D539}\u{1D53B}-\u{1D53E}\u{1D540}-\u{1D544}\u{1D546}\u{1D54A}-\u{1D550}\u{1D552}-\u{1D6A6}\u{1D6A8}-\u{1D6C0}\u{1D6C2}-\u{1D6DA}\u{1D6DC}-\u{1D6FA}\u{1D6FC}-\u{1D714}\u{1D716}-\u{1D734}\u{1D736}-\u{1D74E}\u{1D750}-\u{1D76E}\u{1D770}-\u{1D788}\u{1D78A}-\u{1D7A8}\u{1D7AA}-\u{1D7C2}\u{1D7C4}-\u{1D7CB}\u{1D7CE}-\u{1D7FF}\u{1DF00}-\u{1DF81}\u{1DF90}-\u{1DF96}\u{1DFCD}-\u{1DFFF}\u{1E030}-\u{1E06D}\u{1E100}-\u{1E12C}\u{1E137}-\u{1E13D}\u{1E140}-\u{1E149}\u{1E14E}\u{1E290}-\u{1E2AD}\u{1E2C0}-\u{1E2EB}\u{1E2F0}-\u{1E2F9}\u{1E4D0}-\u{1E4EB}\u{1E4F0}-\u{1E4F9}\u{1E5D0}-\u{1E5ED}\u{1E5F0}-\u{1E5FA}\u{1E6C0}-\u{1E6DE}\u{1E6E0}-\u{1E6E2}\u{1E6E4}\u{1E6E5}\u{1E6E7}-\u{1E6ED}\u{1E6F0}-\u{1E6F4}\u{1E6FE}\u{1E6FF}\u{1E7E0}-\u{1E7E6}\u{1E7E8}-\u{1E7EB}\u{1E7ED}\u{1E7EE}\u{1E7F0}-\u{1E7FE}\u{1E800}-\u{1E8C4}\u{1E8C7}-\u{1E8CF}\u{1E900}-\u{1E943}\u{1E94B}\u{1E950}-\u{1E959}\u{1EC71}-\u{1ECAB}\u{1ECAD}-\u{1ECAF}\u{1ECB1}-\u{1ECB4}\u{1ED01}-\u{1ED2D}\u{1ED2F}-\u{1ED3D}\u{1EE00}-\u{1EE03}\u{1EE05}-\u{1EE1F}\u{1EE21}\u{1EE22}\u{1EE24}\u{1EE27}\u{1EE29}-\u{1EE32}\u{1EE34}-\u{1EE37}\u{1EE39}\u{1EE3B}\u{1EE42}\u{1EE47}\u{1EE49}\u{1EE4B}\u{1EE4D}-\u{1EE4F}\u{1EE51}\u{1EE52}\u{1EE54}\u{1EE57}\u{1EE59}\u{1EE5B}\u{1EE5D}\u{1EE5F}\u{1EE61}\u{1EE62}\u{1EE64}\u{1EE67}-\u{1EE6A}\u{1EE6C}-\u{1EE72}\u{1EE74}-\u{1EE77}\u{1EE79}-\u{1EE7C}\u{1EE7E}\u{1EE80}-\u{1EE89}\u{1EE8B}-\u{1EE9B}\u{1EEA1}-\u{1EEA3}\u{1EEA5}-\u{1EEA9}\u{1EEAB}-\u{1EEBB}\u{1F100}-\u{1F10C}\u{1FBF0}-\u{1FBF9}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}\u{3D000}-\u{3FC3F}]/u.test(q[i-1]||'')&&!/[0-9A-Za-z\xAA\xB2\xB3\xB5\xB9\xBA\xBC-\xBE\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0558\u0559\u0560-\u0588\u058B\u058C\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u0660-\u0669\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07C0-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0966-\u096F\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09F9\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AE6-\u0AEF\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B6F\u0B71-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0BE6-\u0BF2\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C78-\u0C7E\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D58-\u0D61\u0D66-\u0D78\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DE6-\u0DEF\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F20-\u0F33\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F-\u1049\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u1090-\u1099\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1369-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u17E0-\u17E9\u17F0-\u17F9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A20-\u1A54\u1A80-\u1A89\u1A90-\u1A99\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B50-\u1B59\u1B83-\u1BA0\u1BAE-\u1BE5\u1C00-\u1C23\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2070\u2071\u2074-\u2079\u207F-\u2089\u208F-\u209F\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2150-\u2189\u2460-\u249B\u24EA-\u24FF\u2776-\u2793\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2CFD\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3192-\u3195\u31A0-\u31BF\u31F0-\u31FF\u3220-\u3229\u3248-\u324F\u3251-\u325F\u3280-\u3289\u32B1-\u32BF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DD\uA7E2\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA830-\uA835\uA840-\uA873\uA882-\uA8B3\uA8D0-\uA8D9\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA900-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF-\uA9D9\uA9E0-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB6C\uAB6D\uAB70-\uABE2\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC\u{10000}-\u{1000B}\u{1000D}-\u{10026}\u{10028}-\u{1003A}\u{1003C}\u{1003D}\u{1003F}-\u{1004D}\u{10050}-\u{1005D}\u{10080}-\u{100FA}\u{10107}-\u{10133}\u{10140}-\u{10178}\u{1018A}\u{1018B}\u{10280}-\u{1029C}\u{102A0}-\u{102D0}\u{102E1}-\u{102FB}\u{10300}-\u{10323}\u{1032D}-\u{1034A}\u{10350}-\u{10375}\u{10380}-\u{1039D}\u{103A0}-\u{103C3}\u{103C8}-\u{103CF}\u{103D1}-\u{103D5}\u{10400}-\u{1049D}\u{104A0}-\u{104A9}\u{104B0}-\u{104D3}\u{104D8}-\u{104FB}\u{10500}-\u{10527}\u{10530}-\u{10563}\u{10570}-\u{1057A}\u{1057C}-\u{1058A}\u{1058C}-\u{10592}\u{10594}\u{10595}\u{10597}-\u{105A1}\u{105A3}-\u{105B1}\u{105B3}-\u{105B9}\u{105BB}\u{105BC}\u{105C0}-\u{105F3}\u{10600}-\u{10736}\u{10740}-\u{10755}\u{10760}-\u{10767}\u{10780}-\u{10785}\u{10787}-\u{107B0}\u{107B2}-\u{107BF}\u{10800}-\u{10805}\u{10808}\u{1080A}-\u{10835}\u{10837}\u{10838}\u{1083C}\u{1083F}-\u{10855}\u{10858}-\u{10876}\u{10879}-\u{1089E}\u{108A7}-\u{108AF}\u{108E0}-\u{108F2}\u{108F4}\u{108F5}\u{108FB}-\u{1091B}\u{10920}-\u{10939}\u{10940}-\u{10959}\u{10980}-\u{109B7}\u{109BC}-\u{109CF}\u{109D2}-\u{10A00}\u{10A10}-\u{10A13}\u{10A15}-\u{10A17}\u{10A19}-\u{10A35}\u{10A40}-\u{10A48}\u{10A60}-\u{10A7E}\u{10A80}-\u{10A9F}\u{10AC0}-\u{10AC7}\u{10AC9}-\u{10AE4}\u{10AEB}-\u{10AEF}\u{10B00}-\u{10B35}\u{10B40}-\u{10B55}\u{10B58}-\u{10B72}\u{10B78}-\u{10B91}\u{10BA9}-\u{10BAF}\u{10C00}-\u{10C48}\u{10C80}-\u{10CB2}\u{10CC0}-\u{10CF2}\u{10CFA}-\u{10D23}\u{10D30}-\u{10D39}\u{10D40}-\u{10D65}\u{10D6F}-\u{10D85}\u{10E60}-\u{10E7E}\u{10E80}-\u{10EA9}\u{10EB0}\u{10EB1}\u{10EC2}-\u{10EC7}\u{10ED9}-\u{10EEE}\u{10F00}-\u{10F27}\u{10F30}-\u{10F45}\u{10F51}-\u{10F54}\u{10F70}-\u{10F81}\u{10FB0}-\u{10FCB}\u{10FE0}-\u{10FF6}\u{11003}-\u{11037}\u{11052}-\u{1106F}\u{11071}\u{11072}\u{11075}\u{11083}-\u{110AF}\u{110D0}-\u{110E8}\u{110F0}-\u{110F9}\u{11103}-\u{11126}\u{11136}-\u{1113F}\u{11144}\u{11147}\u{11150}-\u{11172}\u{11176}\u{11183}-\u{111B2}\u{111C1}-\u{111C4}\u{111D0}-\u{111DA}\u{111DC}\u{111E1}-\u{111F4}\u{11200}-\u{11211}\u{11213}-\u{1122B}\u{1123F}\u{11240}\u{11280}-\u{11286}\u{11288}\u{1128A}-\u{1128D}\u{1128F}-\u{1129D}\u{1129F}-\u{112A8}\u{112B0}-\u{112DE}\u{112F0}-\u{112F9}\u{11305}-\u{1130C}\u{1130F}\u{11310}\u{11313}-\u{11328}\u{1132A}-\u{11330}\u{11332}\u{11333}\u{11335}-\u{11339}\u{1133D}\u{11350}\u{1135D}-\u{11361}\u{11380}-\u{11389}\u{1138B}\u{1138E}\u{11390}-\u{113B5}\u{113B7}\u{113D1}\u{113D3}\u{11400}-\u{11434}\u{11447}-\u{1144A}\u{11450}-\u{11459}\u{1145F}-\u{11461}\u{11480}-\u{114AF}\u{114C4}\u{114C5}\u{114C7}\u{114D0}-\u{114D9}\u{11580}-\u{115AE}\u{115D8}-\u{115DB}\u{11600}-\u{1162F}\u{11644}\u{11650}-\u{11659}\u{11680}-\u{116AA}\u{116B8}\u{116C0}-\u{116C9}\u{116D0}-\u{116E3}\u{11700}-\u{1171A}\u{11730}-\u{1173B}\u{11740}-\u{11746}\u{11800}-\u{1182B}\u{118A0}-\u{118F2}\u{118FF}-\u{11906}\u{11909}\u{1190C}-\u{11913}\u{11915}\u{11916}\u{11918}-\u{1192F}\u{1193F}\u{11941}\u{11950}-\u{11959}\u{119A0}-\u{119A7}\u{119AA}-\u{119D0}\u{119E1}\u{119E3}\u{11A00}\u{11A0B}-\u{11A32}\u{11A3A}\u{11A50}\u{11A5C}-\u{11A89}\u{11A9D}\u{11AB0}-\u{11AF8}\u{11B0A}\u{11BC0}-\u{11BE0}\u{11BF0}-\u{11BF9}\u{11C00}-\u{11C08}\u{11C0A}-\u{11C2E}\u{11C40}\u{11C50}-\u{11C6C}\u{11C72}-\u{11C8F}\u{11D00}-\u{11D06}\u{11D08}\u{11D09}\u{11D0B}-\u{11D30}\u{11D46}\u{11D50}-\u{11D59}\u{11D60}-\u{11D65}\u{11D67}\u{11D68}\u{11D6A}-\u{11D89}\u{11D98}\u{11DA0}-\u{11DA9}\u{11DB0}-\u{11DDB}\u{11DE0}-\u{11DE9}\u{11DF1}\u{11EE0}-\u{11EF2}\u{11F02}\u{11F04}-\u{11F10}\u{11F12}-\u{11F33}\u{11F50}-\u{11F59}\u{11FB0}\u{11FC0}-\u{11FD4}\u{12000}-\u{12399}\u{12400}-\u{1246F}\u{12475}-\u{12543}\u{12550}-\u{12686}\u{12F90}-\u{12FF0}\u{13000}-\u{1342F}\u{13441}-\u{13446}\u{13460}-\u{143FA}\u{14400}-\u{14646}\u{16100}-\u{1611D}\u{16130}-\u{16139}\u{16800}-\u{16A38}\u{16A40}-\u{16A5E}\u{16A60}-\u{16A69}\u{16A70}-\u{16ABE}\u{16AC0}-\u{16AC9}\u{16AD0}-\u{16AED}\u{16B00}-\u{16B2F}\u{16B40}-\u{16B43}\u{16B50}-\u{16B59}\u{16B5B}-\u{16B61}\u{16B63}-\u{16B77}\u{16B7D}-\u{16B8F}\u{16D40}-\u{16D6C}\u{16D70}-\u{16D79}\u{16E40}-\u{16E96}\u{16EA0}-\u{16EB8}\u{16EBB}-\u{16ED3}\u{16F00}-\u{16F4A}\u{16F50}\u{16F93}-\u{16F9F}\u{16FE0}\u{16FE1}\u{16FE3}\u{16FF2}-\u{16FF6}\u{17000}-\u{18CDA}\u{18CFF}-\u{18D20}\u{18D80}-\u{18DF2}\u{18E00}-\u{19191}\u{191A0}-\u{191D2}\u{1AFF0}-\u{1AFF3}\u{1AFF5}-\u{1AFFB}\u{1AFFD}\u{1AFFE}\u{1B000}-\u{1B128}\u{1B132}\u{1B150}-\u{1B152}\u{1B155}\u{1B164}-\u{1B168}\u{1B170}-\u{1B2FB}\u{1BC00}-\u{1BC6A}\u{1BC70}-\u{1BC7C}\u{1BC80}-\u{1BC88}\u{1BC90}-\u{1BC99}\u{1CCF0}-\u{1CCF9}\u{1D2C0}-\u{1D2D3}\u{1D2E0}-\u{1D2F3}\u{1D360}-\u{1D378}\u{1D400}-\u{1D454}\u{1D456}-\u{1D49C}\u{1D49E}\u{1D49F}\u{1D4A2}\u{1D4A5}\u{1D4A6}\u{1D4A9}-\u{1D4AC}\u{1D4AE}-\u{1D4B9}\u{1D4BB}\u{1D4BD}-\u{1D4C3}\u{1D4C5}-\u{1D505}\u{1D507}-\u{1D50A}\u{1D50D}-\u{1D514}\u{1D516}-\u{1D51C}\u{1D51E}-\u{1D539}\u{1D53B}-\u{1D53E}\u{1D540}-\u{1D544}\u{1D546}\u{1D54A}-\u{1D550}\u{1D552}-\u{1D6A6}\u{1D6A8}-\u{1D6C0}\u{1D6C2}-\u{1D6DA}\u{1D6DC}-\u{1D6FA}\u{1D6FC}-\u{1D714}\u{1D716}-\u{1D734}\u{1D736}-\u{1D74E}\u{1D750}-\u{1D76E}\u{1D770}-\u{1D788}\u{1D78A}-\u{1D7A8}\u{1D7AA}-\u{1D7C2}\u{1D7C4}-\u{1D7CB}\u{1D7CE}-\u{1D7FF}\u{1DF00}-\u{1DF81}\u{1DF90}-\u{1DF96}\u{1DFCD}-\u{1DFFF}\u{1E030}-\u{1E06D}\u{1E100}-\u{1E12C}\u{1E137}-\u{1E13D}\u{1E140}-\u{1E149}\u{1E14E}\u{1E290}-\u{1E2AD}\u{1E2C0}-\u{1E2EB}\u{1E2F0}-\u{1E2F9}\u{1E4D0}-\u{1E4EB}\u{1E4F0}-\u{1E4F9}\u{1E5D0}-\u{1E5ED}\u{1E5F0}-\u{1E5FA}\u{1E6C0}-\u{1E6DE}\u{1E6E0}-\u{1E6E2}\u{1E6E4}\u{1E6E5}\u{1E6E7}-\u{1E6ED}\u{1E6F0}-\u{1E6F4}\u{1E6FE}\u{1E6FF}\u{1E7E0}-\u{1E7E6}\u{1E7E8}-\u{1E7EB}\u{1E7ED}\u{1E7EE}\u{1E7F0}-\u{1E7FE}\u{1E800}-\u{1E8C4}\u{1E8C7}-\u{1E8CF}\u{1E900}-\u{1E943}\u{1E94B}\u{1E950}-\u{1E959}\u{1EC71}-\u{1ECAB}\u{1ECAD}-\u{1ECAF}\u{1ECB1}-\u{1ECB4}\u{1ED01}-\u{1ED2D}\u{1ED2F}-\u{1ED3D}\u{1EE00}-\u{1EE03}\u{1EE05}-\u{1EE1F}\u{1EE21}\u{1EE22}\u{1EE24}\u{1EE27}\u{1EE29}-\u{1EE32}\u{1EE34}-\u{1EE37}\u{1EE39}\u{1EE3B}\u{1EE42}\u{1EE47}\u{1EE49}\u{1EE4B}\u{1EE4D}-\u{1EE4F}\u{1EE51}\u{1EE52}\u{1EE54}\u{1EE57}\u{1EE59}\u{1EE5B}\u{1EE5D}\u{1EE5F}\u{1EE61}\u{1EE62}\u{1EE64}\u{1EE67}-\u{1EE6A}\u{1EE6C}-\u{1EE72}\u{1EE74}-\u{1EE77}\u{1EE79}-\u{1EE7C}\u{1EE7E}\u{1EE80}-\u{1EE89}\u{1EE8B}-\u{1EE9B}\u{1EEA1}-\u{1EEA3}\u{1EEA5}-\u{1EEA9}\u{1EEAB}-\u{1EEBB}\u{1F100}-\u{1F10C}\u{1FBF0}-\u{1FBF9}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}\u{3D000}-\u{3FC3F}]/u.test(q[i+s.length]||''))return true;i=q.indexOf(s,i+1);}return false;};
const str=v=>typeof v==='string'?v.replace(/<[^>]*>/gu,' ').replace(/[\u0000-\u001f\u007f]/gu,' ').replace(/https?:\/\/[^\s]+/gu,'[链接]').replace(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/giu,'[联系信息]').replace(/(?:Bearer|Token)\s+\S+|(?:api[_ -]?key|token|secret|password|authorization)\s*[:=]\s*\S+/giu,'[已隐藏]').trim().slice(0,500):'';
export const TRO_SCHEMA={type:'object',additionalProperties:false,required:['subjects'],properties:{subjects:{type:'array',maxItems:4,items:{type:'object',additionalProperties:false,required:['subject','cases'],properties:{subject:{type:'string'},cases:{type:'array',maxItems:5,items:{type:'object',additionalProperties:false,required:['name','court','docket','date','stage','url','matchEvidence','ecommerce'],properties:Object.fromEntries(['name','court','docket','date','stage','url','matchEvidence','ecommerce'].map(k=>[k,{type:'string'}]))}}}}}}};
export function validateTro(raw,{subjects,now=Date.now(),searched=false,observedUrls=new Set(),searchQueries=[],searchEvidence=[]}={}){
 const value=typeof raw==='string'?JSON.parse(raw):raw,window=troWindow(now);
 if(!value||!Array.isArray(value.subjects))throw Error('TRO检索结果格式无效');
 return {version:1,checkedAt:new Date(now).toISOString(),window,subjects:subjects.map(subject=>{
  const item=value.subjects.find(v=>v&&v.subject===subject),subjectRecords=searchEvidence.filter(r=>Array.isArray(r.queries)&&r.queries.some(q=>typeof q==='string'&&exactQuery(q,subject))&&subjects.filter(name=>r.queries.some(q=>typeof q==='string'&&exactQuery(q,name))).length===1),subjectSearched=searched&&subjectRecords.length>0,subjectUrls=new Set(subjectRecords.flatMap(r=>Array.isArray(r.documents)?r.documents:[]).filter(d=>d&&typeof d.text==='string'&&exactQuery(d.text,subject)).map(d=>sourceURL(d.url)).filter(Boolean));let rejected=!Array.isArray(item?.cases);
  const cases=(subjectSearched&&Array.isArray(item?.cases)?item.cases:[]).slice(0,5).flatMap(c=>{
   if(!c||typeof c!=='object'){rejected=true;return [];}const url=sourceURL(c.url),date=str(c.date);
   if(!url||!subjectUrls.has(url)||!/\d[^\s]*[-:]|[-:]\d/u.test(str(c.docket))||!/^\d{4}-\d{2}-\d{2}$/u.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date<window.from||date>window.to||!['tro_granted','tro_requested','infringement_case'].includes(c.stage)||!['name','court','docket','matchEvidence','ecommerce'].every(k=>str(c[k]))){rejected=true;return [];}
   return [{...Object.fromEntries(['name','court','docket','matchEvidence','ecommerce'].map(k=>[k,str(c[k])])),date,stage:c.stage,url,verification:'needs_review',sourceStatus:'search_result_url_document_unverified'}];
  });
  return {subject,status:!searched?'unavailable':cases.length?'candidates_found':!subjectSearched||!item||rejected?'incomplete':'not_found',cases};
 })};
}
// Normalize only the locally persisted service result. No search is inferred here.
export function normalizeTroResearch(value){
 if(value?.version===3)return normalizeCodexTro(value);
 if(value?.version===2)return normalizeCourtListenerTro(value);
 // Version 1 is legacy hosted-search evidence, never direct API provenance.
 if(['courtlistener','codex_web_search'].includes(value?.provider))return undefined;
 if(!value||value.version!==1||!Number.isFinite(Date.parse(value.checkedAt))||!Array.isArray(value.subjects))return undefined;
 const window=troWindow(Date.parse(value.checkedAt));
 return {version:1,checkedAt:new Date(value.checkedAt).toISOString(),window,subjects:value.subjects.filter(s=>s&&typeof s==='object'&&str(s.subject)).slice(0,4).map(s=>{
  const status=['candidates_found','not_found','unavailable','incomplete'].includes(s.status)?s.status:'incomplete';
  const cases=(status==='candidates_found'&&Array.isArray(s.cases)?s.cases:[]).slice(0,5).flatMap(c=>{
   if(!c||c.verification!=='needs_review'||c.sourceStatus!=='search_result_url_document_unverified'||!sourceURL(c.url)||!/^\d{4}-\d{2}-\d{2}$/u.test(c.date)||!Number.isFinite(Date.parse(c.date))||new Date(c.date).toISOString().slice(0,10)!==c.date||c.date<window.from||c.date>window.to||!['tro_granted','tro_requested','infringement_case'].includes(c.stage)||!['name','court','docket','matchEvidence','ecommerce'].every(k=>str(c[k])))return [];
   return [{...Object.fromEntries(['name','court','docket','matchEvidence','ecommerce'].map(k=>[k,str(c[k])])),date:c.date,stage:c.stage,url:sourceURL(c.url),verification:'needs_review',sourceStatus:'search_result_url_document_unverified'}];
  });
  return {subject:str(s.subject),status:status==='candidates_found'&&!cases.length?'incomplete':status,cases};
 })};
}

const API_STATUSES=new Set(['candidates_found','not_found','incomplete','unavailable','provider_unavailable','authentication_failed','forbidden','rate_limited','network_error','http_error','invalid_response','timeout','cancelled']);
const documentDate=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/u.test(value)&&Number.isFinite(Date.parse(value))&&new Date(value).toISOString().slice(0,10)===value?value:'';
const sourceId=value=>Number.isSafeInteger(value)&&value>0?value:typeof value==='string'&&/^[1-9]\d{0,15}$/u.test(value)?value:'';
const apiCoverage=(value,complete,hasMore,reason)=>({dateField:'entry_date_filed',complete:complete===true&&hasMore!==true,hasMore:hasMore===true,...(str(value?.reason||reason)?{reason:str(value?.reason||reason)}:{})});

/** Direct RECAP search results are document candidates; no order text is verified here. */
export function normalizeCourtListenerTro(value){
 if(!value||value.version!==2||value.provider!=='courtlistener'||typeof value.checkedAt!=='string'||!Number.isFinite(Date.parse(value.checkedAt))||!Array.isArray(value.subjects))return undefined;
 const window={...troWindow(Date.parse(value.checkedAt)),dateField:'entry_date_filed',years:3,inclusive:true};
 const subjects=value.subjects.filter(s=>s&&typeof s==='object'&&str(s.subject)).slice(0,4).map(s=>{
  const requestedStatus=API_STATUSES.has(s.status)?s.status:'incomplete',sourceCoverage=s.sourceCoverage||{};
  let rejected=!Array.isArray(s.cases)||sourceCoverage.dateField!==undefined&&sourceCoverage.dateField!=='entry_date_filed';
  const cases=(Array.isArray(s.cases)?s.cases:[]).slice(0,5).flatMap(c=>{
   if(!c||typeof c!=='object'){rejected=true;return [];}
   // A docket's dateFiled is deliberately never used as a document-date fallback.
   const date=documentDate(Object.hasOwn(c,'entry_date_filed')?c.entry_date_filed:c.date),url=sourceURL(c.url),docketId=sourceId(c.docketId),documentId=sourceId(c.documentId);
   const snippet=str(c.snippet||c.excerpt||c.description),matchEvidence=str(c.matchEvidence||c.subjectEvidence);
   if(!date||date<window.from||date>window.to||c.dateField!==undefined&&c.dateField!=='entry_date_filed'||!url||!['courtlistener.com','www.courtlistener.com'].includes(new URL(url).hostname)||!docketId||!documentId||c.stage!=='tro_document_candidate'||c.verification!=='needs_review'||c.sourceStatus!=='courtlistener_api_document_unverified'||!['name','court','docket'].every(k=>str(c[k]))||!snippet||!matchEvidence){rejected=true;return [];}
   return [{...Object.fromEntries(['name','court','docket','description','excerpt','subjectEvidence','ecommerce'].filter(k=>str(c[k])).map(k=>[k,str(c[k])])),docketId,documentId,date,dateField:'entry_date_filed',url,snippet,matchEvidence,stage:'tro_document_candidate',verification:'needs_review',sourceStatus:'courtlistener_api_document_unverified'}];
  });
  const hasMore=s.hasMore===true||sourceCoverage.hasMore===true||(Array.isArray(s.cases)&&s.cases.length>5),reason=str(s.reason||sourceCoverage.reason);
  const complete=['not_found','candidates_found'].includes(requestedStatus)&&s.complete!==false&&(s.complete===true||sourceCoverage.complete===true)&&!hasMore&&!rejected;
  // Empty and exhaustive is required for a negative search, even when the API said not_found.
  let status=requestedStatus;
  if(rejected||hasMore||!complete&&['not_found','candidates_found'].includes(status)||status==='not_found'&&cases.length||status==='candidates_found'&&!cases.length)status='incomplete';
  return {subject:str(s.subject),status,cases,complete,hasMore,sourceCoverage:apiCoverage(sourceCoverage,complete,hasMore,reason),...(reason?{reason}:{}),...(typeof s.cacheHit==='boolean'?{cacheHit:s.cacheHit}:{})};
 });
 const hasMore=value.hasMore===true||value.sourceCoverage?.hasMore===true||subjects.some(s=>s.hasMore),complete=subjects.length>0&&subjects.every(s=>s.complete)&&!hasMore,reason=str(value.reason||value.sourceCoverage?.reason);
 const status=API_STATUSES.has(value.status)?value.status:subjects.some(s=>s.status==='incomplete')?'incomplete':subjects.some(s=>s.cases.length)?'candidates_found':subjects.every(s=>s.status==='not_found')?'not_found':'unavailable';
 return {version:2,provider:'courtlistener',checkedAt:new Date(value.checkedAt).toISOString(),window,status:status==='not_found'&&(!complete||subjects.some(s=>s.cases.length))||status==='candidates_found'&&(!complete||!subjects.some(s=>s.cases.length))?'incomplete':status,subjects,complete,hasMore,sourceCoverage:apiCoverage(value.sourceCoverage,complete,hasMore,reason),...(reason?{reason}:{}),...(typeof value.cacheHit==='boolean'?{cacheHit:value.cacheHit}:{})};
}

export const CODEX_TRO_PROVIDER='codex_web_search';
export const CODEX_TRO_STRATEGY_VERSION=TRO_RISK_MATCH_VERSION;
const codexDateField='document_filing_date';
const codexStages=new Set(['tro_granted','tro_requested','infringement_case']);
const codexStatuses=new Set(['candidates_found','not_found','incomplete','unavailable']);
const codexReasons=new Set(['web_search_unavailable','source_evidence_incomplete','subject_search_incomplete','search_budget_exhausted','risk_match_unverified']);
const codexCaseFields=['name','court','docket','date','stage','url','matchEvidence','ecommerce','sourceExcerpt','riskPointId','riskKind','matchedContent','scopeExcerpt','jurisdictionExcerpt'];
const codexCaseSchema={type:'object',additionalProperties:false,required:codexCaseFields,
 properties:Object.fromEntries(codexCaseFields.map(key=>[key,key==='stage'?{type:'string',enum:[...codexStages,'tro_document_candidate']}:{type:'string'}]))};
const codexLeadFields=['name','url','docket','reportedDate','matchEvidence'];
const codexLeadSchema={type:'object',additionalProperties:false,required:codexLeadFields,
 properties:Object.fromEntries(codexLeadFields.map(key=>[key,{type:'string'}]))};
export const CODEX_TRO_SCHEMA={type:'object',additionalProperties:false,required:['subjects'],properties:{subjects:{
 type:'array',maxItems:4,items:{type:'object',additionalProperties:false,required:['subject','searchStatus','cases','leads'],properties:{
  subject:{type:'string'},searchStatus:{type:'string',enum:['completed','incomplete']},cases:{type:'array',maxItems:5,items:codexCaseSchema},
  leads:{type:'array',maxItems:5,items:codexLeadSchema},
 }}
}}};

export function codexTroWindow(now=Date.now()){
 return {...troWindow(now,5),dateField:codexDateField,years:5,inclusive:true};
}

const fold=value=>value.normalize('NFKC').toLowerCase().replace(/[‘’]/gu,"'").replace(/[‐‑–—]/gu,'-').replace(/\s+/gu,' ').trim();
export function troSearchTerms(subject){
 const base=subject.normalize('NFKC').trim();
 const aliasSeparator=/\s*(?:\/|、|；|;|:|\||又名|\baka\b)\s*/iu;
 const names=base.replace(/\([^()]*\)/gu,' ').split(aliasSeparator);
 const aliases=[...base.matchAll(/\(([^()]+)\)/gu)].flatMap(([,part])=>part.split(aliasSeparator));
 const terms=[...names,...aliases].map(part=>part.replace(/[®™©《》「」“”]/gu,'')
  .replace(/^(?:又名|英文名|中文名|角色名|品牌名|character name|trademark|character)\s*[:：]?\s*/iu,'')
  .replace(/\s*(?:商标(?:及角色形象)?|角色形象|角色|品牌|character|franchise|trademark)$/iu,'').trim())
  .filter(part=>part.length>=2&&part.length<=100&&/[A-Za-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0558\u0559\u0560-\u0588\u058B\u058C\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u208F-\u209F\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DD\uA7E2\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB6C\uAB6D\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC\u{10000}-\u{1000B}\u{1000D}-\u{10026}\u{10028}-\u{1003A}\u{1003C}\u{1003D}\u{1003F}-\u{1004D}\u{10050}-\u{1005D}\u{10080}-\u{100FA}\u{10280}-\u{1029C}\u{102A0}-\u{102D0}\u{10300}-\u{1031F}\u{1032D}-\u{10340}\u{10342}-\u{10349}\u{10350}-\u{10375}\u{10380}-\u{1039D}\u{103A0}-\u{103C3}\u{103C8}-\u{103CF}\u{10400}-\u{1049D}\u{104B0}-\u{104D3}\u{104D8}-\u{104FB}\u{10500}-\u{10527}\u{10530}-\u{10563}\u{10570}-\u{1057A}\u{1057C}-\u{1058A}\u{1058C}-\u{10592}\u{10594}\u{10595}\u{10597}-\u{105A1}\u{105A3}-\u{105B1}\u{105B3}-\u{105B9}\u{105BB}\u{105BC}\u{105C0}-\u{105F3}\u{10600}-\u{10736}\u{10740}-\u{10755}\u{10760}-\u{10767}\u{10780}-\u{10785}\u{10787}-\u{107B0}\u{107B2}-\u{107BF}\u{10800}-\u{10805}\u{10808}\u{1080A}-\u{10835}\u{10837}\u{10838}\u{1083C}\u{1083F}-\u{10855}\u{10860}-\u{10876}\u{10880}-\u{1089E}\u{108E0}-\u{108F2}\u{108F4}\u{108F5}\u{10900}-\u{10915}\u{10920}-\u{10939}\u{10940}-\u{10959}\u{10980}-\u{109B7}\u{109BE}\u{109BF}\u{10A00}\u{10A10}-\u{10A13}\u{10A15}-\u{10A17}\u{10A19}-\u{10A35}\u{10A60}-\u{10A7C}\u{10A80}-\u{10A9C}\u{10AC0}-\u{10AC7}\u{10AC9}-\u{10AE4}\u{10B00}-\u{10B35}\u{10B40}-\u{10B55}\u{10B60}-\u{10B72}\u{10B80}-\u{10B91}\u{10C00}-\u{10C48}\u{10C80}-\u{10CB2}\u{10CC0}-\u{10CF2}\u{10D00}-\u{10D23}\u{10D4A}-\u{10D65}\u{10D6F}-\u{10D85}\u{10E80}-\u{10EA9}\u{10EB0}\u{10EB1}\u{10EC2}-\u{10EC7}\u{10ED9}-\u{10EEE}\u{10F00}-\u{10F1C}\u{10F27}\u{10F30}-\u{10F45}\u{10F70}-\u{10F81}\u{10FB0}-\u{10FC4}\u{10FE0}-\u{10FF6}\u{11003}-\u{11037}\u{11071}\u{11072}\u{11075}\u{11083}-\u{110AF}\u{110D0}-\u{110E8}\u{11103}-\u{11126}\u{11144}\u{11147}\u{11150}-\u{11172}\u{11176}\u{11183}-\u{111B2}\u{111C1}-\u{111C4}\u{111DA}\u{111DC}\u{11200}-\u{11211}\u{11213}-\u{1122B}\u{1123F}\u{11240}\u{11280}-\u{11286}\u{11288}\u{1128A}-\u{1128D}\u{1128F}-\u{1129D}\u{1129F}-\u{112A8}\u{112B0}-\u{112DE}\u{11305}-\u{1130C}\u{1130F}\u{11310}\u{11313}-\u{11328}\u{1132A}-\u{11330}\u{11332}\u{11333}\u{11335}-\u{11339}\u{1133D}\u{11350}\u{1135D}-\u{11361}\u{11380}-\u{11389}\u{1138B}\u{1138E}\u{11390}-\u{113B5}\u{113B7}\u{113D1}\u{113D3}\u{11400}-\u{11434}\u{11447}-\u{1144A}\u{1145F}-\u{11461}\u{11480}-\u{114AF}\u{114C4}\u{114C5}\u{114C7}\u{11580}-\u{115AE}\u{115D8}-\u{115DB}\u{11600}-\u{1162F}\u{11644}\u{11680}-\u{116AA}\u{116B8}\u{11700}-\u{1171A}\u{11740}-\u{11746}\u{11800}-\u{1182B}\u{118A0}-\u{118DF}\u{118FF}-\u{11906}\u{11909}\u{1190C}-\u{11913}\u{11915}\u{11916}\u{11918}-\u{1192F}\u{1193F}\u{11941}\u{119A0}-\u{119A7}\u{119AA}-\u{119D0}\u{119E1}\u{119E3}\u{11A00}\u{11A0B}-\u{11A32}\u{11A3A}\u{11A50}\u{11A5C}-\u{11A89}\u{11A9D}\u{11AB0}-\u{11AF8}\u{11B0A}\u{11BC0}-\u{11BE0}\u{11C00}-\u{11C08}\u{11C0A}-\u{11C2E}\u{11C40}\u{11C72}-\u{11C8F}\u{11D00}-\u{11D06}\u{11D08}\u{11D09}\u{11D0B}-\u{11D30}\u{11D46}\u{11D60}-\u{11D65}\u{11D67}\u{11D68}\u{11D6A}-\u{11D89}\u{11D98}\u{11DB0}-\u{11DDB}\u{11DF1}\u{11EE0}-\u{11EF2}\u{11F02}\u{11F04}-\u{11F10}\u{11F12}-\u{11F33}\u{11FB0}\u{12000}-\u{12399}\u{12480}-\u{12543}\u{12F90}-\u{12FF0}\u{13000}-\u{1342F}\u{13441}-\u{13446}\u{13460}-\u{143FA}\u{14400}-\u{14646}\u{16100}-\u{1611D}\u{16800}-\u{16A38}\u{16A40}-\u{16A5E}\u{16A70}-\u{16ABE}\u{16AD0}-\u{16AED}\u{16B00}-\u{16B2F}\u{16B40}-\u{16B43}\u{16B63}-\u{16B77}\u{16B7D}-\u{16B8F}\u{16D40}-\u{16D6C}\u{16E40}-\u{16E7F}\u{16EA0}-\u{16EB8}\u{16EBB}-\u{16ED3}\u{16F00}-\u{16F4A}\u{16F50}\u{16F93}-\u{16F9F}\u{16FE0}\u{16FE1}\u{16FE3}\u{16FF2}\u{16FF3}\u{17000}-\u{18CDA}\u{18CFF}-\u{18D20}\u{18D80}-\u{18DF2}\u{18E00}-\u{19191}\u{191A0}-\u{191D2}\u{1AFF0}-\u{1AFF3}\u{1AFF5}-\u{1AFFB}\u{1AFFD}\u{1AFFE}\u{1B000}-\u{1B128}\u{1B132}\u{1B150}-\u{1B152}\u{1B155}\u{1B164}-\u{1B168}\u{1B170}-\u{1B2FB}\u{1BC00}-\u{1BC6A}\u{1BC70}-\u{1BC7C}\u{1BC80}-\u{1BC88}\u{1BC90}-\u{1BC99}\u{1D400}-\u{1D454}\u{1D456}-\u{1D49C}\u{1D49E}\u{1D49F}\u{1D4A2}\u{1D4A5}\u{1D4A6}\u{1D4A9}-\u{1D4AC}\u{1D4AE}-\u{1D4B9}\u{1D4BB}\u{1D4BD}-\u{1D4C3}\u{1D4C5}-\u{1D505}\u{1D507}-\u{1D50A}\u{1D50D}-\u{1D514}\u{1D516}-\u{1D51C}\u{1D51E}-\u{1D539}\u{1D53B}-\u{1D53E}\u{1D540}-\u{1D544}\u{1D546}\u{1D54A}-\u{1D550}\u{1D552}-\u{1D6A6}\u{1D6A8}-\u{1D6C0}\u{1D6C2}-\u{1D6DA}\u{1D6DC}-\u{1D6FA}\u{1D6FC}-\u{1D714}\u{1D716}-\u{1D734}\u{1D736}-\u{1D74E}\u{1D750}-\u{1D76E}\u{1D770}-\u{1D788}\u{1D78A}-\u{1D7A8}\u{1D7AA}-\u{1D7C2}\u{1D7C4}-\u{1D7CB}\u{1DF00}-\u{1DF81}\u{1DF90}-\u{1DF96}\u{1DFCD}-\u{1DFFF}\u{1E030}-\u{1E06D}\u{1E100}-\u{1E12C}\u{1E137}-\u{1E13D}\u{1E14E}\u{1E290}-\u{1E2AD}\u{1E2C0}-\u{1E2EB}\u{1E4D0}-\u{1E4EB}\u{1E5D0}-\u{1E5ED}\u{1E5F0}\u{1E6C0}-\u{1E6DE}\u{1E6E0}-\u{1E6E2}\u{1E6E4}\u{1E6E5}\u{1E6E7}-\u{1E6ED}\u{1E6F0}-\u{1E6F4}\u{1E6FE}\u{1E6FF}\u{1E7E0}-\u{1E7E6}\u{1E7E8}-\u{1E7EB}\u{1E7ED}\u{1E7EE}\u{1E7F0}-\u{1E7FE}\u{1E800}-\u{1E8C4}\u{1E900}-\u{1E943}\u{1E94B}\u{1EE00}-\u{1EE03}\u{1EE05}-\u{1EE1F}\u{1EE21}\u{1EE22}\u{1EE24}\u{1EE27}\u{1EE29}-\u{1EE32}\u{1EE34}-\u{1EE37}\u{1EE39}\u{1EE3B}\u{1EE42}\u{1EE47}\u{1EE49}\u{1EE4B}\u{1EE4D}-\u{1EE4F}\u{1EE51}\u{1EE52}\u{1EE54}\u{1EE57}\u{1EE59}\u{1EE5B}\u{1EE5D}\u{1EE5F}\u{1EE61}\u{1EE62}\u{1EE64}\u{1EE67}-\u{1EE6A}\u{1EE6C}-\u{1EE72}\u{1EE74}-\u{1EE77}\u{1EE79}-\u{1EE7C}\u{1EE7E}\u{1EE80}-\u{1EE89}\u{1EE8B}-\u{1EE9B}\u{1EEA1}-\u{1EEA3}\u{1EEA5}-\u{1EEA9}\u{1EEAB}-\u{1EEBB}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}\u{3D000}-\u{3FC3F}]/u.test(part));
 return [...new Map((terms.length?terms:[base]).map(term=>[fold(term),term])).values()].slice(0,6);
}

export function codexTroSourceURL(value){
 const url=sourceURL(value);
 if(!url)return '';
 const {hostname,pathname}=new URL(url);
 if(pathname==='/'||/\.(?:jpg|jpeg|png|svg|webp|gif|css|js|zip|exe)$/iu.test(pathname))return '';
 if(['courtlistener.com','www.courtlistener.com'].includes(hostname)&&
   !/^\/(?:docket|recap|opinion)\/[1-9]\d*(?:\/|$)|^\/recap\/gov\.uscourts\./u.test(pathname))return '';
 return url;
}

const hasTerm=(value,term)=>/[\u2E80-\u2E99\u2E9B-\u2EF3\u2F00-\u2FD5\u3005\u3007\u3021-\u3029\u3038-\u303B\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFA6D\uFA70-\uFAD9\u{16FE2}\u{16FE3}\u{16FF0}-\u{16FF6}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}]/u.test(term)?fold(value).includes(fold(term)):exactQuery(fold(value),fold(term));
const primarySearchTerms=subject=>{
 const primary=subject.normalize('NFKC').split(/\s*(?:\/|、|；|;|:|\|)\s*/u)[0];
 return primary?troSearchTerms(primary):troSearchTerms(subject);
};
const troWords=/\b(?:temporary restraining order|t\.?\s*r\.?\s*o\.?)\b/iu;
const researchWords=/\b(?:temporary restraining order|t\.?\s*r\.?\s*o\.?|schedule\s+a|preliminary injunction)\b|临时(?:限制令|禁令)|冻结|跨境维权|跨境电商|案号|维权诉讼/iu;
const docketNumbers=value=>[...fold(value).matchAll(/(?:\b(\d{1,2})\s*:\s*)?\b(\d{2,4})\s*-\s*(?:([a-z]{1,5})\s*-\s*(\d{2,9})|(\d{3,9}))\b/giu)]
 .map(([,division,year,kind,serial,short])=>({division,number:year.slice(-2)+'-'+(kind||'')+'-'+Number(serial||short)}));
const caseClue=text=>researchWords.test(text)||docketNumbers(text).length>0||/维权|诉讼|立案|docket|lawsuit|complaint/iu.test(text);
const docketLookup=(a,b)=>docketNumbers(a).some(x=>docketNumbers(b).some(y=>x.number===y.number&&(!x.division||!y.division||x.division===y.division)));
const leadDocket=value=>{const cleaned=str(value);return docketNumbers(cleaned).length?cleaned:'';};

export function codexTroLeadURL(value){
 try{
  const url=new URL(value),host=url.hostname.toLowerCase();
  if(url.protocol!=='https:'||url.username||url.password||url.port||
   !/^(?:[a-z0-9-]+\.)+[a-z]{2,63}$/iu.test(host)||/\.(?:local|internal|test|invalid|example|localhost)$/iu.test(host)||
   url.pathname==='/'||/\.(?:jpg|jpeg|png|svg|webp|gif|css|js|zip|exe)$/iu.test(url.pathname)||codexTroSourceURL(url.href))return '';
  url.search='';url.hash='';return url.href.length<=1000?url.href:'';
 }catch{return '';}
}

function baseLead(raw,window){
 const name=str(raw?.name),url=codexTroLeadURL(raw?.url),matchEvidence=str(raw?.matchEvidence);
 if(!name||!url||!matchEvidence)return;
 const docket=leadDocket(raw.docket),reportedDate=documentDate(raw.reportedDate);
 return {name,url,matchEvidence,...(docket?{docket}:{}),
  ...(reportedDate&&reportedDate<=window.to?{reportedDate}:{}),sourceStatus:'third_party_unverified'};
}
function observedDocuments(searchEvidence){
 const byURL=new Map();
 for(const record of searchEvidence)for(const row of Array.isArray(record?.documents)?record.documents:[]){
  const url=codexTroSourceURL(row?.url)||codexTroLeadURL(row?.url);
  if(!url||typeof row.text!=='string'||!row.text.trim())continue;
  byURL.set(url,{title:typeof row.title==='string'?row.title:row.text,text:row.text.slice(0,2400)});
 }
 return byURL;
}
const baseCase=(c,window)=>{
 if(!c||typeof c!=='object')return;
 const url=codexTroSourceURL(c.url),date=documentDate(c.date);
 const fields=Object.fromEntries(['name','court','docket','matchEvidence','ecommerce'].map(key=>[key,str(c[key])]));
 if(!url||!date||date<window.from||date>window.to||!docketNumbers(fields.docket).length||!['name','court','matchEvidence'].every(k=>fields[k]))return;
 return {...fields,date,dateField:codexDateField,url,verification:'needs_review'};
};

function hasFilingDate(text,date){
 const [year,month,day]=date.split('-'),m=Number(month),d=Number(day);
 const monthName=utcMonthName(date);
 const dates=[date, year+'/'+month+'/'+day,...[month,m].flatMap(mm=>[day,d].flatMap(dd=>[mm+'/'+dd+'/'+year,mm+'/'+dd+'/'+year.slice(-2)])),
  ...new Set([monthName,monthName.slice(0,3),monthName.slice(0,3)+'.'].flatMap(name=>[name+' '+d+', '+year,name+' '+d+' '+year]))];
 const filings=text.matchAll(/\b(?:filed|entered|docketed|filing date|entry date)\b[ :,\-]*(?:on )?(.{1,30})/giu);
 return [...filings].some(([,tail])=>dates.some(form=>tail.startsWith(form)&&!/\d/u.test(tail[form.length]||'')));
}

function grantsTro(quote){
 const clauses=quote.split(/;\s*|[.!?]\s+|\b(?:however|but|whereas)\b/u);
 return clauses.some(clause=>{
  if(/\b(?:if|unless|should|would|could|may|den(?:y|ies|ied)|not|no|without|propos(?:ed|es)|draft)\b/u.test(clause))return false;
  const text=clause.trim().replace(/^(?:therefore|accordingly)\s*,?\s*/u,'');
  return /^(?:the )?court\s+(?:hereby\s+)?grants?\s+(?:the |an? )?(?:(?:plaintiff(?:s'|'s)?\s+)?(?:emergency\s+|ex parte\s+)?(?:motion|application|request)\s+for\s+(?:an?\s+)?)?(?:temporary restraining order|tro)\b/u.test(text)||
   /^(?:it is (?:hereby )?ordered that )?(?:(?:the |a |an )?(?:plaintiff(?:s'|'s)?\s+)?(?:emergency\s+|ex parte\s+)?(?:motion|application|request)\s+for\s+)?(?:an? |the )?(?:temporary restraining order|tro)\s+is\s+(?:hereby\s+)?granted\b/u.test(text);
 });
}

function verifyCodexCase(c,base,source,terms){
 if(typeof source!=='string'||!source||typeof c.sourceExcerpt!=='string')return;
 const text=fold(source),quote=fold(c.sourceExcerpt);
 if(quote.length<15||quote.length>450||!terms.some(term=>hasTerm(text,term)))return;
 const [expected]=docketNumbers(base.docket);
 if(!docketNumbers(text).some(d=>d.number===expected.number&&(!d.division||!expected.division||d.division===expected.division)))return;
 const at=text.indexOf(quote);
 if(at<0)return;
 const nearby=text.slice(Math.max(0,at-220),at+quote.length+240);
 const header=text.slice(0,650);
 if(!hasFilingDate(header,base.date)&&!hasFilingDate(nearby,base.date))return;
 const proposed=/\b(?:proposed|draft)\s+(?:form of\s+)?(?:order|temporary restraining order|tro)\b/u.test(nearby);
 const grant=grantsTro(quote);
 const signed=/\bsigned by (?:the )?(?:hon(?:orable)?\.? )?(?:(?:u\.?s\.?|united states) )?(?:(?:district|magistrate) )?judge\b|\bso ordered\b.{0,100}\/s\/.{0,100}\b(?:district|magistrate) judge\b/u.test(nearby);
 const motion=/\b(?:motion for|application for|request for|moves for|requests?)\s+(?:an? )?(?:temporary restraining order|tro)\b/u.test(quote);
 if(c.stage==='tro_granted'&&(!troWords.test(quote)||!grant||!signed||proposed))return;
 if(c.stage==='tro_requested'&&(!motion||grant||proposed))return;
 if(c.stage==='infringement_case'&&(grant&&troWords.test(quote)||motion))return;
 if(!codexStages.has(c.stage))return;
 return {...base,stage:c.stage,sourceStatus:'codex_web_source_verified',sourceExcerpt:str(c.sourceExcerpt)};
}

const usCourt=/\b(?:united states|u\.?\s*s\.?)\s+(?:district|bankruptcy|court of federal claims|court of international trade|court of appeals)(?:\s+court)?\b/iu;
const usQuery=/\b(?:united states|u\.?s\.?a?|federal court)\b|美国|site:(?:[a-z0-9.-]*uscourts\.gov|(?:www\.)?courtlistener\.com|(?:www\.)?govinfo\.gov)/iu;
const kindWords={artwork:/\b(?:artworks?|characters?|illustrations?|graphics?|logos?|pictorial|drawings?|designs?|images?)\b|图案|角色|图形|美术/iu,
 text:/\b(?:word\s*marks?|words?|names?|phrases?|slogans?|text|literal elements?)\b|文字|名称|字样|词语/iu};
const queriedKind={artwork:/\b(?:copyright|artworks?|characters?|illustrations?|graphics?|logos?|designs?)\b|图案|角色|图形|美术|版权/iu,text:kindWords.text};
const pointFor=(points,c)=>points.find(point=>point.id===c.riskPointId&&point.kind===c.riskKind&&['artwork','text'].includes(point.kind)&&point.identity&&point.terms?.length);
function verifySameRisk(c,base,source,points,primaryTerms){
 const point=pointFor(points,c);
 if(!point||c.stage!=='tro_granted')return;
 const verified=verifyCodexCase(c,base,source,primaryTerms);
 if(!verified)return;
 const text=fold(source),scope=fold(c.scopeExcerpt||''),jurisdiction=fold(c.jurisdictionExcerpt||''),matched=fold(c.matchedContent||'');
 if(scope.length<15||scope.length>500||jurisdiction.length<15||jurisdiction.length>250||!matched||
  !text.includes(scope)||!text.slice(0,1800).includes(jurisdiction)||!usCourt.test(jurisdiction)||
  !kindWords[point.kind].test(scope)||!scope.includes(matched)||!point.terms.some(term=>hasTerm(matched,term))||
  !sameTroOperativeScope(scope,point.kind,matched))return;
 // A quote about a different right, a requested order or an express exclusion cannot match.
 if(/\b(?:not|excluding|except|unrelated|unprotected|requested|proposed|draft)\b|不包括|不涉及|排除/iu.test(scope))return;
 return {...verified,court:str(c.jurisdictionExcerpt),jurisdiction:'US',matchStatus:'same_risk_confirmed',
  riskPointId:point.id,riskKind:point.kind,riskIdentity:point.identity,matchedContent:str(c.matchedContent),
  scopeExcerpt:str(c.scopeExcerpt),jurisdictionExcerpt:str(c.jurisdictionExcerpt)};
}

function finishCodexTro(checkedAt,window,subjects,strategyVersion,omittedSubjects=[]){
 const complete=subjects.length>0&&subjects.every(s=>s.complete)&&!omittedSubjects.length,hasMore=subjects.some(s=>s.hasMore)||omittedSubjects.length>0;
 const status=complete?(subjects.some(s=>s.cases.length)?'candidates_found':'not_found'):
  subjects.every(s=>s.status==='unavailable')?'unavailable':'incomplete';
 return {version:3,provider:CODEX_TRO_PROVIDER,checkedAt,window,status,complete,hasMore,subjects,
  ...(omittedSubjects.length?{omittedSubjects}:{}),
  ...(strategyVersion===CODEX_TRO_STRATEGY_VERSION?{strategyVersion}:{}),
  ...(!complete?{reason:status==='unavailable'?'web_search_unavailable':
   subjects.some(s=>s.reason==='search_budget_exhausted')?'search_budget_exhausted':'subject_search_incomplete'}:{})};
}

export function unavailableCodexTro(subjects,now=Date.now(),riskPoints=[]){
 return finishCodexTro(new Date(now).toISOString(),codexTroWindow(now),subjects.map(subject=>({
  subject:str(subject),riskPoints:riskPoints.filter(point=>point.subject===subject),status:'unavailable',complete:false,hasMore:false,reason:'web_search_unavailable',cases:[],
 })),CODEX_TRO_STRATEGY_VERSION,[...new Set(riskPoints.map(point=>point.subject).filter(subject=>!subjects.includes(subject)))]);
}

/** Ground live results in completed search actions from the same Codex turn. */
export function validateCodexTro(raw,{subjects,riskPoints=[],now=Date.now(),searched=false,searchEvidence=[],openedUrls=new Set(),sourceTexts=new Map(),timedOut=false}={}){
 const value=typeof raw==='string'?JSON.parse(raw):raw,window=codexTroWindow(now);
 if(!Array.isArray(value?.subjects))throw Error('TRO 检索结果格式无效。');
 const opened=new Set([...openedUrls].map(codexTroSourceURL).filter(Boolean));
 const observed=observedDocuments(searchEvidence);
 return finishCodexTro(new Date(now).toISOString(),window,subjects.map(subject=>{
  const terms=troSearchTerms(subject),primaryTerms=primarySearchTerms(subject),points=riskPoints.filter(point=>point.subject===subject);
  const items=value.subjects.filter(item=>item?.subject===subject),item=items[0];
  const queries=searchEvidence.flatMap(row=>Array.isArray(row?.queries)?row.queries:[])
   .filter(q=>typeof q==='string'&&usQuery.test(q)&&troWords.test(q)&&terms.some(term=>hasTerm(q,term)));
  const subjectSearched=searched&&queries.length>0;
  const covered=points.length>0&&points.every(point=>queriedKind[point.kind]&&point.identity&&point.terms?.length&&
   queries.some(q=>queriedKind[point.kind].test(q)&&point.terms.some(term=>hasTerm(q,term))));
  const rawCases=Array.isArray(item?.cases)?item.cases:[];
  let rejected=items.length!==1||!Array.isArray(item?.cases);
  const cases=[],seen=new Set();
  if(subjectSearched)for(const c of rawCases.slice(0,5)){
   const base=baseCase(c,window);
   if(!base||!opened.has(base.url)&&!observed.has(base.url)){rejected=true;continue;}
   const verified=verifySameRisk(c,base,sourceTexts.get(base.url),points,primaryTerms);
   if(!verified){rejected=true;continue;}
   const key=[base.url,base.docket,base.date,verified.riskPointId].join('|');
   if(seen.has(key))continue;seen.add(key);cases.push(verified);
  }
  // Third-party articles and broad same-brand leads are never TRO matches.
  // Preserve an incomplete result when the model still offers such evidence.
  if(Array.isArray(item?.leads)&&item.leads.length)rejected=true;
  const hasMore=rawCases.length>5||item?.searchStatus==='incomplete'||timedOut;
  const complete=subjectSearched&&covered&&item?.searchStatus==='completed'&&!hasMore&&!rejected;
  const status=!searched?'unavailable':complete?(cases.length?'candidates_found':'not_found'):'incomplete';
  const reason=!searched?'web_search_unavailable':timedOut?'search_budget_exhausted':
   rejected?'risk_match_unverified':'subject_search_incomplete';
  return {subject:str(subject),riskPoints:points,status,complete,hasMore,cases,...(!complete?{reason}:{})};
 }),CODEX_TRO_STRATEGY_VERSION,[...new Set(riskPoints.map(point=>point.subject).filter(subject=>!subjects.includes(subject)))]);
}

function normalizeCodexTro(value){
 if(value.provider!==CODEX_TRO_PROVIDER||typeof value.checkedAt!=='string'||!Number.isFinite(Date.parse(value.checkedAt))||!Array.isArray(value.subjects))return;
 const checkedAt=new Date(value.checkedAt).toISOString(),window=codexTroWindow(Date.parse(checkedAt));
 if(Object.keys(window).some(key=>value.window?.[key]!==window[key]))return;
 const current=value.strategyVersion===CODEX_TRO_STRATEGY_VERSION;
 const subjects=value.subjects.filter(s=>s&&typeof s==='object'&&str(s.subject)).slice(0,4).map(s=>{
  const points=current&&Array.isArray(s.riskPoints)?s.riskPoints.filter(point=>point?.subject===s.subject&&
   typeof point.id==='string'&&/^risk-\d{1,2}$/u.test(point.id)&&['artwork','text','unknown'].includes(point.kind)).slice(0,16).map(point=>({
    id:point.id,subject:str(point.subject),kind:point.kind,identity:str(point.identity),
    terms:Array.isArray(point.terms)?point.terms.map(str).filter(Boolean).slice(0,6):[],evidence:str(point.evidence),field:str(point.field),
   })):[];
  let rejected=!current||!Array.isArray(s.cases);
  const cases=(Array.isArray(s.cases)?s.cases:[]).slice(0,5).flatMap(c=>{
   const base=baseCase(c,window);
   if(!current||!base||!sameTroRiskMatch(c,points)||c.dateField!==codexDateField||c.verification!=='needs_review'||
    !usCourt.test(c.jurisdictionExcerpt)||str(c.sourceExcerpt).length<15){rejected=true;return [];}
   return [{...base,stage:'tro_granted',sourceStatus:'codex_web_source_verified',sourceExcerpt:str(c.sourceExcerpt),
    jurisdiction:'US',matchStatus:'same_risk_confirmed',riskPointId:c.riskPointId,riskKind:c.riskKind,
    riskIdentity:str(c.riskIdentity),matchedContent:str(c.matchedContent),scopeExcerpt:str(c.scopeExcerpt),jurisdictionExcerpt:str(c.jurisdictionExcerpt)}];
  });
  const hasMore=s.hasMore===true||Array.isArray(s.cases)&&s.cases.length>5;
  const complete=points.length>0&&s.complete===true&&!hasMore&&!rejected&&
   (s.status==='candidates_found'&&cases.length>0||s.status==='not_found'&&cases.length===0);
  const status=complete?s.status:current&&s.status==='unavailable'&&!cases.length?'unavailable':'incomplete';
  const reason=rejected?'risk_match_unverified':codexReasons.has(s.reason)?s.reason:status==='unavailable'?'web_search_unavailable':'subject_search_incomplete';
  return {subject:str(s.subject),riskPoints:points,status,complete,hasMore,cases,...(!complete?{reason}:{})};
 });
 const omittedSubjects=Array.isArray(value.omittedSubjects)?[...new Set(value.omittedSubjects.map(str).filter(name=>name&&!subjects.some(subject=>subject.subject===name)))].slice(0,40):[];
 return finishCodexTro(checkedAt,window,subjects,current?CODEX_TRO_STRATEGY_VERSION:undefined,omittedSubjects);
}
