import {mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {inspectMiaoshouDraft} from './dist/miaoshou-draft-wire.js';

export const MIAOSHOU_DRAFT_REQUEST_BYTES = 504 * 1024 * 1024;
export const MIAOSHOU_DRAFT_OPERATIONS = new Set(['local-drafts-get','local-drafts-list','local-drafts-put','local-drafts-remove','local-drafts-import']);
const HISTORY_LIMIT = 3;
const HISTORY_BYTES = 32 * 1024 * 1024;
const SCHEMA = 1;

function draftError(code, message, status = 400, data) {
  return Object.assign(new Error(message), {name:'MiaoshouLocalDraftError',code,status,data});
}

function invalid() {
  return draftError('LOCAL_DRAFT_DATA', '本机草稿参数无效，请重新打开商品。');
}

function storageError(error) {
  if (error?.name === 'MiaoshouLocalDraftError') return error;
  if (error?.errcode === 13 || error?.code === 'ENOSPC') return draftError('LOCAL_DRAFT_QUOTA', '本机磁盘空间不足，已有草稿仍保留。', 503);
  return draftError('LOCAL_DRAFT_STORAGE', '主机草稿读取或保存失败，请检查本机存储空间和权限后重试。', 503);
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function checkedKey(key, filter = false) {
  if (!isRecord(key) || Object.keys(key).some(name => !['contextId','shopId','detailId'].includes(name))
    || typeof key.contextId !== 'string' || !/^[a-f0-9]{64}$/u.test(key.contextId)) throw invalid();
  for (const [field, pattern] of [
    ['shopId', /^(?:unclaimed|[1-9]\d{0,24})$/u],
    ['detailId', /^(?:highlights:)?[1-9]\d{0,24}$/u],
  ]) {
    if (filter && key[field] === undefined) continue;
    if (typeof key[field] !== 'string' || !pattern.test(key[field])) throw invalid();
  }
  return key;
}

const keyValues = key => [key.contextId,key.shopId,key.detailId];
const keyFromRow = row => ({contextId:row.scope,shopId:row.shop_id,detailId:row.detail_id});
const isRevision = number => Number.isSafeInteger(number) && number >= 0;
const isTimestamp = value => typeof value === 'string' && Number.isFinite(Date.parse(value))
  && new Date(value).toISOString() === value;
const size = value => Buffer.byteLength(value, 'utf8');

function payloadFor(value) {
  const projection = {format:1,value:inspectMiaoshouDraft(value),blobs:[]};
  const payload = JSON.stringify(value), bytes = size(payload);
  if (bytes >= MIAOSHOU_DRAFT_REQUEST_BYTES) throw draftError('LOCAL_DRAFT_LIMIT','本机草稿图片过大，已有记录仍保留。',413);
  return {payload,bytes,summary:JSON.stringify(projection)};
}

function databaseStore(db) {
  const head = db.prepare('SELECT * FROM draft_head WHERE scope=? AND shop_id=? AND detail_id=?');
  const meta = db.prepare('SELECT scope,shop_id,detail_id,revision,updated_at,created_at,deleted,bytes,summary FROM draft_head WHERE scope=? AND shop_id=? AND detail_id=?');
  const historyMeta = db.prepare('SELECT revision,updated_at,bytes FROM draft_history WHERE scope=? AND shop_id=? AND detail_id=? AND revision<? ORDER BY revision');
  const historyWithValue = db.prepare('SELECT revision,updated_at,bytes,payload FROM draft_history WHERE scope=? AND shop_id=? AND detail_id=? AND revision<? ORDER BY revision');
  const insertHead = db.prepare(`
    INSERT INTO draft_head (scope,shop_id,detail_id,revision,updated_at,created_at,deleted,bytes,summary,payload)
    VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(scope,shop_id,detail_id) DO UPDATE SET
      revision=excluded.revision,updated_at=excluded.updated_at,deleted=excluded.deleted,
      bytes=excluded.bytes,summary=excluded.summary,payload=excluded.payload
  `);
  const retainHead = db.prepare(`
    INSERT INTO draft_history (scope,shop_id,detail_id,revision,updated_at,bytes,payload)
    SELECT scope,shop_id,detail_id,revision,updated_at,bytes,payload FROM draft_head
    WHERE scope=? AND shop_id=? AND detail_id=? AND revision=?
  `);
  const clearHistory = db.prepare('DELETE FROM draft_history WHERE scope=? AND shop_id=? AND detail_id=?');
  const pruneHistory = db.prepare('DELETE FROM draft_history WHERE scope=? AND shop_id=? AND detail_id=? AND revision<?');
  function transaction(operation, mode = 'IMMEDIATE') {
    db.exec('BEGIN ' + mode);
    try {
      const result = operation();
      db.exec('COMMIT');
      return result;
    } catch (error) {
      try { db.exec('ROLLBACK'); } catch {}
      throw error;
    }
  }
  function envelope(row, {payload = null, includeHistory = false, includeHistoryValue = false} = {}) {
    if (!row) return null;
    const key = keyFromRow(row);
    const history = !includeHistory || row.deleted ? [] : (includeHistoryValue ? historyWithValue : historyMeta)
      .all(...keyValues(key),row.revision).map(entry => ({
        revision:entry.revision,updatedAt:entry.updated_at,bytes:entry.bytes,
        ...(includeHistoryValue ? {value:JSON.parse(entry.payload)} : {}),
      }));
    return {key,revision:row.revision,value:payload?JSON.parse(payload):null,updatedAt:row.updated_at,createdAt:row.created_at,deleted:row.deleted===1,history};
  }
  function writeHead(values, old, {revision, updatedAt, createdAt, deleted, payload, bytes, summary}, {keepPrevious = false} = {}) {
    if (deleted) clearHistory.run(...values);
    else if (keepPrevious && old && !old.deleted) {
      const candidates = [...historyMeta.all(...values,old.revision), old];
      let retained = 0, total = 0, oldest;
      for (const entry of candidates.reverse()) {
        if (retained === HISTORY_LIMIT || total + entry.bytes > HISTORY_BYTES) break;
        retained++;
        total += entry.bytes;
        oldest = entry.revision;
      }
      if (oldest === undefined) clearHistory.run(...values);
      else {
        retainHead.run(...values,old.revision);
        pruneHistory.run(...values,oldest);
      }
    }
    insertHead.run(...values,revision,updatedAt,createdAt,deleted?1:0,bytes,summary,payload);
    return envelope(meta.get(...values),{includeHistory:true});
  }
  function compare(current, expectedRevision) {
    if (!isRevision(expectedRevision)) throw draftError('LOCAL_DRAFT_REVISION','保存本机草稿前须读取当前版本。');
    const actualRevision = current?.revision ?? 0;
    if (expectedRevision !== actualRevision) throw draftError('LOCAL_DRAFT_CONFLICT','本机草稿已由其他保存更新，未覆盖较新内容。',409,{
      expectedRevision,actualRevision,currentRevision:actualRevision,
    });
    if (actualRevision === Number.MAX_SAFE_INTEGER) throw draftError('LOCAL_DRAFT_REVISION','本机草稿版本已达到上限，已有记录仍保留。');
    return actualRevision+1;
  }
  return {
    get(key,{includeHistory = false} = {}) {
      const values = keyValues(checkedKey(key));
      return transaction(() => {
        const row = head.get(...values);
        return envelope(row,{payload:row?.payload,includeHistory:true,includeHistoryValue:includeHistory});
      },'DEFERRED');
    },
    list(key,{includeDeleted = false,includeValue = true,offset = 0,limit} = {}) {
      checkedKey(key,true);
      if (typeof includeDeleted !== 'boolean' || typeof includeValue !== 'boolean' || !isRevision(offset)
        || limit !== undefined && !isRevision(limit)) throw invalid();
      const filters = ['scope=?'], values = [key.contextId];
      if (key.shopId !== undefined) { filters.push('shop_id=?'); values.push(key.shopId); }
      if (key.detailId !== undefined) { filters.push('detail_id=?'); values.push(key.detailId); }
      if (!includeDeleted) filters.push('deleted=0');
      const fields = 'scope,shop_id,detail_id,revision,updated_at,created_at,deleted,summary';
      const sql = 'SELECT '+fields+' FROM draft_head WHERE '+filters.join(' AND ')+' ORDER BY updated_at DESC,shop_id,detail_id LIMIT ? OFFSET ?';
      return db.prepare(sql).all(...values,limit??-1,offset).map(row=>envelope(row,{payload:includeValue?row.summary:null}));
    },
    put(key,value,expectedRevision,now) {
      const values = keyValues(checkedKey(key)), fields = payloadFor(value);
      return transaction(() => {
        const current = meta.get(...values), revision = compare(current,expectedRevision);
        return writeHead(values,current,{...fields,revision,updatedAt:now,createdAt:current?.created_at||now,deleted:false},{keepPrevious:true});
      });
    },
    remove(key,expectedRevision,now) {
      const values = keyValues(checkedKey(key));
      return transaction(() => {
        const current = meta.get(...values), revision = compare(current,expectedRevision);
        const record = writeHead(values,current,{revision,updatedAt:now,createdAt:current?.created_at||now,deleted:true,payload:null,bytes:0,summary:null});
        return {...record,removed:!!current&&!current.deleted};
      });
    },
    import(key,record) {
      const values = keyValues(checkedKey(key));
      if (!isRecord(record) || Object.keys(record).some(name => !['revision','updatedAt','createdAt','deleted','value'].includes(name))
        || !isRevision(record.revision) || !record.revision || !isTimestamp(record.updatedAt) || !isTimestamp(record.createdAt)
        || typeof record.deleted !== 'boolean' || record.deleted && record.value !== null) throw invalid();
      const fields = record.deleted ? {payload:null,bytes:0,summary:null} : payloadFor(record.value);
      return transaction(() => {
        const current = meta.get(...values);
        if (current) return {record:envelope(current,{includeHistory:true}),imported:false};
        return {record:writeHead(values,null,{...record,...fields}),imported:true};
      });
    },
  };
}

export function createMiaoshouDraftDiskStore({root,now = Date.now}) {
  const path = resolve(root,'local-drafts.sqlite');
  let pending, database, closed = false;
  async function open() {
    if (closed) throw draftError('LOCAL_DRAFT_STORAGE','本机草稿服务正在关闭，请重新打开设计器。',503);
    return pending ??= (async () => {
      const {DatabaseSync} = await import('./mobile-sqlite.mjs');
      await mkdir(root,{recursive:true,mode:0o700});
      if (closed) throw draftError('LOCAL_DRAFT_STORAGE','本机草稿服务正在关闭，请重新打开设计器。',503);
      const db = new DatabaseSync(path);
      try {
        db.exec('PRAGMA busy_timeout=5000');
        const schema = db.prepare('PRAGMA user_version').get().user_version;
        if (schema !== 0 && schema !== SCHEMA) throw draftError('LOCAL_DRAFT_SCHEMA','本机草稿由更新版本写入，请使用最新版设计器读取。',503);
        db.exec(`
          PRAGMA journal_mode=WAL;
          PRAGMA synchronous=FULL;
          BEGIN IMMEDIATE;
          CREATE TABLE IF NOT EXISTS draft_head (
            scope TEXT NOT NULL,shop_id TEXT NOT NULL,detail_id TEXT NOT NULL,
            revision INTEGER NOT NULL,updated_at TEXT NOT NULL,created_at TEXT NOT NULL,
            deleted INTEGER NOT NULL,bytes INTEGER NOT NULL,summary TEXT,payload TEXT,
            PRIMARY KEY(scope,shop_id,detail_id)
          ) STRICT;
          CREATE TABLE IF NOT EXISTS draft_history (
            scope TEXT NOT NULL,shop_id TEXT NOT NULL,detail_id TEXT NOT NULL,
            revision INTEGER NOT NULL,updated_at TEXT NOT NULL,bytes INTEGER NOT NULL,payload TEXT NOT NULL,
            PRIMARY KEY(scope,shop_id,detail_id,revision)
          ) STRICT;
          PRAGMA user_version=1;
          COMMIT;
        `);
        database = db;
        return databaseStore(db);
      } catch (error) {
        db.close();
        throw error;
      }
    })().catch(error => {
      pending = undefined;
      throw storageError(error);
    });
  }
  async function operation(name, args, guard) {
    const store = await open();
    // Verify the originating connection immediately before entering SQLite.
    guard?.();
    try { return store[name](...args); } catch (error) { throw storageError(error); }
  }
  return {
    get:(key,options,guard)=>operation('get',[key,options],guard),
    list:(key,options,guard)=>operation('list',[key,options],guard),
    put:(key,value,revision,guard)=>operation('put',[key,value,revision,new Date(now()).toISOString()],guard),
    remove:(key,revision,guard)=>operation('remove',[key,revision,new Date(now()).toISOString()],guard),
    import:(key,record,guard)=>operation('import',[key,record],guard),
    async close() {
      closed = true;
      await pending?.catch(()=>{});
      database?.close();
      database = undefined;
    },
  };
}

export function runMiaoshouDraftOperation(store,operation,input,scope,guard) {
  if (!isRecord(input) || !MIAOSHOU_DRAFT_OPERATIONS.has(operation)) throw invalid();
  const action = operation.slice('local-drafts-'.length);
  const extras = {
    get:['includeHistory'],
    list:['includeDeleted','includeValue','offset','limit'],
    put:['expectedRevision','value'],
    remove:['expectedRevision'],
    import:['record'],
  }[action];
  if (Object.keys(input).some(key=>!['contextId','key',...extras].includes(key))) throw invalid();
  const key = checkedKey(input.key,action==='list');
  if (key.contextId !== scope) throw draftError('CONTEXT_CHANGED','妙手账号已变化，请重新打开商品。',409);
  switch (action) {
    case 'get':
      if (input.includeHistory !== undefined && typeof input.includeHistory !== 'boolean') throw invalid();
      return store.get(key,{includeHistory:input.includeHistory},guard);
    case 'list': return store.list(key,{
      includeDeleted:input.includeDeleted,includeValue:input.includeValue,offset:input.offset,limit:input.limit,
    },guard);
    case 'put': return store.put(key,input.value,input.expectedRevision,guard);
    case 'remove': return store.remove(key,input.expectedRevision,guard);
    case 'import': return store.import(key,input.record,guard);
  }
}
