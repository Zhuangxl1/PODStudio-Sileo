import {constants} from 'node:fs';
import {copyFile,lstat,mkdir,mkdtemp,readdir,realpath,rename,rm,symlink} from 'node:fs/promises';
import {execFile} from 'node:child_process';
import {homedir} from 'node:os';
import {basename,dirname,isAbsolute,join,resolve,sep} from 'node:path';
import {promisify} from 'node:util';

export const WINDOWS_STORAGE_ROOT='D:\\Documents\\POD程序包';
export const legacyConfigHome=()=>join(process.env.APPDATA||join(homedir(),'AppData','Roaming'),'PODStudio');
const storageError=message=>Object.assign(new Error(message),{code:'POD_STORAGE_INITIALIZATION'});
const configuredHome=()=>String(process.env.POD_GLOBAL_CONFIG_HOME||'').trim();
export const podConfigHome=()=>configuredHome()||(process.platform==='win32'?join(WINDOWS_STORAGE_ROOT,'PODStudio'):legacyConfigHome());
export const podStorageRoot=()=>configuredHome()?podConfigHome():process.platform==='win32'?WINDOWS_STORAGE_ROOT:podConfigHome();
export const podTemplateRoot=()=>join(podStorageRoot(),'模板库');
export const podMaterialRoot=()=>join(podStorageRoot(),'素材');
export const podDesignExportRoot=()=>join(podStorageRoot(),'套图');
export const usesFixedStorage=()=>process.platform==='win32'&&!configuredHome();
// The bundled Go service appends PODStudio itself to Windows APPDATA.
export const fixedImageEnvironment=()=>usesFixedStorage()?{APPDATA:WINDOWS_STORAGE_ROOT}:{};

const execute=promisify(execFile);
const roots=['global-settings.json','global-provider-secrets.dpapi','design-learning','miaoshou','publishing','UrPicLink'];
const templateStores=new Set(['miaoshou-description-templates','miaoshou-attribute-templates','miaoshou-sku-presets','miaoshou-sku-structure-templates','miaoshou-claim-size-charts','mockup-template-bindings','size-chart-library']);
const ignoredFile=name=>/\.(?:tmp|lock)$|\.sqlite-(?:wal|shm|journal)$/iu.test(name);
const samePath=(a,b)=>process.platform==='win32'?a.toLowerCase()===b.toLowerCase():a===b;
const inside=(root,path)=>samePath(path.slice(0,root.length+1),root+sep);
async function info(path){try{return await lstat(path);}catch(error){if(error.code!=='ENOENT')throw error;return null;}}

async function restrictWindowsDirectory(directory){
  if(process.platform!=='win32')return;
  const account=await execute('whoami.exe',['/user','/fo','csv','/nh'],{windowsHide:true,timeout:5000});
  const sid=account.stdout.match(/\bS-1-\d+(?:-\d+)+\b/u)?.[0];
  if(!sid)throw storageError('无法确认 Windows 用户，未迁移 POD 本机数据。');
  await execute('icacls.exe',[directory,'/inheritance:r','/grant:r','*'+sid+':(OI)(CI)F','*S-1-5-18:(OI)(CI)F'],{windowsHide:true,timeout:10000});
}

async function backupDatabase(source,target,onProgress){
  const {DatabaseSync,backup}=await import('./mobile-sqlite.mjs');
  const database=new DatabaseSync(source,{readOnly:true,timeout:5000});
  try{
    let last=-1;
    await backup(database,target,{rate:512,progress({totalPages,remainingPages}){
      const percent=totalPages>0?Math.floor(100*(totalPages-remainingPages)/totalPages):0;
      if(percent>=last+10||percent===100){last=percent;onProgress(percent);}
    }});
  }
  finally{database.close();}
}

async function copyEntry(source,target,relative,onProgress){
  const entry=await info(source);
  if(!entry||entry.isSymbolicLink())return;
  if(entry.isDirectory()){
    await mkdir(target);
    for(const child of await readdir(source)){
      if(ignoredFile(child)||relative==='miaoshou'&&templateStores.has(child))continue;
      await copyEntry(join(source,child),join(target,child),relative+'/'+child,onProgress);
    }
  }else if(entry.isFile()){
    if(source.endsWith('.sqlite'))await backupDatabase(source,target,percent=>onProgress(relative,percent));
    else await copyFile(source,target,constants.COPYFILE_EXCL);
  }
}

const stageName=/^\.pod-storage-migration-([1-9]\d{0,8})-[\w-]+$/u;
function abandoned(pid){
  try{process.kill(pid,0);return false;}
  catch(error){return error.code==='ESRCH';}
}

async function discardAbandonedStages(parent){
  for(const entry of await readdir(parent,{withFileTypes:true})){
    const match=stageName.exec(entry.name);
    if(!match||!entry.isDirectory()||!abandoned(Number(match[1])))continue;
    const staging=resolve(parent,entry.name);
    const metadata=await info(staging);
    if(dirname(staging)!==parent||!metadata?.isDirectory()||metadata.isSymbolicLink())continue;
    await rm(staging,{recursive:true,force:true}).catch(()=>{});
  }
}

/** The existing legacy stores remain available for older releases. */
export async function migratePodStorage({source=legacyConfigHome(),target=podConfigHome(),onProgress=()=>{},restrict=restrictWindowsDirectory}={}){
  if(!isAbsolute(source)||!isAbsolute(target))throw storageError('POD 数据目录必须是绝对路径。');
  source=resolve(source);target=resolve(target);
  if(samePath(source,target))return false;
  if(inside(source,target)||inside(target,source))throw storageError('POD 数据目录不能与旧目录嵌套。');
  const existing=await info(target);
  if(existing){
    if(existing.isSymbolicLink()||!existing.isDirectory())throw storageError('固定 POD 数据目录无效。');
    return false;
  }
  const previous=await info(source);
  if(previous&&(previous.isSymbolicLink()||!previous.isDirectory()))throw storageError('原 POD 数据目录无效。');
  const parent=dirname(target);
  await mkdir(parent,{recursive:true});
  if((await lstat(parent)).isSymbolicLink())throw storageError('固定 POD 数据上级目录不可使用目录链接。');
  await discardAbandonedStages(parent);
  const staging=await mkdtemp(join(parent,'.pod-storage-migration-'+process.pid+'-'));
  try{
    await restrict(staging);
    for(const name of roots){
      onProgress(name);
      await copyEntry(join(source,name),join(staging,name),name,onProgress);
    }
    // On Windows, rename fails when the destination already exists. Keep a
    // usable directory published by a concurrent launch intact on any system.
    const concurrent=await info(target);
    if(concurrent){
      if(concurrent.isSymbolicLink()||!concurrent.isDirectory())throw storageError('固定 POD 数据目录无效。');
      return false;
    }
    try{await rename(staging,target);}
    catch(error){if(await info(target))return false;throw error;}
    return true;
  }finally{
    if(dirname(staging)===parent&&basename(staging).startsWith('.pod-storage-migration-'))
      await rm(staging,{recursive:true,force:true}).catch(()=>{});
  }
}

export async function fixedFolderAlias(path,original){
  if(!isAbsolute(path)||!isAbsolute(original))throw storageError('POD 素材目录必须是绝对路径。');
  path=resolve(path);original=resolve(original);
  if(samePath(path,original)){
    await mkdir(path,{recursive:true});
    if(!(await lstat(await realpath(path))).isDirectory())throw storageError('固定 POD 文件夹无效。');
    return path;
  }
  const actual=await realpath(original);
  if(!((await lstat(actual)).isDirectory()))throw storageError('共享目录不可读取。');
  const existing=await info(path);
  if(existing){
    if(samePath(await realpath(path),actual))return path;
    throw storageError('固定目录已有其他内容，请保留目录并核对共享路径。');
  }
  await mkdir(dirname(path),{recursive:true});
  try{await symlink(actual,path,'junction');}
  catch(error){if(error.code!=='EEXIST'||!samePath(await realpath(path),actual))throw error;}
  return path;
}

export async function fixedMaterialFolder(original){
  const path=podMaterialRoot();
  return fixedFolderAlias(path,original||path);
}

export async function fixedDesignExportFolder(original){
  const path=podDesignExportRoot();
  if(await info(path))return fixedFolderAlias(path,path);
  try{return await fixedFolderAlias(path,original);}
  catch(error){if(error.code!=='ENOENT')throw error;return fixedFolderAlias(path,path);}
}
