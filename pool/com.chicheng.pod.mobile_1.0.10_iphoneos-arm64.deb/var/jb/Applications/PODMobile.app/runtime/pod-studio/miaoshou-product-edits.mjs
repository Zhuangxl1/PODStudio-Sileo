import {STRUCTURED_EDIT_KEYS,validateStructuredChanges,structuredContextNeeds,compileStructuredPatch} from './miaoshou-structured-edits.mjs';
import {loadMiaoshouEditContext,miaoshouEditRevision,normalizeMiaoshouWarehouseShop,usableMiaoshouWarehouse} from './miaoshou-edit-context.mjs';
import {compileMiaoshouFlatPatch} from './miaoshou-edit-fields.mjs';
import {createHash,randomUUID} from 'node:crypto';
import {validMiaoshouPackage} from './dist/miaoshou-package-defaults.js';
import {open,readFile,mkdir,rename,stat,unlink} from 'node:fs/promises';
import {resolve} from 'node:path';
import {miaoshouId,requireSingleShop} from './dist/miaoshou-policy.js';
import {validateMiaoshouDetail} from './miaoshou-replacement.mjs';
import {serializeMiaoshou} from './miaoshou-client.mjs';
import {MIAOSHOU_FIELD_HASH_SCHEME,createMiaoshouSaveReceipt,createMiaoshouFieldExpectations,reviewMiaoshouFields,miaoshouFieldsEqual} from './miaoshou-save-receipt.mjs';
import {isBuiltinMiaoshouLeafCategory} from './miaoshou-category-names.mjs';
import {compileMiaoshouAttributeUpdates,validateMiaoshouAttributeDependencies} from './miaoshou-attribute-values.mjs';

const fail=(code,message,status=409)=>Object.assign(new Error(message),{code,status});
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const hash=value=>createHash('sha256').update(serializeMiaoshou(value)).digest('hex');
const actions=new Set(['edit','size-chart','package','category']);
const revisionActions=new Set(['category','warehouse']);
const unresolved=entry=>!entry.resolution&&['submitting','uncertain'].includes(entry.state);
const releasable=entry=>entry?.state==='uncertain'&&!entry.receipt&&!entry.resolution;
const validScope=value=>typeof value==='string'&&/^[a-f0-9]{64}$/u.test(value);
const same=miaoshouFieldsEqual;
const own=(value,key)=>value!==null&&typeof value==='object'&&Object.hasOwn(value,key);
const at=(value,path)=>path.reduce((current,key)=>own(current,key)?current[key]:undefined,value);
const review=entry=>Object.assign(fail('MIAOSHOU_EDIT_REVIEW','该商品修改结果尚未确认，请先在妙手核对；系统不会重复提交。'),{state:'needs_review',data:{operationId:entry.operationId,detailId:entry.detailId,shopId:entry.shopId,action:entry.action,state:'needs_review'}});
const reviewChanged=()=>fail('MIAOSHOU_EDIT_REVIEW_CHANGED','商品或旧保存记录已变化，请重新查询保存结果。');
const incompleteSource=message=>fail('MIAOSHOU_EDIT_SOURCE_INCOMPLETE',message);
const optionalEmpty=value=>value===null||value===undefined||value==='';
const emptyChartType=value=>optionalEmpty(value)||value==='image';

function regionCode(value){
  if(typeof value!=='string')return;
  const code=value.trim().toUpperCase();
  if(/^[A-Z]{2}$/u.test(code))return code;
}

function sameId(value,id){
  try{return miaoshouId(value)===id;}
  catch{return false;}
}

function warehouseStock(value){
  const stock=typeof value==='string'&&/^\d+$/u.test(value)?Number(value):value;
  if(!Number.isSafeInteger(stock)||stock<0)throw incompleteSource('原 SKU 库存不完整，无法在保留数量的情况下换仓。');
  return stock;
}

function moveWarehouseInventory(info,shopId,warehouseId){
  if(!plain(info.skuMap)||Object.keys(info.skuMap).length>20000)
    throw incompleteSource('原商品 SKU 结构无效，无法换仓。');
  const skuMap=structuredClone(info.skuMap);
  let skuCount=0;
  for(const sku of Object.values(skuMap)){
    if(!plain(sku))throw incompleteSource('原商品 SKU 结构无效，无法换仓。');
    if([true,1,'1','true'].includes(sku.isDelete))continue;
    const maps=sku.shopIdToWarehouseIdAndStockMap??{};
    if(!plain(maps)||Object.values(maps).some(map=>!plain(map)))
      throw incompleteSource('原 SKU 仓库分配结构无效，无法换仓。');
    const amounts=Object.values(maps[shopId]??{}).map(warehouseStock);
    const others=Object.entries(maps).filter(([id])=>id!==shopId).flatMap(([,map])=>Object.values(map)).map(warehouseStock);
    const stock=sku.stock==null||sku.stock===''?undefined:warehouseStock(sku.stock);
    const existingTotal=warehouseStock([...amounts,...others].reduce((sum,n)=>sum+n,0));
    if(amounts.length&&stock!==undefined&&existingTotal!==stock||!amounts.length&&others.length||!amounts.length&&stock===undefined)
      throw incompleteSource('原 SKU 库存总数与仓库分配无法核对，请检查该商品的分仓库存。');
    const assigned=amounts.length?amounts.reduce((sum,n)=>sum+n,0):stock;
    if(amounts.length!==1||!Object.hasOwn(maps[shopId],warehouseId))
      sku.shopIdToWarehouseIdAndStockMap={...maps,[shopId]:{[warehouseId]:String(assigned)}};
    skuCount++;
  }
  if(!skuCount)throw incompleteSource('商品没有可换仓的有效 SKU。');
  return {skuMap,skuCount};
}

/** Exact logical-to-official fields, verified against save_shop_collect_item_info. */
export function validateMiaoshouEditInput({action,changes={}}={}){
  if(!(actions.has(action)||action==='warehouse')||!plain(changes))throw fail('MIAOSHOU_EDIT_INVALID','商品修改参数无效。',400);
  const keys=Object.keys(changes),patch=[];
  if(action==='edit'){
    if(own(changes,'descriptionImages')&&own(changes,'description'))throw fail('MIAOSHOU_EDIT_INVALID','描述文字覆盖与描述图替换请分开提交。',400);
    if(!keys.length)throw fail('MIAOSHOU_EDIT_INVALID','请选择要修改的字段。',400);
    if(own(changes,'brandId'))throw fail('MIAOSHOU_EDIT_INVALID','当前尚未取得店铺允许的品牌列表，请在妙手后台修改品牌。',400);
    const structured=Object.fromEntries(Object.entries(changes).filter(([k])=>STRUCTURED_EDIT_KEYS.includes(k)));
    if(Object.keys(structured).length)validateStructuredChanges(structured);
    const flat=Object.fromEntries(Object.entries(changes).filter(([k])=>!STRUCTURED_EDIT_KEYS.includes(k)));
    const values=Object.keys(flat).length?compileMiaoshouFlatPatch({selectedFields:Object.keys(flat),values:flat,context:{codSupported:true,sizeChartSupported:true}}):{};
    for(const [key,value] of Object.entries(values))patch.push({path:[key],value});
  }else if(action==='category'){
    if(keys.length!==1||typeof changes.categoryId!=='string'||!/^[1-9]\d{0,19}$/u.test(changes.categoryId)||!isBuiltinMiaoshouLeafCategory(changes.categoryId))
      throw fail('MIAOSHOU_EDIT_INVALID','请选择已核验的 TikTok 美国站末级类目。',400);
    patch.push({path:['cid'],value:changes.categoryId});
  }else if(action==='warehouse'){
    if(keys.length!==1||typeof changes.warehouseId!=='string'||!/^[1-9]\d{0,24}$/u.test(changes.warehouseId))
      throw fail('MIAOSHOU_EDIT_INVALID','请选择当前店铺的有效仓库。',400);
  }else if(action==='size-chart'){
    if(keys.length!==1||keys[0]!=='sizeChartUrl'||typeof changes.sizeChartUrl!=='string')throw fail('MIAOSHOU_EDIT_INVALID','请选择有效的尺码图。',400);
    let url;try{url=new URL(changes.sizeChartUrl);}catch{throw fail('MIAOSHOU_EDIT_INVALID','尺码图需要有效的 HTTPS 图片地址。',400);}
    if(url.protocol!=='https:'||url.username||url.password||url.href.length>255)throw fail('MIAOSHOU_EDIT_INVALID','尺码图需要不超过 255 字符的 HTTPS 图片地址。',400);
    patch.push({path:['sizeChartType'],value:'image'},{path:['sizeChart'],value:url.href});
  }else{
    if(keys.length&&!validMiaoshouPackage(changes))throw fail('MIAOSHOU_EDIT_INVALID','包裹参数不符合本次批量设置范围。',400);
    const weight=(changes.weightGrams??100)/1000,{length,width,height}=changes.packageDimensionsCm??{length:1,width:1,height:1};
    patch.push({path:['weight'],value:weight},{path:['packageLength'],value:length},{path:['packageWidth'],value:width},{path:['packageHeight'],value:height});
  }
  return patch;
}

function createJournal(root){
  const path=root?resolve(root,'product-edit-journal-v1.json'):null;let memory={version:1,entries:[]},queue=Promise.resolve();
  let syncIndex;
  async function read(){
    if(!path)return structuredClone(memory);
    try{
      const bytes=await readFile(path);if(bytes.length>8*1024*1024)throw new Error();const data=JSON.parse(bytes.toString('utf8'));
      if(data?.version!==1||!Array.isArray(data.entries)||data.entries.length>20000)throw new Error();
      for(const e of data.entries){if(!plain(e)||!validScope(e.scope)||!validScope(e.key)||!validScope(e.changeHash)||!validScope(e.sourceHash)||!actions.has(e.action)||!['submitting','uncertain','verified','rejected','acknowledged'].includes(e.state)||typeof e.operationId!=='string'||typeof e.createdAt!=='string'||typeof e.updatedAt!=='string'||miaoshouId(e.detailId)!==e.detailId||miaoshouId(e.shopId)!==e.shopId)throw new Error();}
      for(const e of data.entries){if(e.requestHash!==undefined&&!validScope(e.requestHash))throw new Error();if(e.fieldPaths!==undefined&&(!Array.isArray(e.fieldPaths)||e.fieldPaths.length>20010||e.fieldPaths.some(path=>!Array.isArray(path)||!path.length||path.length>4||path.some(key=>typeof key!=='string'))))throw new Error();}
      for(const e of data.entries){
        if(e.fieldExpectations!==undefined&&(e.fieldExpectations?.scheme!==MIAOSHOU_FIELD_HASH_SCHEME||!Array.isArray(e.fieldExpectations.fields)||e.fieldExpectations.fields.length>200000||e.fieldExpectations.fields.some(field=>!plain(field)||!validScope(field.expectedHash)||!Array.isArray(field.path)||!field.path.length||field.path.length>32||field.path.some(key=>typeof key!=='string'))))throw new Error();
        if(e.receipt!==undefined&&(!plain(e.receipt)||e.receipt.version!==1||e.receipt.api!=='save_shop_collect_item_info'||e.receipt.outcome!=='acknowledged'||e.receipt.operationId!==e.operationId||e.receipt.detailId!==e.detailId||e.receipt.shopId!==e.shopId||e.receipt.accountScope!==e.scope||e.receipt.result!=='success'||e.receipt.code!=='success'||!validScope(e.receipt.ossMd5Hash)||typeof e.receipt.acknowledgedAt!=='string'))throw new Error();
        if(e.state==='acknowledged'&&!e.receipt)throw new Error();
        if(e.resolution!==undefined){
          const resolution=e.resolution;
          if(e.state!=='uncertain'||e.receipt||!plain(resolution)||
            Object.keys(resolution).some(key=>!['kind','at','revision'].includes(key))||
            resolution.kind!=='manually_released'||typeof resolution.at!=='string'||
            !Number.isFinite(Date.parse(resolution.at))||!validScope(resolution.revision))throw new Error();
        }
      }
      return data;
    }catch(error){if(error.code==='ENOENT')return {version:1,entries:[]};throw fail('MIAOSHOU_EDIT_JOURNAL','商品修改记录无法读取，请保留记录并核对后重试。',503);}
  }
  function transaction(change,beforeCommit){
    const work=queue.then(async()=>{
      let lock,temp;
      try{
        if(path){await mkdir(root,{recursive:true});try{lock=await open(path+'.lock','wx');}catch{throw fail('MIAOSHOU_EDIT_JOURNAL','商品修改记录正在使用或需要核对，请稍后重试。',409);}}
        const data=await read(),result=change(data);
        const encoded=JSON.stringify(data);if(Buffer.byteLength(encoded)>8*1024*1024)throw fail('MIAOSHOU_EDIT_JOURNAL','商品修改记录已满，请保留记录后联系管理员。',503);
        if(path){temp=path+'.'+randomUUID()+'.tmp';const file=await open(temp,'wx');try{await file.writeFile(encoded);await file.sync();}finally{await file.close();}if(beforeCommit)await beforeCommit();await rename(temp,path);temp=null;}
        else{if(beforeCommit)await beforeCommit();memory=data;}
        return result;
      }finally{if(temp)await unlink(temp).catch(()=>{});if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}}
    });queue=work.catch(()=>{});return work;
  }
  return {
    async confirmedSyncTimes(scope){
      const file=path?await stat(path).catch(error=>{if(error.code!=='ENOENT')throw error;return null;}):null;
      const version=path?(file&&[file.ino,file.size,file.mtimeMs,file.ctimeMs].join(':')):memory;
      if(!syncIndex||syncIndex.version!==version){
        const byScope=new Map();
        for(const entry of (await read()).entries){
          const time=Date.parse(entry.receipt?.acknowledgedAt??(entry.state==='verified'?entry.fieldReview?.checkedAt??entry.updatedAt:''));
          if(!Number.isFinite(time))continue;
          if(!byScope.has(entry.scope))byScope.set(entry.scope,new Map());
          const rows=byScope.get(entry.scope),key=entry.detailId+':'+entry.shopId;
          if(time>(rows.get(key)??-Infinity))rows.set(key,time);
        }
        syncIndex={version,byScope};
      }
      return new Map(syncIndex.byScope.get(scope));
    },
    async pending(scope,target){return (await read()).entries.findLast(e=>e.scope===scope&&e.detailId===target.detailId&&e.shopId===target.shopId&&unresolved(e));},
    async find(scope,target,operationId){return (await read()).entries.find(e=>e.scope===scope&&e.detailId===target.detailId&&e.shopId===target.shopId&&e.operationId===operationId);},
    reserve(entry){return transaction(data=>{const prior=data.entries.findLast(e=>e.scope===entry.scope&&e.detailId===entry.detailId&&e.shopId===entry.shopId&&unresolved(e));if(prior)throw review(prior);if(data.entries.length>=20000)throw fail('MIAOSHOU_EDIT_JOURNAL','商品修改记录已满，请保留记录后联系管理员。',503);data.entries.push({...entry});return {...entry};});},
    transition(entry,state,details={}){return transaction(data=>{const record=data.entries.find(e=>e.scope===entry.scope&&e.operationId===entry.operationId);if(!record)throw fail('MIAOSHOU_EDIT_JOURNAL','商品修改记录不存在。',503);if(record.resolution)throw reviewChanged();Object.assign(record,details);record.state=state;record.updatedAt=new Date().toISOString();return {...record};});},
    release(scope,target,entry,resolution,checked,beforeCommit){
      return transaction(data=>{
        const record=data.entries.findLast(e=>e.scope===scope&&e.detailId===target.detailId&&e.shopId===target.shopId&&unresolved(e));
        if(!releasable(record)||record.operationId!==entry.operationId||record.updatedAt!==entry.updatedAt)throw reviewChanged();
        // Keep the original transport outcome. Older versions can still read this history.
        Object.assign(record,{resolution,fieldReview:checked,updatedAt:resolution.at});
      },beforeCommit);
    },
    async close(){await queue;}
  };
}

/** Absolute edits with fresh reads, optimistic ossMd5 and a credential-free durable journal. */
export function createMiaoshouProductEdits({client,root,accountScope,assertOpen=()=>{},resolveDescriptionImages,getShopSite=()=>undefined,now=Date.now}={}){
  if(!client?.call||typeof accountScope!=='function')throw new TypeError('商品修改服务缺少妙手连接。');
  const journal=createJournal(root),locks=new Set(),unpersistedReceipts=new Map();let closed=false;
  function guard(){if(closed)throw fail('MIAOSHOU_EDIT_CLOSED','商品修改服务已关闭。',503);assertOpen();}
  async function scopeValue(){guard();const value=await accountScope();guard();if(!validScope(value))throw fail('MIAOSHOU_EDIT_SCOPE','妙手账号作用域无效。',503);return value;}
  async function scopeGuard(scope){if(await scopeValue()!==scope)throw fail('MIAOSHOU_EDIT_SCOPE','妙手连接已变化，请重新确认修改。',409);}
  async function read(target,scope){guard();const value=await client.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)},{guard:()=>scopeGuard(scope)});await scopeGuard(scope);return validateMiaoshouDetail(value,target);}
  async function checkCategory(info,target,categoryId,guard,metadataByShop){
    const sites=new Set([getShopSite(target.shopId),info.site,info.siteCode].map(regionCode).filter(Boolean));
    if(sites.size!==1||!sites.has('US'))throw fail('MIAOSHOU_CATEGORY_SITE','此商品的店铺未核实为 TikTok 美国站，请同步店铺后重试。');
    if(sameId(info.cid,categoryId))return;
    let metadata=metadataByShop?.get(target.shopId);
    if(!metadata){
      const response=await client.call('categoryMetadata',{cid:BigInt(categoryId),shopIds:[BigInt(target.shopId)]},{guard});await guard();
      metadata=response?.categoryMetadata;
      if(!plain(metadata?.categoryConfig)||!Array.isArray(metadata.categoryProductAttrList)||!Array.isArray(metadata.categorySaleAttrList))
        throw fail('MIAOSHOU_CATEGORY_UNVERIFIED','妙手未返回此店铺与目标类目的完整选项。');
      metadataByShop?.set(target.shopId,metadata);
    }
    const invalid=field=>fail('MIAOSHOU_CATEGORY_INCOMPATIBLE','原商品的'+field+'无法在目标类目中确认，请先在妙手核对。');
    const attributes=info.productAttributes??[],certifications=info.productCertifications??[],specifications=info.skuPropertyList??[];
    if(![attributes,certifications,specifications].every(Array.isArray))throw invalid('类目资料');
    const supported=value=>[true,1,'1','true'].includes(value);
    if(supported(info.isCodOpen)&&![metadata.categoryConfig.codIsSupported,metadata.categoryConfig.isSuppCod].some(supported))throw invalid('货到付款设置');
    if((info.sizeChart||info.sizeChartTemplateId)&&![metadata.categoryConfig.sizeChartIsSupported,metadata.categoryConfig.isSuppSizechart].some(supported))throw invalid('尺码表');
    try{
      if(attributes.length)compileMiaoshouAttributeUpdates(attributes.map(attribute=>{
        if(!Array.isArray(attribute?.attributeValues)||!attribute.attributeValues.length)throw invalid('产品属性');
        return {id:String(attribute.attributeId),values:attribute.attributeValues.map(value=>{
          if(value?.valueId)return {id:String(value.valueId)};
          if(typeof value?.valueName!=='string'||!value.valueName.trim())throw invalid('产品属性');
          return {name:value.valueName};
        })};
      }),metadata);
      validateMiaoshouAttributeDependencies(attributes,certifications,metadata);
    }catch{throw invalid('产品属性');}
    for(const certificate of certifications){
      if(!Array.isArray(metadata.categoryConfig.productCertifications)||!metadata.categoryConfig.productCertifications.some(row=>sameId(row?.id,String(certificate?.id))))throw invalid('产品资质');
    }
    for(const specification of specifications){
      const candidates=metadata.categorySaleAttrList.filter(row=>sameId(row.attrId,String(specification?.attrId)));
      const [definition]=candidates;
      if(candidates.length!==1||!Array.isArray(specification.attrValueList)||!Array.isArray(definition.values)||specification.attrValueList.some(value=>!definition.values.some(row=>sameId(row?.id,String(value?.attrValueId)))))throw invalid('销售规格');
    }
  }

  async function completeSavePayload(next,current,target,scope,{changesSizeChart}){
    const needsDelivery=typeof next.deliveryOptionSetType!=='string'||!next.deliveryOptionSetType.trim();
    const needsEmptyChartCheck=!changesSizeChart&&(own(next,'sizeChartType')||own(next,'sizeChart'))&&
      emptyChartType(next.sizeChartType)&&optionalEmpty(next.sizeChart);
    if(!needsDelivery&&!needsEmptyChartCheck)return;

    // Use a site from the verified shop directory or the fresh shop response.
    // If both are available, they must agree before looking up the site record.
    const shopInfo=current.shopCollectItemInfo;
    const sites=new Set([getShopSite(target.shopId),shopInfo.site,shopInfo.siteCode].map(regionCode).filter(Boolean));
    if(sites.size!==1)throw incompleteSource('无法确认当前店铺的站点，请同步店铺或在妙手核对商品配送和尺码表。');
    const [site]=sites;
    await scopeGuard(scope);
    const source=await client.call('siteDetail',{detailId:BigInt(target.detailId),site},{guard:()=>scopeGuard(scope)});
    await scopeGuard(scope);
    const siteInfo=source?.siteCollectItemInfo,claims=source?.claimToShopIds;
    const shopRows=siteInfo?.collectBoxDetailShopList;
    const matching=Array.isArray(shopRows)?shopRows.filter(row=>sameId(row?.shopId,target.shopId)):[];
    const [siteShop]=matching;
    if(!plain(siteInfo)||!sameId(siteInfo.detailId,target.detailId)||regionCode(siteInfo.site)!==site||
      (source.editModel!==undefined&&source.editModel!=='site')||
      !Array.isArray(claims)||claims.length!==1||!sameId(claims[0],target.shopId)||
      matching.length!==1||regionCode(siteShop.site)!==site){
      throw incompleteSource('妙手站点资料未能匹配当前商品及店铺，请重新读取商品后再保存。');
    }

    if(needsDelivery){
      if(siteShop.deliveryOptionSetType!=='default'||!Array.isArray(siteShop.deliveryOptionIds)||siteShop.deliveryOptionIds.length){
        throw incompleteSource('无法保留该商品的原配送设置，请在妙手核对后保存。');
      }
      next.deliveryOptionSetType=siteShop.deliveryOptionSetType;
    }

    if(needsEmptyChartCheck){
      // The shop response can expose an image type without an image. Leave the
      // optional fields out only when the exact site record confirms no chart.
      if(!own(siteInfo,'sizeChart')||!optionalEmpty(siteInfo.sizeChart)||!emptyChartType(siteInfo.sizeChartType)||
        !own(siteShop,'sizeChartTemplateId')||!optionalEmpty(siteShop.sizeChartTemplateId)||
        !optionalEmpty(siteShop.sizeChart)||!emptyChartType(siteShop.sizeChartType)||
        !optionalEmpty(siteInfo.sizeChartTemplateId)||!optionalEmpty(next.sizeChartTemplateId)){
        throw incompleteSource('无法确认该商品没有尺码图或尺码表模板，请在妙手核对后保存。');
      }
      delete next.sizeChartType;
      delete next.sizeChart;
    }
  }

  function fieldReview(entry,info){
    if(entry.fieldPaths?.some(path=>path.length===1&&path[0]==='cid')&&info.cid!==undefined){
      try{info={...info,cid:miaoshouId(info.cid)};}catch{}
    }
    if(entry.fieldExpectations)return reviewMiaoshouFields(info,entry.fieldExpectations,new Date(now()).toISOString());
    if(!entry.fieldPaths?.length)return {state:'unavailable',reason:'legacy_expected_values_unavailable',fields:[]};
    // Legacy entries stored a serialization hash. Do not reinterpret that hash
    // using the new canonical scheme, or infer an API acknowledgement from it.
    const matched=hash(entry.fieldPaths.map(path=>({path,value:at(info,path)})))===entry.changeHash;
    return {state:matched?'matched':'different',scheme:'legacy-serialized-patch-v1',checkedAt:new Date(now()).toISOString(),fields:entry.fieldPaths.map(path=>({path,state:matched?'matched':'unconfirmed'}))};
  }
  async function verifyEntry(entry,target,scope,{offerRecovery=false}={}){
    let current;
    try{current=await read(target,scope);}catch(error){
      if(!entry.receipt)throw error;
      return {result:{...target,state:'succeeded',verified:false,confirmation:'api_receipt',receipt:entry.receipt,fieldReview:{state:'unavailable',reason:'readback_unavailable',fields:[]},fields:entry.fieldPaths?.map(path=>path.join('.'))||[]}};
    }
    const info=current.shopCollectItemInfo;
    const checked=fieldReview(entry,info);
    if(entry.receipt){
      let localReceiptWarning;
      try{await journal.transition(entry,'acknowledged',{fieldReview:checked});}catch{localReceiptWarning='本机字段核对记录未能保存；妙手已确认的保存回执仍然有效。';}
      return {result:{...target,state:'succeeded',verified:checked.state==='matched',confirmation:'api_receipt',receipt:entry.receipt,fieldReview:checked,fields:entry.fieldPaths?.map(path=>path.join('.'))||[],title:info.title,thumbnail:info.imgUrls[0]||'',...(localReceiptWarning?{localReceiptWarning}:{})}};
    }
    if(checked.state!=='matched'){
      return offerRecovery&&checked.state==='different'&&releasable(entry)
        ?{recovery:{operationId:entry.operationId,revision:miaoshouEditRevision(current)}}:{};
    }
    if(unresolved(entry))await journal.transition(entry,'verified',{fieldReview:checked});
    await scopeGuard(scope);
    return {result:{...target,state:'succeeded',verified:true,confirmation:'readback',revision:miaoshouEditRevision(current),fieldReview:checked,fields:entry.fieldPaths?.map(path=>path.join('.'))||[],title:info.title,thumbnail:info.imgUrls[0]||''}};
  }
  return {
    async confirmedSyncTimes(){
      const scope=await scopeValue(),times=await journal.confirmedSyncTimes(scope);
      await scopeGuard(scope);
      for(const value of unpersistedReceipts.values()){
        const receipt=value.result?.receipt;
        if(receipt?.accountScope!==scope)continue;
        const time=Date.parse(receipt.acknowledgedAt),key=receipt.detailId+':'+receipt.shopId;
        if(Number.isFinite(time)&&time>(times.get(key)??-Infinity))times.set(key,time);
      }
      return times;
    },
    async previewCategory({detailId,shopIds,categoryId},{expectedScope,guard=async()=>{},metadataByShop}={}){
      validateMiaoshouEditInput({action:'category',changes:{categoryId}});
      const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)},scope=await scopeValue();
      if(scope!==expectedScope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新选择商品。');
      if(await journal.pending(scope,target))throw fail('MIAOSHOU_EDIT_REVIEW','原商品有保存结果待核对，请先查询结果。');
      await guard();const source=await read(target,scope);await guard();
      await checkCategory(source.shopCollectItemInfo,target,categoryId,guard,metadataByShop);
      let previousCategoryId='';
      try{previousCategoryId=miaoshouId(source.shopCollectItemInfo.cid);}catch{}
      return {sourceRevision:miaoshouEditRevision(source),previousCategoryId};
    },
    async previewWarehouse({detailId,shopIds,warehouseId},{expectedScope,guard=async()=>{}}={}){
      validateMiaoshouEditInput({action:'warehouse',changes:{warehouseId}});
      const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)},scope=await scopeValue();
      if(scope!==expectedScope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新选择商品。');
      if(await journal.pending(scope,target))throw fail('MIAOSHOU_EDIT_REVIEW','原商品有保存结果待核对，请先查询结果。');
      await guard();const source=await read(target,scope);await guard();
      const {skuCount}=moveWarehouseInventory(source.shopCollectItemInfo,target.shopId,warehouseId);
      return {sourceRevision:miaoshouEditRevision(source),skuCount};
    },
    async apply(input,{expectedSourceHash,expectedScope,directCategory=false}={}){
      guard();if(!plain(input)||Object.keys(input).some(key=>!['detailId','shopIds','action','changes'].includes(key)))throw fail('MIAOSHOU_EDIT_INVALID','商品修改参数无效。',400);
      if(expectedSourceHash!==undefined&&(!validScope(expectedSourceHash)||!['edit','category','package','warehouse'].includes(input.action)))throw fail('MIAOSHOU_EDIT_INVALID','商品原件版本无效，请重新读取。',400);
      if(input.action==='category'&&expectedSourceHash===undefined&&!(directCategory&&validScope(expectedScope)))throw fail('MIAOSHOU_EDIT_INVALID','请先核对批量类目与商品原件。',400);
      if(input.action==='warehouse'&&expectedSourceHash===undefined)throw fail('MIAOSHOU_EDIT_INVALID','请先预览商品换仓。',400);
      const target={detailId:miaoshouId(input.detailId),shopId:requireSingleShop(input.shopIds)},basePatch=validateMiaoshouEditInput(input),scope=await scopeValue(),lockKey=scope+':'+target.detailId;
      if(expectedScope!==undefined&&expectedScope!==scope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新提交商品修改。');
      if(locks.has(lockKey))throw fail('MIAOSHOU_EDIT_BUSY','该商品正在修改，请等待本次操作完成。',409);locks.add(lockKey);
      let entry,writeAttempted=false;
      try{
        const remembered=unpersistedReceipts.get(lockKey+':'+target.shopId);
        if(remembered){
          if(remembered.requestHash===hash([input.action,input.changes??{}]))return structuredClone(remembered.result);
          throw Object.assign(fail('MIAOSHOU_EDIT_JOURNAL','妙手已确认上笔保存，但本机回执未能保存，请保留回执并检查本机记录后再修改。',503),{state:'needs_review',data:{operationId:remembered.result.receipt.operationId,receipt:remembered.result.receipt}});
        }
        const current=await read(target,scope),patch=structuredClone(basePatch),info=current.shopCollectItemInfo;
        const prior=await journal.pending(scope,target);await scopeGuard(scope);
        if(prior?.fieldPaths){
          const sameRequest=prior.requestHash===hash([input.action,input.changes??{}]);
          const checked=fieldReview(prior,info);
          if(!sameRequest||checked.state!=='matched')throw review(prior);
          await journal.transition(prior,'verified',{fieldReview:checked});await scopeGuard(scope);
          return {...target,state:'unchanged',fields:prior.fieldPaths.map(path=>path.join('.')),verified:true,confirmation:'readback',revision:miaoshouEditRevision(current),fieldReview:checked,title:info.title,thumbnail:info.imgUrls[0]||''};
        }
        if(expectedSourceHash!==undefined&&miaoshouEditRevision(current)!==expectedSourceHash)throw fail('MIAOSHOU_EDIT_STALE','商品已在别处修改，请重新读取并核对后保存。',409);
        if(input.action==='category'){
          await checkCategory(info,target,input.changes.categoryId,()=>scopeGuard(scope));
          if(sameId(info.cid,input.changes.categoryId))return {...target,state:'unchanged',fields:['cid'],verified:true,confirmation:'readback',revision:miaoshouEditRevision(current)};
        }
        if(input.action==='warehouse'){
          const {warehouseId}=input.changes;
          const raw=await client.call('warehouses',{shopIds:[BigInt(target.shopId)]},{guard:()=>scopeGuard(scope)});
          await scopeGuard(scope);
          const warehouses=normalizeMiaoshouWarehouseShop(raw,{id:target.shopId});
          if(!warehouses?.some(row=>row.warehouseId===warehouseId&&usableMiaoshouWarehouse(row)))
            throw fail('MIAOSHOU_EDIT_WAREHOUSE','所选仓库已不可用或不属于当前店铺，请重新预览。');
          const {skuMap}=moveWarehouseInventory(info,target.shopId,warehouseId);
          patch.push({path:['skuMap'],value:skuMap});
        }
        if(input.action==='package'&&info.skuMap!==undefined&&info.skuMap!==null){
          if(!plain(info.skuMap)||Object.keys(info.skuMap).length>20000)throw fail('MIAOSHOU_EDIT_INVALID','商品 SKU 资料格式无效，未修改任何数据。',400);
          const weight=basePatch.find(item=>item.path[0]==='weight').value;
          for(const key of Object.keys(info.skuMap).sort()){if(!plain(info.skuMap[key]))throw fail('MIAOSHOU_EDIT_INVALID','商品 SKU 资料格式无效，未修改任何数据。',400);patch.push({path:['skuMap',key,'weight'],value:weight});}
        }
        if(input.action==='size-chart'||input.action==='edit'&&(own(input.changes,'codEnabled')||own(input.changes,'sizeChartUrl'))){
          const cid=miaoshouId(info.cid);
          const metadata=await client.call('categoryMetadata',{cid:BigInt(cid),shopIds:[BigInt(target.shopId)]},{guard:()=>scopeGuard(scope)});await scopeGuard(scope);
          const config=metadata?.categoryMetadata?.categoryConfig;
          const supported=value=>value===true||value===1||value==='1';
          const disabled=value=>value===false||value===0||value==='0';
          const allows=keys=>{const flags=keys.map(key=>config?.[key]).filter(v=>v!==undefined&&v!==null);return flags.some(supported)&&!flags.some(disabled);};
          if(own(input.changes,'codEnabled')&&!allows(['codIsSupported','isSuppCod']))throw fail('MIAOSHOU_EDIT_INVALID','当前商品类目不支持 COD 或未能确认支持状态。',400);
          if(own(input.changes,'sizeChartUrl')&&!allows(['sizeChartIsSupported','isSuppSizechart']))throw fail('MIAOSHOU_EDIT_INVALID','当前商品类目不支持尺码图或未能确认支持状态。',400);
        }
        if(input.action==='edit'){
          const structured=Object.fromEntries(Object.entries(input.changes).filter(([k])=>STRUCTURED_EDIT_KEYS.includes(k)));
          if(Object.keys(structured).length){
            const context=await loadMiaoshouEditContext({info,target,client,guard:()=>scopeGuard(scope),needs:structuredContextNeeds(structured)});
            if(structured.descriptionImages){
              if(!resolveDescriptionImages)throw fail('MIAOSHOU_EDIT_INVALID','描述图处理服务不可用。',400);
              context.descriptionNotes=await resolveDescriptionImages(structured.descriptionImages,target,info);await scopeGuard(scope);
            }
            if(structured.brandFromSample){
              const sampleTarget={detailId:miaoshouId(structured.brandFromSample.detailId),shopId:target.shopId};
              const sample=await read(sampleTarget,scope);context.brandSampleId=sampleTarget.detailId;context.brandId=sample.shopCollectItemInfo.brandId;
            }
            for(const [key,value] of Object.entries(compileStructuredPatch(info,structured,context)))patch.push({path:[key],value});
          }
        }
        // SKU replacement changes only specifications. Also verify that the
        // response preserved the original gallery and description, unless an
        // explicit edit in this same request already supplies the expected value.
        const preserved=input.action==='category'
          ?['title','notes','imgUrls','skuMap','skuPropertyList','productAttributes','productCertifications','brandId']
          :input.changes?.replaceSkuStructure?['imgUrls','notes']:[];
        const verification=[...patch,...preserved.filter(key=>!patch.some(item=>item.path[0]===key)).map(key=>({path:[key],value:info[key]}))];
        const requestHash=hash([input.action,input.changes??{}]),changeHash=hash(verification),pending=await journal.pending(scope,target);await scopeGuard(scope);
        const matches=value=>verification.every(item=>same(at(value,item.path),item.value));
        if(pending){
          const actualHash=hash(verification.map(p=>({path:p.path,value:at(info,p.path)})));
          if(pending.requestHash?(pending.requestHash!==requestHash||pending.changeHash!==actualHash):(pending.changeHash!==changeHash||!matches(info)))throw review(pending);
          await journal.transition(pending,'verified');await scopeGuard(scope);
          return {...target,state:'unchanged',fields:patch.map(p=>p.path.join('.')),verified:true,confirmation:'readback',revision:miaoshouEditRevision(current),title:info.title,thumbnail:info.imgUrls[0]||''};
        }
        if(matches(info))return {...target,state:'unchanged',fields:patch.map(p=>p.path.join('.')),verified:true,confirmation:'readback',revision:miaoshouEditRevision(current),title:info.title,thumbnail:info.imgUrls[0]||''};
        const next=structuredClone(info);
        for(const item of patch){let holder=next;for(const key of item.path.slice(0,-1)){if(!own(holder,key)||!plain(holder[key]))throw fail('MIAOSHOU_EDIT_INVALID','商品资料结构已变化，请刷新后重新确认。',400);holder=holder[key];}Object.defineProperty(holder,item.path.at(-1),{value:item.value,writable:true,enumerable:true,configurable:true});}
        await completeSavePayload(next,current,target,scope,{changesSizeChart:input.action==='size-chart'||own(input.changes,'sizeChartUrl')});
        const fieldExpectations=createMiaoshouFieldExpectations(info,verification);
        if(fieldExpectations.fields.length>200000)throw fail('MIAOSHOU_EDIT_INVALID','本次修改涉及字段过多，请分批核对。',400);
        const timestamp=new Date(now()).toISOString();entry=await journal.reserve({operationId:randomUUID(),key:hash([scope,target.detailId,target.shopId,input.action,changeHash]),scope,...target,action:revisionActions.has(input.action)?'edit':input.action,requestHash,fieldPaths:verification.map(p=>p.path),fieldExpectations,changeHash,sourceHash:hash(current),state:'submitting',createdAt:timestamp,updatedAt:timestamp});
        await scopeGuard(scope);guard();writeAttempted=true;
        const saved=await client.call('save',{ossMd5:current.ossMd5,shopCollectItemInfo:next,detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)},{guard:()=>scopeGuard(scope)});
        const receipt=createMiaoshouSaveReceipt(saved,{...target,operationId:entry.operationId,scope,acknowledgedAt:new Date(now()).toISOString()}),checked={state:'not_checked',fields:[]};
        const result={...target,state:'succeeded',fields:patch.map(p=>p.path.join('.')),verified:false,confirmation:'api_receipt',receipt,fieldReview:checked,title:next.title,thumbnail:next.imgUrls[0]||''};
        // The official acknowledgement is conclusive. Local persistence failure
        // cannot change it to transport-unknown, trigger replay, or claim durability.
        try{await journal.transition(entry,'acknowledged',{receipt,fieldReview:checked});}
        catch{result.localReceiptWarning='妙手已确认保存，但本机回执未能保存；请保留本次回执并检查本机记录。';unpersistedReceipts.set(lockKey+':'+target.shopId,{requestHash,result:structuredClone(result)});}
        if(revisionActions.has(input.action)){
          let reviewed;
          try{const refreshed=await read(target,scope);reviewed=fieldReview(entry,refreshed.shopCollectItemInfo);}catch{}
          if(reviewed){
            result.fieldReview=reviewed;
            if(!result.localReceiptWarning)try{await journal.transition(entry,'acknowledged',{fieldReview:reviewed});}
            catch{result.localReceiptWarning='本机字段核对记录未能保存；妙手已确认的保存回执仍然有效。';}
          }
          result.verified=reviewed?.state==='matched';
          if(!result.verified)result.state='needs_review';
        }
        return result;
      }catch(error){
        if(entry){const rejected=!writeAttempted||error.notDispatched===true||error.definitive===true;try{entry=await journal.transition(entry,rejected?'rejected':'uncertain');}catch{throw review(entry);}if(!rejected)throw review(entry);if(writeAttempted&&!error.notDispatched)throw Object.assign(fail('MIAOSHOU_EDIT_REJECTED',error.remoteMessage?'妙手拒绝本次商品修改：'+error.remoteMessage:'妙手拒绝本次商品修改，请检查资料后重新确认。'),{definitive:true,remoteCode:error.remoteCode,remoteMessage:error.remoteMessage,httpStatus:error.httpStatus});}
        if(error.code)throw error;
        throw fail('MIAOSHOU_EDIT_READ','读取妙手商品资料未完成，请刷新后重新确认。',503);
      }finally{locks.delete(lockKey);}
    },
    async hasPendingResult({detailId,shopIds},{expectedScope}){
      const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)},scope=await scopeValue();
      if(expectedScope!==scope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新核对商品修改。');
      const pending=await journal.pending(scope,target);
      await scopeGuard(scope);
      return Boolean(pending);
    },
    async verifyResult({detailId,shopIds,operationId,changes},{expectedScope}){
      const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)},scope=await scopeValue();
      if(expectedScope!==scope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新核对商品修改。');
      const lockKey=scope+':'+target.detailId;
      if(locks.has(lockKey))return;
      locks.add(lockKey);
      try{
        const entry=await journal.find(scope,target,operationId);
        if(!entry||entry.action!=='edit'||entry.requestHash!==hash(['edit',changes])||
          !(unresolved(entry)||entry.state==='verified'||entry.state==='acknowledged'))return;
        return (await verifyEntry(entry,target,scope)).result;
      }finally{locks.delete(lockKey);}
    },
    async verifyPendingResult({detailId,shopIds},{expectedScope}){
      const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)},scope=await scopeValue();
      if(expectedScope!==scope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新核对商品修改。');
      const lockKey=scope+':'+target.detailId;
      if(locks.has(lockKey))return {state:'needs_review'};
      locks.add(lockKey);
      try{
        const entry=await journal.pending(scope,target);
        await scopeGuard(scope);
        if(!entry)return {state:'none'};
        const offerRecovery=!unpersistedReceipts.has(lockKey+':'+target.shopId);
        const {result,recovery}=await verifyEntry(entry,target,scope,{offerRecovery});
        return result?{state:'succeeded',result}:{state:'needs_review',...(recovery?{recovery}:{})};
      }finally{locks.delete(lockKey);}
    },
    async releasePendingResult({detailId,shopIds,operationId,revision},{expectedScope,verifyTarget}){
      const target={detailId:miaoshouId(detailId),shopId:requireSingleShop(shopIds)},scope=await scopeValue();
      if(expectedScope!==scope)throw fail('CONTEXT_CHANGED','妙手账号已变化，请重新查询保存结果。');
      if(typeof operationId!=='string'||!operationId||!validScope(revision))throw reviewChanged();
      const lockKey=scope+':'+target.detailId;
      if(locks.has(lockKey))throw fail('MIAOSHOU_EDIT_BUSY','该商品正在保存或核对，请稍后再试。');
      locks.add(lockKey);
      const checkTarget=async()=>{await scopeGuard(scope);verifyTarget();};
      try{
        await checkTarget();
        const entry=await journal.pending(scope,target);
        if(!releasable(entry)||entry.operationId!==operationId||unpersistedReceipts.has(lockKey+':'+target.shopId))throw reviewChanged();
        const current=await read(target,scope);
        await checkTarget();
        if(miaoshouEditRevision(current)!==revision)throw reviewChanged();
        const checked=fieldReview(entry,current.shopCollectItemInfo);
        if(checked.state!=='different')throw reviewChanged();
        const resolution={kind:'manually_released',at:new Date(now()).toISOString(),revision};
        await journal.release(scope,target,entry,resolution,checked,checkTarget);
        return {state:'released',message:'已结束旧保存核对。请重新读取商品，再确认并保存新的修改。'};
      }finally{locks.delete(lockKey);}
    },
    async close(){closed=true;await journal.close();}
  };
}
