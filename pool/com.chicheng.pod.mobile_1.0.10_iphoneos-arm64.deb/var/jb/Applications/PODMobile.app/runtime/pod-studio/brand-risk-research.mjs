import {createHash,randomUUID} from 'node:crypto';
import {lstat,mkdir,open,rename,unlink} from 'node:fs/promises';
import {dirname,isAbsolute,join,resolve} from 'node:path';
import {BRAND_RESEARCH_VERSION,BRAND_SOURCE_KEYS,brandResearchSelection,normalizeBrandResearch} from './dist/brand-risk-research-contract.js';

const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const hex=value=>typeof value==='string'&&/^[a-f0-9]{64}$/u.test(value);
const id=value=>typeof value==='string'&&value.trim()&&value.length<=160&&!/[\u0000-\u001f\u007f]/u.test(value);
const same=(a,b)=>a?.accountScope===b?.accountScope&&a?.contextId===b?.contextId;
const subjectKeys=subjects=>subjects.map(s=>s.normalize('NFKC').replace(/\s+/gu,' ').trim().toLowerCase());
const copy=value=>structuredClone(value);
const MAX_BYTES=2*1024*1024;
function context(input){if(!hex(input?.accountScope)||!id(input?.contextId))throw new Error('品牌资料检查的账号连接已失效。');return {accountScope:input.accountScope,contextId:input.contextId};}
function unavailable(subjects,now,reason='provider_unavailable',inputTruncated=false){
 const at=new Date(now).toISOString();return normalizeBrandResearch({version:1,provider:'brand-research',checkedAt:at,subjects:subjects.map(subject=>({subject,identity:{candidates:[]},sources:Object.fromEntries(BRAND_SOURCE_KEYS.map(key=>[key,{status:'unavailable',checkedAt:at,complete:false,hasMore:false,reason,records:[]}]))}))},{subjects,now,inputTruncated});
}
function boundResult(value,subjects,now,inputTruncated){
 const result=normalizeBrandResearch(value,{subjects,now,inputTruncated});
 if(Buffer.byteLength(JSON.stringify(result))<=MAX_BYTES)return result;
 // Retain a small, explicit partial sample rather than hiding a cap as a full search.
 for(const subject of result.subjects)for(const key of BRAND_SOURCE_KEYS){const source=subject.sources[key];if(source.records.length>3){source.records=source.records.slice(0,3);source.status='partial';source.complete=false;source.hasMore=true;source.reason='result_limit';}}
 result.status='partial';result.complete=false;
 if(Buffer.byteLength(JSON.stringify(result))>MAX_BYTES)throw Object.assign(new Error('品牌资料超过安全大小限制。'),{code:'BRAND_RESULT_LIMIT'});
 return normalizeBrandResearch(result,{subjects,now,inputTruncated});
}
async function guardedDirectory(path,{create=false}={}){
 const target=resolve(path),ancestors=[];for(let current=target;;current=dirname(current)){ancestors.push(current);if(dirname(current)===current)break;}
 for(const current of ancestors.reverse())try{const stat=await lstat(current);if(!stat.isDirectory()||stat.isSymbolicLink())throw new Error('unsafe path');}catch(error){if(error?.code!=='ENOENT')throw error;}
 if(create)await mkdir(target,{recursive:true});
 for(let current=target;;current=dirname(current)){try{const stat=await lstat(current);if(!stat.isDirectory()||stat.isSymbolicLink())throw new Error('unsafe path');}catch(error){if(error?.code!=='ENOENT')throw error;else if(create)throw error;}if(dirname(current)===current)break;}
 return target;
}

/** Independent public-evidence queue. It never calls the visual model or writes products. */
export function createBrandRiskResearch({root,runResearch,now=Date.now,concurrency=2,timeoutMs=90000}={}){
 if(typeof runResearch!=='function'||typeof now!=='function'||root!==undefined&&(typeof root!=='string'||!isAbsolute(root)||root.includes('\0')))throw new TypeError('品牌资料检索连接无效。');
 const storage=root?resolve(root):null,limit=Number.isSafeInteger(concurrency)?Math.max(1,Math.min(2,concurrency)):2,budget=Number.isFinite(timeoutMs)?Math.max(10,Math.min(180000,timeoutMs)):90000;
 const jobs=new Map(),queue=[],matching=[],active=new Set(),matchingActive=new Set(),io=new Set(),writes=new Map();let selected=null,generation=0,closed=false,pumping=false,matchingPump=false;
 const pathFor=job=>join(storage,'brand-risk-research',job.accountScope,job.binding+'.json');
 const live=job=>!closed&&job.generation===generation&&same(job,selected)&&jobs.get(job.id)===job;
 const track=work=>{const promise=Promise.resolve(work);io.add(promise);promise.finally(()=>io.delete(promise)).catch(()=>{});return promise;};
 function activate(input){if(closed)throw new Error('品牌资料服务已关闭。');const next=context(input);if(same(next,selected))return next;generation++;for(const job of active)job.controller.abort();for(const job of matchingActive)job.controller.abort();queue.length=0;matching.length=0;jobs.clear();selected=next;return next;}
 const binding=(identifier,inputHash,subjects,truncated)=>hash({version:BRAND_RESEARCH_VERSION,id:identifier,inputHash,subjects:subjectKeys(subjects),subjectLimit:truncated});
 async function load(job){
  if(!storage)return null;
  try{
   const path=pathFor(job);await guardedDirectory(dirname(path));let stat;
   try{stat=await lstat(path);}catch(error){if(error?.code==='ENOENT')return null;throw error;}
   if(!stat.isFile()||stat.isSymbolicLink()||stat.size>MAX_BYTES+32768)throw new Error('unsafe cache');
   let file;try{file=await open(path,'r');const actual=await file.stat();if(actual.ino!==stat.ino||actual.dev!==stat.dev||!actual.isFile()||actual.size>MAX_BYTES+32768)throw new Error('unsafe cache');
    const text=await file.readFile({encoding:'utf8'});if(Buffer.byteLength(text)>MAX_BYTES+32768)throw new Error('unsafe cache');
    let data;try{data=JSON.parse(text);}catch{return null;}
    if(data?.version!==BRAND_RESEARCH_VERSION||data.accountScope!==job.accountScope||data.id!==job.id||data.inputHash!==job.inputHash||data.binding!==job.binding||!Array.isArray(data.subjects)||JSON.stringify(subjectKeys(data.subjects))!==JSON.stringify(subjectKeys(job.subjects)))return null;
    try{return boundResult(data.brandResearch,job.subjects,now(),job.inputTruncated);}catch{return null;}
   }finally{await file?.close();}
  }catch(error){throw Object.assign(new Error('本地品牌资料未能安全读取，请检查本地存储。'),{code:'BRAND_CACHE_ERROR'});}
 }
 async function persist(job){
  if(!storage||!live(job))return false;
  const path=pathFor(job),prior=writes.get(path)||Promise.resolve();
  const work=prior.catch(()=>{}).then(async()=>{
   if(!live(job))return false;let temporary,file;
   try{
    await guardedDirectory(dirname(path),{create:true});if(!live(job))return false;
    try{const stat=await lstat(path);if(!stat.isFile()||stat.isSymbolicLink())throw new Error('unsafe target');}catch(error){if(error?.code!=='ENOENT')throw error;}
    const data={version:BRAND_RESEARCH_VERSION,accountScope:job.accountScope,id:job.id,inputHash:job.inputHash,binding:job.binding,subjects:job.subjects,brandResearch:job.brandResearch};
    const text=JSON.stringify(data);if(Buffer.byteLength(text)>MAX_BYTES+32768)throw new Error('cache limit');
    temporary=path+'.'+randomUUID()+'.tmp';file=await open(temporary,'wx');await file.writeFile(text);await file.sync();await file.close();file=null;
    if(!live(job)){await unlink(temporary).catch(()=>{});return false;}
    await guardedDirectory(dirname(path));if(!live(job)){await unlink(temporary).catch(()=>{});return false;}
    await rename(temporary,path);return true;
   }catch{await file?.close().catch(()=>{});if(temporary)await unlink(temporary).catch(()=>{});throw Object.assign(new Error('本次品牌资料尚未保存到本机。'),{code:'BRAND_CACHE_ERROR'});}
  });writes.set(path,work);work.finally(()=>{if(writes.get(path)===work)writes.delete(path);}).catch(()=>{});return track(work);
 }
 function publicJob(job){return {id:job.id,inputHash:job.inputHash,brandResearchState:job.state,...(job.brandResearch?{brandResearch:copy(job.brandResearch)}:{}),...(job.cached?{cached:true}:{}),...(['pending','running','matching'].includes(job.state)&&job.brandResearch?{refreshing:true}:{}),...(job.error?{error:job.error}:{})};}
 function counters(){return {state:closed?'closed':queue.length||active.size||matching.length||matchingActive.size?'reviewing':'idle',queued:queue.length,running:active.size,matching:matching.length+matchingActive.size,total:jobs.size,maxConcurrent:limit};}
 function complete(job,result,cached=false){job.brandResearch=result;job.state=result.status==='not_required'?'not_required':'ready';job.cached=cached;job.error='';}
 function schedule(job){if(!live(job))return;job.state='pending';queue.push(job);queueMicrotask(pump);}
 async function admit(job){
  try{const result=await track(load(job));if(!live(job))return;if(result){complete(job,result,true);job.persisted=true;return;}schedule(job);}
  catch{if(live(job)){job.state='failed';job.error='本地品牌资料未能读取，未重复提交外部检索。';job.brandResearch=job.previous||unavailable(job.subjects,now(),'cache_unavailable',job.inputTruncated);job.cached=!!job.previousPersisted;}}
 }
 function pumpMatching(){
  if(matchingPump||closed)return;matchingPump=true;
  try{while(matching.length&&matchingActive.size<8){const job=matching.shift();if(!live(job))continue;matchingActive.add(job);job.admission=admit(job).finally(()=>{matchingActive.delete(job);if(!closed)queueMicrotask(pumpMatching);});job.admission.catch(()=>{});}}
  finally{matchingPump=false;}
 }
 function bounded(job){
  const signal=job.controller.signal;let timer,abort;
  const work=Promise.resolve().then(()=>{signal.throwIfAborted();return runResearch([...job.subjects],{accountScope:job.accountScope,signal,force:job.force});});
  const result=new Promise((resolve,reject)=>{
   let settled=false;const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);signal.removeEventListener('abort',abort);error?reject(error):resolve(value);};
   abort=()=>finish(Object.assign(new Error('品牌资料检查已取消。'),{code:'BRAND_CANCELLED'}));signal.addEventListener('abort',abort,{once:true});
   timer=setTimeout(()=>{finish(Object.assign(new Error('品牌资料检索超时。'),{code:'BRAND_TIMEOUT'}));job.controller.abort();},budget);
   work.then(value=>finish(null,value),error=>finish(error));if(signal.aborted)abort();
  });
  return {result,drained:work.then(()=>{},()=>{})};
 }
 async function execute(job){
  let operation;
  try{
   if(!live(job))return;job.state='running';operation=bounded(job);
   const raw=await operation.result;if(!live(job)||job.controller.signal.aborted)return;
   const result=boundResult(raw,job.subjects,now(),job.inputTruncated);
   if(result.status==='unavailable'&&job.previous){job.brandResearch=job.previous;job.state='failed';job.cached=job.previousPersisted;job.error='本次品牌资料更新未完成，已保留上次候选和原检查时间。';return;}
   complete(job,result);try{job.persisted=await persist(job);}catch{if(live(job)){job.state='failed';job.error='本次品牌资料尚未保存到本机，当前候选不能视为已完成核验。';}}
  }catch(error){if(live(job)){
   const reason=error?.code==='BRAND_TIMEOUT'?'timeout':error?.code==='BRAND_RESULT_LIMIT'?'result_limit':'provider_error';
   job.brandResearch=job.previous||unavailable(job.subjects,now(),reason,job.inputTruncated);job.state='failed';job.cached=!!job.previousPersisted;
   job.error=job.previous?'本次品牌资料更新未完成，已保留上次候选和原检查时间。':reason==='timeout'?'品牌资料检索超时，可稍后仅重试品牌资料。':'品牌资料检索未完成，不能视为已通过检查。';
   if(!job.previous)try{job.persisted=await persist(job);}catch{job.error='品牌资料检索未完成，且结果尚未保存到本机。';}
  }}finally{if(operation)await operation.drained;}
 }
 function pump(){
  if(pumping||closed)return;pumping=true;
  try{while(queue.length&&active.size<limit){const index=queue.findIndex(j=>![...active].some(a=>a.id===j.id));if(index<0)break;const [job]=queue.splice(index,1);if(!live(job))continue;active.add(job);job.work=execute(job).finally(()=>{active.delete(job);if(!closed)queueMicrotask(pump);});job.work.catch(()=>{});}}
  finally{pumping=false;}
 }
 function enqueue(input,{force=false}={}){
  if(closed)throw new Error('品牌资料服务已关闭。');const next=context(input);
  if(!Array.isArray(input.reviews)||input.reviews.length>50000)throw new Error('品牌资料商品范围无效。');
  const rows=input.reviews.map(review=>{
   const findings=review?.result?.findings??review?.findings;
   if(!review||!['string','number'].includes(typeof review.id)||!id(String(review.id))||!hex(review.inputHash)||!['ready','partial'].includes(review.status)||!Array.isArray(findings)||findings.length>16||findings.some(f=>!f||typeof f!=='object'||!['ip','policy','content','information'].includes(f.type)||typeof f.subject!=='string'))throw new Error('品牌资料需要已完成的对应商品检查。');
   return {id:String(review.id),inputHash:review.inputHash,...brandResearchSelection(review)};
  });if(new Set(rows.map(r=>r.id)).size!==rows.length||(same(next,selected)?jobs.size:0)+rows.filter(r=>!same(next,selected)||!jobs.has(r.id)).length>50000)throw new Error('品牌资料商品编号重复或超过范围。');activate(next);let accepted=0;
  for(const row of rows){
   const key=binding(row.id,row.inputHash,row.subjects,row.hasMore),old=jobs.get(row.id);if(old?.binding===key&&!force)continue;
   old?.controller.abort();for(let n=queue.length-1;n>=0;n--)if(queue[n].id===row.id)queue.splice(n,1);
   const job={...next,id:row.id,inputHash:row.inputHash,subjects:row.subjects,inputTruncated:row.hasMore,binding:key,generation,state:'pending',force:force===true,controller:new AbortController(),...(old?.binding===key&&old.brandResearch?{previous:copy(old.brandResearch),previousPersisted:old.persisted===true||old.cached===true,brandResearch:copy(old.brandResearch)}:{})};
   jobs.set(row.id,job);accepted++;
   if(!row.subjects.length){complete(job,normalizeBrandResearch({version:1,checkedAt:new Date(now()).toISOString(),subjects:[]},{subjects:[],now:now()}));continue;}
   if(storage&&!force){job.state='matching';matching.push(job);}else schedule(job);
  }
  queueMicrotask(pumpMatching);queueMicrotask(pump);return {...counters(),accepted};
 }
 async function snapshot(input){
  const next=context(input);if(closed)return {...counters(),results:[]};if(!selected)selected=next;
  if(!same(selected,next))return {state:'unavailable',queued:0,running:0,matching:0,total:0,maxConcurrent:limit,results:[]};
  const ids=input.ids===undefined?[...jobs.keys()].slice(0,500):input.ids;
  if(!Array.isArray(ids)||ids.length>500||ids.some(value=>!['string','number'].includes(typeof value)||!id(String(value))))throw new Error('品牌资料读取范围无效。');
  return {...counters(),results:[...new Set(ids.map(String))].map(value=>jobs.has(value)?publicJob(jobs.get(value)):{id:value,brandResearchState:'pending'})};
 }
 function reset(){generation++;for(const job of active)job.controller.abort();for(const job of matchingActive)job.controller.abort();queue.length=0;matching.length=0;jobs.clear();selected=null;}
 return {enqueue,snapshot,retry:input=>enqueue(input,{force:true}),activate,reset,async close(){if(closed)return;closed=true;reset();await Promise.allSettled([...io]);}};
}
