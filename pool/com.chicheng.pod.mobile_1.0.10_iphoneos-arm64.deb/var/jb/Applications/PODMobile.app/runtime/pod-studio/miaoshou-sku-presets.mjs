import {open,readFile,mkdir,rename,unlink} from 'node:fs/promises';
import {resolve,isAbsolute} from 'node:path';
import {randomUUID} from 'node:crypto';
import {validateSkuPreset} from './dist/miaoshou-sku-preset-schema.js';

const failure=(message,code='MIAOSHOU_SKU_PRESET_INVALID',status=400)=>Object.assign(new Error(message),{code,status});
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const id=value=>typeof value==='string'&&/^[a-f\d]{8}-[a-f\d]{4}-4[a-f\d]{3}-[89ab][a-f\d]{3}-[a-f\d]{12}$/u.test(value);
const normalizedName=value=>value.normalize('NFKC').trim().toLowerCase();
const empty=()=>({version:1,revision:0,items:[]});
const clone=value=>structuredClone(value);
const invalidStore=()=>failure('SKU 模板库未能读取，请保留原文件并核对后重试。','MIAOSHOU_SKU_PRESET_STORAGE',503);

/** Account-scoped host storage shared by all products and LAN clients. */
export function createMiaoshouSkuPresets({root,limit=200,now=Date.now}={}){
  if(root!==undefined&&(typeof root!=='string'||!isAbsolute(root)))throw new TypeError('SKU 模板库须使用主机绝对目录。');
  if(!Number.isSafeInteger(limit)||limit<1||limit>1000)throw new TypeError('SKU 模板数量上限无效。');
  const memory=new Map(),queues=new Map();let closed=false;
  const scope=input=>{if(closed)throw failure('SKU 模板库正在关闭。','MIAOSHOU_SKU_PRESET_CLOSED',503);if(!plain(input)||typeof input.accountScope!=='string'||!/^[a-f\d]{64}$/u.test(input.accountScope))throw failure('SKU 模板账号连接无效。');return input.accountScope;};
  const pathFor=scope=>root?resolve(root,'miaoshou-sku-presets',scope+'.json'):null;
  function checked(data){
    if(!plain(data)||Object.keys(data).some(key=>!['version','revision','items'].includes(key))||data.version!==1||!Number.isSafeInteger(data.revision)||data.revision<0||!Array.isArray(data.items)||data.items.length>limit)throw invalidStore();
    const names=new Set(),ids=new Set(),items=[];
    for(const item of data.items){
      if(!plain(item)||Object.keys(item).some(key=>!['id','name','settings','scope','createdAt','updatedAt'].includes(key))||!id(item.id)||ids.has(item.id)||!['createdAt','updatedAt'].every(key=>typeof item[key]==='string'&&Number.isFinite(Date.parse(item[key]))))throw invalidStore();
      let preset;try{preset=validateSkuPreset({name:item.name,settings:item.settings,...(Object.hasOwn(item,'scope')?{scope:item.scope}:{})});}catch{throw invalidStore();}
      const name=normalizedName(preset.name);if(names.has(name))throw invalidStore();names.add(name);ids.add(item.id);items.push({id:item.id,...preset,createdAt:item.createdAt,updatedAt:item.updatedAt});
    }
    return {version:1,revision:data.revision,items};
  }
  async function load(selected){
    if(!root)return clone(memory.get(selected)||empty());
    try{const raw=await readFile(pathFor(selected));if(raw.length>2*1024*1024)throw invalidStore();return checked(JSON.parse(raw.toString('utf8')));}
    catch(error){if(error.code==='ENOENT')return empty();if(error.code==='MIAOSHOU_SKU_PRESET_STORAGE')throw error;throw invalidStore();}
  }
  function validateInput(input,operation){
    const selected=scope(input),allowed=operation==='list'?['accountScope']:operation==='create'?['accountScope','revision','preset']:operation==='update'?['accountScope','revision','id','preset']:['accountScope','revision','id'];
    if(Object.keys(input).some(key=>!allowed.includes(key)))throw failure('SKU 模板参数无效。');
    if(operation!=='list'&&(!Number.isSafeInteger(input.revision)||input.revision<0))throw failure('请先读取最新的 SKU 模板库。');
    if(['update','remove'].includes(operation)&&!id(input.id))throw failure('SKU 模板编号无效。');
    return selected;
  }
  function mutate(input,operation){
    const selected=validateInput(input,operation),preset=operation==='remove'?null:validateSkuPreset(input.preset);
    input={...input};
    const work=(queues.get(selected)||Promise.resolve()).catch(()=>{}).then(async()=>{
      let lock,temp;const path=pathFor(selected);
      try{
        if(path){await mkdir(resolve(root,'miaoshou-sku-presets'),{recursive:true});try{lock=await open(path+'.lock','wx');}catch{throw failure('SKU 模板库正在修改或上次保存需要核对，请稍后重试。','MIAOSHOU_SKU_PRESET_BUSY',409);}}
        const data=await load(selected);
        if(data.revision!==input.revision)throw failure('SKU 模板已被其他窗口修改，请刷新模板库后重试。','MIAOSHOU_SKU_PRESET_CONFLICT',409);
        if(data.revision>=Number.MAX_SAFE_INTEGER)throw failure('SKU 模板版本已达上限，请联系管理员。');
        const index=data.items.findIndex(item=>item.id===input.id);
        if(operation!=='create'&&index<0)throw failure('SKU 模板已删除，请刷新后重新选择。','MIAOSHOU_SKU_PRESET_NOT_FOUND',409);
        if(preset&&data.items.some(item=>item.id!==input.id&&normalizedName(item.name)===normalizedName(preset.name)))throw failure('此 SKU 模板名称已存在，请使用其他名称。','MIAOSHOU_SKU_PRESET_DUPLICATE',409);
        let item;
        const at=new Date(now()).toISOString();
        if(operation==='create'){
          if(data.items.length>=limit)throw failure('SKU 模板已达 '+limit+' 个，请先删除不用的模板。');
          item={id:randomUUID(),...preset,createdAt:at,updatedAt:at};data.items.push(item);
        }else if(operation==='update'){item={...data.items[index],...preset,updatedAt:at};data.items[index]=item;}
        else data.items.splice(index,1);
        data.revision++;
        if(path){temp=path+'.'+randomUUID()+'.tmp';const file=await open(temp,'wx');try{await file.writeFile(JSON.stringify(data));await file.sync();}finally{await file.close();}await rename(temp,path);temp=null;}
        else memory.set(selected,clone(data));
        return {revision:data.revision,items:clone(data.items),...(item?{item:clone(item)}:{})};
      }catch(error){if(error?.code?.startsWith('MIAOSHOU_SKU_PRESET_'))throw error;throw failure('SKU 模板未能保存，原模板数据已保留，请稍后重试。','MIAOSHOU_SKU_PRESET_STORAGE',503);}
      finally{if(temp)await unlink(temp).catch(()=>{});if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}}
    });
    const settled=work.catch(()=>{});queues.set(selected,settled);void settled.finally(()=>{if(queues.get(selected)===settled)queues.delete(selected);});return work;
  }
  return {
    async list(input){const selected=validateInput(input,'list'),data=await load(selected);return {revision:data.revision,items:clone(data.items)};},
    async create(input){return mutate(input,'create');},async update(input){return mutate(input,'update');},async remove(input){return mutate(input,'remove');},
    async close(){closed=true;await Promise.allSettled([...queues.values()]);}
  };
}
