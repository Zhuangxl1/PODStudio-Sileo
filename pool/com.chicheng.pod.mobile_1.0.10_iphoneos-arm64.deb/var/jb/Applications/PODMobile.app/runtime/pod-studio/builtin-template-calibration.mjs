/** Recover only exact public seven-color photographs; never infer user calibration. */
import {createHash} from 'node:crypto';
import {builtinTemplates} from './dist/templates.js';
import {builtinMaskProvenance,builtinVisibilityMask} from './dist/builtin-masks.js';
import {defaultTemplateRegions} from './dist/template-library-schema.js';

const clone=value=>structuredClone(value);
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const sha=value=>createHash('sha256').update(value).digest('hex');
const fail=message=>{throw new Error('内置模板校准恢复已停止：'+message);};
const definitions=builtinTemplates.map(template=>{
  const provenance=builtinMaskProvenance.find(item=>item.id===template.id);
  if(!provenance||provenance.src!==template.src||provenance.sha256!==provenance.sourceSHA256
    ||provenance.pixelDifference!==0||provenance.maximumDifference!==0)fail('公开原图来源记录不一致。');
  return {builtinId:template.id,sourcePath:'Zeesloop/200gT恤_'+template.name+'_正面+背面.png',fileRevision:provenance.sha256,
    width:1080,height:1080,shop:'Zeesloop',style:'200gT恤',placementId:'front-back',template};
});
const match=record=>plain(record)&&definitions.find(item=>['sourcePath','fileRevision','width','height','shop','style','placementId'].every(key=>record[key]===item[key]));
const equalQuad=(first,second)=>Array.isArray(first)&&first.length===4&&first.every((point,index)=>plain(point)&&Object.keys(point).length===2&&point.x===second[index].x&&point.y===second[index].y);
const empty=value=>value===undefined||plain(value)&&Object.keys(value).length===0;

export function listBuiltinSeedTemplates(){return clone(definitions.map(({template,...metadata})=>metadata));}

/** IDs use exactly the existing host store's canonical path identity. */
export function builtinSeedHostId(sourcePath,{platform=process.platform}={}){
  if(!definitions.some(item=>item.sourcePath===sourcePath))fail('路径不属于已验证的七色公开模板。');
  return 'ht-'+sha('pod-host-template-v1\0'+(platform==='win32'?sourcePath.toLowerCase():sourcePath));
}

export function matchesBuiltinSeedTemplate(record){return Boolean(match(record));}

/** No group inheritance, prior edits, masks, changed originals or partial calibration qualify. */
export function assertPristineBuiltinSeedTemplate(record){
  const definition=match(record);if(!definition)fail('店铺、款式、位置、尺寸或原图 SHA 与公开模板不一致。');
  if(record.id!==builtinSeedHostId(record.sourcePath))fail('模板编号与精确路径不一致。');
  if(record.regionRevision!==0||record.inherited!==false||record.calibrationStatus!=='pending'||record.needsCalibration!==true)fail('模板已调整、已继承分组或原图需要复核。');
  if(!plain(record.confirmed)||['front','back','leftUpper'].some(position=>record.confirmed[position]!==false)
    ||Object.keys(record.confirmed).some(position=>!['front','back','leftUpper'].includes(position)))fail('模板已有区域确认记录。');
  const defaults=defaultTemplateRegions('front-back');
  if(!plain(record.regions)||Object.keys(record.regions).length!==3||Object.entries(defaults).some(([position,quad])=>!equalQuad(record.regions[position],quad)))fail('模板印花区域已修改。');
  if(!empty(record.printContours)||record.regionModes!==undefined&&(!plain(record.regionModes)
    ||Object.entries(record.regionModes).some(([position,mode])=>!['front','back','leftUpper'].includes(position)||mode!=='rectangle')))fail('模板轮廓或区域模式已修改。');
  if(record.hasPrintMasks!==false||!Array.isArray(record.maskPositions)||record.maskPositions.length||record.maskRevision!=='none'||!empty(record.printMasks))fail('模板已有独立遮挡设置。');
  if(record.blankVerified===true)fail('模板已有干净底图确认记录。');
  const {template,...metadata}=definition;return clone(metadata);
}

/** Typed masks go through the existing toHostCalibration encoder / host transaction. */
export function buildBuiltinSeedCalibration(record){
  assertPristineBuiltinSeedTemplate(record);const {template}=match(record);
  const printMasks=Object.fromEntries(['front','back'].map(position=>{
    const mask=builtinVisibilityMask(template,position);
    if(mask?.version!==1||mask.width!==768||mask.height!==768||!(mask.data instanceof Uint8Array)||mask.data.length!==768*768)fail('公开遮挡蒙版无法物化。');
    return [position,mask];
  }));
  return {expectedRevision:record.regionRevision,expectedFileRevision:record.fileRevision,syncGroup:false,
    regions:clone(template.regions),confirmed:{front:true,back:true,leftUpper:false},regionModes:{front:'rectangle',back:'rectangle'},printContours:{},printMasks};
}

/** Exact already-restored bytes may be skipped safely after an interrupted API repair. */
export function isRestoredBuiltinSeedTemplate(record){
  const definition=match(record);if(!definition||record.id!==builtinSeedHostId(record.sourcePath)||!Number.isSafeInteger(record.regionRevision)||record.regionRevision<=0
    ||record.inherited!==false||record.calibrationStatus!=='ready'||record.needsCalibration!==false||!plain(record.confirmed)
    ||record.confirmed.front!==true||record.confirmed.back!==true||record.confirmed.leftUpper!==false||Object.keys(record.confirmed).length!==3||!empty(record.printContours))return false;
  const expected={...defaultTemplateRegions('front-back'),...definition.template.regions};
  if(!plain(record.regions)||Object.keys(record.regions).length!==3||Object.entries(expected).some(([position,quad])=>!equalQuad(record.regions[position],quad)))return false;
  if(!plain(record.regionModes)||record.regionModes.front!=='rectangle'||record.regionModes.back!=='rectangle'
    ||Object.entries(record.regionModes).some(([position,mode])=>!['front','back','leftUpper'].includes(position)||mode!=='rectangle'))return false;
  if(record.hasPrintMasks!==true||!Array.isArray(record.maskPositions)||record.maskPositions.length!==2||!['front','back'].every(position=>record.maskPositions.includes(position))||!/^[a-f0-9]{64}$/.test(record.maskRevision||'')
    ||!plain(record.printMasks)||Object.keys(record.printMasks).length!==2)return false;
  for(const position of ['front','back']){
    const mask=record.printMasks[position];if(mask?.version!==1||mask.width!==768||mask.height!==768)return false;
    let bytes;
    if(mask.data instanceof Uint8Array)bytes=mask.data;
    else if(mask.encoding==='base64'&&typeof mask.data==='string'){
      bytes=Buffer.from(mask.data,'base64');if(bytes.toString('base64')!==mask.data)return false;
    }else return false;
    if(bytes.length!==768*768||sha(bytes)!==sha(builtinVisibilityMask(definition.template,position).data))return false;
  }
  return true;
}
