import http from 'node:http';
import {createHash,randomBytes,timingSafeEqual} from 'node:crypto';
import {open,readFile,stat} from 'node:fs/promises';
import {resolve,sep,extname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createReadStream} from 'node:fs';
import {MAX_REGION_PRESET_BYTES} from './dist/region-presets.js';
import {uploadProviderHint,IMAGE_UPLOAD_HTTP_HINTS,IMAGE_UPLOAD_STAGE_HINTS} from './dist/image-upload.js';
import {createDesignFolderStore,MAX_DESIGN_EXPORT_BYTES} from './design-folder-store.mjs';
import {validateHostedReference} from '../shared/mobile/recent-materials.mjs';

const PROJECT=fileURLToPath(new URL('./',import.meta.url)),TTL=12*60*60*1000;
const API_ROUTES=new Set(['GET /health','GET /api/v1/config/github','POST /api/v1/config/github','POST /api/v1/github/inspect','POST /api/v1/upload/file','POST /api/v1/upload/base64']);
const ADMIN_ROUTES=new Set(['POST /api/v1/config/github','POST /api/v1/github/inspect']);
const TYPES={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.webp':'image/webp','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
const secret=()=>randomBytes(32).toString('hex');
const equal=(a,b)=>typeof a==='string'&&typeof b==='string'&&Buffer.byteLength(a)===Buffer.byteLength(b)&&timingSafeEqual(Buffer.from(a),Buffer.from(b));
export function isPrivateIPv4(value){const p=String(value).split('.');if(p.length!==4||p.some(x=>!/^\d{1,3}$/.test(x)||Number(x)>255))return false;const[a,b]=p.map(Number);return value==='127.0.0.1'||a===10||(a===172&&b>=16&&b<=31)||(a===192&&b===168);}
const peer=req=>String(req.socket.remoteAddress||'').replace(/^::ffff:/,'');
export function createLanServer({serviceAuthorization,addresses=['127.0.0.1'],staticRoot=resolve(PROJECT,'dist'),manualFile=resolve(PROJECT,'docs/POD局域网版操作手册.html'),fetchImpl=fetch,now=Date.now,settingsStore,materialStore,templateStore,assistantService,publishingService,miaoshouService,designFolderStore=createDesignFolderStore()}={}){
  if(typeof serviceAuthorization!=='string'||!/^Bearer [^\s\u0000-\u001f\u007f]{1,4096}$/.test(serviceAuthorization))throw new Error('服务授权无效。');
  const hosts=new Set(['127.0.0.1',...addresses.filter(isPrivateIPv4)]),sessions=new Map();
  const root=resolve(staticRoot),json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
  const fail=(res,status,message)=>json(res,status,{success:false,message});
  const uploadFailure=(res,status,stage)=>{
    if(res.destroyed)return;
    const providerHint=uploadProviderHint(stage,status);
    if(providerHint){
      res.setHeader('X-POD-Upload-Code',stage);
      return json(res,status,{success:false,code:stage,message:providerHint});
    }
    if(Number.isInteger(status)&&Object.hasOwn(IMAGE_UPLOAD_HTTP_HINTS,status))return fail(res,status,IMAGE_UPLOAD_HTTP_HINTS[status]);
    const code=Object.hasOwn(IMAGE_UPLOAD_STAGE_HINTS,stage)?stage:'POD_UPLOAD_GATEWAY';
    res.setHeader('X-POD-Upload-Code',code);
    return json(res,502,{success:false,code,message:IMAGE_UPLOAD_STAGE_HINTS[code]});
  };
  const prune=()=>{for(const[key,value]of sessions)if(value.expires<=now())sessions.delete(key);};
  const cookie=(res,id)=>res.setHeader('Set-Cookie',`pod_lan_session=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200`);
  const current=req=>{const match=String(req.headers.cookie||'').match(/(?:^|;\s*)pod_lan_session=([a-f0-9]{64})(?:;|$)/);return match?sessions.get(match[1]):null;};
  const newSession=res=>{const id=secret(),session={csrf:secret(),admin:false,expires:now()+TTL};sessions.set(id,session);cookie(res,id);return session;};
  const profile=async(signal)=>{
    const response=await fetchImpl('http://127.0.0.1:8080/api/v1/config/github',{headers:{Authorization:serviceAuthorization},redirect:'error',signal:signal||AbortSignal.timeout(6000)});
    const text=await boundedResponse(response);if(!response.ok)throw new Error();const result=JSON.parse(text.toString('utf8'));if(result?.success!==true||typeof result?.data?.configured!=='boolean'||typeof result?.data?.tokenConfigured!=='boolean')throw new Error();return result.data;
  };
  async function body(req,limit){const chunks=[];let bytes=0;for await(const chunk of req){bytes+=chunk.length;if(bytes>limit){const error=new Error();error.status=413;throw error;}chunks.push(chunk);}return Buffer.concat(chunks);}
  // Drain over-limit bodies instead of destroying their socket before the 413
  // response can reach a browser. No excess bytes are retained in memory.
  async function templateBody(req,limit){return new Promise((done,reject)=>{const chunks=[];let bytes=0,failed=false;const cleanup=()=>{req.off('data',data);req.off('end',end);req.off('error',error);};const data=chunk=>{if(failed)return;bytes+=chunk.length;if(bytes>limit){failed=true;chunks.length=0;reject(Object.assign(new Error(),{status:413}));}else chunks.push(chunk);};const end=()=>{cleanup();if(!failed)done(Buffer.concat(chunks));};const error=()=>{cleanup();if(!failed)reject(Object.assign(new Error(),{status:400}));};req.on('data',data);req.once('end',end);req.once('error',error);});}
  const publicTemplate=record=>Object.fromEntries(Object.entries(record).filter(([key])=>['id','shop','style','name','title','product','color','colorHex','colorName','width','height','size','mime','placementId','positions','surfaces','sourcePath','fileRevision','custom','shared','hostTemplate','library','regions','confirmed','regionModes','printContours','regionRevision','revision','inherited','universalGeometry','needsCalibration','calibrationStatus','reviewReason','blankVerified','blankVerifiedAt','hasPrintMasks','maskPositions','maskRevision','masksLoaded','createdAt','updatedAt','printMasks'].includes(key)));
  async function templateOriginal(record){
    const changed=()=>Object.assign(new Error(),{code:'TEMPLATE_FILE_CHANGED',status:409});
    if(!Number.isSafeInteger(record.size)||record.size<1||record.size>25*1024*1024)throw changed();
    const handle=await open(record.path,'r');
    try{const before=await handle.stat();if(!before.isFile()||before.size!==record.size)throw changed();const buffer=Buffer.alloc(record.size+1);let offset=0;while(offset<buffer.length){const{bytesRead}=await handle.read(buffer,offset,buffer.length-offset,offset);if(!bytesRead)break;offset+=bytesRead;}const after=await handle.stat(),current=await stat(record.path);if(offset!==record.size||['size','mtimeMs','ctimeMs','dev','ino'].some(key=>before[key]!==after[key]||after[key]!==current[key]))throw changed();const bytes=buffer.subarray(0,offset);if(createHash('sha256').update(bytes).digest('hex')!==record.fileRevision)throw changed();return bytes;}finally{await handle.close();}
  }
  const templateFailure=(res,error)=>{const status=[400,404,409,413,503].includes(error?.status)?error.status:503;const messages={400:'模板保存内容无效，请重新框选区域或检查蒙版。',404:'主机模板不存在，请重新加载模板库。',409:'模板原图或区域已更新，请重新加载后再保存。',413:'模板保存内容过大，请缩小蒙版或拆分模板库。',503:'主机模板库暂时无法读取，请检查启动程序中的模板目录权限。'};return json(res,status,{success:false,message:error?.code==='TEMPLATE_PRESET_FILE'?'印花区域已保存，但独立区域文件写入失败；请检查模板目录权限后重新加载区域文件重试。':messages[status],code:['TEMPLATE_INVALID','TEMPLATE_CONFLICT','TEMPLATE_FILE_CHANGED','TEMPLATE_ACCESS','TEMPLATE_LIMIT','TEMPLATE_NOT_FOUND','TEMPLATE_MASK','TEMPLATE_REGION','TEMPLATE_NAME','TEMPLATE_PRESET_FILE'].includes(error?.code)?error.code:'TEMPLATE_REQUEST_FAILED'});};
  async function boundedResponse(response){const chunks=[];let bytes=0;for await(const chunk of response.body){bytes+=chunk.length;if(bytes>1024*1024)throw new Error();chunks.push(chunk);}return Buffer.concat(chunks);}
  const connection=async(session,origin,localDraftHost)=>{const value=settingsStore?await settingsStore.publicStatus():await profile();return {provider:'urpiclink',endpoint:origin+'/api/v1/upload/file',authHeaderName:'X-POD-Session',authValue:session.csrf,configured:value.configured,tokenConfigured:value.tokenConfigured,admin:session.admin,lan:true,...(localDraftHost&&miaoshouService?.supportsLocalDrafts?{durableDrafts:true}:{}),...(settingsStore?{global:true,uploadProvider:value.uploadProvider,materialFolderName:value.materialFolderName}:{})};};
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','same-origin');
    prune();
    const ownPort=server.address()?.port;
    let url;try{url=new URL(req.url,`http://${req.headers.host}`);}catch{return fail(res,400,'地址无效。');}
    if(!hosts.has(url.hostname)||url.port!==String(ownPort)||req.headers.host!==url.host||!isPrivateIPv4(peer(req)))return fail(res,403,'只允许局域网访问。');
    const route=`${req.method} ${url.pathname}`;
    // Old bookmarks and cached login forms simply return to the now public designer.
    // No state changes or credentials are accepted at these retired endpoints.
    if((req.method==='GET'||req.method==='POST')&&['/__pod/lan/login','/__pod/lan/connect'].includes(url.pathname)){
      res.writeHead(req.method==='POST'?303:302,{Location:'/','Cache-Control':'no-store'});return res.end();
    }
    const origin=url.origin,requestOrigin=req.headers.origin;
    if(requestOrigin&&requestOrigin!==origin)return fail(res,403,'请求来源不允许。');
    if(req.method==='OPTIONS')return fail(res,403,'只支持同源访问。');
    if(req.method==='POST'&&requestOrigin!==origin)return fail(res,403,'请通过设计器网页提交。');
    if(route==='GET /__pod/lan/status')return json(res,200,{app:'pod-lan',version:2,passwordRequired:false});
    if(route==='GET /__pod/manual'){try{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache'});return res.end(await readFile(manualFile));}catch{return fail(res,404,'操作文档尚未安装。');}}
    // Only the connection handshake creates cookies. Parallel public asset or
    // material reads must never overwrite that session's mutation capability.
    let session=current(req);
    if(!session&&route==='GET /__pod/lan/session'){
      if(sessions.size>=200)return fail(res,429,'访问设备较多，请稍后重试。');
      session=newSession(res);
    }
    if(!session&&req.method!=='GET')return fail(res,401,'网页连接已失效，请刷新设计器。');
    if(route==='GET /__pod/lan/session'){try{return json(res,200,{success:true,data:await connection(session,origin,hosts.has(peer(req)))});}catch{return fail(res,503,'图床服务未就绪。');}}
    if(url.pathname==='/__pod/design-folder/save'){
      if(req.method!=='POST')return fail(res,404,'效果图保存接口不存在。');
      if(!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'效果图保存授权无效，请刷新设计器。');
      if(url.search)return fail(res,400,'效果图保存地址无效。');
      const header=req.headers['x-pod-export-meta'];let meta;
      try{if(typeof header!=='string'||header.length>10000)throw Error();meta=JSON.parse(decodeURIComponent(header));}
      catch{return fail(res,400,'效果图命名资料无效，请重新选择设计后保存。');}
      const mime=String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase();
      if(!['application/octet-stream','image/png','image/jpeg','image/webp'].includes(mime))return fail(res,400,'请选择 PNG、JPG 或 WebP 效果图。');
      try{
        const bytes=await templateBody(req,MAX_DESIGN_EXPORT_BYTES),data=await designFolderStore.save({bytes,mime,meta});
        return json(res,200,{success:true,data});
      }catch(error){
        const known=/^DESIGN_EXPORT_/.test(error?.code||''),status=[400,409,413,503].includes(error?.status)?error.status:503;
        return json(res,status,{success:false,message:known?error.message:status===413?'每张效果图不得超过 25 MB。':'效果图保存失败，请检查主机磁盘空间和文件夹写入权限。',code:known?error.code:'DESIGN_EXPORT_FAILED'});
      }
    }
    if(url.pathname.startsWith('/__pod/miaoshou/')){
      if(!miaoshouService)return fail(res,503,'妙手工作台尚未启动，请使用新版启动程序。');
      if(!session)return fail(res,401,'连接已失效，请刷新页面。');
      if(req.method==='POST'&&!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'操作授权无效，请刷新页面。');
            // The launcher can open this host by its LAN address. Use the actual
      // socket peer for draft access without expanding administrative access.
      return miaoshouService.handle(req,res,{isHost:peer(req)==='127.0.0.1',localDraftHost:hosts.has(peer(req))});
    }
    if(url.pathname.startsWith('/__pod/publishing/')){
      if(!publishingService)return fail(res,503,'多店铺服务尚未启动，请使用新版启动程序。');
      if(!session)return fail(res,401,'工作台连接已失效，请刷新页面。');
      if(req.method==='POST'&&!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'多店铺操作授权无效，请刷新页面。');
      // Configuring the host API key is limited to the loopback connection,
      // never a browser-provided flag or a trusted LAN address.
      return publishingService.handle(req,res,{csrf:session.csrf,isHost:peer(req)==='127.0.0.1'});
    }
    if(url.pathname.startsWith('/__pod/codex/')){
      if(!assistantService)return fail(res,503,'Codex 助手尚未由启动程序启动。');
      if(req.method==='POST'&&(!session||!equal(req.headers['x-pod-session'],session.csrf)))return fail(res,403,'助手操作授权无效，请刷新设计器。');
      // LAN devices share the host account through this same-origin gateway.
      // Account management is still derived from the real socket peer, never a
      // browser-supplied flag or forwarded header.
      return assistantService.handle(req,res,{csrf:session?.csrf,isHost:hosts.has(peer(req)),loadMiaoshouTitle:miaoshouService?.loadListingTitle});
    }
    if(route==='GET /__pod/global-config'&&settingsStore){try{const[summary,listed]=await Promise.all([settingsStore.publicStatus(),materialStore?(typeof materialStore.summary==='function'?materialStore.summary():materialStore.list({pageSize:1})):null]);return json(res,200,{success:true,data:{...summary,materialCount:listed?.total||0,scanning:listed?.scanning===true,scanProgress:listed?.scanProgress||null,scanError:listed?.scanError||'',revision:(summary.revision||'')+'|'+(listed?.revision||'')}});}catch{return fail(res,503,'主机全局配置暂时无法读取，请检查启动程序。');}}
    if(url.pathname==='/__pod/universal-region-presets'){
      if(!templateStore?.listUniversalRegionPresets||!templateStore?.saveUniversalRegionPreset)return fail(res,503,'主机通用印花区域尚未就绪，请重新启动设计器。');
      try{
        if(req.method==='GET'){
          const allowed=new Set(['style','placementId','metadataOnly']);
          if([...url.searchParams.keys()].some(key=>!allowed.has(key)||url.searchParams.getAll(key).length!==1||url.searchParams.get(key).length>255)||url.searchParams.has('metadataOnly')&&!['0','1'].includes(url.searchParams.get('metadataOnly')))return fail(res,400,'通用区域检索参数无效。');
          const records=await templateStore.listUniversalRegionPresets(Object.fromEntries(url.searchParams));return json(res,200,{success:true,data:{records,storage:'host'}});
        }
        if(req.method!=='POST')return fail(res,404,'通用区域接口不存在。');
        if(!session||!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'通用区域保存授权无效，请刷新设计器。');
        if(url.search||String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase()!=='application/json')return fail(res,400,'请使用 JSON 保存通用印花区域。');
        const bytes=await templateBody(req,MAX_REGION_PRESET_BYTES);let request;try{request=JSON.parse(bytes.toString('utf8'));}catch{return fail(res,400,'通用区域保存内容不是有效 JSON。');}
        if(!request?.preset||Array.isArray(request)||Object.keys(request).some(key=>!['preset','seed','expectedRevision'].includes(key))||request.seed!==undefined&&typeof request.seed!=='boolean')return fail(res,400,'通用区域保存参数无效。');
        const {preset,...options}=request,result=await templateStore.saveUniversalRegionPreset(preset,options);
        return json(res,200,{success:true,data:{...result,records:result.records.map(publicTemplate),storage:'host'}});
      }catch(error){return templateFailure(res,error);}
    }
    if(url.pathname==='/__pod/region-presets'){
      if(!templateStore?.listRegionPresets||!templateStore?.saveRegionPreset)return fail(res,503,'主机印花区域库尚未就绪，请重新启动设计器。');
      try{
        if(req.method==='GET'){
          const allowed=new Set(['shop','style','placementId']);if([...url.searchParams.keys()].some(key=>!allowed.has(key)||url.searchParams.getAll(key).length!==1||url.searchParams.get(key).length>255))return fail(res,400,'印花区域检索参数无效。');
          const records=await templateStore.listRegionPresets(Object.fromEntries(url.searchParams));return json(res,200,{success:true,data:{records,storage:'host'}});
        }
        if(req.method!=='POST')return fail(res,404,'印花区域接口不存在。');
        if(!session||!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'印花区域保存授权无效，请刷新设计器。');
        if(url.search||String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase()!=='application/json')return fail(res,400,'请使用 JSON 保存印花区域文件。');
        const bytes=await templateBody(req,MAX_REGION_PRESET_BYTES);let request;try{request=JSON.parse(bytes.toString('utf8'));}catch{return fail(res,400,'印花区域保存内容不是有效 JSON。');}
        if(!request||typeof request!=='object'||Array.isArray(request)||request.preset!==undefined&&Object.keys(request).some(key=>key!=='preset'))return fail(res,400,'印花区域保存参数无效。');
        const record=await templateStore.saveRegionPreset(request.preset??request);return json(res,200,{success:true,data:{record,storage:'host'}});
      }catch(error){return templateFailure(res,error);}
    }
    if(url.pathname==='/__pod/templates'||url.pathname.startsWith('/__pod/templates/')){
      if(!templateStore)return fail(res,503,'主机模板库尚未就绪，请稍后重新加载。');
      try{
        if(route==='GET /__pod/templates'){
          const allowed=new Set(['query','page','pageSize','all','shop','style','placementId']);if([...url.searchParams.keys()].some(key=>!allowed.has(key)||url.searchParams.getAll(key).length!==1))return fail(res,400,'模板检索参数无效。');
          for(const key of ['page','pageSize'])if(url.searchParams.has(key)&&(!/^[1-9]\d{0,5}$/.test(url.searchParams.get(key))||key==='pageSize'&&Number(url.searchParams.get(key))>500))return fail(res,400,'模板分页参数无效。');
          if(url.searchParams.has('all')&&!['0','1'].includes(url.searchParams.get('all'))||['query','shop','style'].some(key=>(url.searchParams.get(key)||'').length>256))return fail(res,400,'模板检索参数无效。');
          const listed=await templateStore.list({query:url.searchParams.get('query')||'',page:Number(url.searchParams.get('page')||1),pageSize:Number(url.searchParams.get('pageSize')||60),all:url.searchParams.get('all')==='1',shop:url.searchParams.get('shop')||'',style:url.searchParams.get('style')||'',placementId:url.searchParams.get('placementId')||''});
          const records=(listed.records||listed.items).map(publicTemplate),{items:_items,records:_records,...metadata}=listed;return json(res,200,{success:true,data:{...metadata,records}});
        }
        const match=url.pathname.match(/^\/__pod\/templates\/(ht-[a-f0-9]{64})(?:\/(file|calibration))?$/);
        if(req.method==='GET'&&match){
          const isFile=match[2]==='file';if(match[2]&&!isFile)return fail(res,404,'模板接口不存在。');
          if([...url.searchParams.keys()].some(key=>!isFile||key!=='v')||url.searchParams.getAll('v').length>1||url.searchParams.has('v')&&!/^[a-f0-9]{64}$/.test(url.searchParams.get('v')))return fail(res,400,'模板原图版本参数无效。');
          const record=await templateStore.get(match[1],{includeMasks:!isFile});if(!record)return fail(res,404,'主机模板不存在或原图已变化，请重新加载。');
          if(!isFile)return json(res,200,{success:true,data:{record:publicTemplate(record)}});
          if(url.searchParams.has('v')&&url.searchParams.get('v')!==record.fileRevision)return fail(res,409,'模板原图版本已变化，请重新加载模板库。');
          const bytes=await templateOriginal(record);
          const mime=['image/png','image/jpeg','image/webp'].includes(record.mime)?record.mime:'application/octet-stream';
          res.writeHead(200,{'Content-Type':mime,'Content-Length':bytes.length,'Cache-Control':'private, no-store','Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(record.sourcePath?.split('/').at(-1)||record.name||'template.png')}`});return res.end(bytes);
        }
        if(req.method!=='POST')return fail(res,404,'模板接口不存在。');
        if(!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'模板保存授权无效，请刷新设计器。');
        if(route==='POST /__pod/templates/scan'){
          if(url.search)return fail(res,400,'模板检索请求地址无效。');
          const bytes=await templateBody(req,2048);if(bytes.length){let request;try{request=JSON.parse(bytes.toString('utf8'));}catch{return fail(res,400,'模板检索请求无效。');}if(!request||typeof request!=='object'||Array.isArray(request)||Object.keys(request).length)return fail(res,400,'模板检索请求无效。');}
          const scanning=templateStore.scan();void Promise.resolve(scanning).catch(()=>{});return json(res,200,{success:true,data:{requested:true}});
        }
        if(match?.[2]==='calibration'){
          if(url.search)return fail(res,400,'模板区域保存地址无效。');
          if(String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase()!=='application/json')return fail(res,400,'请使用 JSON 保存模板区域。');
          const bytes=await templateBody(req,24*1024*1024);let patch;try{patch=JSON.parse(bytes.toString('utf8'));}catch{return fail(res,400,'模板区域保存内容不是有效 JSON。');}
          const keys=['expectedRevision','expectedFileRevision','regions','regionModes','printContours','confirmed','printMasks','blankVerified','syncGroup','syncUniversal'];if(!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(key=>!keys.includes(key))||patch.syncGroup!==undefined&&typeof patch.syncGroup!=='boolean'||patch.syncUniversal!==undefined&&typeof patch.syncUniversal!=='boolean')return fail(res,400,'模板区域保存参数无效。');
          const saved=await templateStore.saveCalibration(match[1],patch);return json(res,200,{success:true,data:{...saved,records:saved.records.map(publicTemplate)}});
        }
        return fail(res,404,'模板接口不存在。');
      }catch(error){return templateFailure(res,error);}
    }
    if(url.pathname.startsWith('/__pod/materials')&&materialStore){
      try{
        if(route==='GET /__pod/materials'){const listed=await materialStore.list({query:url.searchParams.get('query')||'',page:Number(url.searchParams.get('page')||1),pageSize:Number(url.searchParams.get('pageSize')||60),trash:url.searchParams.get('trash')==='1'});return json(res,200,{success:true,data:{...listed,records:listed.items}});}
        const match=url.pathname.match(/^\/__pod\/materials\/([a-f0-9]{64})\/(file|trash|restore)$/);
        if(req.method==='GET'&&match?.[2]==='file'){
          if(typeof materialStore.read==='function'){
            const record=await materialStore.read(match[1],{used:url.searchParams.get('use')==='1'});if(!record)return fail(res,404,'素材暂不可用，请检查电脑连接或图片网址。');
            const bytes=Buffer.from(record.bytes),referenceHeaders={};
            if(/^[a-f0-9]{64}$/.test(record.sha256||'')&&createHash('sha256').update(bytes).digest('hex')===record.sha256){
              referenceHeaders['X-POD-Material-SHA256']=record.sha256;
              try{
                const source=new URL(record.sourceUrl),parts=source.pathname.split('/');
                if(!/^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/.test(parts[1]||'')||!/^[A-Za-z0-9_.-]{1,100}$/.test(parts[2]||'')||['.','..'].includes(parts[2]))throw new Error();
                const trusted=validateHostedReference({url:record.sourceUrl,sha256:record.sha256},{owner:parts[1],repo:parts[2]});
                referenceHeaders['X-POD-Material-URL']=trusted.url;
              }catch{}
            }
            res.writeHead(200,{'Content-Type':record.mime,'Content-Length':bytes.length,'Cache-Control':'no-store','Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(record.name||'material')}`,...referenceHeaders});return res.end(bytes);
          }
          const record=await materialStore.get(match[1]);if(!record)return fail(res,404,'共享素材不存在，请刷新素材库。');
          res.writeHead(200,{'Content-Type':record.mime,'Content-Length':record.size,'Cache-Control':'private, max-age=60','Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(record.name)}`});const stream=createReadStream(record.path);stream.once('error',()=>res.destroy());res.once('close',()=>stream.destroy());return stream.pipe(res);
        }
        if(req.method!=='POST')return fail(res,404,'素材接口不存在。');
        if(!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'素材上传授权无效，请重新打开网页。');
        if(route==='POST /__pod/materials/upload'){
          let name;try{name=decodeURIComponent(req.headers['x-pod-name']||'未命名素材');}catch{return fail(res,400,'素材名称无效。');}
          const identityPolicy=req.headers['x-pod-material-identity'];if(identityPolicy!==undefined&&!['content','name-and-content'].includes(identityPolicy))return fail(res,400,'素材命名保存规则无效。');
          const bytes=await body(req,25*1024*1024),declaredMime=String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase();const saved=await materialStore.put({bytes,name,mime:declaredMime==='application/octet-stream'?'':declaredMime,...(identityPolicy===undefined?{}:{identityPolicy})});return json(res,200,{success:true,data:saved});
        }
        if(match?.[2]==='trash')return json(res,200,{success:true,data:await materialStore.trash(match[1])});
        if(match?.[2]==='restore')return json(res,200,{success:true,data:await materialStore.restore(match[1])});
        return fail(res,404,'素材接口不存在。');
      }catch(error){return fail(res,Number.isInteger(error.status)&&error.status>=400&&error.status<600?error.status:400,/[一-鿿]/.test(error.message||'')?error.message:'主机素材读写失败，请检查全局设置中的素材目录权限。');}
    }
    if(API_ROUTES.has(route)){
      if(!session)return fail(res,401,'网页连接已失效，请刷新设计器。');
      if(!equal(req.headers['x-pod-session'],session.csrf))return fail(res,403,'连接授权无效，请重新打开网页。');
      if(ADMIN_ROUTES.has(route))return fail(res,403,'图床上传设置已迁移，请在启动程序“全局设置”中修改。');
      if(settingsStore&&route==='POST /api/v1/upload/base64')return fail(res,404,'请使用统一的效果图上传接口。');
      const controller=new AbortController();res.once('close',()=>{if(!res.writableEnded)controller.abort();});
      const uploadRoute=route==='POST /api/v1/upload/file'||route==='POST /api/v1/upload/base64';
      try{
        const payload=uploadRoute?await templateBody(req,15*1024*1024):undefined;
        if(settingsStore&&route==='GET /health'){const summary=await settingsStore.publicStatus();return json(res,200,{success:true,configured:summary.configured,authRequired:true,maxFileBytes:summary.maxFileBytes??10*1024*1024,uploadProvider:summary.uploadProvider});}
        if(settingsStore&&route==='POST /api/v1/upload/file'){const url=await settingsStore.upload(payload,req.headers['content-type'],{signal:controller.signal});return json(res,200,{success:true,data:url});}
        const response=await fetchImpl('http://127.0.0.1:8080'+url.pathname,{method:req.method,headers:{Authorization:serviceAuthorization,...(req.headers['content-type']?{'Content-Type':req.headers['content-type']}:{})},...(payload?.length?{body:payload}:{}),redirect:'error',signal:AbortSignal.any([controller.signal,AbortSignal.timeout(90000)])});
        if(uploadRoute&&!response.ok){void response.body?.cancel().catch(()=>{});return uploadFailure(res,response.status,'POD_UPLOAD_PROVIDER_HTTP');}
        const output=await boundedResponse(response);res.writeHead(response.status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});return res.end(output);
      }catch(error){
        if(uploadRoute)return uploadFailure(res,error?.status,error?.name==='PodImageUploadError'?error.code:undefined);
        return fail(res,error.status===413?413:502,error.status===413?'上传内容过大。':'图床请求失败，请检查主机服务和网络。');
      }
    }
    if(req.method!=='GET')return fail(res,404,'接口不存在。');
    try{
      const path=resolve(root,'.'+decodeURIComponent(url.pathname));if(path!==root&&!path.startsWith(root+sep))return fail(res,403,'文件路径无效。');
      const file=(await stat(path)).isDirectory()?resolve(path,'index.html'):path;
      const data=await readFile(file);res.writeHead(200,{'Content-Type':TYPES[extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(data);
    }catch{return fail(res,404,'文件不存在。');}
  });
  server.requestTimeout=100000;server.headersTimeout=10000;
  return {server};
}
