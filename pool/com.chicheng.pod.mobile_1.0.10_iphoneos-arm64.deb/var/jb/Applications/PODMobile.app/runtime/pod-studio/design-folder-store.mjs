import {shanghaiTimestamp} from './mobile-date.mjs';
import {createHash, randomBytes} from 'node:crypto';
import {link, lstat, mkdir, open, readFile, rename, unlink} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {inspectHostImage} from './host-materials.mjs';

export const DESIGN_EXPORT_DIRECTORY = 'E:\\共享文件夹\\POD套图';
export const MAX_DESIGN_EXPORT_BYTES = 25 * 1024 * 1024;
const PLACEMENTS = {front:'正面',back:'背面',leftUpper:'左胸口','front-back':'正面＋背面','leftUpper-back':'左胸口＋背面'};
const EXTENSIONS = {'image/png':'.png','image/jpeg':'.jpg','image/webp':'.webp'};
const hash = value => createHash('sha256').update(value).digest('hex');
const failure = (message, code = 'DESIGN_EXPORT_INVALID', status = 400) => Object.assign(new Error(message), {code, status});
const missing = error => error?.code === 'ENOENT';
const isObject = value => value && typeof value === 'object' && !Array.isArray(value);
function metadata(value) {
  const keys = ['operationId','itemId','templateName','colorName','placementId'];
  if (!isObject(value) || Object.keys(value).length !== keys.length || Object.keys(value).some(key => !keys.includes(key))
    || typeof value.operationId !== 'string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(value.operationId)
    || !['itemId','templateName','colorName'].every(key => typeof value[key] === 'string' && value[key].trim() && value[key].length <= (key === 'itemId' ? 160 : 256))
    || typeof value.placementId !== 'string' || !Object.hasOwn(PLACEMENTS, value.placementId)) throw failure('效果图命名资料无效，请重新选择设计后保存。');
  return Object.fromEntries(keys.map(key => [key,key === 'operationId' ? value[key].toLowerCase() : value[key]]));
}
function component(value, max) {
  // Strip Windows filename punctuation, control and directional format marks.
  const cleaned = value.normalize('NFC').replace(/[<>:"/\\|?*\u0000-\u001f\u007f-\u009f\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,'_')
    .replace(/\s+/g,' ').trim().replace(/[. ]+$/g,'');
  return [...cleaned].slice(0,max).join('') || '未记录';
}
function timeName(value) {
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) throw failure('主机时间无效，请检查系统时间。', 'DESIGN_EXPORT_CLOCK', 503);
  return shanghaiTimestamp(date);
}
async function readJSON(path) {
  try {
    const info = await lstat(path);
    if (!info.isFile() || info.isSymbolicLink() || info.size > 12000) throw failure('保存凭据无法读取，请检查文件夹权限。','DESIGN_EXPORT_STATE',503);
    return JSON.parse(await readFile(path,'utf8'));
  } catch (error) { if (missing(error)) return null; throw error; }
}
async function writeExclusive(path, bytes) {
  const handle = await open(path,'wx');
  try { await handle.writeFile(bytes); await handle.sync(); }
  catch (error) { await handle.close(); await unlink(path).catch(()=>{}); throw error; }
  await handle.close();
}
async function replaceJSON(path, value) {
  const temp = path+'.'+randomBytes(8).toString('hex')+'.tmp';
  try { await writeExclusive(temp,JSON.stringify(value)); await rename(temp,path); }
  finally { await unlink(temp).catch(()=>{}); }
}
async function savedFile(path, sha256, size) {
  try {
    const info = await lstat(path);
    return info.isFile() && !info.isSymbolicLink() && info.size === size && hash(await readFile(path)) === sha256;
  } catch (error) { if (missing(error)) return false; throw error; }
}

/** Only the host chooses this root. A browser can supply naming metadata, never a path. */
export function createDesignFolderStore({directory = DESIGN_EXPORT_DIRECTORY, now = Date.now} = {}) {
  const root = resolve(directory), stateRoot = join(root,'.pod-export-state');
  let tail = Promise.resolve();
  async function save({bytes, mime, meta}) {
    const names = metadata(meta);
    if (!Buffer.isBuffer(bytes) || !bytes.length || bytes.length > MAX_DESIGN_EXPORT_BYTES)
      throw failure('每张效果图须为非空图片，且不超过 25 MB。','DESIGN_EXPORT_LIMIT',413);
    let image;
    try { image = await inspectHostImage(bytes); }
    catch { throw failure('效果图文件不完整、格式或尺寸无效，请重新生成后保存。'); }
    if (mime !== 'application/octet-stream' && (!Object.hasOwn(EXTENSIONS,mime) || image.mime !== mime)) throw failure('效果图格式与文件内容不一致，请重新生成后保存。');
    mime = image.mime;
    const fingerprint = hash(JSON.stringify(names)+'\n'+mime+'\n'+hash(bytes));
    const operationRoot = join(stateRoot,names.operationId), receiptPath = join(operationRoot,hash(names.itemId)+'.json');
    await mkdir(operationRoot,{recursive:true});
    const batchPath = join(operationRoot,'batch.json');
    let batch = await readJSON(batchPath);
    if (!batch) {
      const created = {version:1,timestamp:timeName(now())};
      try { await writeExclusive(batchPath,JSON.stringify(created)); batch = created; }
      catch (error) { if (error?.code !== 'EEXIST') throw error; batch = await readJSON(batchPath); }
    }
    if (batch?.version !== 1 || !/^\d{8}_\d{6}$/.test(batch.timestamp)) throw failure('批量保存凭据无效，请重新选择设计后保存。','DESIGN_EXPORT_STATE',503);
    const base = `${batch.timestamp}_${component(names.templateName,60)}_${component(names.colorName,30)}_${PLACEMENTS[names.placementId]}`;
    const extension = EXTENSIONS[mime], contentSha256 = hash(bytes), stagePath = join(operationRoot,hash(names.itemId)+'.image');
    let receipt = await readJSON(receiptPath);
    if (receipt && (receipt.version !== 1 || receipt.fingerprint !== fingerprint))
      throw failure('同一保存任务的图片或命名已变化，请重新选择设计后保存。','DESIGN_EXPORT_CONFLICT',409);
    if (receipt && (typeof receipt.fileName !== 'string' || !Number.isInteger(receipt.sequence) || receipt.sequence < 1 || receipt.sequence > 10000
      || receipt.fileName !== base+(receipt.sequence === 1 ? '' : ` (${receipt.sequence})`)+extension))
      throw failure('图片保存凭据无效，请重新选择设计后保存。','DESIGN_EXPORT_STATE',503);
    const result = reused => ({fileName:receipt.fileName,path:join(root,receipt.fileName),directory:root,reused});
    if (receipt?.state === 'saved' && await savedFile(join(root,receipt.fileName),contentSha256,bytes.length)) return result(true);
    // A durable staging inode lets an interrupted link/receipt transaction be
    // recognized on retry, without mistaking another identical design for it.
    try { await writeExclusive(stagePath,bytes); }
    catch (error) {
      if (error?.code !== 'EEXIST') throw error;
      if (!await savedFile(stagePath,contentSha256,bytes.length)) throw failure('图片暂存文件已变化，请重新选择设计后保存。','DESIGN_EXPORT_STATE',409);
    }
    for (let sequence = receipt?.sequence || 1; sequence <= 10000; sequence++) {
      const fileName = base+(sequence === 1 ? '' : ` (${sequence})`)+extension;
      receipt = {version:1,fingerprint,contentSha256,fileName,sequence,state:'pending'};
      await replaceJSON(receiptPath,receipt);
      const path = join(root,fileName);
      let linked = false;
      try { await link(stagePath,path); linked = true; }
      catch (error) {
        if (error?.code !== 'EEXIST') throw error;
        const [staged,target] = await Promise.all([lstat(stagePath),lstat(path)]);
        // Do not follow a user-created link at a colliding output filename.
        if (!target.isSymbolicLink() && target.isFile() && staged.dev === target.dev && staged.ino === target.ino) linked = true;
      }
      if (!linked) continue;
      receipt.state = 'saved'; await replaceJSON(receiptPath,receipt);
      await unlink(stagePath).catch(()=>{});
      return result(false);
    }
    throw failure('同名效果图过多，请稍后重新保存。','DESIGN_EXPORT_COLLISION',409);
  }
  return {
    save(input) {
      const task = tail.then(()=>save(input)).catch(error => {
        if (/^DESIGN_EXPORT_/.test(error?.code || '')) throw error;
        throw failure('无法保存到主机 E:\\共享文件夹\\POD套图，请检查磁盘空间和文件夹写入权限。','DESIGN_EXPORT_IO',503);
      });
      tail = task.catch(()=>{}); return task;
    },
    idle:()=>tail,
  };
}
