import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {buildCapturedCategoryTree} from './tiktok-builtin-catalog.mjs';

let names,leafIds;
/** Exact public category identities only. No leaf attributes or store permissions. */
export function builtinMiaoshouCategoryName(categoryId){
  if(names===undefined){
    names=new Map();leafIds=new Set();
    try{
      const bytes=readFileSync(new URL('./resources/tiktok-catalog/manifest.json',import.meta.url));
      if(bytes.length>32*1024*1024)throw new Error('Category index exceeds limit');
      const manifest=JSON.parse(bytes.toString('utf8')),proof=manifest.treeDefinitionEvidence;
      if(manifest.schemaVersion!==1||manifest.catalogId!=='tiktok-us'||manifest.region!=='US'||!proof||createHash('sha256').update(JSON.stringify(proof.publicNodes)).digest('hex')!==proof.projectionSha256)throw new Error('Unverified public category index');
      const tree=buildCapturedCategoryTree({nodes:proof.publicNodes,requestEvidence:proof});
      if(tree.treeDefinitionEvidence.projectionSha256!==proof.projectionSha256||tree.treeDefinitionEvidence.nodeCount!==proof.nodeCount)throw new Error('Public category identity mismatch');
      leafIds=new Set(proof.publicNodes.filter(node=>node.leaf===true).map(node=>String(node.id)));
      names=new Map(tree.categoryIdentities.map(item=>[item.categoryId,{name:item.displayPath.at(-1),path:item.displayPath}]));
    }catch{/* Missing display labels must never block reading or saving a product. */}
  }
  const found=names.get(String(categoryId));return found?structuredClone(found):null;
}

/** True only for a leaf of the hash-verified public category tree. */
export function isBuiltinMiaoshouLeafCategory(categoryId){builtinMiaoshouCategoryName(categoryId);return leafIds?.has(String(categoryId))===true;}

export function builtinMiaoshouLeafCategoryIds(){builtinMiaoshouCategoryName('');return [...(leafIds||[])];}
