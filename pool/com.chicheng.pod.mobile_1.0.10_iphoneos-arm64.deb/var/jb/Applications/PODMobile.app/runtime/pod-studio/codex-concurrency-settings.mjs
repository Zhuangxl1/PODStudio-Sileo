import {mkdir, readFile, rename, unlink, writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {DEFAULT_CODEX_MAX_CONCURRENT_TASKS, MIN_CODEX_MAX_CONCURRENT_TASKS,
  MAX_CODEX_MAX_CONCURRENT_TASKS, isCodexConcurrentTaskLimit} from './dist/codex-concurrency-contract.js';

const FILE = 'codex-concurrency-settings.json';
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const invalid = () => Object.assign(new Error(`并发会话上限须为 ${MIN_CODEX_MAX_CONCURRENT_TASKS} 至 ${MAX_CODEX_MAX_CONCURRENT_TASKS} 的整数。`),
  {code:'CODEX_CONCURRENCY_SETTINGS_INVALID',status:400});

/** Non-secret host settings live alongside the persistent provider settings. */
export function createCodexConcurrencySettings({root} = {}) {
  let settings, loading, writes = Promise.resolve();
  async function load() {
    if (settings) return settings;
    if (!loading) loading = (async () => {
      let value;
      if (root) {
        try { value = JSON.parse(await readFile(join(root, FILE), 'utf8')); }
        catch (error) { if (error.code !== 'ENOENT') throw error; }
      }
      if (value !== undefined && (!plain(value) || value.version !== 1 ||
          !isCodexConcurrentTaskLimit(value.maxConcurrentTasks))) throw new Error('并发会话设置文件无效。');
      settings = {maxConcurrentTasks:value?.maxConcurrentTasks ?? DEFAULT_CODEX_MAX_CONCURRENT_TASKS};
      return settings;
    })().finally(() => { loading = undefined; });
    return loading;
  }
  async function get() { await writes; return {...await load()}; }
  function save(input) {
    if (!plain(input) || Object.keys(input).some(key => key !== 'maxConcurrentTasks') ||
        !isCodexConcurrentTaskLimit(input.maxConcurrentTasks)) return Promise.reject(invalid());
    const next = {maxConcurrentTasks:input.maxConcurrentTasks};
    const operation = writes.then(async () => {
      await load();
      if (root) {
        await mkdir(root, {recursive:true});
        const path = join(root, FILE), temporary = path + '.' + randomUUID() + '.tmp';
        try {
          await writeFile(temporary, JSON.stringify({version:1,...next}) + '\n', {flag:'wx',mode:0o600});
          await rename(temporary, path);
        } finally { await unlink(temporary).catch(() => {}); }
      }
      settings = next;
      return {...next};
    });
    writes = operation.catch(() => {});
    return operation;
  }
  return {get,save};
}
