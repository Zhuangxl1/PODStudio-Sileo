import {verifyPackagedCatalogForBuild} from './scripts/verify-tiktok-catalog.mjs';
import {readFile,writeFile,readdir,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {zipFileSource,writeStreamingZip,digestZipValue} from './streaming-zip.mjs';
import {loadHandoverKnowledge} from './handover-knowledge.mjs';
const project=fileURLToPath(new URL('./',import.meta.url)),output=resolve(process.env.POD_PACKAGE_OUTPUT||resolve(project,'../delivery'));
const catalogBuildProof=verifyPackagedCatalogForBuild(project);
const knowledge=await loadHandoverKnowledge();
const generatedKnowledge=JSON.parse(await readFile(resolve(project,'dist/handover/assistant-knowledge.json'),'utf8'));
if(JSON.stringify(generatedKnowledge)!==JSON.stringify(knowledge))throw new Error('交接知识索引缺失或过期：请先运行 node handover-knowledge.mjs --build。');
const payload=new Map();
async function add(path,target=path){payload.set(target,zipFileSource(resolve(project,path)));}
async function tree(directory){for(const entry of await readdir(resolve(project,directory),{withFileTypes:true})){const path=directory+'/'+entry.name;if(entry.isDirectory())await tree(path);else if(entry.isFile())await add(path);}}
await tree('dist');await tree('docs');await tree('resources/tiktok-catalog');
for(const path of ['miaoshou-batch.mjs','miaoshou-product-edits.mjs','miaoshou-claim-defaults.mjs','miaoshou-size-chart-library.mjs','miaoshou-category-attribute-templates.mjs','miaoshou-local-category-attributes.mjs','miaoshou-category-names.mjs','miaoshou-attribute-values.mjs','miaoshou-sku-presets.mjs','miaoshou-sku-structure-templates.mjs','miaoshou-edit-fields.mjs','miaoshou-edit-context.mjs','miaoshou-structured-edits.mjs','miaoshou-description-images.mjs','miaoshou-description-templates.mjs','miaoshou-mockup-template-bindings.mjs','miaoshou-cache.mjs','miaoshou-client.mjs','courtlistener-client.mjs','courtlistener-secrets.mjs','brand-research-client.mjs','brand-risk-research.mjs','miaoshou-risk-review.mjs','miaoshou-risk-api-source.mjs','risk-review-runner.mjs','risk-review-contract.mjs','risk-description-evidence.mjs','risk-tro-contract.mjs','risk-tro-runner.mjs','miaoshou-service.mjs','miaoshou-listing-title-evidence.mjs','miaoshou-replacement.mjs','miaoshou-image.mjs','lan-launcher.mjs','lan-server.mjs','design-folder-store.mjs','lan-addresses.mjs','global-settings.mjs','storage-root.mjs','host-materials.mjs','host-templates.mjs','adspower-settings.mjs','adspower-client.mjs','tiktok-publishing-service.mjs','tiktok-shop-category-cache.mjs','tiktok-schema-store.mjs','tiktok-builtin-catalog.mjs','tiktok-catalog-codec.mjs','streaming-zip.mjs','tiktok-build-api-schema.mjs','tiktok-seller-rpa.mjs','tiktok-supplemental-compliance-rpa.mjs','tiktok-browser-driver.mjs','tiktok-category-definition.mjs','tiktok-category-localized-definition.mjs','tiktok-category-definition-observer.mjs','tiktok-category-definition-fields.mjs','seed-template-library.mjs','builtin-template-calibration.mjs','provider-secrets.ps1','desktop-launcher.mjs','desktop-gateway.mjs','codex-bridge.mjs','codex-provider-settings.mjs','lanyi-provider.mjs','lanyi-image-runtime.mjs','siliconflow-runtime.mjs','provider-http.mjs','codex-network.mjs','assistant-service.mjs','listing-suggestion-service.mjs','listing-suggestion-runner.mjs','listing-suggestion-contract.mjs','handover-knowledge.mjs','design-rules.mjs','fission-generation.mjs','quick-fission.mjs','solid-white-print.mjs','server.mjs','package.json','scripts/verify-tiktok-catalog.mjs','scripts/finalize-tiktok-catalog.mjs'])await add(path);
for(const path of ['bin/urpiclink.exe','read-service-key.ps1','LICENSE','UPSTREAM.md','README.md'])await add('integrations/urpiclink/'+path);
// Runtime and public program files only; user configuration and encrypted credentials are outside this allowlist.
payload.set('runtime/node.exe',zipFileSource(process.execPath));
await add('third-party/NODE_LICENSE.txt','runtime/NODE_LICENSE.txt');
await mkdir(output,{recursive:true});await mkdir(resolve(project,'build'),{recursive:true});
const target=resolve(project,'build/pod-lan-payload.zip'),archive=await writeStreamingZip(target,payload,{maxBytes:1536*1024*1024});
await writeFile(resolve(output,'POD局域网版操作手册.html'),await readFile(resolve(project,'docs/POD局域网版操作手册.html')));
await writeFile(resolve(output,'API配置说明.md'),await readFile(resolve(project,'docs/API配置说明.md')));
await writeFile(resolve(output,'交接包深度解析.md'),await readFile(resolve(project,'docs/交接包深度解析.md')));
await writeFile(resolve(output,'模板库使用说明.html'),await readFile(resolve(project,'docs/模板库使用说明.html')));
await writeFile(resolve(output,'模板库使用说明.md'),await readFile(resolve(project,'docs/模板库使用说明.md')));
console.log(JSON.stringify({payload:target,files:payload.size,bytes:archive.bytes}));
