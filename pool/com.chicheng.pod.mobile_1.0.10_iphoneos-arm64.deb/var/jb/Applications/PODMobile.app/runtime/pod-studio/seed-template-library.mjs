import {readFile, writeFile, mkdir, lstat, realpath, readdir, link, rename, unlink} from 'node:fs/promises';
import {resolve, join, dirname, parse, isAbsolute, sep, win32} from 'node:path';
import {createHash, randomUUID} from 'node:crypto';
import {parseTemplateLibraryPath} from './dist/template-library-schema.js';
import {inspectHostImage} from './host-materials.mjs';
import {createHostTemplateStore} from './host-templates.mjs';
import {listBuiltinSeedTemplates,builtinSeedHostId,buildBuiltinSeedCalibration} from './builtin-template-calibration.mjs';

const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const within = (root, path) => path.startsWith(root + sep);
const fail = () => new Error('模板库预置清单无效，请使用完整软件包。');
const CONTENT = Symbol('verified public seed bytes');
const invalidPart = value => !value || value === '.' || value === '..' || /[<>:"\\|?*\u0000-\u001f]/.test(value) || /[. ]$/.test(value) || /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(value);

export const MIAOSHOU_TEMPLATE_FOLDER = '.pod-miaoshou-templates';
const MIAOSHOU_STORES = new Map([
  ['miaoshou-description-templates', /^[a-f0-9]{64}-[1-9]\d{0,24}\.json$/u],
  ['miaoshou-attribute-templates', /^[a-f0-9]{64}\.json$/u],
  ['miaoshou-sku-presets', /^[a-f0-9]{64}\.json$/u],
  ['miaoshou-sku-structure-templates', /^[a-f0-9]{64}\.json$/u],
  ['miaoshou-claim-size-charts', /^[a-f0-9]{64}\.json$/u],
  ['mockup-template-bindings', /^[a-f0-9]{64}-[1-9]\d{0,24}\.json$/u],
]);
const SCOPE_ID = /^[a-f0-9]{64}$/u;
const SIZE_CHART_STORE = 'size-chart-library';
const MAX_MIGRATION_FILE = 16 * 1024 * 1024;
const migrationError = () => new Error('妙手模板库迁移未完成，请检查“模板库”目录权限后重新启动。');
function safeRelative(value) {
  return typeof value === 'string' && !isAbsolute(value) && !win32.isAbsolute(value) && !value.includes('\\') && !value.split('/').some(invalidPart);
}
async function noLinks(path, {allowMissing = false} = {}) {
  const absolute = resolve(path), root = parse(absolute).root;
  let current = root;
  for (const part of absolute.slice(root.length).split(sep).filter(Boolean)) {
    current = join(current, part);
    try {if ((await lstat(current)).isSymbolicLink()) throw fail();}
    catch (cause) {if (allowMissing && cause.code === 'ENOENT') continue; throw cause;}
  }
}

async function directoryEntries(path) {
  try {
    const info = await lstat(path);
    if (!info.isDirectory() || info.isSymbolicLink()) throw migrationError();
    return await readdir(path, {withFileTypes: true});
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }
}

async function readMigrationFileInfo(path) {
  try {
    const info = await lstat(path);
    if (!info.isFile() || info.isSymbolicLink() || info.size > MAX_MIGRATION_FILE) throw migrationError();
    const bytes = await readFile(path);
    if (bytes.length > MAX_MIGRATION_FILE) throw migrationError();
    return {bytes, modifiedAt: info.mtimeMs};
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw error;
  }
}

async function readMigrationFile(path) {
  return (await readMigrationFileInfo(path))?.bytes ?? null;
}

async function legacyTemplateFiles(root) {
  const files = [];
  for (const [store, validName] of MIAOSHOU_STORES) {
    for (const entry of await directoryEntries(join(root, store))) {
      if (!validName.test(entry.name)) continue;
      if (!entry.isFile() || entry.isSymbolicLink()) throw migrationError();
      files.push([store, entry.name]);
    }
  }
  for (const scope of await directoryEntries(join(root, SIZE_CHART_STORE))) {
    if (!SCOPE_ID.test(scope.name)) continue;
    if (!scope.isDirectory() || scope.isSymbolicLink()) throw migrationError();
    const entries = await directoryEntries(join(root, SIZE_CHART_STORE, scope.name));
    const names = new Set(entries.filter(entry => entry.isFile() && !entry.isSymbolicLink()).map(entry => entry.name));
    for (const name of names) {
      if (!name.endsWith('.json') || !SCOPE_ID.test(name.slice(0, -5))) continue;
      const image = name.slice(0, -5) + '.image';
      if (!names.has(image)) throw migrationError();
      // Readers only discover a chart after its image bytes are in place.
      files.push([SIZE_CHART_STORE, scope.name, image], [SIZE_CHART_STORE, scope.name, name]);
    }
  }
  return files;
}

async function installMigrationFile(path, bytes, {replace = false, expectedHash} = {}) {
  const temporary = join(dirname(path), '.import-' + randomUUID() + '.tmp');
  try {
    await writeFile(temporary, bytes, {flag: 'wx', mode: 0o600, flush: true});
    if (replace) {
      if (expectedHash !== undefined) {
        const current = await readMigrationFile(path);
        if (!current || digest(current) !== expectedHash) return false;
      }
      await rename(temporary, path);
    } else await link(temporary, path);
    return true;
  } catch (error) {
    if (!replace && error.code === 'EEXIST') return false;
    throw error;
  } finally {
    await unlink(temporary).catch(() => {});
  }
}

async function planFinalizedMigrationFile(source, target, parts, state, cutoff) {
  const key = parts.join('/'), destination = join(target, ...parts);
  const legacy = await readMigrationFileInfo(join(source, ...parts));
  if (!legacy) return {action: 'skip'};

  const sourceHash = digest(legacy.bytes), known = Object.hasOwn(state.prepared, key);
  if (parts[0] === SIZE_CHART_STORE && key.endsWith('.image') && parts.at(-1) !== sourceHash + '.image')
    return {action: 'conflict'};

  await noLinks(dirname(destination), {allowMissing: true});
  const existing = await readMigrationFile(destination);
  if (!existing) {
    // A missing tracked destination is a deletion. An unknown old source
    // could also have been removed after cutover, so leave it alone.
    if (known) return {action: 'conflict'};
    if (legacy.modifiedAt <= cutoff) return {action: 'skip'};
    return {action: 'copy', key, destination, sourceHash, bytes: legacy.bytes};
  }

  const currentHash = digest(existing);
  if (currentHash === sourceHash) return {action: 'unchanged'};
  if (!known || state.prepared[key] !== currentHash) return {action: 'conflict'};
  return {action: 'update', key, destination, sourceHash, bytes: legacy.bytes, currentHash};
}

async function reconcileFinalizedMigration({source, target, marker, prior, state, result}) {
  const prepared = Object.assign(Object.create(null), state.prepared);
  const files = await legacyTemplateFiles(source);
  for (let index = 0; index < files.length; index++) {
    const parts = files[index];
    // The legacy list emits each chart as an image followed by its metadata.
    // Validate the pair together and install the discoverable metadata last.
    const group = parts[0] === SIZE_CHART_STORE ? [parts, files[++index]] : [parts];
    const plans = [];
    for (const file of group) plans.push(await planFinalizedMigrationFile(source, target, file, state, prior.modifiedAt));
    result.conflicts += plans.filter(plan => plan.action === 'conflict').length;
    if (plans.some(plan => plan.action === 'skip' || plan.action === 'conflict')) continue;
    for (const plan of plans) {
      if (plan.action === 'unchanged') {
        result.unchanged++;
        continue;
      }
      await mkdir(dirname(plan.destination), {recursive: true});
      await noLinks(dirname(plan.destination));
      const replace = plan.action === 'update';
      if (!await installMigrationFile(plan.destination, plan.bytes, {replace, expectedHash: plan.currentHash})) {
        result.conflicts++;
        break;
      }
      result[replace ? 'updated' : 'copied']++;
      prepared[plan.key] = plan.sourceHash;
    }
  }
  const reconciled = JSON.stringify({...state, prepared, reconciledFinalized: true});
  if (!await installMigrationFile(marker, reconciled, {replace: true, expectedHash: digest(prior.bytes)})) throw migrationError();
  return result;
}

/** Bring forward exact store files. A prepared copy can catch up on first start.
 * An opted-in upgrade also reconciles edits made by an older host after cutover. */
export async function migrateMiaoshouTemplateLibrary({legacyRoot, templateRoot, finalize = true, reconcileFinalized = false} = {}) {
  if (![legacyRoot, templateRoot].every(value => typeof value === 'string' && isAbsolute(value))) throw migrationError();
  const source = resolve(legacyRoot), target = resolve(templateRoot);
  if (source === target || within(source, target) || within(target, source)) throw migrationError();
  await noLinks(source, {allowMissing: true});
  await noLinks(target, {allowMissing: true});
  await mkdir(target, {recursive: true});
  await noLinks(target);
  const marker = join(target, '.legacy-' + digest(process.platform === 'win32' ? source.toLowerCase() : source) + '.json');
  const prior = await readMigrationFileInfo(marker);
  const state = prior ? JSON.parse(prior.bytes.toString('utf8')) : {version: 1, complete: false, prepared: {}};
  if (state?.version !== 1 || typeof state.complete !== 'boolean' || !state.prepared ||
    typeof state.prepared !== 'object' || Array.isArray(state.prepared)) throw migrationError();
  const result = {copied: 0, updated: 0, unchanged: 0, conflicts: 0, complete: state.complete};
  if (state.complete) {
    if (finalize && reconcileFinalized && state.reconciledFinalized !== true)
      return reconcileFinalizedMigration({source, target, marker, prior, state, result});
    return result;
  }
  const prepared = Object.create(null);
  const matchedChartImages = new Set();
  for (const parts of await legacyTemplateFiles(source)) {
    const sourcePath = join(source, ...parts), destination = join(target, ...parts), key = parts.join('/');
    const bytes = await readMigrationFile(sourcePath);
    if (!bytes) continue;
    const newHash = digest(bytes), chart = parts[0] === SIZE_CHART_STORE;
    const chartImage = chart && key.endsWith('.image');
    if (chartImage && parts.at(-1) !== newHash + '.image' ||
      chart && !chartImage && !matchedChartImages.has(key.slice(0, -5) + '.image')) {
      result.conflicts++;
      continue;
    }
    await noLinks(dirname(destination), {allowMissing: true});
    await mkdir(dirname(destination), {recursive: true});
    await noLinks(dirname(destination));
    let existing = await readMigrationFile(destination);
    if (!existing && await installMigrationFile(destination, bytes)) {
      result.copied++;
      prepared[key] = newHash;
      if (chartImage) matchedChartImages.add(key);
      continue;
    }
    existing ??= await readMigrationFile(destination);
    if (!existing) throw migrationError();
    const currentHash = digest(existing);
    if (newHash === currentHash) {
      result.unchanged++;
      if (chartImage) matchedChartImages.add(key);
      // Only track copies made by this migration. Identical user files remain authoritative.
      if (state.prepared[key] === currentHash) prepared[key] = currentHash;
    } else if (state.prepared[key] === currentHash) {
      await installMigrationFile(destination, bytes, {replace: true});
      result.updated++;
      prepared[key] = newHash;
      if (chartImage) matchedChartImages.add(key);
    } else {
      result.conflicts++;
    }
  }
  await installMigrationFile(marker, JSON.stringify({version: 1, complete: finalize, prepared}), {replace: true});
  return {...result, complete: finalize};
}

/** Only verified public distribution inputs may initialize a new template library. */
export async function readTemplateLibrarySeeds({projectRoot, manifestPath = process.env.POD_TEMPLATE_LIBRARY_SEED || join(projectRoot, 'dist/template-library-seeds.json')} = {}) {
  const root = await realpath(resolve(projectRoot));
  const manifestInfo = await lstat(manifestPath);
  if (!manifestInfo.isFile() || manifestInfo.isSymbolicLink() || manifestInfo.size > 512 * 1024) throw fail();
  let manifest;
  try {manifest = JSON.parse(await readFile(manifestPath, 'utf8'));} catch {throw fail();}
  if (manifest?.version !== 1 || !Array.isArray(manifest.files) || manifest.files.length > 100) throw fail();
  const paths = new Set(), files = [];
  let totalBytes = 0;
  for (const entry of manifest.files) {
    if (!entry || !safeRelative(entry.path) || !safeRelative(entry.source) || !/^dist\/(?:assets|handover)\/.+\.(?:png|jpe?g|webp)$/i.test(entry.source) ||
      paths.has(entry.path.toLowerCase()) || !/^[a-f0-9]{64}$/.test(entry.sha256 || '') || !Number.isSafeInteger(entry.bytes) || entry.bytes <= 0 || entry.bytes > 25 * 1024 * 1024 ||
      (totalBytes += entry.bytes) > 128 * 1024 * 1024) throw fail();
    try {parseTemplateLibraryPath(entry.path);} catch {throw fail();}
    const source = resolve(root, entry.source);
    await noLinks(source);
    const sourceInfo = await lstat(source), actual = await realpath(source);
    if (!within(root, actual) || !sourceInfo.isFile() || sourceInfo.size !== entry.bytes) throw fail();
    const bytes = await readFile(actual);
    if (bytes.length !== entry.bytes || digest(bytes) !== entry.sha256) throw fail();
    let image;
    try {image = await inspectHostImage(bytes);} catch {throw fail();}
    if (!(image.mime === 'image/png' ? /\.png$/i : image.mime === 'image/jpeg' ? /\.jpe?g$/i : /\.webp$/i).test(entry.source)) throw fail();
    const file = {...entry, source: actual};
    Object.defineProperty(file, CONTENT, {value: bytes});
    paths.add(entry.path.toLowerCase()); files.push(file);
  }
  return files;
}

/** Existing folders, including intentionally emptied libraries, are never reseeded. */
export async function initializeTemplateLibrary({projectRoot, libraryRoot, manifestPath} = {}) {
  if (typeof libraryRoot !== 'string' || !isAbsolute(libraryRoot) || libraryRoot.includes('\0')) throw new Error('模板库目录必须是绝对路径。');
  const target = resolve(libraryRoot);
  if (target.slice(parse(target).root.length).split(sep).filter(Boolean).some(invalidPart)) throw fail();
  await noLinks(target, {allowMissing: true});
  try {
    const info = await lstat(target);
    if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('模板库目录无效，请选择普通文件夹。');
    return {created: false, count: 0};
  } catch (cause) {if (cause.code !== 'ENOENT') throw cause;}
  const files = await readTemplateLibrarySeeds({projectRoot, manifestPath});
  await mkdir(dirname(target), {recursive: true});
  await noLinks(dirname(target));
  try {await mkdir(target);}
  catch (cause) {
    if (cause.code !== 'EEXIST') throw cause;
    const info = await lstat(target);
    if (info.isSymbolicLink() || !info.isDirectory()) throw fail();
    return {created: false, count: 0};
  }
  const actualRoot = await realpath(target);
  let count = 0;
  for (const entry of files) {
    const destination = resolve(actualRoot, entry.path);
    if (!within(actualRoot, destination)) throw fail();
    const shop = join(actualRoot, entry.path.split('/')[0]);
    try {await mkdir(shop);} catch (cause) {if (cause.code !== 'EEXIST') throw cause;}
    if ((await lstat(shop)).isSymbolicLink() || !within(actualRoot, await realpath(shop))) throw fail();
    // Use the bytes already checked above, eliminating a source-copy race.
    try {await writeFile(destination, entry[CONTENT], {flag: 'wx', mode: 0o644}); count++;}
    catch (cause) {if (cause.code !== 'EEXIST') throw cause;}
  }
  // Only this newly created directory belongs to initialization. Existing user
  // libraries return above; their regions, groups and masks are never migrated.
  const known=listBuiltinSeedTemplates(),initial=files.filter(entry=>known.some(item=>item.sourcePath===entry.path&&item.fileRevision===entry.sha256));
  if(initial.length){
    const store=createHostTemplateStore({projectRoot,libraryRoot:actualRoot});
    try{
      await store.scan();
      for(const entry of initial){
        const record=await store.get(builtinSeedHostId(entry.path));
        await store.saveCalibration(record.id,buildBuiltinSeedCalibration(record));
      }
    }finally{await store.idle();}
  }
  return {created: true, count};
}
