import {createCategoryAttributeDefinition,validateCategoryAttributeTemplate} from './dist/miaoshou-category-attribute-template-schema.js';
import {miaoshouId} from './dist/miaoshou-policy.js';
import {confirmedMiaoshouReadId} from './dist/miaoshou-editor-read-model.js';

const copy=value=>structuredClone(value);
const fail=(message,code='MIAOSHOU_LOCAL_ATTRIBUTE_INVALID',status=400)=>Object.assign(new Error(message),{code,status});
const ids=value=>{try{return miaoshouId(value);}catch{return null;}};
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
export const LOCAL_ATTRIBUTE_OPERATIONS=Object.freeze(['attribute-templates-editor-list','attribute-templates-bootstrap','attribute-templates-editor-save','attribute-templates-editor-delete','attribute-templates-editor-default']);

/** Import only values confirmed in this exact leaf's observed dropdowns. Other
 * source values stay on the remote product and are not invented in a template. */
export function localTemplateSourceValues(productAttributes,definition){
 const attributes=[],warnings=[];
 if(productAttributes!==undefined&&!Array.isArray(productAttributes))throw fail('链接的产品属性格式无法核对。');
 const seen=new Set();
 for(const raw of productAttributes||[]){
  const id=confirmedMiaoshouReadId(raw?.attributeId??raw?.id??raw?.attrId),field=definition.fields.find(item=>item.id===id),values=raw?.attributeValues??raw?.values;
  if(!Array.isArray(values)||!values.length)continue;
  if(!field||seen.has(id)){warnings.push('部分链接属性未能对应当前子类目，未带入模板。');continue;}
  const selected=[],keys=new Set();let valid=true;
  for(const value of values){
   const rawId=value?.valueId??value?.id;
   if(rawId!==undefined&&rawId!==null&&rawId!==''){
    const option=confirmedMiaoshouReadId(rawId);if(!option||!field.values.some(item=>item.id===option)||keys.has('id:'+option)){valid=false;break;}keys.add('id:'+option);selected.push({id:option});
   }else{
    const name=value?.valueName??value?.name;
    if(!field.custom||typeof name!=='string'||!name.trim()||Array.from(name).length>255||/[\u0000-\u001f\u007f]/u.test(name)||keys.has('name:'+name)){valid=false;break;}keys.add('name:'+name);selected.push({name});
   }
  }
  if(!valid||!field.multiple&&selected.length>1||selected.filter(value=>Object.hasOwn(value,'name')).length>1){warnings.push(field.name+'的原链接属性值未能核对，请在模板中重新选择。');continue;}
  seen.add(id);attributes.push({id,values:selected});
 }
 return {currentAttributes:attributes,warnings:[...new Set(warnings)]};
}

/** Host-local template editor. Browsers can edit chosen values, never schemas.
 * Only an explicit bootstrap reads remote product/category data. Actual product
 * writes remain in the separate official save/validation path. */
export function createMiaoshouLocalCategoryAttributes({templates,client,now=Date.now,maxImports=64}={}){
 if(typeof templates?.resolveSharedEditor!=='function'||typeof client?.call!=='function'||typeof now!=='function'||!Number.isSafeInteger(maxImports)||maxImports<1||maxImports>128)throw new TypeError('本机类目模板连接不完整。');
 const imports=new Map();let closed=false;
 const binding=ctx=>JSON.stringify([ctx.accountScope,ctx.contextId,ctx.detailId,ctx.shopId,ctx.categoryId,ctx.sourceRevision]);
 const storeInput=ctx=>({accountScope:ctx.accountScope,shopId:ctx.shopId,categoryId:ctx.categoryId,scope:'category'});
 const libraryData=(ctx,library,extra={})=>({...copy(library),contextId:ctx.contextId,detailId:ctx.detailId,sourceRevision:ctx.sourceRevision,scope:{shopId:ctx.shopId,categoryId:ctx.categoryId,scope:'category'},...extra});
 async function handle(operation,input,ctx){
  if(closed)throw fail('本机类目模板正在关闭。','MIAOSHOU_LOCAL_ATTRIBUTE_CLOSED',503);
  if(!LOCAL_ATTRIBUTE_OPERATIONS.includes(operation)||!plain(input)||typeof ctx?.guard!=='function')throw fail('本机类目模板请求无效。');
  const basic=['contextId','detailId','sourceRevision','scope'];
  const allowed=operation==='attribute-templates-editor-save'?[...basic,'revision','id','template','editorDefault']:['attribute-templates-editor-delete','attribute-templates-editor-default'].includes(operation)?[...basic,'revision','id']:basic;
  if(Object.keys(input).some(key=>!allowed.includes(key))||input.scope!==undefined&&input.scope!=='category'||input.editorDefault!==undefined&&typeof input.editorDefault!=='boolean')throw fail('本机类目模板按子类目管理，请刷新工作台后重试。');
  for(const key of ['detailId','shopId','categoryId'])if(ids(ctx[key])!==ctx[key])throw fail('当前链接、店铺或子类目尚未确认。');
  if(input.contextId!==ctx.contextId||String(input.detailId)!==ctx.detailId||input.sourceRevision!==ctx.sourceRevision)throw fail('链接来源已变化，请重新打开。','MIAOSHOU_EDIT_STALE',409);
  await ctx.guard();
  if(operation==='attribute-templates-editor-list'){
   const resolved=await templates.resolveSharedEditor({...storeInput(ctx),legacyShopIds:ctx.legacyShopIds},{guard:ctx.guard});await ctx.guard();
   return libraryData(ctx,resolved.library,{autoApplyId:resolved.autoApplyId});
  }
  const target=storeInput(ctx);
  if(operation==='attribute-templates-bootstrap'){
   if(typeof ctx.readSource!=='function')throw fail('当前链接的属性读取未连接。');
   const source=await ctx.readSource();await ctx.guard();
   if(source?.revision!==ctx.sourceRevision||ids(source?.info?.cid)!==ctx.categoryId)throw fail('链接的子类目或内容已变化，请重新读取后创建模板。','MIAOSHOU_EDIT_STALE',409);
   const response=await client.call('categoryMetadata',{cid:BigInt(ctx.categoryId),shopIds:[BigInt(ctx.shopId)]});await ctx.guard();
   const definition=createCategoryAttributeDefinition({metadata:response?.categoryMetadata,categoryId:ctx.categoryId,shopId:ctx.shopId,detailId:ctx.detailId,readAt:new Date(now()).toISOString()});
   const sourceValues=localTemplateSourceValues(source.info.productAttributes,definition),key=binding(ctx);
   for(const [key,value]of imports)if(value.expires<=now())imports.delete(key);
   imports.delete(key);imports.set(key,{definition,expires:now()+30*60*1000});while(imports.size>maxImports)imports.delete(imports.keys().next().value);
   const library=await templates.editorList(target);await ctx.guard();
   return libraryData(ctx,library,{definition:copy(definition),...sourceValues});
  }
  if(operation==='attribute-templates-editor-delete')return libraryData(ctx,await templates.remove({...target,revision:input.revision,id:input.id},{guard:ctx.guard}));
  if(operation==='attribute-templates-editor-default')return libraryData(ctx,await templates.setEditorDefault({...target,revision:input.revision,id:input.id},{guard:ctx.guard}));
  const library=await templates.editorList(target);await ctx.guard();
  const existing=Object.hasOwn(input,'id')?library.items.find(item=>item.id===input.id):null;
  if(Object.hasOwn(input,'id')&&!existing)throw fail('模板已删除或不在当前子类目中。','MIAOSHOU_ATTRIBUTE_TEMPLATE_NOT_FOUND',409);
  const imported=imports.get(binding(ctx)),newDefinition=(!existing?.definition&&imported?.expires>now())?imported.definition:undefined;
  const definition=existing?.definition||newDefinition;
  if(!definition)throw fail('请先点击从当前链接读取子类目属性，再保存模板。','MIAOSHOU_ATTRIBUTE_TEMPLATE_NEEDS_SCHEMA',409);
  const preset=validateCategoryAttributeTemplate(input.template,{definition});
  const data=await templates[existing?'update':'create']({...target,revision:input.revision,...(existing?{id:existing.id}:{}),preset},{guard:ctx.guard,...(newDefinition?{definition:newDefinition}:{}),editorDefault:input.editorDefault!==false});
  await ctx.guard();return libraryData(ctx,data,{autoApplyId:data.item?.id||null});
 }
 return {handle,reset(){imports.clear();},close(){closed=true;imports.clear();}};
}
