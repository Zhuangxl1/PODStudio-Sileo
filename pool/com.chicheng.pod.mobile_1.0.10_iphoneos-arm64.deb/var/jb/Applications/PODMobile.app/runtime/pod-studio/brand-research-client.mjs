// Bounded public-source candidates. This module never decides infringement or queries CourtListener.
import {createHash,randomUUID} from 'node:crypto';
import {mkdir,readFile,open,rename,unlink,lstat,realpath} from 'node:fs/promises';
import path from 'node:path';
import {normalizeBrandResearch,brandResearchSubjects} from './dist/brand-risk-research-contract.js';

const TM='https://tmsearch.uspto.gov/prod-v1-0-0/tmsearch';
const COPYRIGHT='https://api.publicrecords.copyright.gov/search_service_external/simple_search_dsl';
const PATENT_SESSION='https://ppubs.uspto.gov/api/users/me/session';
const PATENT_SEARCH='https://ppubs.uspto.gov/api/searches/searchWithBeFamily';
const SD='https://sellerdefense.cn';
const KEYS=['uspto_trademarks','us_copyright','uspto_design_patents','sellerdefense'];
const JSON_LIMIT=2*1024*1024,HTML_LIMIT=4*1024*1024,RECORD_LIMIT=50,PAGE_LIMIT=2,PAGE_SIZE=50;
const CACHE_TTL=24*60*60*1000,PARTIAL_TTL=30*60*1000,FAILURE_TTL=10*60*1000,YEAR_TTL=7*24*60*60*1000;
const memory=new Map(),inflight=new Map(),yearMemory=new Map(),yearInflight=new Map(),cooldowns=new Map(),cooldownLoads=new Map();
const MAP_LIMITS={subjects:512,years:64,cooldowns:2048,loads:128};
function remember(map,key,value,limit){map.delete(key);map.set(key,value);while(map.size>limit)map.delete(map.keys().next().value);return value;}
function cached(map,key){const value=map.get(key);if(value!==undefined){map.delete(key);map.set(key,value);}return value;}
let netActive=0;
const netQueue=[];
const obj=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const hash=v=>createHash('sha256').update(v).digest('hex');
const copy=v=>structuredClone(v);
const scopeOK=v=>typeof v==='string'&&/^[a-f0-9]{64}$/u.test(v);
const secretRX=/(?:Bearer|Token)\s+\S{12,}|(?:api[_ -]?key|app[_ -]?secret|secret|token|password|authorization)\s*[:=]\s*\S+/giu;
const text=(v,max=500)=>typeof v==='string'?v.replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/giu,' ').replace(/<[^>]*>/gu,' ').replace(/&(?:amp|lt|gt|quot|apos|nbsp|#39);/gu,m=>({'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&apos;':"'",'&#39;':"'",'&nbsp;':' '}[m])).replace(/[\u0000-\u001f\u007f]/gu,' ').replace(secretRX,'[已隐藏]').replace(/\s+/gu,' ').trim().slice(0,max):'';
const scalar=v=>typeof v==='string'?v:typeof v==='number'&&Number.isFinite(v)?String(v):'';
const strings=v=>Array.isArray(v)?v.filter(x=>typeof x==='string'):typeof v==='string'?[v]:[];
const normalized=v=>v.normalize('NFKC').toLocaleLowerCase('en-US').replace(/\s+/gu,' ').trim();
const exact=(value,needle)=>{
 const a=normalized(value),b=normalized(needle);let at=a.indexOf(b);
 while(at>=0){if(!/[0-9A-Za-z\xAA\xB2\xB3\xB5\xB9\xBA\xBC-\xBE\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0558\u0559\u0560-\u0588\u058B\u058C\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u0660-\u0669\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07C0-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0966-\u096F\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09F9\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AE6-\u0AEF\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B6F\u0B71-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0BE6-\u0BF2\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C78-\u0C7E\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D58-\u0D61\u0D66-\u0D78\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DE6-\u0DEF\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F20-\u0F33\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F-\u1049\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u1090-\u1099\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1369-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u17E0-\u17E9\u17F0-\u17F9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A20-\u1A54\u1A80-\u1A89\u1A90-\u1A99\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B50-\u1B59\u1B83-\u1BA0\u1BAE-\u1BE5\u1C00-\u1C23\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2070\u2071\u2074-\u2079\u207F-\u2089\u208F-\u209F\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2150-\u2189\u2460-\u249B\u24EA-\u24FF\u2776-\u2793\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2CFD\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3192-\u3195\u31A0-\u31BF\u31F0-\u31FF\u3220-\u3229\u3248-\u324F\u3251-\u325F\u3280-\u3289\u32B1-\u32BF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DD\uA7E2\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA830-\uA835\uA840-\uA873\uA882-\uA8B3\uA8D0-\uA8D9\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA900-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF-\uA9D9\uA9E0-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB6C\uAB6D\uAB70-\uABE2\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC\u{10000}-\u{1000B}\u{1000D}-\u{10026}\u{10028}-\u{1003A}\u{1003C}\u{1003D}\u{1003F}-\u{1004D}\u{10050}-\u{1005D}\u{10080}-\u{100FA}\u{10107}-\u{10133}\u{10140}-\u{10178}\u{1018A}\u{1018B}\u{10280}-\u{1029C}\u{102A0}-\u{102D0}\u{102E1}-\u{102FB}\u{10300}-\u{10323}\u{1032D}-\u{1034A}\u{10350}-\u{10375}\u{10380}-\u{1039D}\u{103A0}-\u{103C3}\u{103C8}-\u{103CF}\u{103D1}-\u{103D5}\u{10400}-\u{1049D}\u{104A0}-\u{104A9}\u{104B0}-\u{104D3}\u{104D8}-\u{104FB}\u{10500}-\u{10527}\u{10530}-\u{10563}\u{10570}-\u{1057A}\u{1057C}-\u{1058A}\u{1058C}-\u{10592}\u{10594}\u{10595}\u{10597}-\u{105A1}\u{105A3}-\u{105B1}\u{105B3}-\u{105B9}\u{105BB}\u{105BC}\u{105C0}-\u{105F3}\u{10600}-\u{10736}\u{10740}-\u{10755}\u{10760}-\u{10767}\u{10780}-\u{10785}\u{10787}-\u{107B0}\u{107B2}-\u{107BF}\u{10800}-\u{10805}\u{10808}\u{1080A}-\u{10835}\u{10837}\u{10838}\u{1083C}\u{1083F}-\u{10855}\u{10858}-\u{10876}\u{10879}-\u{1089E}\u{108A7}-\u{108AF}\u{108E0}-\u{108F2}\u{108F4}\u{108F5}\u{108FB}-\u{1091B}\u{10920}-\u{10939}\u{10940}-\u{10959}\u{10980}-\u{109B7}\u{109BC}-\u{109CF}\u{109D2}-\u{10A00}\u{10A10}-\u{10A13}\u{10A15}-\u{10A17}\u{10A19}-\u{10A35}\u{10A40}-\u{10A48}\u{10A60}-\u{10A7E}\u{10A80}-\u{10A9F}\u{10AC0}-\u{10AC7}\u{10AC9}-\u{10AE4}\u{10AEB}-\u{10AEF}\u{10B00}-\u{10B35}\u{10B40}-\u{10B55}\u{10B58}-\u{10B72}\u{10B78}-\u{10B91}\u{10BA9}-\u{10BAF}\u{10C00}-\u{10C48}\u{10C80}-\u{10CB2}\u{10CC0}-\u{10CF2}\u{10CFA}-\u{10D23}\u{10D30}-\u{10D39}\u{10D40}-\u{10D65}\u{10D6F}-\u{10D85}\u{10E60}-\u{10E7E}\u{10E80}-\u{10EA9}\u{10EB0}\u{10EB1}\u{10EC2}-\u{10EC7}\u{10ED9}-\u{10EEE}\u{10F00}-\u{10F27}\u{10F30}-\u{10F45}\u{10F51}-\u{10F54}\u{10F70}-\u{10F81}\u{10FB0}-\u{10FCB}\u{10FE0}-\u{10FF6}\u{11003}-\u{11037}\u{11052}-\u{1106F}\u{11071}\u{11072}\u{11075}\u{11083}-\u{110AF}\u{110D0}-\u{110E8}\u{110F0}-\u{110F9}\u{11103}-\u{11126}\u{11136}-\u{1113F}\u{11144}\u{11147}\u{11150}-\u{11172}\u{11176}\u{11183}-\u{111B2}\u{111C1}-\u{111C4}\u{111D0}-\u{111DA}\u{111DC}\u{111E1}-\u{111F4}\u{11200}-\u{11211}\u{11213}-\u{1122B}\u{1123F}\u{11240}\u{11280}-\u{11286}\u{11288}\u{1128A}-\u{1128D}\u{1128F}-\u{1129D}\u{1129F}-\u{112A8}\u{112B0}-\u{112DE}\u{112F0}-\u{112F9}\u{11305}-\u{1130C}\u{1130F}\u{11310}\u{11313}-\u{11328}\u{1132A}-\u{11330}\u{11332}\u{11333}\u{11335}-\u{11339}\u{1133D}\u{11350}\u{1135D}-\u{11361}\u{11380}-\u{11389}\u{1138B}\u{1138E}\u{11390}-\u{113B5}\u{113B7}\u{113D1}\u{113D3}\u{11400}-\u{11434}\u{11447}-\u{1144A}\u{11450}-\u{11459}\u{1145F}-\u{11461}\u{11480}-\u{114AF}\u{114C4}\u{114C5}\u{114C7}\u{114D0}-\u{114D9}\u{11580}-\u{115AE}\u{115D8}-\u{115DB}\u{11600}-\u{1162F}\u{11644}\u{11650}-\u{11659}\u{11680}-\u{116AA}\u{116B8}\u{116C0}-\u{116C9}\u{116D0}-\u{116E3}\u{11700}-\u{1171A}\u{11730}-\u{1173B}\u{11740}-\u{11746}\u{11800}-\u{1182B}\u{118A0}-\u{118F2}\u{118FF}-\u{11906}\u{11909}\u{1190C}-\u{11913}\u{11915}\u{11916}\u{11918}-\u{1192F}\u{1193F}\u{11941}\u{11950}-\u{11959}\u{119A0}-\u{119A7}\u{119AA}-\u{119D0}\u{119E1}\u{119E3}\u{11A00}\u{11A0B}-\u{11A32}\u{11A3A}\u{11A50}\u{11A5C}-\u{11A89}\u{11A9D}\u{11AB0}-\u{11AF8}\u{11B0A}\u{11BC0}-\u{11BE0}\u{11BF0}-\u{11BF9}\u{11C00}-\u{11C08}\u{11C0A}-\u{11C2E}\u{11C40}\u{11C50}-\u{11C6C}\u{11C72}-\u{11C8F}\u{11D00}-\u{11D06}\u{11D08}\u{11D09}\u{11D0B}-\u{11D30}\u{11D46}\u{11D50}-\u{11D59}\u{11D60}-\u{11D65}\u{11D67}\u{11D68}\u{11D6A}-\u{11D89}\u{11D98}\u{11DA0}-\u{11DA9}\u{11DB0}-\u{11DDB}\u{11DE0}-\u{11DE9}\u{11DF1}\u{11EE0}-\u{11EF2}\u{11F02}\u{11F04}-\u{11F10}\u{11F12}-\u{11F33}\u{11F50}-\u{11F59}\u{11FB0}\u{11FC0}-\u{11FD4}\u{12000}-\u{12399}\u{12400}-\u{1246F}\u{12475}-\u{12543}\u{12550}-\u{12686}\u{12F90}-\u{12FF0}\u{13000}-\u{1342F}\u{13441}-\u{13446}\u{13460}-\u{143FA}\u{14400}-\u{14646}\u{16100}-\u{1611D}\u{16130}-\u{16139}\u{16800}-\u{16A38}\u{16A40}-\u{16A5E}\u{16A60}-\u{16A69}\u{16A70}-\u{16ABE}\u{16AC0}-\u{16AC9}\u{16AD0}-\u{16AED}\u{16B00}-\u{16B2F}\u{16B40}-\u{16B43}\u{16B50}-\u{16B59}\u{16B5B}-\u{16B61}\u{16B63}-\u{16B77}\u{16B7D}-\u{16B8F}\u{16D40}-\u{16D6C}\u{16D70}-\u{16D79}\u{16E40}-\u{16E96}\u{16EA0}-\u{16EB8}\u{16EBB}-\u{16ED3}\u{16F00}-\u{16F4A}\u{16F50}\u{16F93}-\u{16F9F}\u{16FE0}\u{16FE1}\u{16FE3}\u{16FF2}-\u{16FF6}\u{17000}-\u{18CDA}\u{18CFF}-\u{18D20}\u{18D80}-\u{18DF2}\u{18E00}-\u{19191}\u{191A0}-\u{191D2}\u{1AFF0}-\u{1AFF3}\u{1AFF5}-\u{1AFFB}\u{1AFFD}\u{1AFFE}\u{1B000}-\u{1B128}\u{1B132}\u{1B150}-\u{1B152}\u{1B155}\u{1B164}-\u{1B168}\u{1B170}-\u{1B2FB}\u{1BC00}-\u{1BC6A}\u{1BC70}-\u{1BC7C}\u{1BC80}-\u{1BC88}\u{1BC90}-\u{1BC99}\u{1CCF0}-\u{1CCF9}\u{1D2C0}-\u{1D2D3}\u{1D2E0}-\u{1D2F3}\u{1D360}-\u{1D378}\u{1D400}-\u{1D454}\u{1D456}-\u{1D49C}\u{1D49E}\u{1D49F}\u{1D4A2}\u{1D4A5}\u{1D4A6}\u{1D4A9}-\u{1D4AC}\u{1D4AE}-\u{1D4B9}\u{1D4BB}\u{1D4BD}-\u{1D4C3}\u{1D4C5}-\u{1D505}\u{1D507}-\u{1D50A}\u{1D50D}-\u{1D514}\u{1D516}-\u{1D51C}\u{1D51E}-\u{1D539}\u{1D53B}-\u{1D53E}\u{1D540}-\u{1D544}\u{1D546}\u{1D54A}-\u{1D550}\u{1D552}-\u{1D6A6}\u{1D6A8}-\u{1D6C0}\u{1D6C2}-\u{1D6DA}\u{1D6DC}-\u{1D6FA}\u{1D6FC}-\u{1D714}\u{1D716}-\u{1D734}\u{1D736}-\u{1D74E}\u{1D750}-\u{1D76E}\u{1D770}-\u{1D788}\u{1D78A}-\u{1D7A8}\u{1D7AA}-\u{1D7C2}\u{1D7C4}-\u{1D7CB}\u{1D7CE}-\u{1D7FF}\u{1DF00}-\u{1DF81}\u{1DF90}-\u{1DF96}\u{1DFCD}-\u{1DFFF}\u{1E030}-\u{1E06D}\u{1E100}-\u{1E12C}\u{1E137}-\u{1E13D}\u{1E140}-\u{1E149}\u{1E14E}\u{1E290}-\u{1E2AD}\u{1E2C0}-\u{1E2EB}\u{1E2F0}-\u{1E2F9}\u{1E4D0}-\u{1E4EB}\u{1E4F0}-\u{1E4F9}\u{1E5D0}-\u{1E5ED}\u{1E5F0}-\u{1E5FA}\u{1E6C0}-\u{1E6DE}\u{1E6E0}-\u{1E6E2}\u{1E6E4}\u{1E6E5}\u{1E6E7}-\u{1E6ED}\u{1E6F0}-\u{1E6F4}\u{1E6FE}\u{1E6FF}\u{1E7E0}-\u{1E7E6}\u{1E7E8}-\u{1E7EB}\u{1E7ED}\u{1E7EE}\u{1E7F0}-\u{1E7FE}\u{1E800}-\u{1E8C4}\u{1E8C7}-\u{1E8CF}\u{1E900}-\u{1E943}\u{1E94B}\u{1E950}-\u{1E959}\u{1EC71}-\u{1ECAB}\u{1ECAD}-\u{1ECAF}\u{1ECB1}-\u{1ECB4}\u{1ED01}-\u{1ED2D}\u{1ED2F}-\u{1ED3D}\u{1EE00}-\u{1EE03}\u{1EE05}-\u{1EE1F}\u{1EE21}\u{1EE22}\u{1EE24}\u{1EE27}\u{1EE29}-\u{1EE32}\u{1EE34}-\u{1EE37}\u{1EE39}\u{1EE3B}\u{1EE42}\u{1EE47}\u{1EE49}\u{1EE4B}\u{1EE4D}-\u{1EE4F}\u{1EE51}\u{1EE52}\u{1EE54}\u{1EE57}\u{1EE59}\u{1EE5B}\u{1EE5D}\u{1EE5F}\u{1EE61}\u{1EE62}\u{1EE64}\u{1EE67}-\u{1EE6A}\u{1EE6C}-\u{1EE72}\u{1EE74}-\u{1EE77}\u{1EE79}-\u{1EE7C}\u{1EE7E}\u{1EE80}-\u{1EE89}\u{1EE8B}-\u{1EE9B}\u{1EEA1}-\u{1EEA3}\u{1EEA5}-\u{1EEA9}\u{1EEAB}-\u{1EEBB}\u{1F100}-\u{1F10C}\u{1FBF0}-\u{1FBF9}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}\u{3D000}-\u{3FC3F}]/u.test(a[at-1]||'')&&!/[0-9A-Za-z\xAA\xB2\xB3\xB5\xB9\xBA\xBC-\xBE\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0558\u0559\u0560-\u0588\u058B\u058C\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u0660-\u0669\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07C0-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0966-\u096F\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09E6-\u09F1\u09F4-\u09F9\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A66-\u0A6F\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AE6-\u0AEF\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B66-\u0B6F\u0B71-\u0B77\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0BE6-\u0BF2\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C66-\u0C6F\u0C78-\u0C7E\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CE6-\u0CEF\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D58-\u0D61\u0D66-\u0D78\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DE6-\u0DEF\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F20-\u0F33\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F-\u1049\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u1090-\u1099\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1369-\u137C\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u17E0-\u17E9\u17F0-\u17F9\u1810-\u1819\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A16\u1A20-\u1A54\u1A80-\u1A89\u1A90-\u1A99\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B50-\u1B59\u1B83-\u1BA0\u1BAE-\u1BE5\u1C00-\u1C23\u1C40-\u1C49\u1C4D-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2070\u2071\u2074-\u2079\u207F-\u2089\u208F-\u209F\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2150-\u2189\u2460-\u249B\u24EA-\u24FF\u2776-\u2793\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2CFD\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u3192-\u3195\u31A0-\u31BF\u31F0-\u31FF\u3220-\u3229\u3248-\u324F\u3251-\u325F\u3280-\u3289\u32B1-\u32BF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DD\uA7E2\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA830-\uA835\uA840-\uA873\uA882-\uA8B3\uA8D0-\uA8D9\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA900-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF-\uA9D9\uA9E0-\uA9E4\uA9E6-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB6C\uAB6D\uAB70-\uABE2\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC\u{10000}-\u{1000B}\u{1000D}-\u{10026}\u{10028}-\u{1003A}\u{1003C}\u{1003D}\u{1003F}-\u{1004D}\u{10050}-\u{1005D}\u{10080}-\u{100FA}\u{10107}-\u{10133}\u{10140}-\u{10178}\u{1018A}\u{1018B}\u{10280}-\u{1029C}\u{102A0}-\u{102D0}\u{102E1}-\u{102FB}\u{10300}-\u{10323}\u{1032D}-\u{1034A}\u{10350}-\u{10375}\u{10380}-\u{1039D}\u{103A0}-\u{103C3}\u{103C8}-\u{103CF}\u{103D1}-\u{103D5}\u{10400}-\u{1049D}\u{104A0}-\u{104A9}\u{104B0}-\u{104D3}\u{104D8}-\u{104FB}\u{10500}-\u{10527}\u{10530}-\u{10563}\u{10570}-\u{1057A}\u{1057C}-\u{1058A}\u{1058C}-\u{10592}\u{10594}\u{10595}\u{10597}-\u{105A1}\u{105A3}-\u{105B1}\u{105B3}-\u{105B9}\u{105BB}\u{105BC}\u{105C0}-\u{105F3}\u{10600}-\u{10736}\u{10740}-\u{10755}\u{10760}-\u{10767}\u{10780}-\u{10785}\u{10787}-\u{107B0}\u{107B2}-\u{107BF}\u{10800}-\u{10805}\u{10808}\u{1080A}-\u{10835}\u{10837}\u{10838}\u{1083C}\u{1083F}-\u{10855}\u{10858}-\u{10876}\u{10879}-\u{1089E}\u{108A7}-\u{108AF}\u{108E0}-\u{108F2}\u{108F4}\u{108F5}\u{108FB}-\u{1091B}\u{10920}-\u{10939}\u{10940}-\u{10959}\u{10980}-\u{109B7}\u{109BC}-\u{109CF}\u{109D2}-\u{10A00}\u{10A10}-\u{10A13}\u{10A15}-\u{10A17}\u{10A19}-\u{10A35}\u{10A40}-\u{10A48}\u{10A60}-\u{10A7E}\u{10A80}-\u{10A9F}\u{10AC0}-\u{10AC7}\u{10AC9}-\u{10AE4}\u{10AEB}-\u{10AEF}\u{10B00}-\u{10B35}\u{10B40}-\u{10B55}\u{10B58}-\u{10B72}\u{10B78}-\u{10B91}\u{10BA9}-\u{10BAF}\u{10C00}-\u{10C48}\u{10C80}-\u{10CB2}\u{10CC0}-\u{10CF2}\u{10CFA}-\u{10D23}\u{10D30}-\u{10D39}\u{10D40}-\u{10D65}\u{10D6F}-\u{10D85}\u{10E60}-\u{10E7E}\u{10E80}-\u{10EA9}\u{10EB0}\u{10EB1}\u{10EC2}-\u{10EC7}\u{10ED9}-\u{10EEE}\u{10F00}-\u{10F27}\u{10F30}-\u{10F45}\u{10F51}-\u{10F54}\u{10F70}-\u{10F81}\u{10FB0}-\u{10FCB}\u{10FE0}-\u{10FF6}\u{11003}-\u{11037}\u{11052}-\u{1106F}\u{11071}\u{11072}\u{11075}\u{11083}-\u{110AF}\u{110D0}-\u{110E8}\u{110F0}-\u{110F9}\u{11103}-\u{11126}\u{11136}-\u{1113F}\u{11144}\u{11147}\u{11150}-\u{11172}\u{11176}\u{11183}-\u{111B2}\u{111C1}-\u{111C4}\u{111D0}-\u{111DA}\u{111DC}\u{111E1}-\u{111F4}\u{11200}-\u{11211}\u{11213}-\u{1122B}\u{1123F}\u{11240}\u{11280}-\u{11286}\u{11288}\u{1128A}-\u{1128D}\u{1128F}-\u{1129D}\u{1129F}-\u{112A8}\u{112B0}-\u{112DE}\u{112F0}-\u{112F9}\u{11305}-\u{1130C}\u{1130F}\u{11310}\u{11313}-\u{11328}\u{1132A}-\u{11330}\u{11332}\u{11333}\u{11335}-\u{11339}\u{1133D}\u{11350}\u{1135D}-\u{11361}\u{11380}-\u{11389}\u{1138B}\u{1138E}\u{11390}-\u{113B5}\u{113B7}\u{113D1}\u{113D3}\u{11400}-\u{11434}\u{11447}-\u{1144A}\u{11450}-\u{11459}\u{1145F}-\u{11461}\u{11480}-\u{114AF}\u{114C4}\u{114C5}\u{114C7}\u{114D0}-\u{114D9}\u{11580}-\u{115AE}\u{115D8}-\u{115DB}\u{11600}-\u{1162F}\u{11644}\u{11650}-\u{11659}\u{11680}-\u{116AA}\u{116B8}\u{116C0}-\u{116C9}\u{116D0}-\u{116E3}\u{11700}-\u{1171A}\u{11730}-\u{1173B}\u{11740}-\u{11746}\u{11800}-\u{1182B}\u{118A0}-\u{118F2}\u{118FF}-\u{11906}\u{11909}\u{1190C}-\u{11913}\u{11915}\u{11916}\u{11918}-\u{1192F}\u{1193F}\u{11941}\u{11950}-\u{11959}\u{119A0}-\u{119A7}\u{119AA}-\u{119D0}\u{119E1}\u{119E3}\u{11A00}\u{11A0B}-\u{11A32}\u{11A3A}\u{11A50}\u{11A5C}-\u{11A89}\u{11A9D}\u{11AB0}-\u{11AF8}\u{11B0A}\u{11BC0}-\u{11BE0}\u{11BF0}-\u{11BF9}\u{11C00}-\u{11C08}\u{11C0A}-\u{11C2E}\u{11C40}\u{11C50}-\u{11C6C}\u{11C72}-\u{11C8F}\u{11D00}-\u{11D06}\u{11D08}\u{11D09}\u{11D0B}-\u{11D30}\u{11D46}\u{11D50}-\u{11D59}\u{11D60}-\u{11D65}\u{11D67}\u{11D68}\u{11D6A}-\u{11D89}\u{11D98}\u{11DA0}-\u{11DA9}\u{11DB0}-\u{11DDB}\u{11DE0}-\u{11DE9}\u{11DF1}\u{11EE0}-\u{11EF2}\u{11F02}\u{11F04}-\u{11F10}\u{11F12}-\u{11F33}\u{11F50}-\u{11F59}\u{11FB0}\u{11FC0}-\u{11FD4}\u{12000}-\u{12399}\u{12400}-\u{1246F}\u{12475}-\u{12543}\u{12550}-\u{12686}\u{12F90}-\u{12FF0}\u{13000}-\u{1342F}\u{13441}-\u{13446}\u{13460}-\u{143FA}\u{14400}-\u{14646}\u{16100}-\u{1611D}\u{16130}-\u{16139}\u{16800}-\u{16A38}\u{16A40}-\u{16A5E}\u{16A60}-\u{16A69}\u{16A70}-\u{16ABE}\u{16AC0}-\u{16AC9}\u{16AD0}-\u{16AED}\u{16B00}-\u{16B2F}\u{16B40}-\u{16B43}\u{16B50}-\u{16B59}\u{16B5B}-\u{16B61}\u{16B63}-\u{16B77}\u{16B7D}-\u{16B8F}\u{16D40}-\u{16D6C}\u{16D70}-\u{16D79}\u{16E40}-\u{16E96}\u{16EA0}-\u{16EB8}\u{16EBB}-\u{16ED3}\u{16F00}-\u{16F4A}\u{16F50}\u{16F93}-\u{16F9F}\u{16FE0}\u{16FE1}\u{16FE3}\u{16FF2}-\u{16FF6}\u{17000}-\u{18CDA}\u{18CFF}-\u{18D20}\u{18D80}-\u{18DF2}\u{18E00}-\u{19191}\u{191A0}-\u{191D2}\u{1AFF0}-\u{1AFF3}\u{1AFF5}-\u{1AFFB}\u{1AFFD}\u{1AFFE}\u{1B000}-\u{1B128}\u{1B132}\u{1B150}-\u{1B152}\u{1B155}\u{1B164}-\u{1B168}\u{1B170}-\u{1B2FB}\u{1BC00}-\u{1BC6A}\u{1BC70}-\u{1BC7C}\u{1BC80}-\u{1BC88}\u{1BC90}-\u{1BC99}\u{1CCF0}-\u{1CCF9}\u{1D2C0}-\u{1D2D3}\u{1D2E0}-\u{1D2F3}\u{1D360}-\u{1D378}\u{1D400}-\u{1D454}\u{1D456}-\u{1D49C}\u{1D49E}\u{1D49F}\u{1D4A2}\u{1D4A5}\u{1D4A6}\u{1D4A9}-\u{1D4AC}\u{1D4AE}-\u{1D4B9}\u{1D4BB}\u{1D4BD}-\u{1D4C3}\u{1D4C5}-\u{1D505}\u{1D507}-\u{1D50A}\u{1D50D}-\u{1D514}\u{1D516}-\u{1D51C}\u{1D51E}-\u{1D539}\u{1D53B}-\u{1D53E}\u{1D540}-\u{1D544}\u{1D546}\u{1D54A}-\u{1D550}\u{1D552}-\u{1D6A6}\u{1D6A8}-\u{1D6C0}\u{1D6C2}-\u{1D6DA}\u{1D6DC}-\u{1D6FA}\u{1D6FC}-\u{1D714}\u{1D716}-\u{1D734}\u{1D736}-\u{1D74E}\u{1D750}-\u{1D76E}\u{1D770}-\u{1D788}\u{1D78A}-\u{1D7A8}\u{1D7AA}-\u{1D7C2}\u{1D7C4}-\u{1D7CB}\u{1D7CE}-\u{1D7FF}\u{1DF00}-\u{1DF81}\u{1DF90}-\u{1DF96}\u{1DFCD}-\u{1DFFF}\u{1E030}-\u{1E06D}\u{1E100}-\u{1E12C}\u{1E137}-\u{1E13D}\u{1E140}-\u{1E149}\u{1E14E}\u{1E290}-\u{1E2AD}\u{1E2C0}-\u{1E2EB}\u{1E2F0}-\u{1E2F9}\u{1E4D0}-\u{1E4EB}\u{1E4F0}-\u{1E4F9}\u{1E5D0}-\u{1E5ED}\u{1E5F0}-\u{1E5FA}\u{1E6C0}-\u{1E6DE}\u{1E6E0}-\u{1E6E2}\u{1E6E4}\u{1E6E5}\u{1E6E7}-\u{1E6ED}\u{1E6F0}-\u{1E6F4}\u{1E6FE}\u{1E6FF}\u{1E7E0}-\u{1E7E6}\u{1E7E8}-\u{1E7EB}\u{1E7ED}\u{1E7EE}\u{1E7F0}-\u{1E7FE}\u{1E800}-\u{1E8C4}\u{1E8C7}-\u{1E8CF}\u{1E900}-\u{1E943}\u{1E94B}\u{1E950}-\u{1E959}\u{1EC71}-\u{1ECAB}\u{1ECAD}-\u{1ECAF}\u{1ECB1}-\u{1ECB4}\u{1ED01}-\u{1ED2D}\u{1ED2F}-\u{1ED3D}\u{1EE00}-\u{1EE03}\u{1EE05}-\u{1EE1F}\u{1EE21}\u{1EE22}\u{1EE24}\u{1EE27}\u{1EE29}-\u{1EE32}\u{1EE34}-\u{1EE37}\u{1EE39}\u{1EE3B}\u{1EE42}\u{1EE47}\u{1EE49}\u{1EE4B}\u{1EE4D}-\u{1EE4F}\u{1EE51}\u{1EE52}\u{1EE54}\u{1EE57}\u{1EE59}\u{1EE5B}\u{1EE5D}\u{1EE5F}\u{1EE61}\u{1EE62}\u{1EE64}\u{1EE67}-\u{1EE6A}\u{1EE6C}-\u{1EE72}\u{1EE74}-\u{1EE77}\u{1EE79}-\u{1EE7C}\u{1EE7E}\u{1EE80}-\u{1EE89}\u{1EE8B}-\u{1EE9B}\u{1EEA1}-\u{1EEA3}\u{1EEA5}-\u{1EEA9}\u{1EEAB}-\u{1EEBB}\u{1F100}-\u{1F10C}\u{1FBF0}-\u{1FBF9}\u{20000}-\u{2A6DF}\u{2A700}-\u{2B81E}\u{2B820}-\u{2CEAD}\u{2CEB0}-\u{2EBE0}\u{2EBF0}-\u{2EE5D}\u{2F800}-\u{2FA1D}\u{30000}-\u{3134A}\u{31350}-\u{33479}\u{3D000}-\u{3FC3F}]/u.test(a[at+b.length]||''))return true;at=a.indexOf(b,at+1);}return false;
};
const failure=(reason,status='unavailable')=>Object.assign(new Error(reason),{reason,status});
const abortError=()=>Object.assign(new Error('Brand research cancelled'),{name:'AbortError',code:'BRAND_RESEARCH_CANCELLED'});
const iso=v=>{
 const s=typeof v==='string'?v.slice(0,10):'';
 return /^\d{4}-\d{2}-\d{2}$/u.test(s)&&Number.isFinite(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s?s:'';
};
function sourceDate(v){
 const original=text(scalar(v),40),match=original.match(/^(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})日?$/u);
 return iso(match?[match[1],match[2].padStart(2,'0'),match[3].padStart(2,'0')].join('-'):original);
}
function subjectList(values){
 if(!Array.isArray(values)||values.length>4)throw failure('invalid_subjects');
 const seen=new Set(),out=[];
 for(const value of values){
  if(typeof value!=='string'||value.length>160||/[\u0000-\u001f\u007f<>]/u.test(value)||/https?:\/\/|(?:Bearer|Token)\s+\S{12,}|(?:api[_ -]?key|secret|token|password|authorization)\s*[:=]/iu.test(value))throw failure('invalid_subjects');
  const subject=value.normalize('NFKC').replace(/\s+/gu,' ').trim();if(!subject)throw failure('invalid_subjects');
  if(brandResearchSubjects({findings:[{type:'ip',subject}]}).length!==1)throw failure('invalid_subjects');
  const key=normalized(subject);if(!seen.has(key)){seen.add(key);out.push(subject);}
 }return out;
}
export function brandResearchWindow(now=Date.now()){
 const end=new Date(now);if(!Number.isFinite(end.valueOf()))throw failure('invalid_clock');
 const start=new Date(end),month=start.getUTCMonth();start.setUTCFullYear(start.getUTCFullYear()-3);if(start.getUTCMonth()!==month)start.setUTCDate(0);
 return {from:start.toISOString().slice(0,10),to:end.toISOString().slice(0,10),years:3};
}
function race(promise,signal){
 if(!signal)return promise;if(signal.aborted)return Promise.reject(abortError());
 return new Promise((resolve,reject)=>{
  const stop=()=>{clean();reject(abortError());},clean=()=>signal.removeEventListener('abort',stop);
  signal.addEventListener('abort',stop,{once:true});promise.then(v=>{clean();resolve(v);},e=>{clean();reject(e);});
 });
}
function deadline(signal,ms){
 const controller=new AbortController(),stop=()=>controller.abort();signal?.addEventListener('abort',stop,{once:true});if(signal?.aborted)controller.abort();
 const timer=setTimeout(()=>controller.abort(),ms);return {signal:controller.signal,close(){clearTimeout(timer);signal?.removeEventListener('abort',stop);}};
}
function takeSlot(signal){
 if(signal.aborted)return Promise.reject(abortError());
 const release=()=>{netActive--;while(netQueue.length){const next=netQueue.shift();if(next.signal.aborted)continue;next.signal.removeEventListener('abort',next.stop);netActive++;next.resolve(release);break;}};
 if(netActive<4){netActive++;return Promise.resolve(release);}
 return new Promise((resolve,reject)=>{const item={signal,resolve,reject};item.stop=()=>{const at=netQueue.indexOf(item);if(at>=0)netQueue.splice(at,1);reject(abortError());};signal.addEventListener('abort',item.stop,{once:true});netQueue.push(item);});
}
function subscribe(entry,signal){
 if(signal?.aborted)return Promise.reject(abortError());
 const consumer=Symbol();entry.consumers.add(consumer);
 return new Promise((resolve,reject)=>{
  const clean=()=>{signal?.removeEventListener('abort',stop);entry.consumers.delete(consumer);if(!entry.settled&&!entry.consumers.size)entry.controller.abort();};
  const stop=()=>{clean();reject(abortError());};signal?.addEventListener('abort',stop,{once:true});
  entry.promise.then(value=>{clean();resolve(copy(value));},error=>{clean();reject(error);});
 });
}
async function boundedText(response,limit,signal){
 const length=Number(response.headers?.get('content-length'));if(Number.isFinite(length)&&length>limit){await response.body?.cancel().catch(()=>{});throw failure('response_too_large');}
 const reader=response.body?.getReader();if(!reader)throw failure('invalid_response');
 let size=0;const chunks=[];
 try{while(true){const next=await race(reader.read(),signal);if(next.done)break;size+=next.value.byteLength;if(size>limit)throw failure('response_too_large');chunks.push(Buffer.from(next.value));}return Buffer.concat(chunks).toString('utf8');}
 catch(error){await reader.cancel().catch(()=>{});throw error;}finally{reader.releaseLock();}
}
function count(value){const n=typeof value==='string'&&/^\d{1,12}$/u.test(value)?Number(value):value;return Number.isSafeInteger(n)&&n>=0?n:null;}
function allowedURL(value,initial){
 let u;try{u=new URL(value,initial);}catch{throw failure('unsafe_redirect');}
 const original=new URL(initial);if(u.origin!==original.origin||u.pathname!==original.pathname||u.username||u.password||u.hash||u.search!==original.search)throw failure('unsafe_redirect');
 return u.href;
}
function record(id,title,owner,number,date,url,details={}){
 return {id:text(String(id),200),title:text(title,500),owner:text(owner,300),number:text(String(number||''),200),date:iso(date),url,verification:'candidate',details};
}
function state(checkedAt){return {status:'complete',checkedAt,complete:true,hasMore:false,reason:'query_scope_only',records:[]};}
function partial(s,reason,more=false){s.status='partial';s.complete=false;s.hasMore=s.hasMore||more;s.reason=reason;}
function add(s,value){if(!value)return;if(s.records.length>=RECORD_LIMIT){partial(s,'record_limit',true);return;}s.records.push(value);}
function summaryStatus(subjects){
 const sources=subjects.flatMap(s=>KEYS.map(k=>s.sources[k]));if(!sources.length)return'not_required';
 if(sources.every(s=>['unavailable','unsupported'].includes(s.status)))return'unavailable';
 return sources.every(s=>s.complete)?'complete':'partial';
}
function yearURL(year){return SD+(year<=2023?'/allcase-'+year+'/':'/allcase'+year+'/');}
export function parseSellerDefensePage(html,year){
 if(typeof html!=='string'||Buffer.byteLength(html)>HTML_LIMIT)throw failure('response_too_large');
 const body=html.replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/giu,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/giu,' ');
 let columns=null,index=0;const out=[],headers={'起诉时间':'date','起诉日期':'date','案件号':'docket','案号':'docket','品牌':'brand','律所':'firm','州':'state','法院':'court','法院编号':'courtId','Court ID':'courtId'};
 for(const match of body.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr\s*>/giu)){
 if(index++>20_000)throw failure('html_row_limit');
  const cells=[...match[1].matchAll(/<t[dh]\b[^>]*>([\s\S]*?)<\/t[dh]\s*>/giu)].slice(0,30).map(v=>text(v[1],1000));
  if(cells.includes('案件号')||cells.includes('案号')){columns=cells.map(c=>headers[c]||'');continue;}
  if(!columns||cells.length!==columns.length)continue;
  const row=Object.fromEntries(columns.map((name,i)=>[name,cells[i]]).filter(([name])=>name));
  if(!row.docket||!row.brand)continue;
  out.push({index:out.length,year,date:sourceDate(row.date),docket:text(row.docket,200),brand:text(row.brand,500),firm:text(row.firm,300),state:text(row.state,100),court:text(row.court,200),courtId:/^[a-z0-9-]{2,30}$/u.test(row.courtId||'')?row.courtId:'',url:yearURL(year)});
 }
 if(!columns||!columns.includes('docket')||!columns.includes('brand')||!out.length)throw failure('html_structure_changed','unsupported');
 return out;
}

export function createBrandResearchClient({root,fetchImpl=globalThis.fetch,now=Date.now,wait=ms=>new Promise(resolve=>setTimeout(resolve,ms)),timeoutMs=12_000}={}){
 if(typeof fetchImpl!=='function'||typeof wait!=='function')throw failure('invalid_transport');
 const clock=typeof now==='function'?now:()=>Number(now),budget=Number.isFinite(timeoutMs)?Math.max(10,Math.min(15_000,timeoutMs)):12_000;
 const namespace=root?path.resolve(root):'memory-'+randomUUID();
 const sourceClock=()=>{const value=clock();if(!Number.isFinite(value))throw failure('invalid_clock');return value;};
 async function directory(accountScope){
  if(!root)return null;
  await mkdir(path.resolve(root),{recursive:true});const real=await realpath(path.resolve(root)),dir=path.join(real,'brand-research',accountScope);
  await mkdir(dir,{recursive:true});if(await realpath(dir)!==dir)throw failure('local_cache_unavailable');return dir;
 }
 async function readCache(accountScope,name,max=2*1024*1024){
  if(!root)return null;try{const dir=await directory(accountScope),file=path.join(dir,name),info=await lstat(file);if(!info.isFile()||info.isSymbolicLink()||info.size>max)return null;return JSON.parse(await readFile(file,'utf8'));}catch{return null;}
 }
 async function writeCache(accountScope,name,value,signal){
  if(signal?.aborted)throw abortError();if(!root)return;const dir=await directory(accountScope),target=path.join(dir,name),temporary=target+'.'+randomUUID()+'.tmp';let handle;
  try{const data=JSON.stringify(value);if(Buffer.byteLength(data)>4*1024*1024)throw failure('local_cache_too_large');if(signal?.aborted)throw abortError();handle=await open(temporary,'wx',0o600);await handle.writeFile(data);await handle.sync();await handle.close();handle=null;if(signal?.aborted)throw abortError();await rename(temporary,target);}catch(error){await handle?.close().catch(()=>{});await unlink(temporary).catch(()=>{});throw error;}
 }
 async function loadCooldown(accountScope){
  const key=namespace+'|'+accountScope;if(!cooldownLoads.has(key)){const load=(async()=>{const saved=await readCache(accountScope,'cooldowns.json',16384);if(saved?.version===1&&obj(saved.hosts))for(const [host,until]of Object.entries(saved.hosts))if(['tmsearch.uspto.gov','api.publicrecords.copyright.gov','ppubs.uspto.gov','sellerdefense.cn'].includes(host)&&Number.isFinite(until)&&until>sourceClock()&&until<=sourceClock()+86400000)remember(cooldowns,key+'|'+host,until,MAP_LIMITS.cooldowns);})();remember(cooldownLoads,key,load,MAP_LIMITS.loads);}await cached(cooldownLoads,key);
 }
 async function cool(accountScope,host,value){
  const key=namespace+'|'+accountScope,until=sourceClock()+Math.max(60_000,Math.min(24*60*60*1000,value));remember(cooldowns,key+'|'+host,until,MAP_LIMITS.cooldowns);
  const hosts={};for(const h of ['tmsearch.uspto.gov','api.publicrecords.copyright.gov','ppubs.uspto.gov','sellerdefense.cn']){const n=cooldowns.get(key+'|'+h);if(n>sourceClock())hosts[h]=n;}
  await writeCache(accountScope,'cooldowns.json',{version:1,hosts}).catch(()=>{});
 }
 async function request(url,options,accountScope,signal,html=false){
  const host=new URL(url).hostname;await loadCooldown(accountScope);if((cooldowns.get(namespace+'|'+accountScope+'|'+host)||0)>sourceClock())throw failure('rate_limited');
  const release=await takeSlot(signal);
  try{
   let current=url;
   for(let redirects=0;redirects<=1;redirects++){
    if(signal.aborted)throw abortError();
    const pending=Promise.resolve().then(()=>fetchImpl(current,{...options,headers:{Accept:html?'text/html':'application/json',...(options?.headers||{})},redirect:'manual',signal}));
    pending.then(response=>{if(signal.aborted)response.body?.cancel().catch(()=>{});},()=>{});
    const response=await race(pending,signal);
    if([301,302,303,307,308].includes(response.status)){
     const next=allowedURL(response.headers.get('location')||'',current);await response.body?.cancel().catch(()=>{});
     if(redirects===1||next===current||(!['GET',undefined].includes(options?.method)&&![307,308].includes(response.status)))throw failure('unsafe_redirect');
     current=next;continue;
    }
    if(response.status===429){const value=response.headers.get('retry-after')||'',seconds=/^\d+(?:\.\d+)?$/u.test(value)?Number(value)*1000:Date.parse(value)-sourceClock();await response.body?.cancel().catch(()=>{});await cool(accountScope,host,Number.isFinite(seconds)?seconds:60_000);throw failure('rate_limited');}
    if(response.status===401||response.status===403){await response.body?.cancel().catch(()=>{});throw failure('authentication_required','unsupported');}
    if(!response.ok){await response.body?.cancel().catch(()=>{});throw failure('http_error');}
    const type=(response.headers.get('content-type')||'').toLowerCase();
    if(html?!type.includes('text/html'):!(type.includes('application/json')||type.includes('+json'))){await response.body?.cancel().catch(()=>{});throw failure('unexpected_content_type');}
    const body=await boundedText(response,html?HTML_LIMIT:JSON_LIMIT,signal);
    if(html)return body;
    let parsed;try{parsed=JSON.parse(body);}catch{throw failure('parse_error');}if(!obj(parsed))throw failure('parse_error');
    return {data:parsed,headers:response.headers};
   }
   throw failure('unsafe_redirect');
  }catch(error){if(signal.aborted)throw error?.name==='AbortError'?error:abortError();throw error?.reason?error:failure('network_error');}finally{release();}
 }
 async function source(name,accountScope,parentSignal,work){
  const at=new Date(sourceClock()).toISOString(),result=state(at),limit=deadline(parentSignal,budget);
  try{await work(result,limit.signal);if(parentSignal.aborted)throw abortError();}
  catch(error){
   if(parentSignal.aborted)throw abortError();
   const reason=limit.signal.aborted?'timeout':error?.reason||'network_error';
   if(result.records.length)partial(result,reason,true);
   else Object.assign(result,{status:error?.status==='unsupported'?'unsupported':'unavailable',complete:false,hasMore:false,reason});
  }finally{limit.close();}
  result.records=result.records.slice(0,RECORD_LIMIT);return result;
 }
 const pause=signal=>race(Promise.resolve().then(()=>wait(100)),signal);
 async function trademarks(subject,accountScope,signal){
  return source('uspto_trademarks',accountScope,signal,async(s,active)=>{
   for(let page=0;page<PAGE_LIMIT;page++){
    const body={query:{match_phrase:{wordmark:subject}},size:PAGE_SIZE,from:page*PAGE_SIZE,track_total_hits:true,_source:['id','registrationId','wordmark','ownerName','internationalClass','filedDate','registrationDate','statusDescription','alive']};
    const {data}=await request(TM,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)},accountScope,active);
    const rows=data.hits?.hits,total=count(data.hits?.totalValue??data.hits?.total?.value??data.hits?.total);if(!Array.isArray(rows)||total===null)throw failure('parse_error');
    if(data.timedOut===true||Number(data.shardsFailed)>0)partial(s,'upstream_partial',true);
    for(const row of rows){
     const value=row?.source||row?._source;if(!obj(value)){partial(s,'invalid_record');continue;}
     const serial=scalar(value.id),title=strings(value.wordmark).join(' ');if(!/^\d{8}$/u.test(serial)||!title||!exact(title,subject)){if(!/^\d{8}$/u.test(serial)||!title)partial(s,'invalid_record');continue;}
     const owner=strings(value.ownerName).join(' | '),details={serial,status:text(value.statusDescription,200),classes:text(strings(value.internationalClass).join(', '),200),registeredOn:iso(value.registrationDate)};
     if(typeof value.alive==='boolean')details.live=value.alive;
     add(s,record('tm-'+serial,title,owner,scalar(value.registrationId)||serial,iso(value.filedDate),'https://tsdr.uspto.gov/#caseNumber='+serial+'&caseType=SERIAL_NO&searchType=statusSearch',details));
    }
    const consumed=(page+1)*PAGE_SIZE;if(total<=consumed)return;
    if(s.records.length>=RECORD_LIMIT){partial(s,'record_limit',true);return;}
    if(page+1===PAGE_LIMIT){partial(s,'page_limit',true);return;}
    if(!rows.length){partial(s,'upstream_partial',true);return;}await pause(active);
   }
  });
 }
 function owners(tm,subject){
  const candidates=[];
  for(const row of tm.records)for(const name of row.owner.split(' | ')){const value=text(name,300);if(value&&!candidates.some(c=>normalized(c.name)===normalized(value)))candidates.push({name:value,source:'uspto_trademarks',url:row.url,verification:'candidate'});}
  // A single exact-mark owner is still a candidate, never an automatic identity confirmation.
  const exactRows=tm.records.filter(row=>normalized(row.title)===normalized(subject)),names=[...new Set(exactRows.flatMap(row=>row.owner.split(' | ').map(v=>text(v,300))).filter(Boolean))];
  return {candidates:candidates.slice(0,20),hasMore:candidates.length>20,additional:names.length===1?names[0]:null};
 }
 async function copyrights(subject,owner,accountScope,signal){
  const targets=[...new Set([subject,owner].filter(Boolean))].slice(0,2);
  return source('us_copyright',accountScope,signal,async(s,active)=>{
   const seen=new Set();
   for(const target of targets)for(let page=1;page<=PAGE_LIMIT;page++){
    const url=new URL(COPYRIGHT);for(const [k,v]of Object.entries({query:target,field_type:'name',type_of_record:'registration',records_per_page:PAGE_SIZE,page_number:page,sort_field:'registration_date_as_date',sort_order:'desc'}))url.searchParams.set(k,String(v));
    const {data}=await request(url.href,{},accountScope,active),rows=data.data,total=count(data.metadata?.hit_count);
    if(!Array.isArray(rows)||total===null)throw failure('parse_error');
    for(const item of rows){
     const value=item?.hit||item?._source||item;if(!obj(value)){partial(s,'invalid_record');continue;}
     const claimants=Array.isArray(value.claimants_list)?value.claimants_list:[],organizations=Array.isArray(value.organizations)?value.organizations:[],persons=Array.isArray(value.persons)?value.persons:[];
     const names=[...claimants.map(v=>v?.claimant_full_name),...organizations.map(v=>v?.name_organization_indexed_form),...persons.map(v=>v?.name_personal_indexed_form)].filter(v=>typeof v==='string');
     if(!names.some(n=>exact(n,target)))continue;
     const id=scalar(value.public_records_id),number=scalar(value.registration_number||value.copyright_number_for_display);if(!id||id.length>160||!number){partial(s,'invalid_record');continue;}
     if(seen.has(id))continue;seen.add(id);
     const title=text(value.title_concatenated,500);if(!title){partial(s,'invalid_record');continue;}
     add(s,record('cr-'+id,title,claimants.map(v=>text(v?.claimant_full_name,300)).filter(Boolean).join(' | '),number,iso(value.registration_date_as_date||value.registration_date),'https://publicrecords.copyright.gov/detailed-record/'+encodeURIComponent(id),{regClass:text(value.registration_class,100),typeOfWork:text(value.type_of_work_to_english||value.type_of_work,160),firstPublished:iso(value.first_published_date_as_date||value.first_published_date||value.date_of_first_publication),registrationDate:iso(value.registration_date_as_date||value.registration_date)}));
    }
    if(total<=page*PAGE_SIZE)break;
    if(s.records.length>=RECORD_LIMIT){partial(s,'record_limit',true);return;}
    if(page===PAGE_LIMIT){partial(s,'page_limit',true);break;}
    if(!rows.length){partial(s,'upstream_partial',true);break;}await pause(active);
   }
   if(s.complete&&!owner)partial(s,'owner_not_confirmed');
  });
 }
 function expiry(filed,granted){
  if(!filed||!granted)return '';const date=new Date(granted+'T00:00:00Z'),month=date.getUTCMonth();date.setUTCFullYear(date.getUTCFullYear()+(filed>='2015-05-13'?15:14));if(date.getUTCMonth()!==month)date.setUTCDate(0);return date.toISOString().slice(0,10);
 }
 async function patents(subject,owner,accountScope,signal){
  return source('uspto_design_patents',accountScope,signal,async(s,active)=>{
   const session=await request(PATENT_SESSION,{method:'POST',headers:{'Content-Type':'application/json'},body:'-1'},accountScope,active);
   const token=session.headers.get('x-access-token'),caseId=session.data.userCase?.caseId;
   if(typeof token!=='string'||!token||token.length>4096||/[\r\n]/u.test(token)||!['string','number'].includes(typeof caseId))throw failure('session_unavailable','unsupported');
   const seen=new Set(),targets=[...new Set([subject,owner].filter(Boolean))].slice(0,2);
   for(const target of targets)for(let page=0;page<PAGE_LIMIT;page++){
    const q='"'+target.replace(/[\\"]/gu,'\\$&')+'".as.',query={caseId,hl_snippets:'2',op:'OR',q,queryName:q,highlights:'1',qt:'brs',spellCheck:false,viewName:'tile',plurals:true,britishEquivalents:true,databaseFilters:[{databaseName:'USPAT',countryCodes:[]}],searchType:1,ignorePersist:true,userEnteredQuery:q};
    const body={start:page*PAGE_SIZE,pageCount:PAGE_SIZE,sort:'date_publ desc',docFamilyFiltering:'familyIdFiltering',searchType:1,familyIdEnglishOnly:true,familyIdFirstPreferred:'US-PGPUB',familyIdSecondPreferred:'USPAT',familyIdThirdPreferred:'FPRS',showDocPerFamilyPref:'showEnglish',queryId:0,tagDocSearch:false,query};
    const {data}=await request(PATENT_SEARCH,{method:'POST',headers:{'Content-Type':'application/json','x-access-token':token},body:JSON.stringify(body)},accountScope,active);
    const rows=data.patents,total=count(data.totalPatents??data.totalResults??data.numFound??data.total);
    if(!Array.isArray(rows))throw failure('parse_error');
    for(const value of rows){
     if(!obj(value)){partial(s,'invalid_record');continue;}
     const guid=scalar(value.guid).replace(/-/gu,'');if(!/^USD\d+S\d?$/u.test(guid))continue;
     const assignees=strings(value.assigneeName);if(!assignees.some(n=>exact(n,target)))continue;
     if(seen.has(guid))continue;seen.add(guid);
     const title=text(value.inventionTitle,500);if(!title){partial(s,'invalid_record');continue;}
     const filed=iso(strings(value.applicationFilingDate)[0]),granted=iso(value.datePublished),details={patentType:'design',filed,granted,expires:expiry(filed,granted),sourceDateMeaning:'estimated_term_only_not_verified_legal_status'};
     if(typeof value.patentStatus==='string')details.status=text(value.patentStatus,160);
     add(s,record('pat-'+guid,title,assignees.join(' | '),guid,granted,'https://patents.google.com/patent/'+guid,details));
    }
    if(total===null){partial(s,'unknown_total',true);break;}
    if(total<=(page+1)*PAGE_SIZE)break;
    if(s.records.length>=RECORD_LIMIT){partial(s,'record_limit',true);return;}
    if(page+1===PAGE_LIMIT){partial(s,'page_limit',true);break;}
    if(!rows.length){partial(s,'upstream_partial',true);break;}await pause(active);
   }
   if(s.complete&&!owner)partial(s,'owner_not_confirmed');
  });
 }
 async function yearRows(year,accountScope,signal,force){
  const key=namespace+'|'+accountScope+'|year|'+year;
  let saved=cached(yearMemory,key);
  const valid=value=>value?.version===1&&value.accountScope===accountScope&&value.year===year&&Number.isFinite(value.fetchedAt)&&value.fetchedAt<=sourceClock()&&[YEAR_TTL,FAILURE_TTL].includes(value.ttl)&&Array.isArray(value.rows)&&value.rows.length<=20_000&&value.rows.every(row=>obj(row)&&row.year===year&&row.url===yearURL(year)&&Number.isSafeInteger(row.index)&&row.index>=0&&['date','docket','brand','firm','state','court','courtId'].every(k=>typeof row[k]==='string'&&row[k].length<=1000)&&(!row.date||iso(row.date)===row.date))&&(!value.error||['network_error','http_error','rate_limited','timeout','authentication_required','html_structure_changed','parse_error','unexpected_content_type','response_too_large','unsafe_redirect','invalid_response','html_row_limit'].includes(value.error.reason));
  if(!saved&&!force){saved=await readCache(accountScope,'year-'+year+'.json',4*1024*1024);if(valid(saved))remember(yearMemory,key,saved,MAP_LIMITS.years);}
  if(!force&&valid(saved)&&sourceClock()-saved.fetchedAt<saved.ttl){if(saved.error)throw failure(saved.error.reason,saved.error.status);return copy(saved.rows);}
  let entry=yearInflight.get(key);
  if(!entry){
   entry={controller:new AbortController(),consumers:new Set(),settled:false};
   entry.promise=(async()=>{const limit=deadline(entry.controller.signal,Math.max(10,Math.min(4000,budget/4)));try{const body=await request(yearURL(year),{},accountScope,limit.signal,true),rows=parseSellerDefensePage(body,year),value={version:1,accountScope,year,fetchedAt:sourceClock(),ttl:YEAR_TTL,rows};if(!limit.signal.aborted){await writeCache(accountScope,'year-'+year+'.json',value,entry.controller.signal).catch(()=>{});if(!entry.controller.signal.aborted)remember(yearMemory,key,value,MAP_LIMITS.years);}return rows;}catch(error){if(entry.controller.signal.aborted)throw abortError();const reason=limit.signal.aborted?'timeout':error?.reason||'network_error',value={version:1,accountScope,year,fetchedAt:sourceClock(),ttl:FAILURE_TTL,rows:[],error:{reason,status:error?.status==='unsupported'?'unsupported':'unavailable'}};await writeCache(accountScope,'year-'+year+'.json',value,entry.controller.signal).catch(()=>{});if(!entry.controller.signal.aborted)remember(yearMemory,key,value,MAP_LIMITS.years);throw failure(reason,value.error.status);}finally{limit.close();}})().finally(()=>{entry.settled=true;if(yearInflight.get(key)===entry)yearInflight.delete(key);});
   entry.promise.catch(()=>{});yearInflight.set(key,entry);
  }
  return subscribe(entry,signal);
 }
 async function scheduleA(subject,owner,accountScope,signal,force){
  return source('sellerdefense',accountScope,signal,async(s,active)=>{
   const window=brandResearchWindow(sourceClock()),from=Number(window.from.slice(0,4)),to=Number(window.to.slice(0,4));
   for(let year=from;year<=to;year++){
    let rows;try{rows=await yearRows(year,accountScope,active,force);}catch(error){if(active.aborted)throw error;if(s.records.length)partial(s,error.reason||'year_unavailable',true);else Object.assign(s,{status:error.status==='unsupported'?'unsupported':'unavailable',complete:false,hasMore:true,reason:error.reason||'year_unavailable'});continue;}
    for(const row of rows){
     if(!obj(row)||typeof row.brand!=='string'||!([subject,owner].filter(Boolean).some(n=>exact(row.brand,n))))continue;
     const date=iso(row.date);if(date&&date<window.from)continue;if(date&&date>window.to){partial(s,'future_date_filtered');continue;}
     if(['unavailable','unsupported'].includes(s.status))s.status='partial';
     const details={courtId:text(row.courtId,30),court:text(row.court,200),docket:text(row.docket,200),firm:text(row.firm,300),state:text(row.state,100),caseName:text(row.brand,500),sourceDateMeaning:'third_party_list_filing_date_unverified'};
     add(s,record('sd-'+year+'-'+row.index+'-'+hash(JSON.stringify([row.brand,row.docket,row.courtId,row.court,row.firm,row.date])).slice(0,20),row.brand,row.brand,row.docket,date,yearURL(year),details));
     if(!date||!details.courtId||!details.court||!details.docket)partial(s,'unverified_case_metadata');
     if(s.records.length>=RECORD_LIMIT){partial(s,'record_limit',true);return;}
    }
   }
  });
 }
 async function work(subject,accountScope,signal,force){
  const tm=await trademarks(subject,accountScope,signal),identity=owners(tm,subject);
  const [cr,dp,sd]=await Promise.all([copyrights(subject,identity.additional,accountScope,signal),patents(subject,identity.additional,accountScope,signal),scheduleA(subject,identity.additional,accountScope,signal,force)]);
  return {subject,identity:{status:identity.candidates.length?'candidates_found':'unconfirmed',requiresReview:true,hasMore:identity.hasMore,candidates:identity.candidates},sources:{uspto_trademarks:tm,us_copyright:cr,uspto_design_patents:dp,sellerdefense:sd}};
 }
 function normalizeOne(value,subject){
  const at=KEYS.map(k=>value?.sources?.[k]?.checkedAt).filter(v=>typeof v==='string').sort()[0]||new Date(sourceClock()).toISOString();
  return normalizeBrandResearch({version:1,provider:'brand-research',checkedAt:at,subjects:[value]},{subjects:[subject],now:sourceClock()}).subjects[0];
 }
 function validSaved(saved,subject,accountScope){
  if(saved?.version!==1||saved.accountScope!==accountScope||saved.subjectKey!==hash(normalized(subject))||!Number.isFinite(saved.fetchedAt)||saved.fetchedAt>sourceClock()||![CACHE_TTL,PARTIAL_TTL,FAILURE_TTL].includes(saved.ttl)||typeof saved.subject?.subject!=='string'||normalized(saved.subject.subject)!==normalized(subject))return false;
  try{return JSON.stringify(normalizeOne(saved.subject,saved.subject.subject))===JSON.stringify(saved.subject);}catch{return false;}
 }
 async function one(subject,accountScope,signal,force){
  const key=namespace+'|'+accountScope+'|'+hash(normalized(subject)),name='subject-'+hash(normalized(subject))+'.json';
  let saved=cached(memory,key);if(!saved&&!force){saved=await readCache(accountScope,name);if(validSaved(saved,subject,accountScope))remember(memory,key,saved,MAP_LIMITS.subjects);}
  if(!force&&validSaved(saved,subject,accountScope)&&sourceClock()-saved.fetchedAt<saved.ttl)return {...copy(saved.subject),subject};
  // Force skips settled caches; an already active identical query is still shared.
  let entry=inflight.get(key);
  if(!entry){
   entry={controller:new AbortController(),consumers:new Set(),settled:false};
   entry.promise=work(subject,accountScope,entry.controller.signal,force).then(raw=>{
    return normalizeOne(raw,subject);
   }).then(async value=>{
    if(!entry.controller.signal.aborted){
     const sources=KEYS.map(k=>value.sources[k]),allBad=sources.every(s=>['unavailable','unsupported'].includes(s.status)),complete=sources.every(s=>s.complete)&&value.identity.hasMore!==true;
     const stored={version:1,accountScope,subjectKey:hash(normalized(subject)),fetchedAt:sourceClock(),ttl:complete?CACHE_TTL:allBad?FAILURE_TTL:PARTIAL_TTL,subject:value};await writeCache(accountScope,name,stored,entry.controller.signal).catch(()=>{});if(!entry.controller.signal.aborted)remember(memory,key,stored,MAP_LIMITS.subjects);
    }return value;
   }).finally(()=>{entry.settled=true;if(inflight.get(key)===entry)inflight.delete(key);});
   entry.promise.catch(()=>{});inflight.set(key,entry);
  }
  return subscribe(entry,signal);
 }
 return {async research(values,{accountScope,signal,force=false}={}){
  const subjects=subjectList(values);if(!scopeOK(accountScope))throw failure('invalid_account_scope');if(typeof force!=='boolean')throw failure('invalid_force');if(signal?.aborted)throw abortError();
  if(!subjects.length)return {version:1,provider:'brand-research',checkedAt:new Date(sourceClock()).toISOString(),status:'not_required',subjects:[]};
  const results=await Promise.all(subjects.map(subject=>one(subject,accountScope,signal,force)));
  const dates=results.flatMap(s=>KEYS.map(k=>s.sources[k].checkedAt)).filter(v=>Number.isFinite(Date.parse(v))).sort();
  return normalizeBrandResearch({version:1,provider:'brand-research',checkedAt:dates[0]||new Date(sourceClock()).toISOString(),status:summaryStatus(results),subjects:results},{subjects,now:sourceClock()});
 }};
}
