import {createMiaoshouService} from './miaoshou-service.mjs';
import {isAbsolute,resolve} from 'node:path';
import {realpath} from 'node:fs/promises';
import {createInterface} from 'node:readline';
import {ensureImageService,readImageServiceProfile,servicePortOccupied,StartupError} from './desktop-launcher.mjs';
import {createLanServer} from './lan-server.mjs';
import {discoverLanAddresses} from './lan-addresses.mjs';
import {createGlobalSettings} from './global-settings.mjs';
import {createHostMaterialStore} from './host-materials.mjs';
import {createHostTemplateStore} from './host-templates.mjs';
import {initializeTemplateLibrary, migrateMiaoshouTemplateLibrary, MIAOSHOU_TEMPLATE_FOLDER} from './seed-template-library.mjs';
import {createAssistantService} from './assistant-service.mjs';
import {canonicalProjectRoot} from './handover-knowledge.mjs';
import {createAdsPowerSettings} from './adspower-settings.mjs';
import {createAdsPowerClient} from './adspower-client.mjs';
import {createTikTokPublishingService} from './tiktok-publishing-service.mjs';
import {createTikTokSellerRpa} from './tiktok-seller-rpa.mjs';
import {createDesignFolderStore,DESIGN_EXPORT_DIRECTORY} from './design-folder-store.mjs';
import {fixedDesignExportFolder,fixedMaterialFolder,legacyConfigHome,migratePodStorage,podTemplateRoot,usesFixedStorage} from './storage-root.mjs';

// BEGIN Existing template library root resolution.
async function resolveExistingTemplateLibraryRoot(requestedRoot){
  try{return await realpath(requestedRoot);}
  catch(error){if(error?.code==='ENOENT')return requestedRoot;throw error;}
}
// END Existing template library root resolution.

const root=await canonicalProjectRoot(import.meta.url);
const emit=value=>process.stdout.write(JSON.stringify(value)+'\n');
const owned={};let stopping=false,app,readyURL,globalSettings,materials,templates,templateLibraryRoot;
function stop(){if(stopping)return;stopping=true;const miaoshouClosing=owned.miaoshou?.close();clearInterval(owned.templateTimer);owned.server?.closeAllConnections?.();owned.server?.close();owned.image?.kill();Promise.allSettled([miaoshouClosing,owned.assistant?.close(),owned.publishing?.close()]).finally(()=>{process.exitCode=0;});setTimeout(()=>process.exit(0),1500).unref();}
process.on('SIGTERM',stop);process.on('SIGINT',stop);
async function handleCommand(request){
  if(request.type==='stop')return stop();
  if(request.type==='open'&&app&&!stopping)return emit({type:'open',launchUrl:readyURL});
  if(request.type==='assistant.open'&&app&&!stopping)return emit({type:'open',launchUrl:readyURL+'#pod-assistant=open'});
  if(request.type==='assistant.retry'&&owned.assistant&&!stopping){const status=await owned.assistant.start();if(status.available&&readyURL&&!stopping)emit({type:'open',launchUrl:readyURL+'#pod-assistant=open'});return;}
  if(!['settings.get','settings.save','settings.inspect','materials.scan','miaoshou.save','miaoshou.probe','adspower.save','adspower.probe'].includes(request.type)||!request.requestId||stopping)return;
  try{
    if(!globalSettings||!materials)throw new Error('启动程序尚未就绪，请稍后重试。');let data;
    if(request.type==='settings.get')data={settings:await globalSettings.read(),miaoshou:await owned.miaoshou.status(),adspower:await owned.adsSettings.publicStatus()};
    if(request.type==='adspower.save')data=await owned.publishing.configureAdsPower(request.settings);
    if(request.type==='adspower.probe')data=await owned.publishing.probeAdsPower();
    if(request.type==='miaoshou.save')data=await owned.miaoshou.configure(request.settings);
    if(request.type==='miaoshou.probe')data=await owned.miaoshou.probe();
    if(request.type==='settings.inspect')data=await globalSettings.inspect(request.token||'');
    if(request.type==='settings.save'){const settings=await globalSettings.save(request.settings);data={settings};void materials.scan().catch(()=>{});}
    if(request.type==='materials.scan'){const result=await materials.scan();data={materialCount:result.count,materialScan:result};}
    emit({type:'settings.result',requestId:request.requestId,ok:true,data});
  }catch(error){emit({type:'settings.result',requestId:request.requestId,ok:false,message:/[一-鿿]/.test(error.message||'')?error.message:'全局设置操作失败，请检查主机文件夹权限、图床权限和网络连接。'});}
}
const commands=createInterface({input:process.stdin});commands.on('close',stop);commands.on('line',line=>{try{void handleCommand(JSON.parse(line.replace(/^\uFEFF/,'')));}catch{}});
try{
  emit({type:'progress',message:'正在启动 POD、GitHub 图床和局域网服务…'});
  const fixedStorage=usesFixedStorage();
  if(fixedStorage){
    if(await servicePortOccupied(5180))throw new StartupError('POD 局域网服务已在运行，请先退出旧版，再启动当前版本。');
    if(await migratePodStorage({onProgress:(name,percent)=>{
      if(name==='miaoshou/local-drafts.sqlite')emit({type:'progress',message:'正在迁移本机商品草稿 '+percent+'%…'});
      else if(name==='global-settings.json'||name==='miaoshou')emit({type:'progress',message:name==='miaoshou'?'正在迁移妙手缓存和本机草稿；首次迁移需要一点时间…':'正在将本机数据迁移到 D:\\Documents\\POD程序包…'});
    }}))
      emit({type:'progress',message:'固定 POD 数据目录已就绪。'});
  }
  await ensureImageService(owned,message=>emit({type:'progress',message}));
  const {authorization,profile}=await readImageServiceProfile();
  const addresses=await discoverLanAddresses();
  globalSettings=createGlobalSettings({serviceAuthorization:authorization,initialProfile:profile.data,...(fixedStorage?{fixedMaterialFolder}:{})});await globalSettings.load();
  materials=createHostMaterialStore({getFolder:globalSettings.getFolder,metadataRoot:fixedStorage?folder=>resolve(folder,'.pod-index'):resolve(globalSettings.root,'materials'),onScanProgress:progress=>emit({type:'material.scan.progress',...progress})});
  // Template initialization runs independently: a slow directory or unavailable
  // seed must not delay the designer, shared materials, or assistant startup.
  const requireTemplates=()=>{if(!templates)throw Object.assign(new Error('主机模板库尚未就绪。'),{name:'HostTemplateError',code:'TEMPLATE_ACCESS',status:503});return templates;};
  const templateStore={
    list:options=>requireTemplates().list(options),
    get:(id,options)=>requireTemplates().get(id,options),
    saveCalibration:(id,patch)=>requireTemplates().saveCalibration(id,patch),
    listRegionPresets:options=>requireTemplates().listRegionPresets(options),
    saveRegionPreset:preset=>requireTemplates().saveRegionPreset(preset),
    listUniversalRegionPresets:options=>requireTemplates().listUniversalRegionPresets(options),
    saveUniversalRegionPreset:(preset,options)=>requireTemplates().saveUniversalRegionPreset(preset,options),
    scan:()=>requireTemplates().scan(),
  };
  const scanTemplates=()=>{if(templates&&!stopping)void templates.scan().catch(()=>{if(!stopping)emit({type:'progress',message:'模板目录暂时无法读取，POD 可继续使用；请检查“模板库”文件夹后重新检索。'});});};
  // The native launcher forwards a version-relative path. Ignore it for the
  // installed data root; tests and explicitly isolated hosts retain overrides.
  const override=fixedStorage?'':String(process.env.POD_TEMPLATE_LIBRARY_ROOT||'').trim();
  const requestedRoot=override&&isAbsolute(override)?resolve(override):podTemplateRoot();
  const designTemplatesReady=(async()=>{
    if(override&&!isAbsolute(override))throw new Error('模板库目录必须使用绝对路径。');
    templateLibraryRoot=await resolveExistingTemplateLibraryRoot(requestedRoot);
    await initializeTemplateLibrary({projectRoot:root,libraryRoot:templateLibraryRoot});
    if(!stopping){
      templates=createHostTemplateStore({projectRoot:root,libraryRoot:templateLibraryRoot,universalGeometry:true,onScanProgress:progress=>{if(!stopping)emit({type:'template.scan.progress',...progress});}});
      if(owned.ready)scanTemplates();
    }
    return templateLibraryRoot;
  })();
  void designTemplatesReady.catch(()=>{if(!stopping)emit({type:'progress',message:'主机模板库暂时无法初始化，POD 可继续使用；请检查完整软件包和模板目录权限。'});});
  owned.assistant=createAssistantService({onStatus:emit,providerRoot:globalSettings.root,learningRoot:resolve(globalSettings.root,'design-learning')});
  const publishingRoot=resolve(globalSettings.root,'publishing');
  const adsSettings=createAdsPowerSettings({root:publishingRoot}),ads=createAdsPowerClient({settings:adsSettings});
  owned.adsSettings=adsSettings;owned.ads=ads;
  owned.publishing=createTikTokPublishingService({root:publishingRoot,settings:adsSettings,ads,rpa:createTikTokSellerRpa({assetRoot:resolve(publishingRoot,'assets')})});
  // A disconnected AdsPower account must not block local design or templates.
  void owned.publishing.ready().catch(()=>emit({type:'progress',message:'多店铺连接尚未就绪，可在工作台的店铺设置中检查；本地设计仍可继续。'}));
  const miaoshouRoot=resolve(globalSettings.root,'miaoshou');
  const legacyMiaoshouRoot=fixedStorage?resolve(legacyConfigHome(),'miaoshou'):miaoshouRoot;
  const listenerBound=Promise.withResolvers();
  const templatesReady=Promise.all([designTemplatesReady,listenerBound.promise]).then(async([libraryRoot])=>{
    if(stopping)return;
    const imported=await migrateMiaoshouTemplateLibrary({legacyRoot:legacyMiaoshouRoot,templateRoot:resolve(libraryRoot,MIAOSHOU_TEMPLATE_FOLDER),reconcileFinalized:true});
    if(imported.conflicts&&!stopping)emit({type:'progress',message:'妙手模板库已启用，发现同名文件时保留了模板库中的现有版本。'});
  });
  void templatesReady.catch(()=>{if(!stopping)emit({type:'progress',message:'妙手模板库未能初始化，请检查“模板库”目录后重启。'});});
  owned.miaoshou=createMiaoshouService({root:miaoshouRoot,templateRoot:resolve(requestedRoot,MIAOSHOU_TEMPLATE_FOLDER),
    templatesReady,findExecutable:owned.assistant.findExecutable,runCodexTask:owned.assistant.runBackgroundTask});
  let designFolderStore;
  if(fixedStorage){
    const directory=await fixedDesignExportFolder(DESIGN_EXPORT_DIRECTORY);
    designFolderStore=createDesignFolderStore({directory});
  }
  app=createLanServer({serviceAuthorization:authorization,addresses,settingsStore:globalSettings,materialStore:materials,templateStore,assistantService:owned.assistant,publishingService:owned.publishing,miaoshouService:owned.miaoshou,...(designFolderStore?{designFolderStore}:{})});owned.server=app.server;
  await new Promise((done,reject)=>{app.server.once('error',reject);app.server.listen(5180,'0.0.0.0',()=>{app.server.off('error',reject);done();});});
  listenerBound.resolve();
  readyURL=`http://${addresses[0]||'127.0.0.1'}:5180/`;
  const assistant=await owned.assistant.start();
  if(!stopping){
    emit({type:'ready',url:readyURL,localUrl:'http://127.0.0.1:5180/',launchUrl:readyURL,manualPath:resolve(root,'docs/POD局域网版操作手册.html'),message:profile.data.configured?'POD 和 GitHub 图床已就绪，局域网免密码访问。':'POD 已就绪，局域网免密码访问；请在启动程序“全局设置”配置图床和素材目录。',addresses:addresses.map(ip=>`http://${ip}:5180/`),assistant});
    owned.ready=true;scanTemplates();owned.templateTimer=setInterval(scanTemplates,15000);owned.templateTimer.unref();
    void materials.scan().catch(()=>emit({type:'progress',message:'共享素材目录暂时无法读取，请在全局设置中选择可用文件夹。'}));
  }
}catch(error){emit({type:'error',message:error.code==='EADDRINUSE'?'5180 端口已被占用，请关闭已启动的 POD 软件或占用该端口的程序后重试。':error instanceof StartupError||error.code==='POD_STORAGE_INITIALIZATION'?error.message:'启动失败，请检查软件文件、本机服务和 Windows 网络设置。'});stop();}
