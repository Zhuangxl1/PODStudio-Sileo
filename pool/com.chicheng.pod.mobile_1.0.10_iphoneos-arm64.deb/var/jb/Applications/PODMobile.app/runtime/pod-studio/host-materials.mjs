import {createHash, randomBytes} from 'node:crypto';
import {constants} from 'node:fs';
import {copyFile, link, lstat, mkdir, open, readFile, readdir, realpath, rename, unlink, writeFile} from 'node:fs/promises';
import {homedir} from 'node:os';
import {basename, dirname, extname, isAbsolute, join, relative, resolve, sep, win32} from 'node:path';
import {createInflate} from 'node:zlib';
import {materialIdentityPolicy,namedMaterialFilename,namedMaterialIdentityKey} from './dist/material-identity.js';

const MAX_BYTES = 25 * 1024 * 1024, MAX_PIXELS = 40_000_000;
const MAX_FILES = 10_000, MAX_ENTRIES = 100_000;
const EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp']);
const IMAGE_EXTENSIONS = new Set([...EXTENSIONS, '.avif', '.bmp', '.gif', '.heic', '.heif', '.ico', '.psd', '.svg', '.tif', '.tiff']);
const TYPES = {'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp'};
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const idValid = id => typeof id === 'string' && /^[a-f0-9]{64}$/.test(id);
const within = (root, path) => path === root || path.startsWith(root + sep);
const portable = path => path.split(sep).join('/');
const error = (message, code = 'MATERIAL_INVALID', status = 400) => Object.assign(new Error(message), {name: 'HostMaterialError', code, status});
const invalid = () => error('素材文件损坏或格式不符，请选择有效的 PNG、JPG 或 WebP 图片。');
function dimensions(width, height) {
  if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width < 1 || height < 1 || width * height > MAX_PIXELS) {
    throw error('素材尺寸无效，每张最多支持 4000 万像素。', 'MATERIAL_DIMENSIONS');
  }
  return {width, height};
}

const crcTable = Uint32Array.from({length: 256}, (_, value) => {
  for (let i = 0; i < 8; i++) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});
function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

async function png(bytes) {
  if (bytes.length < 57 || !bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) throw invalid();
  let offset = 8, width, height, depth, color, interlace, palette = false, seenData = false, closedData = false, ended = false;
  const compressed = [];
  while (offset < bytes.length) {
    if (offset + 12 > bytes.length) throw invalid();
    const length = bytes.readUInt32BE(offset), end = offset + 12 + length;
    if (end > bytes.length) throw invalid();
    const type = bytes.toString('ascii', offset + 4, offset + 8), data = bytes.subarray(offset + 8, end - 4);
    if (!/^[A-Za-z]{2}[A-Z][A-Za-z]$/.test(type) || crc32(bytes.subarray(offset + 4, end - 4)) !== bytes.readUInt32BE(end - 4)) throw invalid();
    if (offset === 8 && type !== 'IHDR') throw invalid();
    if (type === 'IHDR') {
      if (offset !== 8 || length !== 13) throw invalid();
      width = data.readUInt32BE(0); height = data.readUInt32BE(4); dimensions(width, height);
      depth = data[8]; color = data[9]; interlace = data[12];
      const allowed = {0: [1, 2, 4, 8, 16], 2: [8, 16], 3: [1, 2, 4, 8], 4: [8, 16], 6: [8, 16]};
      if (!allowed[color]?.includes(depth) || data[10] !== 0 || data[11] !== 0 || interlace > 1) throw invalid();
    } else if (type === 'PLTE') {
      if (seenData || palette || !length || length % 3 || length > 768 || color === 0 || color === 4 || (color === 3 && length / 3 > 2 ** depth)) throw invalid();
      palette = true;
    } else if (type === 'IDAT') {
      if (closedData || (color === 3 && !palette)) throw invalid();
      seenData = true; compressed.push(data);
    } else if (type === 'IEND') {
      if (length || !seenData || end !== bytes.length) throw invalid();
      ended = true;
    } else {
      if (type[0] === type[0].toUpperCase()) throw invalid();
      if (seenData) closedData = true;
    }
    offset = end;
  }
  if (!ended || !compressed.some(chunk => chunk.length)) throw invalid();
  const channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[color], rows = [];
  const passes = interlace ? [[0, 0, 8, 8], [4, 0, 8, 8], [0, 4, 4, 8], [2, 0, 4, 4], [0, 2, 2, 4], [1, 0, 2, 2], [0, 1, 1, 2]] : [[0, 0, 1, 1]];
  let expected = 0;
  for (const [x, y, dx, dy] of passes) {
    const w = Math.max(0, Math.ceil((width - x) / dx)), h = Math.max(0, Math.ceil((height - y) / dy));
    if (!w || !h) continue;
    const rowBytes = Math.ceil(w * depth * channels / 8) + 1;
    rows.push({rowBytes, count: h}); expected += rowBytes * h;
  }
  const input = Buffer.concat(compressed), inflater = createInflate();
  let count = 0, pass = 0, rowOffset = 0, row = 0;
  inflater.end(input);
  try {
    for await (const chunk of inflater) {
      count += chunk.length;
      if (count > expected) throw invalid();
      for (let i = 0; i < chunk.length;) {
        if (pass >= rows.length || (rowOffset === 0 && chunk[i] > 4)) throw invalid();
        const take = Math.min(chunk.length - i, rows[pass].rowBytes - rowOffset);
        rowOffset += take; i += take;
        if (rowOffset === rows[pass].rowBytes) {
          rowOffset = 0; row++;
          if (row === rows[pass].count) { pass++; row = 0; }
        }
      }
    }
    if (count !== expected || inflater.bytesWritten !== input.length) throw invalid();
  } catch { throw invalid(); }
  finally { inflater.destroy(); }
  return {mime: 'image/png', ...dimensions(width, height)};
}

function jpeg(bytes) {
  if (bytes.length < 20 || bytes[0] !== 0xff || bytes[1] !== 0xd8) throw invalid();
  let offset = 2, foundFrame = false, foundScan = false, width, height, frameMarker;
  const componentsById = new Map(), quantization = new Set(), dcTables = new Set(), acTables = new Set();
  while (offset < bytes.length) {
    if (bytes[offset++] !== 0xff) throw invalid();
    while (bytes[offset] === 0xff) offset++;
    const marker = bytes[offset++];
    if (marker === 0xd9) {
      if (!foundFrame || !foundScan || offset !== bytes.length) throw invalid();
      return {mime: 'image/jpeg', ...dimensions(width, height)};
    }
    if (!marker || marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7) || marker === 1 || offset + 2 > bytes.length) throw invalid();
    const length = bytes.readUInt16BE(offset), start = offset + 2, end = offset + length;
    if (length < 2 || end > bytes.length) throw invalid();
    const isFrame = marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker);
    if (isFrame) {
      if (foundFrame || length < 11 || ![0xc0, 0xc1, 0xc2].includes(marker) || bytes[start] !== 8) throw invalid();
      frameMarker = marker;
      height = bytes.readUInt16BE(start + 1); width = bytes.readUInt16BE(start + 3); dimensions(width, height);
      const components = bytes[start + 5];
      if (![1, 3, 4].includes(components) || length !== 8 + 3 * components) throw invalid();
      for (let i = 0; i < components; i++) {
        const sampling = bytes[start + 7 + i * 3];
        if (!(sampling >> 4) || (sampling >> 4) > 4 || !(sampling & 15) || (sampling & 15) > 4 || bytes[start + 8 + i * 3] > 3) throw invalid();
        const id = bytes[start + 6 + i * 3];
        if (componentsById.has(id)) throw invalid();
        componentsById.set(id, bytes[start + 8 + i * 3]);
      }
      foundFrame = true;
    } else if (marker === 0xdb) {
      let position = start;
      while (position < end) {
        const descriptor = bytes[position++], precision = descriptor >> 4, table = descriptor & 15;
        if (precision > 1 || table > 3 || position + 64 * (precision + 1) > end) throw invalid();
        for (let i = 0; i < 64; i++, position += precision + 1) if (!(precision ? bytes.readUInt16BE(position) : bytes[position])) throw invalid();
        quantization.add(table);
      }
      if (position !== end || position === start) throw invalid();
    } else if (marker === 0xc4) {
      let position = start;
      while (position < end) {
        if (position + 17 > end) throw invalid();
        const descriptor = bytes[position++], type = descriptor >> 4, table = descriptor & 15;
        if (type > 1 || table > 3) throw invalid();
        let symbols = 0, available = 1;
        for (let i = 0; i < 16; i++) { const count = bytes[position++]; symbols += count; available = available * 2 - count; if (available < 0) throw invalid(); }
        if (!symbols || symbols > 256 || position + symbols > end) throw invalid();
        for (let i = 0; i < symbols; i++) {
          const symbol = bytes[position++];
          if (type === 0 ? symbol > 11 : (symbol & 15) > 10) throw invalid();
        }
        (type ? acTables : dcTables).add(table);
      }
      if (position !== end || position === start) throw invalid();
    } else if (marker === 0xdd) {
      if (length !== 4) throw invalid();
    } else if (marker !== 0xda && marker !== 0xfe && !(marker >= 0xe0 && marker <= 0xef)) {
      throw invalid();
    }
    offset = end;
    if (marker === 0xda) {
      if (!foundFrame || length < 8 || bytes[start] < 1 || bytes[start] > 4 || length !== 6 + 2 * bytes[start]) throw invalid();
      const components = bytes[start], spectralStart = bytes[end - 3], spectralEnd = bytes[end - 2], approximation = bytes[end - 1];
      if (frameMarker !== 0xc2 && (spectralStart !== 0 || spectralEnd !== 63 || approximation !== 0)) throw invalid();
      if (frameMarker === 0xc2 && (spectralEnd > 63 || spectralStart > spectralEnd || (spectralStart === 0 && spectralEnd !== 0) ||
          (spectralStart > 0 && components !== 1) || (approximation >> 4) > 13 || (approximation & 15) > 13 ||
          ((approximation >> 4) && (approximation >> 4) !== (approximation & 15) + 1))) throw invalid();
      const scanComponents = new Set();
      for (let i = 0; i < components; i++) {
        const id = bytes[start + 1 + i * 2], table = bytes[start + 2 + i * 2];
        if (!componentsById.has(id) || scanComponents.has(id) || !quantization.has(componentsById.get(id)) || (table >> 4) > 3 || (table & 15) > 3) throw invalid();
        scanComponents.add(id);
        if (spectralStart === 0 && !(approximation >> 4) && !dcTables.has(table >> 4)) throw invalid();
        if (spectralEnd > 0 && !acTables.has(table & 15)) throw invalid();
      }
      foundScan = true;
      const entropyStart = offset;
      while (offset < bytes.length) {
        if (bytes[offset] !== 0xff) { offset++; continue; }
        let next = offset + 1;
        while (bytes[next] === 0xff) next++;
        if (next >= bytes.length) throw invalid();
        if (bytes[next] === 0 || (bytes[next] >= 0xd0 && bytes[next] <= 0xd7)) { offset = next + 1; continue; }
        break;
      }
      if (offset === entropyStart) throw invalid();
    }
  }
  throw invalid();
}

function webp(bytes) {
  if (bytes.length < 26 || bytes.toString('ascii', 0, 4) !== 'RIFF' || bytes.toString('ascii', 8, 12) !== 'WEBP' || bytes.readUInt32LE(4) + 8 !== bytes.length) throw invalid();
  let offset = 12, image, canvas, extended = false;
  while (offset < bytes.length) {
    if (offset + 8 > bytes.length) throw invalid();
    const type = bytes.toString('ascii', offset, offset + 4), length = bytes.readUInt32LE(offset + 4), start = offset + 8, end = start + length;
    if (end + (length & 1) > bytes.length || ((length & 1) && bytes[end] !== 0)) throw invalid();
    if (type === 'VP8X') {
      if (offset !== 12 || extended || length !== 10 || (bytes[start] & 0xc3) || bytes[start + 1] || bytes[start + 2] || bytes[start + 3] || (bytes[start] & 2)) throw invalid();
      extended = true;
      canvas = dimensions(bytes.readUIntLE(start + 4, 3) + 1, bytes.readUIntLE(start + 7, 3) + 1);
    } else if (type === 'VP8 ') {
      if (image || length < 11 || (bytes[start] & 1) || ((bytes[start] >> 1) & 7) > 3 || !(bytes[start] & 16) || bytes[start + 3] !== 0x9d || bytes[start + 4] !== 0x01 || bytes[start + 5] !== 0x2a) throw invalid();
      const partition = bytes.readUIntLE(start, 3) >>> 5;
      if (partition < 1 || partition + 10 > length) throw invalid();
      image = dimensions(bytes.readUInt16LE(start + 6) & 0x3fff, bytes.readUInt16LE(start + 8) & 0x3fff);
    } else if (type === 'VP8L') {
      if (image || length < 6 || bytes[start] !== 0x2f || (bytes[start + 4] & 0xe0)) throw invalid();
      const bits = bytes.readUInt32LE(start + 1);
      image = dimensions((bits & 0x3fff) + 1, ((bits >>> 14) & 0x3fff) + 1);
    } else if (type === 'ANIM' || type === 'ANMF') throw error('共享素材暂不支持动态 WebP，请转换为静态图片。', 'MATERIAL_UNSUPPORTED');
    else if (!extended || !['ALPH', 'ICCP', 'EXIF', 'XMP '].includes(type)) throw invalid();
    offset = end + (length & 1);
  }
  if (!image || (canvas && (canvas.width !== image.width || canvas.height !== image.height))) throw invalid();
  return {mime: 'image/webp', ...image};
}

async function inspect(input, declaredMime = '') {
  const bytes = Buffer.isBuffer(input) ? input : input instanceof Uint8Array ? Buffer.from(input) : null;
  if (!bytes || !bytes.length) throw invalid();
  if (bytes.length > MAX_BYTES) throw error('素材文件每张最多 25 MB。', 'MATERIAL_TOO_LARGE', 413);
  let result;
  if (bytes[0] === 137) result = await png(bytes);
  else if (bytes[0] === 255) result = jpeg(bytes);
  else if (bytes.toString('ascii', 0, 4) === 'RIFF') result = webp(bytes);
  else throw invalid();
  if (declaredMime && declaredMime.toLowerCase() !== result.mime) throw invalid();
  return {...result, bytes};
}

// Shared host-side validation; exporting this does not alter material behavior.
export {inspect as inspectHostImage};

function safeRelative(value) {
  if (typeof value !== 'string' || !value || value.includes('\0') || isAbsolute(value) || win32.isAbsolute(value)) return false;
  return !value.replace(/\\/g, '/').split('/').some(part => !part || part === '.' || part === '..');
}
function fileStem(value) {
  const name = win32.basename(String(value || '未命名素材').replace(/\//g, '\\'));
  let stem = basename(name, extname(name)).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/[. ]+$/g, '').trim();
  stem = Array.from(stem || '未命名素材').slice(0, 80).join('');
  return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(stem) ? '素材_' + stem : stem;
}
const publicRecord = record => ({id: record.id, name: record.name, width: record.width, height: record.height, size: record.size, mime: record.mime,
  ...(record.identityPolicy==='name-and-content'?{identityPolicy:record.identityPolicy,contentSha256:record.contentSha256}:{}),
  sourcePath: record.trashed ? record.originalPath || record.path : record.path, createdAt: record.createdAt, updatedAt: record.updatedAt, trashed: !!record.trashed});

/** Host-owned shared originals. Browser clients address records by SHA-256 only. */
export function createHostMaterialStore({getFolder, metadataRoot = join(process.env.APPDATA || join(homedir(), '.config'), 'PODStudio', 'materials'), onScanProgress} = {}) {
  if (typeof getFolder !== 'function') throw new TypeError('getFolder must be a function');
  const states = new Map(), pendingContexts = new Map();
  const sanitize = cause => cause?.name === 'HostMaterialError' ? cause : error('共享素材读写失败，请检查主机素材文件夹的权限和可用空间。', 'MATERIAL_ACCESS', 503);
  const protectedCall = action => {
    try { return Promise.resolve(action()).catch(cause => {throw sanitize(cause);}); }
    catch (cause) { return Promise.reject(sanitize(cause)); }
  };
  const serialized = (state, action) => {
    const next = state.queue.then(action).catch(cause => {throw sanitize(cause);});
    state.queue = next.catch(() => {}); return next;
  };
  const identity = info => ({size: info.size, mtimeMs: info.mtimeMs, ctimeMs: info.ctimeMs, dev: info.dev, ino: info.ino});
  const sameIdentity = (cached, info) => cached?.validated === true && ['size', 'mtimeMs', 'ctimeMs', 'dev', 'ino'].every(key => Number.isFinite(cached[key]) && cached[key] === info[key]);
  const changed = (state, id) => state.versions.set(id, ++state.version);
  function selectedFolder(configured) {
    if (typeof configured !== 'string' || !configured.trim()) throw error('请先在启动软件中设置全局素材文件夹。', 'MATERIAL_FOLDER_REQUIRED', 409);
    if (configured.includes('\ufffd')) throw error('素材文件夹地址出现乱码，请在启动软件中重新选择正确文件夹并保存。', 'MATERIAL_ACCESS', 503);
    if (!isAbsolute(configured)) throw error('素材文件夹地址无效，请在启动软件中重新选择文件夹。', 'MATERIAL_ACCESS', 503);
    return resolve(configured);
  }
  async function contextForFolder(configured) {
    const selected = selectedFolder(configured);
    let root;
    // Creating a folder belongs to saving a deliberate native setting. A scan
    // must never silently create an empty directory from a mistyped address.
    try { root = await realpath(selected); if (!(await lstat(root)).isDirectory()) throw new Error(); }
    catch { throw error('全局素材文件夹不存在或无法访问，请在启动软件中重新选择可读写的文件夹。', 'MATERIAL_ACCESS', 503); }
    const key = process.platform === 'win32' ? root.toLowerCase() : root;
    if (states.has(key)) return states.get(key);
    if (pendingContexts.has(key)) return pendingContexts.get(key);
    const loading = loadContext(root, key);
    pendingContexts.set(key, loading);
    try { return await loading; }
    finally { if (pendingContexts.get(key) === loading) pendingContexts.delete(key); }
  }
  async function loadContext(root, key) {
    const indexRoot=typeof metadataRoot==='function'?await metadataRoot(root):metadataRoot;
    const state = {root, indexFile: join(resolve(indexRoot), hash(key) + '.json'), records: new Map(), files: new Map(), needsScan: true,
      scannedAt: null, revision: randomBytes(16).toString('hex'), queue: Promise.resolve(), versions: new Map(), version: 0,
      scanning: false, scanPromise: null, scanProgress: null, scanError: ''};
    try {
      const data = JSON.parse(await readFile(state.indexFile, 'utf8'));
      if (data.version === 1 && Array.isArray(data.records)) for (const record of data.records.slice(0, MAX_FILES * 2)) {
        if (idValid(record.id) && (record.identityPolicy===undefined||record.identityPolicy==='name-and-content'&&idValid(record.contentSha256)&&typeof record.name==='string'&&record.name&&record.id===hash(namedMaterialIdentityKey(record.contentSha256,record.name))) && safeRelative(record.path) && (!record.originalPath || safeRelative(record.originalPath)) && TYPES[record.mime] &&
          typeof record.name === 'string' && record.name.length <= 512 && Number.isSafeInteger(record.size) && record.size > 0 && record.size <= MAX_BYTES &&
          Number.isSafeInteger(record.width) && record.width > 0 && Number.isSafeInteger(record.height) && record.height > 0 && record.width * record.height <= MAX_PIXELS &&
          typeof record.createdAt === 'string' && Number.isFinite(Date.parse(record.createdAt)) && typeof record.updatedAt === 'string' && Number.isFinite(Date.parse(record.updatedAt))) state.records.set(record.id, record);
      }
      state.scannedAt = typeof data.scannedAt === 'string' ? data.scannedAt : null;
      if (typeof data.revision === 'string' && /^[a-f0-9]{32}$/.test(data.revision)) state.revision = data.revision;
      if (Array.isArray(data.files)) for (const file of data.files.slice(0, MAX_FILES)) {
        if (idValid(file.id) && safeRelative(file.path) && TYPES[file.mime] && file.validated === true &&
          ['size', 'mtimeMs', 'ctimeMs', 'dev', 'ino', 'width', 'height'].every(key => Number.isFinite(file[key])) &&
          file.size > 0 && file.size <= MAX_BYTES && file.width > 0 && file.height > 0 && file.width * file.height <= MAX_PIXELS) state.files.set(file.path, file);
      }
      for (const record of state.records.values()) if (!record.trashed && record.validated === true && !state.files.has(record.path)) state.files.set(record.path, record);
    } catch {}
    states.set(key, state); return state;
  }
  const context = async () => contextForFolder(await getFolder());
  async function save(state) {
    await mkdir(dirname(state.indexFile), {recursive: true});
    const temporary = state.indexFile + '.' + randomBytes(8).toString('hex') + '.tmp';
    // A distinct revision makes uploads and reversible deletions visible to LAN pollers,
    // including multiple mutations performed within the same millisecond.
    state.revision = randomBytes(16).toString('hex');
    try { await writeFile(temporary, JSON.stringify({version: 1, revision: state.revision, scannedAt: state.scannedAt, records: [...state.records.values()], files: [...state.files.values()].slice(0, MAX_FILES)}), {flag: 'wx', mode: 0o600}); await rename(temporary, state.indexFile); }
    finally { await unlink(temporary).catch(() => {}); }
  }
  async function checkedPath(state, relativePath) {
    if (!safeRelative(relativePath)) throw invalid();
    const path = resolve(state.root, relativePath);
    if (!within(state.root, path)) throw invalid();
    let cursor = state.root;
    for (const part of relativePath.replace(/\\/g, '/').split('/')) {
      cursor = join(cursor, part);
      if ((await lstat(cursor)).isSymbolicLink()) throw invalid();
    }
    const actual = await realpath(path), info = await lstat(actual);
    if (!within(state.root, actual) || !info.isFile() || info.size > MAX_BYTES || !info.size) throw invalid();
    return {path: actual, info};
  }
  async function scanState(state) {
    // Disk traversal and image validation deliberately happen outside the write
    // queue. Only short batches enter that queue to publish verified records.
    const baseline = new Map([...state.records].map(([id, record]) => [id, {...record}])), versions = new Map(state.versions);
    const baselinePaths=new Map([...baseline.values()].filter(record=>!record.trashed).map(record=>[record.path,record]));
    const records = new Map(), files = new Map(), pending = new Map(), stack = [{path: state.root, depth: 0}];
    const skippedReasons = {invalidFormat: 0, unsupportedFormat: 0, tooLarge: 0, invalidDimensions: 0, accessDenied: 0, symlink: 0, depthLimit: 0, other: 0};
    let skipped = 0, scannedEntries = 0, foundImageFiles = 0, supportedImageFiles = 0, validImageFiles = 0, duplicateFiles = 0, limited = false;
    let lastSaved = Date.now();
    const progress = stage => {
      const update = {stage, scannedEntries: Math.min(scannedEntries, MAX_ENTRIES), supportedImageFiles, validImageFiles, duplicateFiles};
      state.scanProgress = update;
      if (typeof onScanProgress !== 'function') return;
      try {
        // Observers receive counts only, never host paths or filenames. A slow
        // or failed native UI observer must not delay or fail the actual scan.
        const observed = onScanProgress({...update});
        if (observed && typeof observed.then === 'function') Promise.resolve(observed).catch(() => {});
      } catch {}
    };
    progress('scanning');
    const skip = reason => {skipped++; skippedReasons[reason]++;};
    const reasonFor = cause => cause?.code === 'MATERIAL_TOO_LARGE' ? 'tooLarge' : cause?.code === 'MATERIAL_DIMENSIONS' ? 'invalidDimensions' :
      cause?.code === 'MATERIAL_UNSUPPORTED' ? 'unsupportedFormat' : cause?.code === 'MATERIAL_INVALID' ? 'invalidFormat' :
      ['MATERIAL_ACCESS', 'EACCES', 'EPERM', 'ENOENT', 'ENOTDIR', 'EIO', 'EBUSY', 'EMFILE', 'ENFILE'].includes(cause?.code) ? 'accessDenied' : 'other';
    const modifiedDuringScan = id => state.versions.get(id) !== versions.get(id);
    const publish = async (final = false) => {
      const batch = new Map(pending); pending.clear();
      if (!final && !batch.size) return;
      await serialized(state, async () => {
        let updated = false;
        for (const [id, record] of batch) {
          if (modifiedDuringScan(id) || state.records.get(id)?.trashed) continue;
          const current = state.records.get(id);
          // Keep an already indexed path for an identical image, instead of
          // switching names and locations whenever traversal order changes.
          if (!current || !files.has(current.path)) {state.records.set(id, record); updated = true;}
        }
        if (final) {
          for (const [id, current] of state.records) {
            if (current.trashed || modifiedDuringScan(id) || records.has(id) || limited) continue;
            state.records.delete(id); updated = true;
          }
          // Mutations publish their own identities immediately. A scan started
          // before an upload/trash/restore may never replace those identities.
          const mergedFiles = new Map([...files].filter(([, cached]) => !modifiedDuringScan(cached.id)));
          for (const [path, cached] of state.files) if (modifiedDuringScan(cached.id)) mergedFiles.set(path, cached);
          state.files = mergedFiles;
          state.scannedAt = new Date().toISOString();
        }
        if (updated) state.revision = randomBytes(16).toString('hex');
        if (final || Date.now() - lastSaved >= 1500) {await save(state); lastSaved = Date.now();}
      });
    };
    while (stack.length && !limited) {
      const current = stack.pop();
      let entries;
      try {
        if ((await lstat(current.path)).isSymbolicLink() || !within(state.root, await realpath(current.path))) {skip('symlink'); continue;}
        entries = await readdir(current.path, {withFileTypes: true});
      }
      catch {
        if (current.depth === 0) throw error('无法读取全局素材文件夹，请检查目录权限、网络磁盘或移动硬盘连接。', 'MATERIAL_ACCESS', 503);
        skip('accessDenied'); continue;
      }
      for (const entry of entries) {
        if (++scannedEntries > MAX_ENTRIES) { limited = true; break; }
        if (scannedEntries % 25 === 0) {
          await publish(); progress('scanning');
          await new Promise(done => setImmediate(done));
        }
        if (entry.name === '.pod-trash' || entry.name === '.pod-index' || entry.name.startsWith('.pod-upload-')) continue;
        const path = join(current.path, entry.name);
        try {
          // Most folders also contain non-image documents. Avoid stat/realpath
          // calls for ordinary files whose names cannot enter the library.
          if (entry.isFile() && !IMAGE_EXTENSIONS.has(extname(entry.name).toLowerCase())) continue;
          const info = await lstat(path);
          if (info.isSymbolicLink() || !within(state.root, await realpath(path))) { skip('symlink'); continue; }
          if (info.isDirectory()) { if (current.depth < 64) stack.push({path, depth: current.depth + 1}); else skip('depthLimit'); continue; }
          if (!info.isFile()) continue;
          const extension = extname(entry.name).toLowerCase();
          if (!IMAGE_EXTENSIONS.has(extension)) continue;
          foundImageFiles++;
          if (!EXTENSIONS.has(extension)) { skip('unsupportedFormat'); continue; }
          if (++supportedImageFiles > MAX_FILES) { limited = true; break; }
          if (!info.size) { skip('invalidFormat'); continue; }
          if (info.size > MAX_BYTES) { skip('tooLarge'); continue; }
          const sourcePath = portable(relative(state.root, path)), checked = await checkedPath(state, sourcePath), cached = state.files.get(sourcePath);
          let image, id;
          if (sameIdentity(cached, checked.info)) {image = cached; id = cached.id;}
          else {
            image = await inspect(await readFile(checked.path)); id = hash(image.bytes);
            const after = await lstat(checked.path);
            if (!sameIdentity({validated: true, ...identity(checked.info)}, after) || image.bytes.length !== after.size) throw error('素材文件在扫描期间发生变化，请稍后重新扫描。', 'MATERIAL_ACCESS', 503);
          }
          const named=baselinePaths.get(sourcePath);
          const contentSha256=image.bytes?hash(image.bytes):cached?.contentSha256||id;
          const naming=named?.identityPolicy==='name-and-content'&&named.contentSha256===contentSha256
            ?{identityPolicy:'name-and-content',contentSha256}:{};
          if(naming.identityPolicy) id=named.id;
          validImageFiles++;
          const file = {id, ...naming, path: sourcePath, width: image.width, height: image.height, mime: image.mime, validated: true, ...identity(checked.info)};
          files.set(sourcePath, file);
          const old = baseline.get(id), existing = records.get(id);
          if (existing || old?.trashed || state.records.get(id)?.trashed) {duplicateFiles++; continue;}
          const timestamp = new Date().toISOString(), record = {...file, name: old?.name || entry.name,
            createdAt: old?.createdAt || info.birthtime.toISOString(), updatedAt: old?.updatedAt || timestamp, trashed: false};
          records.set(id, record); pending.set(id, record);
        } catch (cause) { skip(reasonFor(cause)); }
      }
    }
    await publish(true);
    const count = [...state.records.values()].filter(record => !record.trashed).length;
    const status = count ? 'ok' : foundImageFiles && !supportedImageFiles ? 'no-supported-images' : foundImageFiles || skipped ? 'all-skipped' : 'empty';
    const message = count ? `已载入 ${count} 张素材${duplicateFiles ? `，合并 ${duplicateFiles} 个重复文件` : ''}${skipped ? `，另有 ${skipped} 项未载入` : ''}。` :
      status === 'empty' ? '目录可正常读取，但未发现图片文件。可上传图片，或检查是否选中了正确目录。' :
      status === 'no-supported-images' ? `发现 ${foundImageFiles} 个图片文件，但格式暂不支持；请使用 PNG、JPG 或静态 WebP。` :
      `未载入素材：发现 ${foundImageFiles} 个图片文件，${skipped} 项因格式、尺寸或访问问题被跳过，请查看扫描详情。`;
    progress('complete');
    return {count, foundImageFiles, supportedImageFiles, validImageFiles, duplicateFiles, skipped, skippedReasons,
      scannedEntries: Math.min(scannedEntries, MAX_ENTRIES), limited, scannedAt: state.scannedAt, status, message: message + (limited ? ' 扫描已达到文件数量限制，请分目录整理后再试。' : '')};
  }
  function startScan(state) {
    if (state.scanPromise) return state.scanPromise;
    state.needsScan = false; state.scanning = true; state.scanError = '';
    const pending = Promise.resolve().then(() => scanState(state)).catch(cause => {
      const safe = sanitize(cause); state.scanError = safe.message;
      state.scanProgress = {...state.scanProgress, stage: 'failed'}; throw safe;
    });
    state.scanPromise = pending;
    const finish = () => {if (state.scanPromise === pending) {state.scanPromise = null; state.scanning = false;}};
    void pending.then(finish, finish);
    return pending;
  }
  async function ready(background = false) {
    const state = await context();
    if (background && state.needsScan) void startScan(state).catch(() => {});
    return state;
  }
  async function recordPath(state, record) {
    const checked = await checkedPath(state, record.path);
    // Serving originals always verifies actual bytes. Scan metadata caching
    // cannot make a changed host file available under a previously trusted ID.
    const bytes = await readFile(checked.path);
    if (bytes.length !== record.size || hash(bytes) !== (record.identityPolicy==='name-and-content'?record.contentSha256:record.id)) return null;
    if (record.validated !== true) {
      const image = await inspect(bytes);
      if (image.width !== record.width || image.height !== record.height || image.mime !== record.mime) return null;
    }
    return checked.path;
  }
  async function placeFile(state, bytes, filename, folder = '') {
    if (folder && !safeRelative(folder)) throw invalid();
    let directory = state.root;
    for (const part of folder.replace(/\\/g, '/').split('/').filter(Boolean)) {
      directory = join(directory, part);
      try { await mkdir(directory); } catch (cause) { if (cause.code !== 'EEXIST') throw cause; }
      const info = await lstat(directory);
      if (info.isSymbolicLink() || !info.isDirectory() || !within(state.root, await realpath(directory))) throw invalid();
    }
    const temporary = join(directory, '.pod-upload-' + randomBytes(16).toString('hex') + '.tmp');
    const handle = await open(temporary, 'wx', 0o600);
    try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
    const extension = extname(filename), stem = basename(filename, extension);
    try {
      for (let attempt = 0; attempt < 1000; attempt++) {
        const candidate = join(directory, stem + (attempt ? '_' + (attempt + 1) : '') + extension);
        try {
          try { await link(temporary, candidate); }
          catch (cause) {
            if (!['EPERM', 'ENOTSUP', 'EINVAL', 'EXDEV'].includes(cause.code)) throw cause;
            await copyFile(temporary, candidate, constants.COPYFILE_EXCL);
          }
          return portable(relative(state.root, candidate));
        } catch (cause) { if (cause.code !== 'EEXIST') throw cause; }
      }
      throw error('素材文件重名过多，请更换素材名称后重试。');
    } finally { await unlink(temporary).catch(() => {}); }
  }
  async function moveFile(state, from, filename, folder = '') {
    const checked = await checkedPath(state, from), bytes = await readFile(checked.path);
    const destination = await placeFile(state, bytes, filename, folder);
    try { await unlink(checked.path); }
    catch (cause) { await unlink(resolve(state.root, destination)).catch(() => {}); throw cause; }
    return destination;
  }
  function scan() {
    // Capture the selection at invocation; each canonical folder owns its own
    // scan and write queue, so another folder cannot block or overwrite it.
    let selection;
    try { selection = getFolder(); } catch (cause) { return Promise.reject(sanitize(cause)); }
    return Promise.resolve(selection).then(contextForFolder).then(startScan).catch(cause => {throw sanitize(cause);});
  }
  const summaryFor = state => ({total: [...state.records.values()].filter(record => !record.trashed).length,
    trashCount: [...state.records.values()].filter(record => record.trashed).length, revision: state.revision, scannedAt: state.scannedAt,
    scanning: state.scanning, scanProgress: state.scanProgress ? {...state.scanProgress} : null, scanError: state.scanError});
  const summary = () => protectedCall(async () => summaryFor(await ready(true)));
  return {
    list: (options = {}) => protectedCall(async () => {
      const state = await ready(true), query = String(options.query || '').trim().toLocaleLowerCase().slice(0, 256);
      const pageSize = Math.min(200, Math.max(1, Math.floor(Number(options.pageSize) || 60))), requestedPage = Math.max(1, Math.floor(Number(options.page) || 1));
      const records = [...state.records.values()].filter(record => !!record.trashed === !!options.trash && (!query || (record.name + '\n' + (record.originalPath || record.path)).toLocaleLowerCase().includes(query)))
        .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt) || a.name.localeCompare(b.name));
      const page = Math.min(requestedPage, Math.max(1, Math.ceil(records.length / pageSize)));
      return {...summaryFor(state), items: records.slice((page - 1) * pageSize, page * pageSize).map(publicRecord), total: records.length, page, pageSize, folderConfigured: true};
    }),
    summary, status: summary,
    put: input => protectedCall(async () => {
      let policy;try{policy=materialIdentityPolicy(input?.identityPolicy);}catch(cause){throw error(cause.message);}
      const [state, image] = await Promise.all([ready(), inspect(input?.bytes, input?.mime || '')]);
      const contentSha256=hash(image.bytes);
      const originalName=policy==='name-and-content'?namedMaterialFilename(input?.name,TYPES[image.mime]):win32.basename(String(input?.name || '未命名素材').replace(/\//g, '\\')).slice(0, 255) || '未命名素材';
      const id=policy==='name-and-content'?hash(namedMaterialIdentityKey(contentSha256,originalName)):contentSha256;
      if ((input?.width !== undefined && input.width !== image.width) || (input?.height !== undefined && input.height !== image.height)) throw invalid();
      return serialized(state, async () => {
      const old = state.records.get(id);
      if (old && !old.trashed) {
        try { if (await recordPath(state, old)) return {record: publicRecord(old), created: false}; } catch {}
      }
      if (old?.trashed) {
        if (!await recordPath(state, old)) throw error('回收站素材已更改，请检查原图后重新上传。', 'MATERIAL_NOT_FOUND', 404);
        const filename = basename(old.originalPath || old.path), path = await moveFile(state, old.path, filename, dirname(old.originalPath || '') === '.' ? '' : dirname(old.originalPath || ''));
        const info = await lstat(resolve(state.root, path));
        Object.assign(old, {path, trashed: false, updatedAt: new Date().toISOString(), validated: true, ...identity(info)}); delete old.originalPath;
        changed(state, id); state.files.set(path, {...old});
        await save(state); return {record: publicRecord(old), created: false};
      }
      if ([...state.records.values()].filter(record => !record.trashed).length >= MAX_FILES) throw error('共享素材已达到 10000 张，请整理后再上传。', 'MATERIAL_LIMIT', 409);
      const path = await placeFile(state, image.bytes, policy==='name-and-content'?originalName:fileStem(originalName) + '_' + id.slice(0, 16) + TYPES[image.mime]);
      const info = await lstat(resolve(state.root, path)), timestamp = new Date().toISOString();
      const record = {id, ...(policy==='name-and-content'?{identityPolicy:policy,contentSha256}:{}), name: originalName, width: image.width, height: image.height, mime: image.mime, path, createdAt: timestamp, updatedAt: timestamp,
        validated: true, ...identity(info), trashed: false};
      state.records.set(id, record); changed(state, id); state.files.set(path, {...record});
      await save(state); return {record: publicRecord(record), created: true};
      });
    }),
    get: id => protectedCall(async () => {
      if (!idValid(id)) throw error('素材编号无效。');
      const state = await ready(), current = state.records.get(id);
      if (!current || current.trashed) return null;
      const record = {...current};
      try {
        const path = await recordPath(state, record);
        if (!path || state.records.get(id)?.trashed) return null;
        return {...publicRecord(record), path};
      } catch { return null; }
    }),
    scan,
    idle: () => Promise.allSettled([...states.values()].flatMap(state => [state.scanPromise, state.queue].filter(Boolean))),
    trash: id => protectedCall(async () => {
      if (!idValid(id)) throw error('素材编号无效。');
      const state = await ready();
      return serialized(state, async () => {
      const record = state.records.get(id);
      if (!record) throw error('素材不存在，请刷新列表。', 'MATERIAL_NOT_FOUND', 404);
      if (record.trashed) return publicRecord(record);
      if (!await recordPath(state, record)) throw error('素材已更改，请重新扫描素材文件夹。', 'MATERIAL_NOT_FOUND', 404);
      const originalPath = record.path, path = await moveFile(state, originalPath, id + TYPES[record.mime], '.pod-trash');
      const info = await lstat(resolve(state.root, path));
      Object.assign(record, {originalPath, path, trashed: true, updatedAt: new Date().toISOString(), ...identity(info)});
      changed(state, id);
      for (const [cachedPath, cached] of state.files) if (cached.id === id) state.files.delete(cachedPath);
      await save(state); return publicRecord(record);
      });
    }),
    restore: id => protectedCall(async () => {
      if (!idValid(id)) throw error('素材编号无效。');
      const state = await ready();
      return serialized(state, async () => {
      const record = state.records.get(id);
      if (!record) throw error('素材不存在，请刷新列表。', 'MATERIAL_NOT_FOUND', 404);
      if (!record.trashed) return publicRecord(record);
      if (!await recordPath(state, record)) throw error('回收站素材已更改，请检查原图后重新上传。', 'MATERIAL_NOT_FOUND', 404);
      const original = record.originalPath, folder = dirname(original) === '.' ? '' : dirname(original);
      if (!safeRelative(original)) throw invalid();
      const path = await moveFile(state, record.path, basename(original), folder), info = await lstat(resolve(state.root, path));
      Object.assign(record, {path, trashed: false, updatedAt: new Date().toISOString(), ...identity(info)}); delete record.originalPath;
      changed(state, id); state.files.set(path, {...record});
      await save(state); return publicRecord(record);
      });
    })
  };
}
