import {copyFile, lstat, mkdir, open, readFile, rename, unlink} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash, randomUUID} from 'node:crypto';
import {dirname, join, resolve, sep} from 'node:path';

async function hashFile(path) {
  const hash=createHash('sha256');
  try {const stat=await lstat(path);if(!stat.isFile()||stat.isSymbolicLink())return null;
    for await(const chunk of createReadStream(path))hash.update(chunk);
    return hash.digest('hex');
  } catch(error) {if(error.code==='ENOENT')return null;throw error;}
}
async function json(path, fallback) {try{return JSON.parse(await readFile(path,'utf8'));}catch(error){if(error.code==='ENOENT')return fallback;throw error;}}
async function atomic(path,value) {
  await mkdir(dirname(path),{recursive:true});const stage=path+'.'+randomUUID()+'.tmp';
  const file=await open(stage,'wx',0o600);
  try {await file.writeFile(JSON.stringify(value));await file.sync();}finally{await file.close();}
  await rename(stage,path);
}
function targetFor(dataRoot,logical) {
  if(typeof logical!=='string'||logical.includes('\\')||logical.includes(':')||logical.split('/').some(p=>!p||p==='.'||p==='..'))throw Error('同步文件路径无效。');
  const [scope,...parts]=logical.split('/');
  if(!parts.length||!['PODStudio','模板库','套图'].includes(scope))return null;
  if(scope==='PODStudio'&&parts[0]==='global-settings.json')return null;
  const target=resolve(dataRoot,...(scope==='PODStudio'?parts:[scope,...parts]));
  if(!target.startsWith(resolve(dataRoot)+sep))throw Error('同步路径超出应用目录。');
  return target;
}

/** Call once before opening any mutable service/database; a running DB is never replaced. */
export async function applyPendingSnapshot({dataRoot}) {
  const mirror=join(dataRoot,'mobile-mirror'), current=await json(join(mirror,'current.json'),null);
  if(!current)return {imported:0,conflicts:[],snapshotId:null};
  if(!/^[a-f0-9]{64}$/.test(current.snapshotId||''))throw Error('同步指针无效。');
  const manifest=await json(join(mirror,'manifests',current.snapshotId+'.json'),null);
  if(!manifest?.complete||manifest.snapshotId!==current.snapshotId||!Array.isArray(manifest.files))throw Error('完整同步清单不可用。');
  const sorted=manifest.files.slice().sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:0);
  const id=createHash('sha256').update(JSON.stringify({schema:manifest.schema,files:sorted,totalBytes:manifest.totalBytes})).digest('hex');
  if(id!==current.snapshotId)throw Error('同步清单校验失败。');
  const statePath=join(dataRoot,'mobile-import-state.json'), state=await json(statePath,{files:{}});
  if(state.snapshotId===current.snapshotId)return {imported:0,conflicts:state.conflicts||[],snapshotId:state.snapshotId};
  const files={...state.files}, conflicts=[];let imported=0;
  for(const file of manifest.files) {
    if(!/^[a-f0-9]{64}$/.test(file.sha256||''))throw Error('同步文件校验值无效。');
    const destination=targetFor(dataRoot,file.path);if(!destination)continue;
    const local=await hashFile(destination);
    if(local===file.sha256){files[file.path]=file.sha256;continue;}
    if(local&&local!==state.files?.[file.path]){conflicts.push(file.path);continue;}
    const source=join(mirror,'blobs',file.sha256);
    if(await hashFile(source)!==file.sha256)throw Error('手机同步文件缺失或损坏，请重新同步。');
    // A prior imported SQLite file can leave WAL/SHM data. Never install over those.
    if(/\.(sqlite|db)$/i.test(destination)) {
      for(const suffix of ['-wal','-shm','-journal']) {
        try {if((await lstat(destination+suffix)).size>0){conflicts.push(file.path);continue;}}
        catch(error){if(error.code!=='ENOENT')throw error;}
      }
      if(conflicts.includes(file.path))continue;
    }
    await mkdir(dirname(destination),{recursive:true});
    const stage=destination+'.import-'+randomUUID();
    try {await copyFile(source,stage);if(await hashFile(stage)!==file.sha256)throw Error('同步安装校验失败。');await rename(stage,destination);}
    finally{await unlink(stage).catch(()=>{});}
    files[file.path]=file.sha256;imported++;
  }
  await atomic(statePath,{snapshotId:current.snapshotId,files,conflicts,importedAt:new Date().toISOString()});
  return {imported,conflicts,snapshotId:current.snapshotId};
}
