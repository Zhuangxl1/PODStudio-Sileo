import fs from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash, randomUUID} from 'node:crypto';
import {isIP} from 'node:net';
import {resolve, join} from 'node:path';

const HASH = /^[a-f0-9]{64}$/i;
const MANIFEST_SCHEMA = 'pod-offline-manifest/v1';
const CURRENT_SCHEMA = 'pod-offline-current/v1';
const failure = (code, message) => Object.assign(new Error(message), {code});
const cancelled = () => Object.assign(failure('MIRROR_ABORTED', '同步已取消；上次完整快照仍然保留。'), {name: 'AbortError'});
const checkAbort = signal => { if (signal?.aborted) throw cancelled(); };
const storageFailure = error => failure(['ENOSPC', 'EDQUOT'].includes(error?.code) ? 'NO_SPACE' : 'LOCAL_STORAGE_ERROR',
  ['ENOSPC', 'EDQUOT'].includes(error?.code) ? '本机存储空间不足；上次完整快照仍然保留。' : '本机文件无法读写；上次完整快照仍然保留。');

function logicalPath(path) {
  if (typeof path !== 'string' || !path || /[\\:\u0000-\u001f\u007f]/u.test(path)
    || path.split('/').some(part => !part || part === '.' || part === '..'))
    throw failure('INVALID_MANIFEST', '快照包含无效的相对文件路径。');
  return path;
}

function normalizeManifest(value) {
  if (!value || value.schema !== MANIFEST_SCHEMA || value.complete !== true || typeof value.snapshotId !== 'string' || !HASH.test(value.snapshotId)
    || typeof value.createdAt !== 'string' || !/^\d{4}-\d{2}-\d{2}T.+(?:Z|[+-]\d{2}:\d{2})$/u.test(value.createdAt)
    || !Number.isFinite(Date.parse(value.createdAt)) || !Array.isArray(value.files)
    || !Number.isSafeInteger(value.totalBytes) || value.totalBytes < 0)
    throw failure('INVALID_MANIFEST', '服务器未返回有效的完整快照。');
  const paths = new Set(), hashes = new Map(); let totalBytes = 0;
  const files = value.files.map(file => {
    if (!file || typeof file.sha256 !== 'string' || !HASH.test(file.sha256) || !Number.isSafeInteger(file.size) || file.size < 0)
      throw failure('INVALID_MANIFEST', '快照文件大小或校验值无效。');
    const path = logicalPath(file.path), sha256 = file.sha256.toLowerCase();
    if (paths.has(path) || hashes.has(sha256) && hashes.get(sha256) !== file.size)
      throw failure('INVALID_MANIFEST', '快照包含重复路径或冲突的文件信息。');
    paths.add(path); hashes.set(sha256, file.size); totalBytes += file.size;
    if (!Number.isSafeInteger(totalBytes)) throw failure('INVALID_MANIFEST', '快照总大小无效。');
    return {path, sha256, size: file.size};
  });
  if (totalBytes !== value.totalBytes) throw failure('INVALID_MANIFEST', '快照总大小与文件列表不一致。');
  files.sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
  const contentId = createHash('sha256').update(JSON.stringify({schema: MANIFEST_SCHEMA, files, totalBytes})).digest('hex');
  if (contentId !== value.snapshotId.toLowerCase()) throw failure('INVALID_MANIFEST', '快照清单的内容校验失败。');
  return {schema: MANIFEST_SCHEMA, snapshotId: value.snapshotId.toLowerCase(), createdAt: value.createdAt, files, totalBytes, complete: true};
}

function normalizeBase(value) {
  let url;
  try { url = new URL(value); } catch { throw failure('INVALID_SERVER', '同步服务地址无效。'); }
  const host = url.hostname.replace(/^\[|\]$/g, ''), ip = isIP(host), parts = host.split('.').map(Number);
  const privateHost = host === 'localhost' || ip === 4 && (parts[0] === 127 || parts[0] === 10
    || parts[0] === 192 && parts[1] === 168 || parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)
    || ip === 6 && (host === '::1' || /^(?:fc|fd)[a-f0-9]{2}:/i.test(host));
  if (url.username || url.password || url.search || url.hash || !(url.protocol === 'https:' || url.protocol === 'http:' && privateHost))
    throw failure('INVALID_SERVER', '同步服务仅支持 HTTPS 或私网、回环 HTTP 地址。');
  return url.href.replace(/\/+$/u, '');
}

async function fileInfo(path) {
  try {
    const stat = await fs.lstat(path);
    if (!stat.isFile() || stat.isSymbolicLink()) throw failure('LOCAL_STORAGE_ERROR', '同步文件位置被其他文件类型占用。');
    return stat;
  } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

async function verify(path, expected, signal) {
  const stat = await fileInfo(path);
  if (!stat || stat.size !== expected.size) return false;
  checkAbort(signal);
  const hash = createHash('sha256'); let bytes = 0;
  for await (const chunk of createReadStream(path, {signal})) {
    checkAbort(signal); bytes += chunk.length; hash.update(chunk);
  }
  return bytes === expected.size && hash.digest('hex') === expected.sha256;
}

async function writeSynced(path, bytes) {
  const handle = await fs.open(path, 'wx', 0o600);
  try { await handle.writeFile(bytes); await handle.sync(); } finally { await handle.close(); }
}

/** Content-addressed mirror, with a single owning client/process per directory.
 * sync serializes this instance; it is not an interprocess filesystem lock.
 * This Node implementation is the reference for an iOS-native port.
 */
export function createMirrorClient({baseUrl, token, directory, concurrency = 4, idleTimeoutMs = 30000, fetchImpl = globalThis.fetch, onProgress} = {}) {
  const base = normalizeBase(baseUrl);
  if (typeof token !== 'string' || !token.trim() || /[\r\n]/u.test(token)) throw failure('INVALID_TOKEN', '同步访问令牌无效。');
  if (typeof directory !== 'string' || !directory || !Number.isSafeInteger(concurrency) || concurrency < 1
    || !Number.isSafeInteger(idleTimeoutMs) || idleTimeoutMs < 1 || typeof fetchImpl !== 'function')
    throw failure('INVALID_OPTIONS', '同步存储目录或并发设置无效。');
  const root = resolve(directory), blobs = join(root, 'blobs'), partial = join(root, 'partial'), manifests = join(root, 'manifests');
  let syncing = false;

  async function prepare() {
    for (const dir of [root, blobs, partial, manifests]) {
      await fs.mkdir(dir, {recursive: true});
      const stat = await fs.lstat(dir);
      if (!stat.isDirectory() || stat.isSymbolicLink()) throw failure('LOCAL_STORAGE_ERROR', '同步目录不可用。');
    }
  }
  async function request(path, signal, headers = {}) {
    checkAbort(signal);
    const controller = new AbortController(), parentAbort = () => controller.abort();
    let timer, timedOut = false;
    const touch = () => { clearTimeout(timer); timer = setTimeout(() => { timedOut = true; controller.abort(); }, idleTimeoutMs); };
    const finish = () => { clearTimeout(timer); signal?.removeEventListener('abort', parentAbort); };
    const timeoutError = () => failure('NETWORK_TIMEOUT', '同步服务长时间没有返回数据；下次连接可继续下载。');
    signal?.addEventListener('abort', parentAbort, {once: true});
    touch();
    try {
      const response = await fetchImpl(base + path, {method: 'GET', headers: {Authorization: 'Bearer ' + token, ...headers},
        signal: controller.signal, redirect: 'error', credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer'});
      touch(); return {response, touch, finish, timedOut: () => timedOut, timeoutError};
    } catch { finish(); checkAbort(signal); if (timedOut) throw timeoutError(); throw failure('NETWORK_ERROR', '无法连接同步服务；已下载内容和上次完整快照仍然保留。'); }
  }

  async function readManifest() {
    try {
      if (!await fileInfo(join(root, 'current.json'))) return null;
      let pointer;
      try { pointer = JSON.parse(await fs.readFile(join(root, 'current.json'), 'utf8')); }
      catch { throw failure('LOCAL_MANIFEST_INVALID', '本机快照指针无法读取。'); }
      if (pointer?.schema !== CURRENT_SCHEMA || typeof pointer.snapshotId !== 'string' || !HASH.test(pointer.snapshotId))
        throw failure('LOCAL_MANIFEST_INVALID', '本机快照指针无效。');
      const path = join(manifests, pointer.snapshotId.toLowerCase() + '.json');
      if (!await fileInfo(path)) throw failure('LOCAL_MANIFEST_INVALID', '本机完整快照记录不存在。');
      let manifest;
      try { manifest = normalizeManifest(JSON.parse(await fs.readFile(path, 'utf8'))); }
      catch { throw failure('LOCAL_MANIFEST_INVALID', '本机完整快照记录无效。'); }
      if (manifest.snapshotId !== pointer.snapshotId.toLowerCase()) throw failure('LOCAL_MANIFEST_INVALID', '本机快照绑定不一致。');
      return manifest;
    } catch (error) { if (error.code?.startsWith('LOCAL_')) throw error; throw storageFailure(error); }
  }
  async function resolvePath(path) {
    logicalPath(path);
    const manifest = await readManifest(), file = manifest?.files.find(file => file.path === path);
    if (!file) throw failure('OFFLINE_FILE_NOT_FOUND', '上次完整快照中不存在该文件。');
    const local = join(blobs, file.sha256);
    try {
      if (!await verify(local, file)) throw failure('OFFLINE_FILE_INVALID', '本机快照文件缺失或校验失败，请重新同步。');
    } catch (error) { if (error.code === 'OFFLINE_FILE_INVALID') throw error; throw storageFailure(error); }
    return local;
  }

  async function sync({signal, onProgress: progress, verifyExisting = false} = {}) {
    if (syncing) throw failure('SYNC_IN_PROGRESS', '当前客户端已在同步中。');
    if (typeof verifyExisting !== 'boolean') throw failure('INVALID_OPTIONS', '完整性校验选项无效。');
    syncing = true;
    const controller = new AbortController(), abort = () => controller.abort();
    if (signal?.aborted) abort(); else signal?.addEventListener('abort', abort, {once: true});
    const workSignal = controller.signal;
    let filesTotal = 0, bytesTotal = 0, filesDone = 0, downloadedFiles = 0, reusedFiles = 0, downloadedBytes = 0;
    const byteProgress = new Map(); let snapshotId;
    const emit = (phase, extra = {}) => {
      const event = {phase, filesDone, filesTotal, bytesDone: [...byteProgress.values()].reduce((sum, count) => sum + count, 0),
        bytesTotal, downloadedBytes, ...(snapshotId ? {snapshotId} : {}), ...extra};
      for (const callback of new Set([onProgress, progress])) if (typeof callback === 'function') try { callback({...event}); } catch {}
    };
    const updateBytes = (file, aliases, size) => { byteProgress.set(file.sha256, size * aliases); emit('downloading', {path: file.path}); };

    async function download(file, aliases) {
      const destination = join(blobs, file.sha256), part = join(partial, file.sha256 + '.part');
      checkAbort(workSignal);
      let info;
      try {
        info = await fileInfo(destination);
        if (info) {
          if (!await verify(destination, file, workSignal)) throw failure('LOCAL_BLOB_INVALID', '已存文件校验失败；未覆盖原文件或切换快照。');
          reusedFiles += aliases; filesDone += aliases; byteProgress.set(file.sha256, file.size * aliases); emit('checking', {path: file.path}); return;
        }
        info = await fileInfo(part);
        if (info?.size === file.size && await verify(part, file, workSignal)) {
          await fs.rename(part, destination); filesDone += aliases; reusedFiles += aliases;
          byteProgress.set(file.sha256, file.size * aliases); emit('checking', {path: file.path}); return;
        }
      } catch (error) { checkAbort(workSignal); if (error.code?.startsWith('LOCAL_')) throw error; throw storageFailure(error); }
      let offset = info && info.size < file.size ? info.size : 0;
      updateBytes(file, aliases, offset);
      const transfer = await request('/v1/blobs/' + file.sha256, workSignal, offset ? {Range: 'bytes=' + offset + '-'} : {});
      const {response} = transfer;
      let handle;
      try {
        if (![200, 206].includes(response.status)) throw failure('BLOB_HTTP_ERROR', '同步文件请求未成功。');
        if (response.status === 200) offset = 0;
        const expected = file.size - offset, length = response.headers.get('content-length');
        const range = response.headers.get('content-range');
        if (response.headers.get('etag') !== '"' + file.sha256 + '"' || !/^\d+$/u.test(length || '') || Number(length) !== expected
          || response.status === 206 && range !== `bytes ${offset}-${file.size - 1}/${file.size}`)
          throw failure('BLOB_PROTOCOL_ERROR', '同步文件的大小、范围或校验标记不一致。');
        try { handle = await fs.open(part, offset ? 'a' : 'w', 0o600); } catch (error) { throw storageFailure(error); }
        updateBytes(file, aliases, offset);
        let received = 0;
        if (response.body) {
          try {
            for await (const value of response.body) {
              checkAbort(workSignal);
              transfer.touch();
              const chunk = Buffer.from(value); received += chunk.length;
              if (received > expected) throw failure('BLOB_PROTOCOL_ERROR', '同步文件超过清单声明的大小。');
              try {
                let written = 0;
                while (written < chunk.length) {
                  const result = await handle.write(chunk, written, chunk.length - written);
                  if (!result.bytesWritten) throw new Error();
                  written += result.bytesWritten;
                }
              } catch (error) { throw storageFailure(error); }
              downloadedBytes += chunk.length; updateBytes(file, aliases, offset + received);
            }
          } catch (error) {
            checkAbort(workSignal);
            if (transfer.timedOut()) throw transfer.timeoutError();
            if (['NO_SPACE', 'LOCAL_STORAGE_ERROR', 'BLOB_PROTOCOL_ERROR'].includes(error.code)) throw error;
            throw failure('NETWORK_ERROR', '同步传输中断；下次连接将继续下载。');
          }
        }
        if (received !== expected) throw failure('NETWORK_ERROR', '同步传输未完成；下次连接将继续下载。');
        transfer.finish();
        try { await handle.sync(); await handle.close(); handle = null; }
        catch (error) { throw storageFailure(error); }
        checkAbort(workSignal);
        try {
          if (!await verify(part, file, workSignal)) throw failure('CHECKSUM_MISMATCH', '同步文件校验失败；上次完整快照仍然保留。');
          checkAbort(workSignal);
          await fs.rename(part, destination);
        } catch (error) { checkAbort(workSignal); if (error.code === 'CHECKSUM_MISMATCH') throw error; throw storageFailure(error); }
        downloadedFiles += aliases; filesDone += aliases; emit('downloading', {path: file.path});
      } finally {
        transfer.finish();
        if (handle) await handle.close().catch(() => {});
        if (response.body && !response.body.locked) await response.body.cancel().catch(() => {});
      }
    }

    try {
      checkAbort(workSignal); emit('manifest');
      try { await prepare(); } catch (error) { throw storageFailure(error); }
      const previous = verifyExisting ? null : await readManifest();
      const transfer = await request('/v1/manifest', workSignal, {Accept: 'application/json',
        ...(previous ? {'If-None-Match': '"' + previous.snapshotId + '"'} : {})}), {response} = transfer;
      let value;
      try {
        if (response.status === 304) {
          if (!previous || response.headers.get('etag') !== '"' + previous.snapshotId + '"')
            throw failure('MANIFEST_PROTOCOL_ERROR', '服务器未正确确认本机完整快照。');
          snapshotId = previous.snapshotId; filesDone = filesTotal = previous.files.length; bytesTotal = previous.totalBytes;
          byteProgress.set('current', bytesTotal); emit('complete', {unchanged: true});
          return {manifest: previous, downloadedFiles: 0, reusedFiles: filesTotal, downloadedBytes: 0, unchanged: true};
        }
        if (!response.ok) throw failure('MANIFEST_HTTP_ERROR', '同步清单请求未成功。');
        const chunks = [];
        if (response.body) for await (const chunk of response.body) { checkAbort(workSignal); transfer.touch(); chunks.push(Buffer.from(chunk)); }
        value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
      } catch (error) {
        checkAbort(workSignal);
        if (['MANIFEST_HTTP_ERROR', 'MANIFEST_PROTOCOL_ERROR'].includes(error.code)) throw error;
        if (transfer.timedOut()) throw transfer.timeoutError();
        throw failure('INVALID_MANIFEST', '同步清单未完整读取或格式无效。');
      } finally { transfer.finish(); if (response.body && !response.body.locked) await response.body.cancel().catch(() => {}); }
      const manifest = normalizeManifest(value);
      filesTotal = manifest.files.length; bytesTotal = manifest.totalBytes; snapshotId = manifest.snapshotId;
      const groups = new Map();
      for (const file of manifest.files) {
        if (!groups.has(file.sha256)) groups.set(file.sha256, {file, aliases: 0});
        groups.get(file.sha256).aliases++;
      }
      emit('checking'); let cursor = 0, firstError;
      const queue = [...groups.values()];
      await Promise.all(Array.from({length: Math.min(concurrency, queue.length)}, async () => {
        try {
          while (!firstError && cursor < queue.length) {
            const next = queue[cursor++]; await download(next.file, next.aliases);
          }
        } catch (error) { if (!firstError) { firstError = error; controller.abort(); } }
      }));
      if (firstError) throw firstError;
      checkAbort(workSignal); emit('committing');
      let committedManifest = manifest;
      try {
        const manifestFile = join(manifests, manifest.snapshotId + '.json'), serialized = JSON.stringify(manifest);
        if (await fileInfo(manifestFile)) {
          let previous;
          try { previous = normalizeManifest(JSON.parse(await fs.readFile(manifestFile, 'utf8'))); }
          catch { throw failure('SNAPSHOT_CONFLICT', '本机已有快照记录无法验证，未覆盖或切换快照。'); }
          const content = value => JSON.stringify({...value, createdAt: ''});
          if (content(previous) !== content(manifest)) throw failure('SNAPSHOT_CONFLICT', '相同快照编号对应不同清单，未切换快照。');
          committedManifest = previous;
        } else {
          const temp = join(manifests, manifest.snapshotId + '.' + randomUUID() + '.tmp');
          await writeSynced(temp, serialized); checkAbort(workSignal); await fs.rename(temp, manifestFile);
        }
        const pointer = join(root, 'current.' + randomUUID() + '.tmp');
        await writeSynced(pointer, JSON.stringify({schema: CURRENT_SCHEMA, snapshotId: manifest.snapshotId}));
        checkAbort(workSignal); await fs.rename(pointer, join(root, 'current.json'));
      } catch (error) { if (error.code === 'SNAPSHOT_CONFLICT' || error.code === 'MIRROR_ABORTED') throw error; throw storageFailure(error); }
      emit('complete'); return {manifest: committedManifest, downloadedFiles, reusedFiles, downloadedBytes};
    } catch (error) {
      const safe = signal?.aborted ? cancelled() : error;
      emit(safe.code === 'MIRROR_ABORTED' ? 'cancelled' : 'failed', {code: safe.code || 'SYNC_FAILED'});
      throw safe;
    } finally { signal?.removeEventListener('abort', abort); syncing = false; }
  }
  return {sync, readManifest, resolvePath};
}
