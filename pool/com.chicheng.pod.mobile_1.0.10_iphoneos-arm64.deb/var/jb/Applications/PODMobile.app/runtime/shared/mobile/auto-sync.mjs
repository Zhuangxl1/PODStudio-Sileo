/** Foreground/network lifecycle coordinator; platform shell calls start/stop/refresh. */
export function createAutoSync({client, intervalMs = 60000, retryMs = 5000,
  onStatus = () => {}, setTimer = setTimeout, clearTimer = clearTimeout}) {
  if (!client?.sync || !client?.readManifest || intervalMs <= 0 || retryMs <= 0) throw new Error('同步配置无效。');
  let enabled = false, running = null, timer = null, controller = null, failures = 0, rerun = false;
  const notify = value => { try {onStatus(value);} catch {} };
  const readCurrent = signal => new Promise(resolve => {
    let settled=false;
    const finish=value=>{if(settled)return;settled=true;clearTimeout(deadline);signal.removeEventListener('abort',abort);resolve(value);};
    const abort=()=>finish(null), deadline=setTimeout(abort,5000);
    if(signal.aborted) abort(); else signal.addEventListener('abort',abort,{once:true});
    Promise.resolve().then(()=>signal.aborted?null:client.readManifest()).then(finish,()=>finish(null));
  });
  const unschedule = () => { if (timer !== null) clearTimer(timer); timer = null; };
  function schedule(delay) {
    if (!enabled) return;
    unschedule();
    timer = setTimer(() => {timer = null; void run();}, delay);
  }
  function run() {
    if (!enabled) return Promise.resolve(null);
    if (running) return running;
    unschedule(); controller = new AbortController();
    const signal = controller.signal;
    notify({state:'syncing', label:'同步中'});
    const operation = (async () => {
      try {
        const result = await client.sync({signal, onProgress:progress => {
          if (enabled && !signal.aborted) notify({state:'syncing',label:'同步中',progress});
        }});
        failures = 0;
        if (enabled && !signal.aborted) notify({state:'ready',label:'已缓存',snapshotId:result.manifest.snapshotId});
        return result;
      } catch (error) {
        if (enabled && !signal.aborted) {
          failures++;
          const current = await readCurrent(signal);
          if(enabled && !signal.aborted)
            notify({state:'offline',label:'待联网',hasLocalSnapshot:!!current,code:error.code || 'SYNC_FAILED'});
        }
        return null;
      } finally {
        running = null; controller = null;
        if (enabled) {
          const delay = rerun ? 0 : failures ? Math.min(intervalMs, retryMs * (2 ** Math.min(failures - 1, 8))) : intervalMs;
          rerun = false; schedule(delay);
        }
      }
    })();
    running = operation;
    return operation;
  }
  function start() {
    if (enabled) return running || Promise.resolve(null);
    enabled = true;
    if (running) {rerun = true; return running;}
    return run();
  }
  function stop() {
    enabled = false; rerun = false; unschedule(); controller?.abort();
    notify({state:'paused',label:'已暂停'});
  }
  function refresh() {
    if (!enabled) return start();
    if (running) {rerun = true; return running;}
    return run();
  }
  return {start, stop, refresh};
}
