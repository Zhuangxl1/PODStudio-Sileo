// URL records only. Image bytes returned by open() live in memory, never in this store.
export const MATERIAL_RETENTION_MS = 30 * 24 * 60 * 60 * 1000;
const HEX = /^[a-f0-9]{64}$/;
const TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
const fail = (code, message) => Object.assign(new Error(message), {code});
const invalid = () => fail('MATERIAL_REFERENCE_INVALID', '素材链接无效，请重新从电脑素材库选择。');

export function validateHostedReference(value, {owner, repo}) {
  if (!value || !HEX.test(value.sha256 || '')) throw invalid();
  let url;
  try { url = new URL(value.url); } catch { throw invalid(); }
  const parts = url.pathname.split('/');
  if (url.protocol !== 'https:' || url.hostname !== 'raw.githubusercontent.com' || url.port ||
      url.username || url.password || url.search || url.hash || parts.length !== 9 ||
      parts[1] !== owner || parts[2] !== repo || !/^[a-f0-9]{40}$/.test(parts[3]) ||
      parts[4] !== 'assets' || parts[5] !== 'pod-mobile' || parts[6] !== 'materials' ||
      parts[7] !== value.sha256.slice(0, 2) ||
      !['png', 'jpg', 'webp'].some(ext => parts[8] === value.sha256 + '.' + ext)) throw invalid();
  return {url: url.href, sha256: value.sha256};
}

async function sha256(blob) {
  const digest = await globalThis.crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
}

function untilCancelled(promise, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => reject(fail('MATERIAL_CANCELLED', '已取消加载素材。'));
    Promise.resolve(promise).then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
    if (signal.aborted) abort();
    else signal.addEventListener('abort', abort, {once:true});
  });
}

/** storage.load/save persist JSON in Application Support and honor {signal} before atomic save commit. */
export function createRecentMaterials({storage, owner, repo, ensureHosted, fetchImpl = fetch,
  now = Date.now, digest = sha256, timeoutMs = 60000}) {
  if (!storage?.load || !storage?.save || !/^[\w-]+$/.test(owner || '') ||
      !/^[\w.-]+$/.test(repo || '') || typeof ensureHosted !== 'function' ||
      !Number.isFinite(timeoutMs) || timeoutMs <= 0) throw invalid();
  let queue = Promise.resolve();
  function serial(fn) {
    const result = queue.then(fn, fn);
    queue = result.catch(() => {});
    return result;
  }
  const checkedIdentity = ({materialId, revision} = {}) => {
    if (typeof materialId !== 'string' || !materialId.trim() || materialId.length > 512 ||
        typeof revision !== 'string' || !revision.trim() || revision.length > 512) throw invalid();
    return {materialId, revision};
  };
  function reference(value) { return validateHostedReference(value, {owner, repo}); }
  async function records(signal) {
    if (signal.aborted) throw fail('MATERIAL_CANCELLED', '已取消加载素材。');
    let saved;
    try { saved = await untilCancelled(storage.load({signal}), signal); }
    catch (error) { if (signal.aborted) throw error; throw fail('MATERIAL_STORAGE', '最近使用素材记录无法读取。'); }
    if (saved == null) return [];
    if (saved.schema !== 'pod-recent-materials/v1' || !Array.isArray(saved.entries))
      throw fail('MATERIAL_INDEX_INVALID', '最近使用素材记录损坏，未覆盖原记录。');
    const cutoff = now() - MATERIAL_RETENTION_MS;
    return saved.entries.map(entry => ({...checkedIdentity(entry), ...reference(entry),
      lastUsedAt: entry.lastUsedAt})).filter(entry => Number.isSafeInteger(entry.lastUsedAt) &&
        entry.lastUsedAt > cutoff && entry.lastUsedAt <= now());
  }
  const write = async (entries, signal) => {
    if (signal.aborted) throw fail('MATERIAL_CANCELLED', '已取消加载素材。');
    try { await untilCancelled(storage.save({schema: 'pod-recent-materials/v1', entries}, {signal}), signal); }
    catch (error) { if (signal.aborted) throw error; throw fail('MATERIAL_STORAGE', '最近使用素材记录无法保存。'); }
  };
  async function list() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await untilCancelled(serial(async () => {
        const entries = await records(controller.signal);
        await write(entries, controller.signal);
        return entries.sort((a, b) => b.lastUsedAt - a.lastUsedAt);
      }), controller.signal);
    } catch (error) {
      if (controller.signal.aborted) throw fail('MATERIAL_TIMEOUT', '最近使用素材记录读取超时，请重试。');
      throw error;
    } finally {clearTimeout(timer);}
  }
  async function hosted(identity, signal) {
    const found = await serial(async () => (await records(signal)).find(entry =>
      entry.materialId === identity.materialId && entry.revision === identity.revision));
    if (found) return reference(found);
    // The host deduplicates by content hash with independent subscriber signals.
    // Do not share a phone caller's cancellation signal with another open operation.
    return reference(await ensureHosted(identity, {signal}));
  }
  async function open(input, {signal} = {}) {
    const identity = checkedIdentity(input);
    const controller = new AbortController();
    const abort = () => controller.abort();
    let timedOut = false;
    if (signal?.aborted) abort();
    signal?.addEventListener('abort', abort, {once: true});
    const timer = setTimeout(() => { timedOut = true; abort(); }, timeoutMs);
    try {
      if (controller.signal.aborted) throw fail('MATERIAL_CANCELLED', '已取消加载素材。');
      const ref = await untilCancelled(hosted(identity, controller.signal), controller.signal);
      if (controller.signal.aborted) throw fail('MATERIAL_CANCELLED', '已取消加载素材。');
      // Never forward the desktop pairing token or a GitHub token to public images.
      const response = await untilCancelled(fetchImpl(ref.url, {cache: 'no-store', credentials: 'omit',
        redirect: 'error', referrerPolicy: 'no-referrer', signal: controller.signal}), controller.signal);
      if (!response.ok) throw fail('MATERIAL_IMAGE_UNAVAILABLE', 'GitHub 素材图片暂时无法读取，请检查网络后重试。');
      const type = (response.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
      if (!TYPES.has(type)) throw fail('MATERIAL_IMAGE_INVALID', '素材链接未返回可用图片。');
      const blob = await untilCancelled(response.blob(), controller.signal);
      if (!blob.size || await untilCancelled(digest(blob), controller.signal) !== ref.sha256)
        throw fail('MATERIAL_IMAGE_CHANGED', '素材内容与链接记录不一致，请重新从电脑素材库选择。');
      if (controller.signal.aborted) throw fail('MATERIAL_CANCELLED', '已取消加载素材。');
      // Only a successful user open counts as use. Listing/prefetch never renews retention.
      const entry = {...identity, ...ref, lastUsedAt: now()};
      await untilCancelled(serial(async () => {
        const entries = (await records(controller.signal)).filter(item => item.materialId !== identity.materialId);
        entries.push(entry);
        await write(entries, controller.signal);
      }), controller.signal);
      return {entry, blob};
    } catch (error) {
      if (timedOut) throw fail('MATERIAL_TIMEOUT', '素材加载超时，请检查网络后重试。');
      if (signal?.aborted) throw fail('MATERIAL_CANCELLED', '已取消加载素材。');
      if (error?.code?.startsWith('MATERIAL_')) throw error;
      throw fail('MATERIAL_NETWORK', '无法读取素材。未缓存链接的素材需要电脑在线；已有链接需要手机联网。');
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
    }
  }
  return {list, open};
}
