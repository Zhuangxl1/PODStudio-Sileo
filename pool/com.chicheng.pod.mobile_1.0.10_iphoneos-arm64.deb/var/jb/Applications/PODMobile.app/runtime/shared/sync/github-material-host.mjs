import {createHash} from 'node:crypto';

const repoQueues = new Map();
const SHA40 = /^[a-f0-9]{40}$/;
const SHA256 = /^[a-f0-9]{64}$/;
const MESSAGES = Object.freeze({
  GITHUB_CONFIG: 'GitHub 图床配置无效。',
  MATERIAL_IMAGE: '只支持完整的 PNG、JPEG 或 WebP 图片。',
  MATERIAL_HASH: '图片内容校验不一致。',
  GITHUB_AUTH: 'GitHub 授权不可用，请检查令牌。',
  GITHUB_FORBIDDEN: 'GitHub 权限不足或请求受限。',
  GITHUB_NOT_FOUND: 'GitHub 仓库或分支不存在。',
  GITHUB_CONFLICT: '图床路径已有不同内容，未覆盖。',
  GITHUB_REJECTED: 'GitHub 未接受图片上传。',
  GITHUB_NETWORK: 'GitHub 连接失败，请稍后重试。',
  GITHUB_TIMEOUT: 'GitHub 请求超时，请稍后重试。',
  GITHUB_ABORTED: '图片托管已取消。',
  GITHUB_RESPONSE: 'GitHub 返回内容无效。',
  GITHUB_UNCERTAIN: '图片上传结果暂未确认，请稍后重新检查。',
});
const failure = code => Object.assign(new Error(MESSAGES[code]), {code});
const digest = (algorithm, bytes) => createHash(algorithm).update(bytes).digest('hex');
const blobHash = bytes => createHash('sha1').update(Buffer.from(`blob ${bytes.length}\0`)).update(bytes).digest('hex');

const crcTable = Array.from({length: 256}, (_, i) => {
  let value = i;
  for (let j = 0; j < 8; j++) value = (value & 1) ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
  return value >>> 0;
});
const crc32 = bytes => {
  let value = 0xffffffff;
  for (const byte of bytes) value = crcTable[(value ^ byte) & 255] ^ (value >>> 8);
  return (value ^ 0xffffffff) >>> 0;
};

function isPng(bytes) {
  if (bytes.length < 57 || !bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return false;
  let offset = 8, header = false, image = false;
  while (offset + 12 <= bytes.length) {
    const length = bytes.readUInt32BE(offset), end = offset + 12 + length;
    if (end > bytes.length) return false;
    const type = bytes.toString('ascii', offset + 4, offset + 8);
    if (!/^[A-Za-z]{4}$/.test(type) || crc32(bytes.subarray(offset + 4, end - 4)) !== bytes.readUInt32BE(end - 4)) return false;
    if (!header) {
      if (type !== 'IHDR' || length !== 13 || bytes.readUInt32BE(offset + 8) === 0 || bytes.readUInt32BE(offset + 12) === 0) return false;
      const depth = bytes[offset + 16], color = bytes[offset + 17];
      const depths = {0:[1,2,4,8,16],2:[8,16],3:[1,2,4,8],4:[8,16],6:[8,16]};
      if (!depths[color]?.includes(depth) || bytes[offset + 18] !== 0 || bytes[offset + 19] !== 0 || bytes[offset + 20] > 1) return false;
      header = true;
    } else if (type === 'IHDR') return false;
    if (type === 'IDAT' && length > 0) image = true;
    if (type === 'IEND') return image && length === 0 && end === bytes.length;
    offset = end;
  }
  return false;
}

function isJpeg(bytes) {
  if (bytes.length < 20 || bytes[0] !== 255 || bytes[1] !== 216) return false;
  let offset = 2, frame = false, scan = false;
  while (offset < bytes.length) {
    if (bytes[offset++] !== 255) return false;
    while (bytes[offset] === 255) offset++;
    const marker = bytes[offset++];
    if (marker === 217) return frame && scan && offset === bytes.length;
    if (marker === undefined || marker === 0 || marker === 216 || (marker >= 208 && marker <= 215)) return false;
    if (marker === 1) continue;
    if (offset + 2 > bytes.length) return false;
    const length = bytes.readUInt16BE(offset);
    if (length < 2 || offset + length > bytes.length) return false;
    if ([192,193,194,195,197,198,199,201,202,203,205,206,207].includes(marker)) {
      if (length < 8 || bytes.readUInt16BE(offset + 3) === 0 || bytes.readUInt16BE(offset + 5) === 0) return false;
      frame = true;
    }
    offset += length;
    if (marker === 218) {
      if (!frame) return false;
      scan = true;
      while (offset < bytes.length) {
        if (bytes[offset] !== 255) { offset++; continue; }
        let next = offset + 1;
        while (bytes[next] === 255) next++;
        if (bytes[next] === 0 || (bytes[next] >= 208 && bytes[next] <= 215)) { offset = next + 1; continue; }
        break;
      }
    }
  }
  return false;
}

function webpChunks(bytes, start, end, nested = false) {
  let image = false, offset = start;
  while (offset + 8 <= end) {
    const kind = bytes.toString('ascii', offset, offset + 4), size = bytes.readUInt32LE(offset + 4);
    const data = offset + 8, next = data + size + (size % 2);
    if (next > end) return false;
    if (kind === 'VP8 ') {
      if (size < 10 || bytes[data] & 1 || !bytes.subarray(data + 3, data + 6).equals(Buffer.from([157,1,42])) || !(bytes.readUInt16LE(data + 6) & 16383) || !(bytes.readUInt16LE(data + 8) & 16383)) return false;
      image = true;
    } else if (kind === 'VP8L') {
      if (size < 5 || bytes[data] !== 47 || (bytes[data + 4] & 224)) return false;
      image = true;
    } else if (kind === 'ANMF') {
      if (nested || size < 24 || !webpChunks(bytes, data + 16, data + size, true)) return false;
      image = true;
    }
    offset = next;
  }
  return offset === end && image;
}
function isWebp(bytes) {
  return bytes.length >= 26 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP' && bytes.readUInt32LE(4) + 8 === bytes.length && webpChunks(bytes, 12, bytes.length);
}

function material(input) {
  if (!input || !(input.bytes instanceof Uint8Array)) throw failure('MATERIAL_IMAGE');
  const bytes = Buffer.from(input.bytes);
  const formats = {'image/png':['png', isPng], 'image/jpeg':['jpg', isJpeg], 'image/webp':['webp', isWebp]};
  const format = Object.hasOwn(formats, input.mimeType) ? formats[input.mimeType] : null;
  if (!format || !format[1](bytes)) throw failure('MATERIAL_IMAGE');
  const sha256 = digest('sha256', bytes);
  if (input.sha256 !== undefined && (typeof input.sha256 !== 'string' || !SHA256.test(input.sha256) || sha256 !== input.sha256)) throw failure('MATERIAL_HASH');
  return {bytes, mimeType: input.mimeType, sha256, blobSha: blobHash(bytes), path: `assets/pod-mobile/materials/${sha256.slice(0, 2)}/${sha256}.${format[0]}`};
}

function serial(repoKey, task) {
  const previous = repoQueues.get(repoKey) || Promise.resolve();
  const result = previous.then(task, task), tail = result.catch(() => {});
  repoQueues.set(repoKey, tail);
  void tail.then(() => { if (repoQueues.get(repoKey) === tail) repoQueues.delete(repoKey); });
  return result;
}

/** Uploads only validated image bytes. No filesystem or token persistence. */
export function createGitHubMaterialHost({owner, repo, branch = 'master', tokenProvider, fetchImpl = fetch, timeoutMs = 30_000} = {}) {
  if (typeof owner !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/.test(owner) || typeof repo !== 'string' || !/^[A-Za-z0-9_.-]{1,100}$/.test(repo) || ['.', '..'].includes(repo) || typeof branch !== 'string' || !branch || branch.length > 255 || /[\x00-\x20\x7f]/.test(branch) || typeof tokenProvider !== 'function' || typeof fetchImpl !== 'function' || !Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 300_000) throw failure('GITHUB_CONFIG');
  const base = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}`;
  const repoKey = `${owner}/${repo}`.toLowerCase(), flights = new Map();

  async function request(path, {method = 'GET', body, signal} = {}) {
    const controller = new AbortController();
    let timeout = false, finished = false;
    const cancel = () => controller.abort();
    if (signal?.aborted) throw failure('GITHUB_ABORTED');
    signal?.addEventListener('abort', cancel, {once: true});
    const timer = setTimeout(() => { timeout = true; controller.abort(); }, timeoutMs);
    let abort;
    const interrupted = new Promise((_, reject) => {
      abort = () => reject(failure(timeout ? 'GITHUB_TIMEOUT' : 'GITHUB_ABORTED'));
      controller.signal.addEventListener('abort', abort, {once: true});
    });
    const operation = (async () => {
      let token;
      try { token = await tokenProvider(); } catch { throw failure('GITHUB_AUTH'); }
      if (finished || controller.signal.aborted) throw failure(timeout ? 'GITHUB_TIMEOUT' : 'GITHUB_ABORTED');
      if (typeof token !== 'string' || !/^[\x21-\x7e]{1,4096}$/.test(token)) throw failure('GITHUB_AUTH');
      let response;
      try {
        response = await fetchImpl(base + path, {method, headers: {Accept: 'application/vnd.github+json', Authorization: `Bearer ${token}`, 'X-GitHub-Api-Version': '2022-11-28', ...(body ? {'Content-Type':'application/json'} : {})}, redirect: 'error', signal: controller.signal, ...(body ? {body: JSON.stringify(body)} : {})});
      } catch { throw failure('GITHUB_NETWORK'); }
      if (finished || controller.signal.aborted) throw failure(timeout ? 'GITHUB_TIMEOUT' : 'GITHUB_ABORTED');
      const status = response?.status;
      if (!Number.isInteger(status)) throw failure('GITHUB_RESPONSE');
      if (status === 404) return {status, data: null};
      if (status < 200 || status >= 300) {
        const code = status === 401 ? 'GITHUB_AUTH' : status === 403 || status === 429 ? 'GITHUB_FORBIDDEN' : status === 409 || status === 422 ? 'GITHUB_CONFLICT' : status >= 500 ? 'GITHUB_UNCERTAIN' : 'GITHUB_REJECTED';
        throw Object.assign(failure(code), {status});
      }
      let data;
      try { data = await response.json(); } catch { throw failure('GITHUB_RESPONSE'); }
      return {status, data};
    })();
    try { return await Promise.race([operation, interrupted]); }
    finally {
      finished = true;
      clearTimeout(timer);
      signal?.removeEventListener('abort', cancel);
      controller.signal.removeEventListener('abort', abort);
    }
  }

  async function existing(item, signal) {
    const head = await request(`/commits/${encodeURIComponent(branch)}`, {signal});
    if (head.status === 404) throw failure('GITHUB_NOT_FOUND');
    const commitSha = head.data?.sha;
    if (!SHA40.test(commitSha || '')) throw failure('GITHUB_RESPONSE');
    const found = await request(`/contents/${item.path}?ref=${commitSha}`, {signal});
    if (found.status === 404) return null;
    if (found.data?.type !== 'file' || found.data?.path !== item.path || found.data?.sha !== item.blobSha || found.data?.size !== item.bytes.length) throw failure('GITHUB_CONFLICT');
    return commitSha;
  }
  const result = (item, commitSha, reused) => Object.freeze({url: `https://raw.githubusercontent.com/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/${commitSha}/${item.path}`, path: item.path, sha256: item.sha256, blobSha: item.blobSha, commitSha, mimeType: item.mimeType, size: item.bytes.length, reused});

  async function host(item, signal) {
    if (signal.aborted) throw failure('GITHUB_ABORTED');
    const current = await existing(item, signal);
    if (current) return result(item, current, true);
    if (signal.aborted) throw failure('GITHUB_ABORTED');
    try {
      // Omitting sha is intentional: a racing writer cannot be overwritten.
      const created = await request(`/contents/${item.path}`, {method:'PUT', signal, body:{message:`Add POD material ${item.sha256}`, content:item.bytes.toString('base64'), branch}});
      if (created.status === 404) throw failure('GITHUB_NOT_FOUND');
      const content = created.data?.content, commitSha = created.data?.commit?.sha;
      if (created.status !== 201 || content?.type !== 'file' || content?.path !== item.path || content?.sha !== item.blobSha || content?.size !== item.bytes.length || !SHA40.test(commitSha || '')) throw failure('GITHUB_RESPONSE');
      return result(item, commitSha, false);
    } catch (error) {
      if (signal.aborted) throw failure('GITHUB_ABORTED');
      if (['GITHUB_AUTH','GITHUB_FORBIDDEN','GITHUB_NOT_FOUND','GITHUB_REJECTED'].includes(error?.code)) throw error;
      // One read-only verification pass after an ambiguous PUT; never retry PUT.
      try {
        const verified = await existing(item, signal);
        if (verified) return result(item, verified, true);
      } catch (verification) {
        if (signal.aborted) throw failure('GITHUB_ABORTED');
        if (verification?.code === 'GITHUB_CONFLICT') throw verification;
      }
      throw failure('GITHUB_UNCERTAIN');
    }
  }

  function subscribe(flight, signal) {
    return new Promise((resolve, reject) => {
      let done = false;
      const finish = (error, value) => {
        if (done) return;
        done = true; signal?.removeEventListener('abort', cancel); flight.users--;
        if (!flight.users && !flight.settled) flight.controller.abort();
        if (error) reject(error); else resolve(value);
      };
      const cancel = () => finish(failure('GITHUB_ABORTED'));
      flight.users++;
      signal?.addEventListener('abort', cancel, {once:true});
      if (signal?.aborted) cancel();
      flight.promise.then(value => finish(null, value), error => finish(error));
    });
  }

  return Object.freeze({
    ensureHosted(input, {signal} = {}) {
      try {
        if (signal && (typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw failure('GITHUB_CONFIG');
        if (signal?.aborted) return Promise.reject(failure('GITHUB_ABORTED'));
        const item = material(input), key = item.sha256;
        let flight = flights.get(key);
        if (!flight || flight.controller.signal.aborted) {
          flight = {controller:new AbortController(), users:0, settled:false, promise:null};
          const active = flight;
          active.promise = serial(repoKey, () => host(item, active.controller.signal)).finally(() => {
            active.settled = true;
            if (flights.get(key) === active) flights.delete(key);
          });
          flights.set(key, active);
        }
        return subscribe(flight, signal);
      } catch (error) { return Promise.reject(MESSAGES[error?.code] ? error : failure('GITHUB_CONFIG')); }
    },
  });
}
