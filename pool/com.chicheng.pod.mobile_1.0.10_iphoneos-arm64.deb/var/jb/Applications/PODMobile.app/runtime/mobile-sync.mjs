import {readFile, writeFile, mkdir, rename, open} from 'node:fs/promises';
import {createHash, timingSafeEqual, randomUUID, webcrypto} from 'node:crypto';
import {join} from 'node:path';
import {createMirrorClient} from './shared/sync/mirror-client.mjs';
import {createGitHubMaterialHost} from './shared/sync/github-material-host.mjs';
import {createRecentMaterials} from './shared/mobile/recent-materials.mjs';
import {createAutoSync} from './shared/mobile/auto-sync.mjs';

const failure=(message,code='MOBILE_REMOTE_UNAVAILABLE')=>Object.assign(new Error(message),{code,status:503});
const digest=value=>createHash('sha256').update(value).digest();
export function createMobileSync({dataRoot,getConfig,fetchImpl=fetch,onSyncComplete=()=>{}}) {
  let auto,mirror,recent,host,generation=0,status={state:'unconfigured',label:'未配置'}, serial=Promise.resolve();
  const freshlyHosted=new Map();
  const recentPath=join(dataRoot,'mobile-recent-materials.json');
  const storage={load:async({signal})=>{signal.throwIfAborted();try{return JSON.parse(await readFile(recentPath,'utf8'));}catch(e){if(e.code==='ENOENT')return null;throw e;}},
    save:(value,{signal})=>{
      const work=serial.then(async()=>{
        signal.throwIfAborted();await mkdir(dataRoot,{recursive:true});const path=recentPath+'.'+randomUUID()+'.tmp';
        const f=await open(path,'wx',0o600);try{await f.writeFile(JSON.stringify(value));await f.sync();}finally{await f.close();}
        signal.throwIfAborted();await rename(path,recentPath);
      });serial=work.catch(()=>{});return work;
    }};
  const config=()=>getConfig()||{};
  async function remote(path,{signal}={}) {
    const desktop=config().desktop;
    if(!desktop?.endpoint||!desktop?.pairToken)throw failure('请先在手机设置中配置电脑同步地址和配对码。');
    // Reuse the mirror URL validator before forwarding a pairing credential.
    createMirrorClient({baseUrl:desktop.endpoint,token:desktop.pairToken,directory:join(dataRoot,'mobile-mirror'),fetchImpl});
    let response;
    try{response=await fetchImpl(desktop.endpoint.replace(/\/+$/,'')+path,{headers:{Authorization:'Bearer '+desktop.pairToken},signal:signal||AbortSignal.timeout(30000),redirect:'error',cache:'no-store'});}
    catch{throw failure('电脑素材库暂时无法连接；已有 GitHub 链接仍可使用。');}
    if(!response.ok)throw failure('电脑素材库未返回内容，请确认配对码和同步服务。');
    return response;
  }
  async function setupMaterials() {
    const gh=config().github||{};
    host=createGitHubMaterialHost({owner:gh.owner||'Zhuangxl1',repo:gh.repo||'Zhuangxl1.github.io',branch:gh.branch||'master',tokenProvider:()=>config().github?.token,fetchImpl});
    recent=createRecentMaterials({storage,owner:gh.owner||'Zhuangxl1',repo:gh.repo||'Zhuangxl1.github.io',fetchImpl,
      digest:async blob=>createHash('sha256').update(Buffer.from(await blob.arrayBuffer())).digest('hex'),
      ensureHosted:async({materialId,revision},{signal})=>{
        if(freshlyHosted.has(materialId)&&freshlyHosted.get(materialId).sha256===revision)return freshlyHosted.get(materialId);
        const response=await remote('/v1/materials/'+materialId+'/file',{signal});
        const bytes=new Uint8Array(await response.arrayBuffer());
        if(createHash('sha256').update(bytes).digest('hex')!==revision)throw failure('电脑素材已更新，请重新选择。');
        return host.ensureHosted({bytes,mimeType:response.headers.get('content-type')?.split(';')[0],sha256:revision},{signal});
      }});
  }
  const materialStore={
    async list(options={}) {
      try {const response=await remote('/v1/materials?'+new URLSearchParams({query:options.query||'',page:String(options.page||1),pageSize:String(options.pageSize||60)}));return (await response.json()).data;}
      catch(error){const entries=await recent?.list();if(!entries?.length)throw error;return {items:entries.map(e=>({...e,id:e.materialId,name:e.materialId,mime:e.url.endsWith('.jpg')?'image/jpeg':e.url.endsWith('.webp')?'image/webp':'image/png',fileRevision:e.revision})),total:entries.length,page:1,pageSize:entries.length,offline:true};}
    },
    async summary(){return {total:0,scanning:false};},
    async read(id,{used=false}={}) {
      if(!/^[a-f0-9]{64}$/.test(id))throw failure('素材编号无效。');
      const cached=(await recent.list()).find(e=>e.materialId===id);
      if(!used) {
        const response=cached?await fetchImpl(cached.url,{cache:'no-store',credentials:'omit',redirect:'error',signal:AbortSignal.timeout(30000)}):await remote('/v1/materials/'+id+'/file');
        if(!response.ok)throw failure('素材预览暂时无法读取。');
        const bytes=Buffer.from(await response.arrayBuffer());
        if(cached&&createHash('sha256').update(bytes).digest('hex')!==cached.sha256)throw failure('素材预览校验失败。');
        return {bytes,mime:response.headers.get('content-type')?.split(';')[0]||'image/png',name:id};
      }
      let revision=cached?.revision;
      if(!revision){const response=await remote('/v1/materials/'+id);revision=(await response.json()).data?.fileRevision;}
      if(!/^[a-f0-9]{64}$/.test(revision||''))throw failure('素材内容版本不可用。');
      const {blob,entry}=await recent.open({materialId:id,revision});
      return {bytes:Buffer.from(await blob.arrayBuffer()),mime:blob.type,name:id+'.'+(blob.type==='image/jpeg'?'jpg':blob.type==='image/webp'?'webp':'png'),sourceUrl:entry.url,sourceSha256:entry.sha256};
    },
    async get(id){const value=await this.read(id);return {...value,id,size:value.bytes.length};},
    async put(input){const result=await host.ensureHosted({bytes:input.bytes,mimeType:input.mime});freshlyHosted.set(result.sha256,result);try{await recent.open({materialId:result.sha256,revision:result.sha256});}finally{freshlyHosted.delete(result.sha256);}return {created:true,record:{id:result.sha256,name:input.name,mime:input.mime,fileRevision:result.sha256}};},
    async trash(){throw failure('手机素材记录按30天清理，请在电脑管理源素材。');},
    async restore(){throw failure('请在电脑恢复源素材。');},scan:async()=>({count:0}),idle:async()=>{}
  };
  async function reconfigure() {
    generation++;const version=generation;auto?.stop();await setupMaterials();
    const desktop=config().desktop;
    if(!desktop?.endpoint||!desktop?.pairToken){status={state:'unconfigured',label:'未配置'};return;}
    mirror=createMirrorClient({baseUrl:desktop.endpoint,token:desktop.pairToken,directory:join(dataRoot,'mobile-mirror'),fetchImpl});
    const client={readManifest:()=>mirror.readManifest(),sync:async options=>{const result=await mirror.sync(options);if(!result.unchanged&&version===generation)await onSyncComplete(result.manifest);return result;}};
    auto=createAutoSync({client,onStatus:value=>{if(version===generation)status={...value,needsReopen:value.state==='ready'};}});void auto.start();
  }
  async function handle(req,res) {
    const path=new URL(req.url,'http://127.0.0.1').pathname;
    if(path!=='/__pod/mobile/sync/status'&&path!=='/__pod/mobile/sync/refresh')return false;
    const peer=String(req.socket.remoteAddress||'').replace(/^::ffff:/,'');
    if(peer!=='127.0.0.1'){res.writeHead(403);res.end();return true;}
    if(req.method==='POST') {
      const token=process.env.POD_NATIVE_TOKEN;
      if(!token||!timingSafeEqual(digest(String(req.headers['x-pod-native-token']||'')),digest(token))){res.writeHead(403);res.end();return true;}
      void auto?.refresh();
    }else if(req.method!=='GET'){res.writeHead(405);res.end();return true;}
    res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({success:true,data:status}));return true;
  }
  return {materialStore,reconfigure,handle,close(){generation++;auto?.stop();}};
}
