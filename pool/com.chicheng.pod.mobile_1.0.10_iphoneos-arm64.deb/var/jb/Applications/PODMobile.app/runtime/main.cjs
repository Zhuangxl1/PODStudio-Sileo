'use strict';
// The native host starts Node once for the lifetime of the iOS process.
import('./mobile-compat.mjs').then(()=>import('./mobile-diagnostics.mjs')).then(({installMobileDiagnostics})=>{installMobileDiagnostics();return (process.platform==='android'?import('./mobile-android-check.mjs').then(({checkAndroidNative})=>checkAndroidNative()):Promise.resolve()).then(()=>import('./mobile-bootstrap.mjs'));}).then(({startMobileRuntime}) => startMobileRuntime()).catch(error => {
  // Never print native settings, HTTP bodies or credential-bearing errors.
  process.stderr.write('POD mobile runtime could not start (' + (/^[A-Z_]{1,60}$/.test(error?.code || '') ? error.code : 'MOBILE_BOOT_FAILED') + ').\n');
  process.exitCode = 1;
});
