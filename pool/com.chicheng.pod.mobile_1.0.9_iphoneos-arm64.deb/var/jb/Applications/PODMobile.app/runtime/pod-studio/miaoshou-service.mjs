import {CODEX_TRO_PROVIDER} from './risk-tro-contract.mjs';
import {createMiaoshouTitleTranslations} from './miaoshou-title-translations.mjs';
import {runTitleTranslation} from './title-translation-runner.mjs';
import {validateTitleItems} from './title-translation-contract.mjs';
import {createBrandResearchClient} from './brand-research-client.mjs';
import {createBrandRiskResearch} from './brand-risk-research.mjs';
import {runRiskReview} from './risk-review-runner.mjs';
import {createDescriptionImageProcessor} from './miaoshou-description-images.mjs';
import {createMiaoshouSizeChartLibrary,MIAOSHOU_SIZE_CHART_REQUEST_BYTES} from './miaoshou-size-chart-library.mjs';
import {createMiaoshouDraftDiskStore,MIAOSHOU_DRAFT_OPERATIONS,MIAOSHOU_DRAFT_REQUEST_BYTES,runMiaoshouDraftOperation} from './miaoshou-draft-disk.mjs';

import {readMiaoshouCurrentSkuImageOptions,readMiaoshouSavedSkuImages} from './dist/miaoshou-variant-mockups.js';
import {loadMiaoshouEditContext,miaoshouEditRevision,createMiaoshouEditOptionsCache,MIAOSHOU_EDIT_OPTION_GROUPS,MIAOSHOU_WAREHOUSE_SHOPS_PER_REQUEST,normalizeMiaoshouWarehouseShop,usableMiaoshouWarehouse,MIAOSHOU_CATEGORY_UNASSIGNED} from './miaoshou-edit-context.mjs';

import {randomUUID,createHash} from 'node:crypto';

import {open,readFile,mkdir,rename,unlink} from 'node:fs/promises';

import {readMiaoshouImage} from './miaoshou-image.mjs';

import {spawn} from 'node:child_process';

import {resolve} from 'node:path';

import {fileURLToPath} from 'node:url';

import {createMiaoshouClient,sanitizeMiaoshouValue} from './miaoshou-client.mjs';

import {createMiaoshouReplacement,validateMiaoshouDetail} from './miaoshou-replacement.mjs';

import {createMiaoshouBatch} from './miaoshou-batch.mjs';
import {createMiaoshouBatchDelete} from './miaoshou-batch-delete.mjs';

import {createMiaoshouProductEdits,validateMiaoshouEditInput} from './miaoshou-product-edits.mjs';

import {createMiaoshouCache} from './miaoshou-cache.mjs';

import {createMiaoshouRiskReview} from './miaoshou-risk-review.mjs';

import {createMiaoshouRiskApiSource,miaoshouRiskSourceVersion} from './miaoshou-risk-api-source.mjs';

import {createMiaoshouCategoryAttributeTemplates} from './miaoshou-category-attribute-templates.mjs';
import {createMiaoshouLocalCategoryAttributes,LOCAL_ATTRIBUTE_OPERATIONS} from './miaoshou-local-category-attributes.mjs';

import {createMiaoshouClaimSizeCharts,applyMiaoshouClaimDefaults,skippedClaimDefaults,reviewClaimDefaults} from './miaoshou-claim-defaults.mjs';

import {validateCategoryAttributeTemplate} from './dist/miaoshou-category-attribute-template-schema.js';

import {builtinMiaoshouCategoryName,isBuiltinMiaoshouLeafCategory,builtinMiaoshouLeafCategoryIds} from './miaoshou-category-names.mjs';

import {compileMiaoshouAttributeUpdates} from './miaoshou-attribute-values.mjs';

import {compileStructuredPatch,STRUCTURED_EDIT_KEYS,structuredContextNeeds} from './miaoshou-structured-edits.mjs';

import {createMiaoshouSkuPresets} from './miaoshou-sku-presets.mjs';

import {createMiaoshouSkuStructureTemplates} from './miaoshou-sku-structure-templates.mjs';
import {createMiaoshouDescriptionTemplates} from './miaoshou-description-templates.mjs';
import {createMiaoshouMockupTemplateBindings} from './miaoshou-mockup-template-bindings.mjs';

import {localSkuReplacementChanges,localSkuTemplateForShop,validateSkuStructureTemplate} from './dist/miaoshou-sku-structure-schema.js';

import {skuPresetScopeMatches,validateSkuPreset} from './dist/miaoshou-sku-preset-schema.js';

import {preferredMiaoshouBlanketWarehouse,readMiaoshouCategoryName} from './dist/miaoshou-editor-read-model.js';
import {miaoshouLeafCategory} from './dist/print-extraction-policy.js';
import {randomMiaoshouPackage} from './dist/miaoshou-package-defaults.js';

import {createMiaoshouReferenceLayout} from './miaoshou-reference-layout.mjs';
import {listingTitleFacts,readListingTitleEvidence,readListingTitleGallery} from './miaoshou-listing-title-evidence.mjs';

import {miaoshouId,singleShopPolicy} from './dist/miaoshou-policy.js';

const publicJSON=value=>JSON.stringify(value,(_k,v)=>typeof v==='bigint'?String(v):v);

// The collection API supports 500 rows per page but declares no page totals.

const COLLECTION_PAGE_SIZE=500;
const COLLECTION_REFRESH_INTERVAL=5*60*1000;
const COLLECTION_PROPOSAL_LIFETIME=15*60*1000;

const batchSettingsKind=['description','sku','attribute'];
const batchSettingsKeys=['package','descriptionTemplate','skuTemplate','attributeTemplate'];
const batchSettingsObject=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).every(key=>keys.includes(key));
const batchSettingsError=message=>Object.assign(new Error(message),{code:'MIAOSHOU_BATCH_SETTINGS_INVALID',status:400});
const batchSettingsProgressId=value=>typeof value==='string'&&/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/iu.test(value);
const BATCH_SETTINGS_PROGRESS_TTL=2*60*1000;
const BATCH_SETTINGS_PROGRESS_LIMIT=64;

function batchSettingsIds(input){
  if(!Array.isArray(input)||!input.length||input.length>200)throw batchSettingsError('请选择 1–200 个商品。');
  const ids=input.map(miaoshouId);
  if(new Set(ids).size!==ids.length)throw batchSettingsError('批量选择中存在重复链接。');
  return ids;
}

function parseBatchSettings(value){
  if(!batchSettingsObject(value,batchSettingsKeys)||!Object.keys(value).length)throw batchSettingsError('请至少填写或选择一项批量设置。');
  const result={};
  if(Object.hasOwn(value,'package')){
    const input=value.package;
    if(input?.mode==='random'&&batchSettingsObject(input,['mode']))result.package={mode:'random'};
    else{
      const dims=input?.packageDimensionsCm;
      if(!batchSettingsObject(input,['mode','weightGrams','packageDimensionsCm'])||input.mode!=='fixed'||!batchSettingsObject(dims,['length','width','height'])||
         !Number.isFinite(input.weightGrams)||input.weightGrams<1||input.weightGrams>100000||
         ['length','width','height'].some(key=>!Number.isFinite(dims[key])||dims[key]<1||dims[key]>1000))
        throw batchSettingsError('请填写 1–100000 g 的重量和 1–1000 cm 的长宽高。');
      result.package={mode:'fixed',weightGrams:input.weightGrams,packageDimensionsCm:{length:dims.length,width:dims.width,height:dims.height}};
    }
  }
  for(const [kind,scope] of [['descriptionTemplate','shopId'],['skuTemplate',''],['attributeTemplate','categoryId']]){
    if(!Object.hasOwn(value,kind))continue;
    const ref=value[kind];
    if(!batchSettingsObject(ref,scope?['id',scope]:['id'])||typeof ref.id!=='string'||!/^[a-f\d]{8}-[a-f\d]{4}-4[a-f\d]{3}-[89ab][a-f\d]{3}-[a-f\d]{12}$/u.test(ref.id))
      throw batchSettingsError('模板选择无效，请重新读取本机模板。');
    result[kind]={id:ref.id,...(scope?{[scope]:miaoshouId(ref[scope])}:{})};
  }
  return result;
}

export function createMiaoshouSettings({root,secretIO}={}){

  const path=resolve(root,'miaoshou-secrets.dpapi'),script=fileURLToPath(new URL('./provider-secrets.ps1',import.meta.url));let cached;

  const io=secretIO||((mode,input)=>new Promise((done,reject)=>{

    const child=spawn('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',script,'-Mode',mode,'-Path',path],{windowsHide:true,stdio:['pipe','pipe','ignore']});let output='';

    const timer=setTimeout(()=>{child.kill();reject(new Error('妙手配置读取超时。'));},10000);

    child.stdout.on('data',chunk=>{output+=chunk;if(output.length>16384)child.kill();});child.on('error',()=>{clearTimeout(timer);reject(new Error('妙手配置无法读取。'));});

    child.on('close',code=>{clearTimeout(timer);try{if(code)throw new Error();done(mode==='read'?JSON.parse(output):true);}catch{reject(new Error('妙手配置无法读取或保存。'));}});child.stdin.on('error',()=>{});child.stdin.end(input?JSON.stringify(input):'');

  }));

  return {async read(){return cached??=await io('read');},async accountScope(){const c=await this.read();if(!c.appKey||!c.appSecret)throw Object.assign(new Error('请先配置妙手连接。'),{status:503});return createHash('sha256').update(c.appKey).digest('hex');},async status(){const c=await this.read();return {configured:Boolean(c.appKey&&c.appSecret)};},async save(value){

    if(!value||Object.keys(value).some(k=>!['appKey','appSecret'].includes(k))||['appKey','appSecret'].some(k=>typeof value[k]!=='string'||!value[k].trim()||value[k].length>4096||/[\s\u0000-\u001f\u007f]/.test(value[k])))throw Object.assign(new Error('请填写有效的妙手 App Key 和 App Secret。'),{status:400});

    await io('write',value);cached={...value};return this.status();

  }};

}

function extractionLeafCategory(row){
  const id=String(row?.cid??row?.categoryId??'');
  const builtin=/^[1-9]\d*$/u.test(id)?builtinMiaoshouCategoryName(id):undefined;
  return miaoshouLeafCategory(builtin?.name)||miaoshouLeafCategory(readMiaoshouCategoryName(row));
}

export function normalizeMiaoshouPage(data){

  let rows=Array.isArray(data)?data:undefined;

  if(!rows)for(const key of ['detailList','records','list','items','rows','content'])if(Array.isArray(data?.[key])){rows=data[key];break;}

  if(!rows&&data?.collectBoxDetailId)rows=[data];

  if(!rows)throw new Error('妙手采集箱列表格式不匹配，未执行任何替换。');

  return rows.map(row=>{

    const shopIds=Array.isArray(row.collectBoxDetailShopList)?[...new Set(row.collectBoxDetailShopList.map(item=>miaoshouId(item.shopId)))].sort():undefined;

    const policy=singleShopPolicy(shopIds);

    const reviewSourceVersion=miaoshouRiskSourceVersion(row),leafCategory=extractionLeafCategory(row);
    return {...(leafCategory?{leafCategory}:{}),id:miaoshouId(row.collectBoxDetailId),title:String(row.title||''),thumbnail:String(row.thumbnail||''),price:String(row.price??''),itemNum:String(row.itemNum||''),createdAt:String(row.gmtCreate||''),remark:String(row.remark||''),groupId:String(row.collectBoxGroupId||''),groupName:String(row.collectBoxGroupName||''),shopIds,policy,...(reviewSourceVersion?{reviewSourceVersion}:{})};

  });

}

// Only operation identifiers and state are persisted; credentials, shop names,

// product titles and raw platform payloads never enter this journal.

function createActionJournal(root){

  const path=root?resolve(root,'action-journal-v1.json'):null;let memory={version:1,entries:[]},queue=Promise.resolve();

  async function read(){

    if(!path)return structuredClone(memory);

    try{const bytes=await readFile(path);if(bytes.length>8*1024*1024)throw new Error();const data=JSON.parse(bytes.toString('utf8'));if(data?.version!==1||!Array.isArray(data.entries)||data.entries.length>20000)throw new Error();

      for(const e of data.entries)if(!/^[a-f0-9]{64}$/.test(e.key)||!/^[a-f0-9]{64}$/.test(e.accountScope)||!['submitting','submitted','uncertain','failed','claimed','deleted','released'].includes(e.state)||!['claim','delete','publish'].includes(e.action)||typeof e.operationId!=='string')throw new Error();

      return data;

    }catch(error){if(error.code==='ENOENT')return {version:1,entries:[]};throw Object.assign(new Error('妙手操作记录无法读取，请保留记录并核对后再操作。'),{code:'ACTION_JOURNAL_UNAVAILABLE'});}

  }

  async function transaction(fn){

    const work=queue.then(async()=>{

      let lock,temp;

      try{if(path){await mkdir(resolve(root),{recursive:true});try{lock=await open(path+'.lock','wx');}catch{throw new Error('妙手操作记录正在使用或需要核对，请稍后重试。');}}

        const data=await read(),result=fn(data);if(path){temp=path+'.'+randomUUID()+'.tmp';const file=await open(temp,'wx');try{await file.writeFile(JSON.stringify(data));await file.sync();}finally{await file.close();}await rename(temp,path);temp=null;}else memory=data;return result;

      }finally{if(temp)await unlink(temp).catch(()=>{});if(lock){await lock.close();await unlink(path+'.lock').catch(()=>{});}}

    });queue=work.catch(()=>{});return work;

  }

  return {

    async find(key){return (await read()).entries.findLast(e=>e.key===key&&e.state!=='released');},

    async operation(scope,id){return (await read()).entries.find(e=>e.accountScope===scope&&e.operationId===id);},

    reserve(entry){return transaction(data=>{const previous=data.entries.findLast(e=>e.key===entry.key&&e.state!=='released');if(previous)throw Object.assign(new Error('此操作已有提交记录，请核对结果。'),{code:'ACTION_REVIEW_REQUIRED',data:previous});if(data.entries.length>=20000)throw new Error('妙手操作记录已满，请保留记录并联系管理员。');data.entries.push({...entry});return {...entry};});},

    reserveMany(entries){return transaction(data=>{
      const active=new Map(data.entries.filter(entry=>entry.state!=='released').map(entry=>[entry.key,entry]));
      const reserved=[],existing=[];
      for(const entry of entries){const previous=active.get(entry.key);if(previous){existing.push({...previous});continue;}const next={...entry};reserved.push(next);active.set(entry.key,next);}
      if(data.entries.length+reserved.length>20000)throw new Error('妙手操作记录已满，请保留记录并联系管理员。');
      data.entries.push(...reserved);return {reserved:structuredClone(reserved),existing:structuredClone(existing)};
    });},

    transition(id,scope,state){return transaction(data=>{const entry=data.entries.find(e=>e.operationId===id&&e.accountScope===scope);if(!entry)throw new Error('妙手操作记录不存在。');entry.state=state;entry.updatedAt=new Date().toISOString();return {...entry};});},

    transitionMany(changes,scope){return transaction(data=>{
      const entries=changes.map(change=>{const entry=data.entries.find(entry=>entry.operationId===change.operationId&&entry.accountScope===scope);
        if(!entry||!['deleted','failed','uncertain'].includes(change.state))throw new Error('妙手操作记录不存在或状态无效。');return {entry,state:change.state};});
      const updatedAt=new Date().toISOString();for(const {entry,state}of entries){entry.state=state;entry.updatedAt=updatedAt;}
      return entries.map(({entry})=>({...entry}));
    });},

    recordClaimDefaults(id,scope,outcome){return transaction(data=>{const entry=data.entries.find(e=>e.operationId===id&&e.accountScope===scope&&e.state==='claimed'&&e.action==='claim');if(!entry)throw new Error('妙手认领记录不存在。');entry.claimDefaults=structuredClone(outcome);entry.updatedAt=new Date().toISOString();});},

    release(id,scope){return transaction(data=>{const entry=data.entries.find(e=>e.operationId===id&&e.accountScope===scope);if(!entry||entry.state!=='failed')throw new Error('该操作结果尚未明确失败，不能再次提交，请先在妙手核对。');entry.state='released';entry.updatedAt=new Date().toISOString();return {...entry};});}

  };

}

export function createMiaoshouService({root,templateRoot=root,templatesReady,settings=createMiaoshouSettings({root}),client=createMiaoshouClient({settings}),imageReader=readMiaoshouImage,findExecutable,runCodexTask,titleTranslationRunner=runTitleTranslation,riskReview:providedRiskReview,riskVision,referenceVision,courtListenerClient,brandResearch:providedBrandResearch,brandResearchClient}={}){

  const actionTickets=new Map(),actionLocks=new Set(),journal=createActionJournal(root),collectionCache=createMiaoshouCache({root});
  const batchSettingsProgress=new Map();
  const localDraftDisk=root?createMiaoshouDraftDiskStore({root}):null;const fallbackScope=createHash('sha256').update(randomUUID()).digest('hex');let activeOperations=0,closed=false;

  function assertOpen(){if(closed||configuring)throw Object.assign(new Error(closed?'妙手工作台正在关闭，未继续提交操作。':'妙手连接正在更新，请稍后重试。'),{status:409});}

  const api={async call(operation,payload,{guard=()=>{},priority='foreground',signal,timeoutMs,maxRetries}={}){

    if(typeof guard!=='function')throw new TypeError('妙手请求核验函数无效。');

    try{assertOpen();}catch(error){if(operation==='save')error.notDispatched=true;throw error;}const generation=epoch;

    const checkCurrent=()=>{assertOpen();if(generation!==epoch)throw new Error('妙手连接已变化，请重新操作。');};

    const current=()=>{checkCurrent();const result=guard();if(result&&typeof result.then==='function')return Promise.resolve(result).then(checkCurrent);checkCurrent();};

    const value=await client.call(operation,payload,{guard:current,priority,
      ...(signal?{signal}:{}),...(timeoutMs!==undefined?{timeoutMs}:{}),...(maxRetries!==undefined?{maxRetries}:{})});

    // A validated save acknowledgement is a fact about the original request.
    // A later account switch must block UI/cache adoption, not erase that fact.
    if(operation!=='save')await current();return value;

  }};

  const accountScope=async()=>{const scope=settings.accountScope?await settings.accountScope():fallbackScope;if(!/^[a-f0-9]{64}$/.test(scope))throw new Error('妙手账号作用域无效。');return scope;};
  const titleTranslations=createMiaoshouTitleTranslations({root,run:async(items,{signal,onStart})=>{
    if(typeof runCodexTask!=='function')throw new Error('标题翻译服务尚未就绪。');
    return runCodexTask(async options=>{onStart();return titleTranslationRunner(items,options);},{signal,bytes:Buffer.byteLength(JSON.stringify(items))});
  }});

  const emptyAccount=()=>({connection:'unverified',profileAvailable:false,checkedAt:'',lastError:''});

  const emptySyncState=()=>Object.fromEntries(['account','shops','warehouses','collection'].map(key=>[key,{state:'pending',at:'',error:''}]));

  const localDraftScope=async()=> (await settings.status()).configured?createHash('sha256').update('pod-local-draft-v1:'+await accountScope()).digest('hex'):null;
  let account=emptyAccount(),syncState=emptySyncState(),syncTask=null,activeSyncRunId=null,activeSyncMode=null,contextId=randomUUID();
  let confirmedPublication={notPublished:[],published:[]};
  let collectionRefresh={state:'idle'},nextCollectionRefreshAt=0,declinedCollectionRefresh='',collectionRefreshApplying=null;

  function assertContext(input,{required=false}={}){if((required||Object.hasOwn(input,'contextId'))&&input.contextId!==contextId)throw Object.assign(new Error('妙手连接已切换，请刷新列表后重新选择；已提取原件仍保存在素材库。'),{status:409,code:'CONTEXT_CHANGED'});}

  function phase(key,state,error=''){syncState[key]={state,at:state==='success'?new Date().toISOString():syncState[key].at,error:sanitizeMiaoshouValue(error,[],1000)};}

  let replacements=createMiaoshouReplacement({client:api}),records=new Map(),syncing=false,lastError='',syncedAt='',epoch=0,activeWrites=0,configuring=false,shopDirectory=new Map(),shopsError='',syncProgress={pages:0,records:0,complete:false},statusPages={notPublished:null,published:null},cacheLoaded=false,cacheLoading=null,cacheScope='',cacheInfo={restored:false,persisted:false,lastChanges:null,error:''},batchActive=false;

  const json=(res,status,value)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(publicJSON(value));};

  const descriptionImages=createDescriptionImageProcessor({root,client:api,accountScope,guard:assertOpen});

  // The source hash stays public; its account/target association remains local.

  // Reading context is not a write, and changing the connection drops old reads.

  const editorSnapshots=new Map();

  const editorOptions=createMiaoshouEditOptionsCache({client:api});
  let warehouseDirectory=new Map(),warehouseScope='',warehouseUpdates=Promise.resolve();
  const savedWarehouse=(scope,shopId)=>scope===warehouseScope&&shopDirectory.has(shopId)?warehouseDirectory.get(shopId):undefined;
  const queueWarehouseUpdate=task=>{
    const next=warehouseUpdates.then(task);
    warehouseUpdates=next.catch(()=>{});
    return next;
  };

  const productEdits=createMiaoshouProductEdits({
    client:api,root,accountScope,assertOpen,
    getShopSite:shopId=>shopDirectory.get(shopId)?.siteCode,
    resolveDescriptionImages:(input,target,info)=>descriptionImages.resolve(input,target,info)
  });

  const templateSetup=Promise.resolve(templatesReady).then(()=>true,()=>false);
  function openTemplateStore(create){
    const store=create({root:templateRoot});
    if(templatesReady===undefined)return store;
    return Object.fromEntries(Object.entries(store).map(([name,operation])=>[name,name==='close'?operation:async (...args)=>{
      if(!await templateSetup)throw Object.assign(new Error('模板库尚未同步完成，请检查启动程序中的模板目录。'),{status:503,code:'MIAOSHOU_TEMPLATE_LIBRARY_UNAVAILABLE'});
      assertOpen();
      return operation.apply(store,args);
    }]));
  }

  const skuPresets=openTemplateStore(createMiaoshouSkuPresets),skuStructures=openTemplateStore(createMiaoshouSkuStructureTemplates);
  const descriptionTemplates=openTemplateStore(createMiaoshouDescriptionTemplates);
  const mockupTemplateBindings=openTemplateStore(createMiaoshouMockupTemplateBindings);

  const attributeTemplates=openTemplateStore(createMiaoshouCategoryAttributeTemplates);
  const localCategoryAttributes=createMiaoshouLocalCategoryAttributes({templates:attributeTemplates,client:api});

  async function localAttributeContext(req,input){
    assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),detailId=miaoshouId(input.detailId);
    if(typeof input.sourceRevision!=='string'||!/^[a-f0-9]{64}$/.test(input.sourceRevision))throw new Error('请重新读取当前链接后使用本机属性模板。');
    const key=detailId+':'+input.sourceRevision,snapshot=editorSnapshots.get(key);
    const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});
      if(req.aborted||await accountScope()!==scope)throw Object.assign(new Error('妙手连接已变化，请重新读取模板。'),{code:'CONTEXT_CHANGED',status:409});
      const policy=singleShopPolicy(records.get(detailId)?.shopIds);
      if(!snapshot||editorSnapshots.get(key)!==snapshot||snapshot.scope!==scope||snapshot.contextId!==selectedContext||snapshot.expires<Date.now()||!policy.allowed||policy.shopId!==snapshot.shopId)throw Object.assign(new Error('链接原件已失效，请重新读取后编辑模板。'),{code:'MIAOSHOU_EDIT_STALE',status:409});};
    await guard();return {accountScope:scope,contextId:selectedContext,detailId,shopId:snapshot.shopId,categoryId:snapshot.categoryId,sourceRevision:input.sourceRevision,legacyShopIds:[...shopDirectory.keys()],guard,
      async readSource(){await guard();const target={detailId,shopId:snapshot.shopId};const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(detailId),shopId:BigInt(snapshot.shopId)}),target);await guard();return {info:detail.shopCollectItemInfo,revision:miaoshouEditRevision(detail)};}};
  }

  const claimSizeCharts=openTemplateStore(createMiaoshouClaimSizeCharts);
  const sizeChartLibrary=openTemplateStore(createMiaoshouSizeChartLibrary);

  const skuPresetCategories=new Map(),skuPresetCategoryReads=new Map();

  function rememberSkuPresetCategory(context,scope,readContext){

    const shop=shopDirectory.get(context.shopId),path=readMiaoshouCategoryName(context.product);if(!context.categoryId||!shop||!path)return null;

    const item={id:context.categoryId,path,shopId:context.shopId,shopName:shop.code||shop.name,scope,contextId:readContext,at:Date.now()};

    skuPresetCategories.set([scope,readContext,item.shopId,item.id].join('|'),item);while(skuPresetCategories.size>500)skuPresetCategories.delete(skuPresetCategories.keys().next().value);return item;

  }

  async function riskGuard(options){assertOpen();options.signal?.throwIfAborted();assertContext({contextId:options.contextId},{required:true});if(await accountScope()!==options.accountScope)throw new Error('妙手账号已变化，停止旧商品检查。');}

  const riskClient={call:(operation,payload,options={})=>api.call(operation,payload,{...options,priority:'background'})};

  const riskApiSource=createMiaoshouRiskApiSource({client:riskClient,guard:riskGuard,normalizeCollection:normalizeMiaoshouPage});

  const publicBrandClient=brandResearchClient||(!providedBrandResearch&&!providedRiskReview&&!riskVision&&root&&typeof findExecutable==='function'?createBrandResearchClient({root:resolve(root,'brand-public-cache')}):null);
  const brandResearch=providedBrandResearch||(publicBrandClient?createBrandRiskResearch({root,runResearch:(subjects,options)=>publicBrandClient.research(subjects,options)}):null);
  async function onRiskResult({accountScope:scope,contextId:selectedContext,review}){
    if(!brandResearch||closed||configuring||selectedContext!==contextId||await accountScope()!==scope||selectedContext!==contextId)return;
    brandResearch.enqueue({accountScope:scope,contextId:selectedContext,reviews:[review]});
  }
  const legalRiskVision=(input,options)=>(riskVision||runRiskReview)(input,{...options,...(courtListenerClient?{courtListener:courtListenerClient}:{})});
  const riskReview=providedRiskReview||createMiaoshouRiskReview({root,findExecutable,troProvider:!courtListenerClient&&!riskVision?CODEX_TRO_PROVIDER:undefined,onResult:onRiskResult,runReview:legalRiskVision,readProduct:(row,options)=>riskApiSource.readProduct(row,options),async readImage(url,options){await riskGuard(options);const value=await imageReader(url,{signal:options.signal});await riskGuard(options);return {bytes:value.bytes,contentType:value.type};}});

  async function queueRiskReview(rows,{retry=false,changed=false,collectionRows}={}){const selectedContext=contextId,scope=await accountScope();if(closed||configuring||selectedContext!==contextId)return;if(changed&&typeof riskReview.markChanged==='function')await riskReview.markChanged({accountScope:scope,contextId:selectedContext,ids:rows.map(row=>row.id)});if(closed||configuring||selectedContext!==contextId||await accountScope()!==scope)return;if(!providedRiskReview&&typeof findExecutable!=='function')return;const inputRows=providedRiskReview?rows:riskApiSource.prepare({records:rows,collectionRows,contextId:selectedContext,accountScope:scope});return riskReview[retry?'retry':'enqueue']({accountScope:scope,contextId:selectedContext,records:inputRows});}

  const referenceGalleryReceipts=new Map();

  const galleryHash=(scope,id,urls)=>createHash('sha256').update(JSON.stringify([scope,contextId,id,urls])).digest('hex');

  async function referenceGallery(input,{signal}={}){

    const selectedContext=contextId,scope=await accountScope();assertOpen();assertContext(input,{required:true});signal?.throwIfAborted();

    const row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('商品不在当前采集箱中。');

    if(!row.policy?.allowed&&row.policy?.code!=='NO_SHOP')throw new Error(row.policy?.message||'无法确认关联店铺。');

    const policy=singleShopPolicy(row.shopIds);let urls,sourceCoverage='full-gallery';

    if(policy.code==='NO_SHOP'){

      const fresh=await freshRecord(row.id);if(!fresh||singleShopPolicy(fresh.shopIds).code!=='NO_SHOP')throw new Error('采集箱商品或关联店铺已变化，请重新打开套图窗口。');

      urls=[fresh.thumbnail];sourceCoverage='collection-thumbnail-only';

    }else{

      if(!policy.allowed)throw new Error(policy.message);

      const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(row.id),shopId:BigInt(policy.shopId)}),{detailId:row.id,shopId:policy.shopId});urls=detail.shopCollectItemInfo.imgUrls;

    }

    assertOpen();assertContext({contextId:selectedContext},{required:true});signal?.throwIfAborted();if(await accountScope()!==scope)throw new Error('妙手账号已变化，请重新读取原主图。');

    if(!Array.isArray(urls)||!urls.length||urls.length>15||urls.some(url=>typeof url!=='string'||!url))throw new Error('原主图组无效或超过15张，请核对来源。');

    if(input.sourceGallery!==undefined&&JSON.stringify(input.sourceGallery)!==JSON.stringify(urls))throw new Error('原主图组或顺序已变化，请重新打开套图窗口。');

    if(input.sourceUrl!==undefined&&input.sourceUrl!==urls[0])throw new Error('原主图已变化，请重新打开套图窗口。');

    const galleryFingerprint=galleryHash(scope,row.id,urls);

    if(input.galleryFingerprint!==undefined&&input.galleryFingerprint!==galleryFingerprint)throw new Error('原主图组已变化，请重新识别后提取印花。');

    return {urls:[...urls],galleryFingerprint,scope,selectedContext,sourceCoverage};

  }

  const referenceLayouts=createMiaoshouReferenceLayout({findExecutable,runVision:referenceVision,async validateSource(input,source,{signal}){

    if(source.galleryFingerprint)await referenceGallery({...input,galleryFingerprint:source.galleryFingerprint},{signal});

  },async readReference(input,{signal,onCoverage}){

    if(Array.isArray(input.sourceGallery)){

      const source=await referenceGallery(input,{signal}),images=[],failedIndices=[],failures=[];

      const progress=()=>onCoverage?.({total:source.urls.length,read:images.length,failedIndices:[...failedIndices],failures:[...failures],sourceCoverage:source.sourceCoverage});progress();

      for(const [index,url]of source.urls.entries()){

        signal.throwIfAborted();try{const image=await imageReader(url,{signal,usePublicFallback:true});signal.throwIfAborted();images.push({bytes:image.bytes,contentType:image.type,imageIndex:index+1});}

        catch(error){
          if(signal.aborted)throw error;
          const imageIndex=index+1;
          failedIndices.push(imageIndex);
          failures.push({imageIndex,message:error?.sourceImageError===true?String(error.message).slice(0,180):'主机无法读取这张原图。'});
        }
        progress();

        assertOpen();assertContext({contextId:source.selectedContext},{required:true});if(await accountScope()!==source.scope)throw new Error('妙手账号已变化，停止旧原图识别。');

      }

      if(!failedIndices.length){

        const hashes=images.map(image=>createHash('sha256').update(image.bytes).digest('hex'));

        referenceGalleryReceipts.set(source.galleryFingerprint,{detailId:input.detailId,contextId:source.selectedContext,scope:source.scope,hashes,at:Date.now()});

        while(referenceGalleryReceipts.size>100)referenceGalleryReceipts.delete(referenceGalleryReceipts.keys().next().value);

      }

      return {images,total:source.urls.length,failedIndices,failures,galleryFingerprint:source.galleryFingerprint,sourceCoverage:source.sourceCoverage};

    }

    const selectedContext=contextId;assertContext(input,{required:true});signal.throwIfAborted();

    const row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('商品不在当前采集箱中。');

    const policy=singleShopPolicy(row.shopIds);let urls;

    if(policy.code==='NO_SHOP')urls=[row.thumbnail];

    else {if(!policy.allowed)throw new Error(policy.message);const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(row.id),shopId:BigInt(policy.shopId)}),{detailId:row.id,shopId:policy.shopId});urls=detail.shopCollectItemInfo.imgUrls;}

    assertContext({contextId:selectedContext},{required:true});signal.throwIfAborted();

    if(typeof input.sourceUrl!=='string'||!urls.includes(input.sourceUrl))throw new Error('原主图已变化，请重新打开套图窗口。');

    const image=await imageReader(input.sourceUrl,{signal,usePublicFallback:true});assertContext({contextId:selectedContext},{required:true});signal.throwIfAborted();return {bytes:image.bytes,contentType:image.type};

  }});

  async function recordVerifiedProductEdit(detailId,changes,result,{strict=false}={}){

    const row=records.get(detailId);

    if(!row)return;
    if(collectionRefreshApplying){
      await collectionRefreshApplying;
      if(records.get(detailId)!==row)return;
    }

    if(Object.hasOwn(changes,'title')&&typeof result.title==='string'){

      row.sourceTitle??=row.title;

      row.title=result.title;

    }

    if(Object.hasOwn(changes,'mainImages')&&typeof result.thumbnail==='string'){

      row.sourceThumbnail??=row.thumbnail;

      row.thumbnail=result.thumbnail;

      row.imageSource='shop';

    }

    await patchCollectionCache([row],[],{strict});

    if(['title','description','mainImages'].some(key=>Object.hasOwn(changes,key)))try{await queueRiskReview([row],{changed:true});}catch{cacheInfo.error='商品已保存，风险检查更新尚未保存到本机，请重新检查该商品。';}

  }

  const deleteBatch=createMiaoshouBatchDelete({getRecords:()=>records,accountScope,getContextId:()=>contextId,assertOpen,journal,call:api.call,
    acquire(ids){assertOpen();if(activeWrites||syncing||ids.some(id=>actionLocks.has(id)))throw new Error('所选商品正在执行其他操作，请稍后删除。');
      activeWrites++;for(const id of ids)actionLocks.add(id);return ()=>{activeWrites--;for(const id of ids)actionLocks.delete(id);};},
    async getRedactions(){const config=settings.read?await settings.read():{};return [config.appKey,config.appSecret].filter(Boolean);},
    async removeDeleted(ids){const removed=new Set(ids);for(const id of ids)records.delete(id);
      for(const key of ['notPublished','published']){if(Array.isArray(statusPages[key]))statusPages[key]=statusPages[key].filter(id=>!removed.has(id));confirmedPublication[key]=confirmedPublication[key].filter(id=>!removed.has(id));}
      await patchCollectionCache([],ids,{strict:true});}
  });
  const batches=createMiaoshouBatch({getRecords:()=>records,getShops:shops,accountScope,getContextId:()=>contextId,assertOpen,validateChanges:validateMiaoshouEditInput,
    executeBatch:(_action,items,options)=>deleteBatch(items,options),acquire(){

    assertOpen();if(syncing||activeWrites||batchActive)throw new Error('妙手任务正在执行，请完成后再提交批量操作。');

    batchActive=true;activeOperations++;return ()=>{batchActive=false;activeOperations--;};

  },async execute(action,item,{shopId,changes,expectedSourceHash,expectedScope,directCategory}){

    if(['claim','delete'].includes(action)){

      const prepared=await prepareAction({action,detailId:item.detailId,...(action==='claim'?{shopId}:{})});

      if(![item.title,item.sourceTitle].includes(prepared.title)||publicJSON([...(prepared.associatedShopIds||[])].sort())!==publicJSON([...(item.shopIds||[])].sort()))throw new Error('商品或关联店铺在确认后发生变化，请重新核对。');

      return commitAction({ticket:prepared.ticket,confirmed:true},{fromBatch:true});

    }

    if(directCategory&&(!statusPages.notPublished?.includes(item.detailId)||statusPages.published?.includes(item.detailId)))
      throw Object.assign(new Error('商品已不在已核验的未发布链接中。'),{code:'MIAOSHOU_EDIT_STALE'});
    const editContext=contextId,editScope=await accountScope(),editRow=records.get(item.detailId);

    activeWrites++;try{

      const result=await productEdits.apply({detailId:item.detailId,shopIds:item.shopIds,action,changes},{expectedSourceHash,expectedScope,directCategory});

      let refreshWarning='';

      try{

        assertOpen();if(editContext!==contextId||editScope!==await accountScope()||records.get(item.detailId)!==editRow)throw new Error('CONTEXT_CHANGED');

        await recordVerifiedProductEdit(item.detailId,changes,result,{strict:true});

      }catch{refreshWarning=' 修改结果已确认，列表刷新尚未完成，请稍后重新读取。';}

      const message=action==='category'
        ?(result.state==='unchanged'?'妙手商品已是所选类目。':result.verified?'已保存类目并从妙手读回核对。':'妙手已接收保存，类目或原商品资料未能完整核对，请在妙手查看。')
        :action==='warehouse'
          ?(result.state==='unchanged'?'商品已使用所选仓库。':result.verified?'仓库已更新，SKU 库存数量已核对。':'妙手已接收保存，仓库结果需要核对。')
        :(result.state==='unchanged'?'已读取妙手，指定内容已一致，无需重复保存':result.confirmation==='api_receipt'?'已保存到妙手采集箱。':'已读取妙手并核对指定修改内容。');

      return {...result,message:message+refreshWarning,...(refreshWarning?{localRefreshWarning:refreshWarning.trim()}:{})};

    }finally{activeWrites--;}

  },async verify({item,operationId,changes,scope,contextId:expectedContextId}){

    const row=records.get(item.detailId),current=singleShopPolicy(row?.shopIds);

    if(!current.allowed||current.shopId!==singleShopPolicy(item.shopIds).shopId)return;

    const result=await productEdits.verifyResult({detailId:item.detailId,shopIds:item.shopIds,operationId,changes},{expectedScope:scope});

    assertOpen();

    assertContext({contextId:expectedContextId},{required:true});

    if(result?.verified&&records.get(item.detailId)===row)await recordVerifiedProductEdit(item.detailId,changes,result);

    return result;

  }});

  async function ensureCollectionCache(){

    if(cacheLoaded||!root)return;

    if(cacheLoading)return cacheLoading;

    const generation=epoch;

    cacheLoading=(async()=>{try{

      const currentScope=await accountScope();cacheScope=createHash('sha256').update(currentScope+'\0tiktok\0all-sites\0v1').digest('hex');

      const saved=await collectionCache.load(cacheScope);if(generation!==epoch||closed)return;

      if(saved){records=new Map((saved.records||[]).map(row=>[row.id,row]));shopDirectory=new Map((saved.shops||[]).map(shop=>[shop.id,shop]));statusPages=saved.statusPages||{notPublished:null,published:null};syncedAt=saved.syncedAt||'';syncProgress=saved.syncProgress||{pages:0,records:records.size,complete:false};account={...emptyAccount(),...saved.account,connection:'unverified'};syncState={...emptySyncState(),...saved.syncState};cacheInfo={restored:records.size>0||shopDirectory.size>0,persisted:Boolean(saved.syncedAt||records.size||shopDirectory.size),lastChanges:null,error:saved.incomplete?'上次同步未完成，已保留已保存的数据，请继续同步。':''};
        confirmedPublication={notPublished:statusPages.notPublished||[],published:statusPages.published||[]};
        warehouseScope=currentScope;warehouseDirectory=new Map((saved.warehouseSnapshot||[]).filter(entry=>shopDirectory.has(entry.id)).map(entry=>[entry.id,entry]));
        if(saved.warehouseSnapshot){syncProgress.warehouseShopsTotal=warehouseDirectory.size;syncProgress.warehouseShopsFailed=[...warehouseDirectory.values()].filter(entry=>entry.stale).length;syncProgress.warehouseShopsSynced=warehouseDirectory.size-syncProgress.warehouseShopsFailed;}
        if(saved.incomplete){syncProgress={...syncProgress,complete:false,scopeComplete:false,fullyComplete:false};for(const key of ['account','shops','warehouses','collection'])if(['pending','syncing'].includes(syncState[key].state))phase(key,'error','上次同步中断，请重新同步妙手数据。');}}

    }catch{cacheInfo.error='本地同步数据未能读取，请重新同步；原数据文件已保留。';}finally{if(generation===epoch){cacheLoaded=true;cacheLoading=null;}}})();

    return cacheLoading;

  }

  function mergeIncoming(row,old){

    const sourceThumbnail=row.thumbnail;

    if(old){const comparable={...old,thumbnail:old.sourceThumbnail??old.thumbnail,title:old.sourceTitle??old.title};if(Object.keys(row).every(key=>publicJSON(row[key])===publicJSON(comparable[key])))return old;}

    const merged={...row,sourceThumbnail,sourceTitle:row.title};
    if(old?.lastMiaoshouSyncAt&&row.shopIds?.includes(old.lastMiaoshouSyncShopId)){
      merged.lastMiaoshouSyncAt=old.lastMiaoshouSyncAt;
      merged.lastMiaoshouSyncShopId=old.lastMiaoshouSyncShopId;
    }
    return merged;

  }

  async function patchCollectionCache(rows=[],removeIds=[],{runId,strict=false,progress}={}){

    if(!root||!cacheScope)return null;

    try{return await collectionCache.patch(cacheScope,{records:rows,removeIds,...(runId?{runId}:{}),...(progress?{progress}:{})});}catch{cacheInfo.error='本地保存未完成，已保留上次保存结果，请重新同步。';if(strict)throw new Error(cacheInfo.error);return null;}

  }

  async function saveCollectionCache(complete,{runId,finish,strict=false,snapshot,completedStatuses,mode=activeSyncMode||'all',scopeComplete=false,warehouseSnapshot}={}){

    if(!root||!cacheScope)return null;

    const value=snapshot||{records:mode==='notPublished'?[]:[...records.values()],shops:[...shopDirectory.values()],account,syncState,statusPages,syncedAt,syncProgress};
    try{const changes=await collectionCache.commit(cacheScope,warehouseSnapshot===undefined?value:{...value,warehouseSnapshot},{complete,mode,scopeComplete,...(runId?{runId}:{}),...(finish?{finish}:{}),...(completedStatuses?{completedStatuses}:{})});cacheInfo.persisted=true;cacheInfo.error='';return changes;}catch{cacheInfo.error='本地保存未完成，已保留上次保存结果，请重新同步。';if(strict)throw new Error(cacheInfo.error);return null;}

  }

  function collectionSignatures(rows,publication){
    const unpublished=publication.notPublished===null?null:new Set(publication.notPublished);
    const published=publication.published===null?null:new Set(publication.published);
    return new Map([...rows].map(([id,row])=>[id,publicJSON([row,unpublished?.has(id)??null,published?.has(id)??null])]));
  }

  function collectionShopSignature(shop){
    return shop&&publicJSON(Object.fromEntries(Object.keys(shop).sort().map(key=>[key,shop[key]])));
  }

  function collectionFingerprint(signatures,shopsById){
    const ordered=entries=>[...entries].sort(([left],[right])=>left.localeCompare(right));
    const shops=ordered(shopsById).map(([id,shop])=>[id,collectionShopSignature(shop)]);
    return createHash('sha256').update(publicJSON([ordered(signatures),shops])).digest('hex');
  }

  function collectionRefreshStatus(){
    if(!collectionRefreshApplying&&collectionRefresh.proposal?.expires<=Date.now()){
      collectionRefresh={state:'idle',checkedAt:collectionRefresh.checkedAt};
    }
    const {state,checkedAt,error,proposal}=collectionRefresh;
    return {contextId,state,...(checkedAt?{checkedAt}:{}),...(error?{error}:{}),
      ...(nextCollectionRefreshAt?{nextCheckAt:new Date(nextCollectionRefreshAt).toISOString()}:{}),
      ...(proposal?{proposal:{id:proposal.id,checkedAt,changes:proposal.changes}}:{})};
  }

  async function checkCollectionRefresh(check){
    const readContext=contextId,scope=await accountScope(),signal=check.controller.signal;
    const guard=()=>{
      signal.throwIfAborted();
      assertOpen();
      assertContext({contextId:readContext},{required:true});
      if(collectionRefresh!==check||syncing)throw new Error('采集箱检查已停止。');
    };
    guard();
    const baselineRows=collectionSignatures(records,statusPages);
    const baseline=collectionFingerprint(baselineRows,shopDirectory);
    const incomingShops=new Map((await shops(guard,'background',signal)).map(shop=>[shop.id,shop]));
    if([...incomingShops.values()].some(shop=>!shop.code))throw new Error('妙手未返回完整的绑定店铺资料。');
    const incomingRecords=new Map(),apiRows=new Map();
    const publication={};
    let pages=0;
    for(const partition of ['notPublished','published','all']){
      const ids=new Set();
      for(let pageNo=1;;pageNo++){
        guard();
        const rows=normalizeMiaoshouPage(await api.call('list',{pageNo,pageSize:COLLECTION_PAGE_SIZE,
          ...(partition==='all'?{}:{filter:{status:partition}})},{priority:'background',guard,signal}));
        guard();
        pages++;
        if(!rows.length)break;
        const previousSize=ids.size;
        for(const row of rows){
          if(ids.has(row.id))continue;
          ids.add(row.id);
          apiRows.set(row.id,{...row,reviewApiReadAt:new Date().toISOString()});
          incomingRecords.set(row.id,mergeIncoming(row,records.get(row.id)));
        }
        if(ids.size===previousSize)throw new Error('妙手分页返回重复数据，未采用这次读取。');
        if(incomingRecords.size>500000)throw new Error('采集箱链接超过单次读取上限。');
      }
      if(partition!=='all')publication[partition]=[...ids];
    }
    if(await accountScope()!==scope)throw new Error('妙手账号已变化。');
    guard();
    if([...incomingRecords.values()].some(row=>row.shopIds?.some(id=>!incomingShops.get(id)?.code))){
      throw new Error('妙手未返回部分关联店铺，未采用这次读取。');
    }
    const current=collectionFingerprint(collectionSignatures(records,statusPages),shopDirectory);
    if(current!==baseline)throw new Error('读取期间本机采集箱已更新，下次会重新核对。');
    const incoming=collectionSignatures(incomingRecords,publication);
    const changes={added:0,updated:0,removed:0,unchanged:0,shopsChanged:0};
    for(const [id,signature]of incoming){
      if(!baselineRows.has(id))changes.added++;
      else if(baselineRows.get(id)!==signature)changes.updated++;
      else changes.unchanged++;
    }
    for(const id of baselineRows.keys())if(!incoming.has(id))changes.removed++;
    for(const [id,shop]of incomingShops)if(collectionShopSignature(shop)!==collectionShopSignature(shopDirectory.get(id)))changes.shopsChanged++;
    for(const id of shopDirectory.keys())if(!incomingShops.has(id))changes.shopsChanged++;
    const checkedAt=new Date().toISOString();
    if(!changes.added&&!changes.updated&&!changes.removed&&!changes.shopsChanged){
      declinedCollectionRefresh='';
      collectionRefresh={state:'unchanged',checkedAt};
      return;
    }
    const fingerprint=baseline+collectionFingerprint(incoming,incomingShops);
    if(fingerprint===declinedCollectionRefresh){
      collectionRefresh={state:'declined',checkedAt};
      return;
    }
    collectionRefresh={state:'pending',checkedAt,proposal:{id:randomUUID(),expires:Date.now()+COLLECTION_PROPOSAL_LIFETIME,
      fingerprint,baseline,scope,changes,records:incomingRecords,shops:incomingShops,publication,apiRows,pages}};
  }

  function startCollectionRefresh(input){
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>key!=='contextId'))throw new Error('采集箱检查参数无效。');
    assertContext(input,{required:true});
    collectionRefreshStatus();
    if(syncing||activeWrites||batchActive||collectionRefresh.state==='checking'||collectionRefresh.proposal||Date.now()<nextCollectionRefreshAt){
      return collectionRefreshStatus();
    }
    const check={state:'checking',controller:new AbortController()};
    collectionRefresh=check;
    nextCollectionRefreshAt=Date.now()+COLLECTION_REFRESH_INTERVAL;
    void checkCollectionRefresh(check).catch(async error=>{
      if(closed||collectionRefresh!==check)return;
      let secrets=[];
      try{const config=await settings.read?.();secrets=[config?.appKey,config?.appSecret];}catch{}
      if(closed||collectionRefresh!==check)return;
      collectionRefresh={state:'failed',checkedAt:new Date().toISOString(),
        error:sanitizeMiaoshouValue(error?.message,secrets,350)||'妙手采集箱暂未读取，本机数据已保留。'};
    });
    return collectionRefreshStatus();
  }

  async function resolveCollectionRefresh(input){
    if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['contextId','proposalId','accept'].includes(key))
      ||typeof input.proposalId!=='string'||typeof input.accept!=='boolean')throw new Error('采集箱更新确认参数无效。');
    assertContext(input,{required:true});
    const expired=()=>Object.assign(new Error('采集箱更新已失效，下次会重新核对。'),{status:409,code:'COLLECTION_REFRESH_STALE'});
    collectionRefreshStatus();
    const proposalState=collectionRefresh,{checkedAt,proposal}=proposalState;
    if(!proposal||proposal.id!==input.proposalId)throw expired();
    if(!input.accept){
      if(collectionRefreshApplying)throw Object.assign(new Error('采集箱更新正在保存。'),{status:409,code:'COLLECTION_REFRESH_BUSY'});
      declinedCollectionRefresh=proposal.fingerprint;
      collectionRefresh={state:'declined',checkedAt};
      return collectionRefreshStatus();
    }
    const scope=await accountScope();
    assertOpen();
    assertContext(input,{required:true});
    if(collectionRefresh!==proposalState||scope!==proposal.scope||proposal.expires<=Date.now())throw expired();
    if(syncing||activeWrites||batchActive)throw Object.assign(new Error('妙手任务正在执行，请完成后再确认更新。'),{status:409,code:'COLLECTION_REFRESH_BUSY'});
    const current=collectionFingerprint(collectionSignatures(records,statusPages),shopDirectory);
    if(current!==proposal.baseline){collectionRefresh={state:'idle',checkedAt};throw expired();}
    activeWrites++;
    const commit=(async()=>{
      const acceptedAccount={connection:'connected',profileAvailable:false,checkedAt,lastError:''};
      const acceptedState={...syncState};
      for(const key of ['account','shops','collection'])acceptedState[key]={state:'success',at:checkedAt,error:''};
      const acceptedProgress={...syncProgress,pages:proposal.pages,records:proposal.records.size,missingShops:0,mode:'all',
        complete:true,scopeComplete:true,fullyComplete:true,scopeSyncedAt:checkedAt,stage:'complete',completedStatuses:['notPublished','published']};
      const saved=await saveCollectionCache(true,{strict:true,mode:'all',snapshot:{records:[...proposal.records.values()],shops:[...proposal.shops.values()],
        account:acceptedAccount,syncState:acceptedState,statusPages:proposal.publication,syncedAt:checkedAt,syncProgress:acceptedProgress}});
      if(root&&!saved)throw Object.assign(new Error('本机采集箱缓存暂不可写，已保留现有数据。'),{status:503,code:'COLLECTION_REFRESH_STORAGE'});
      records=proposal.records;
      shopDirectory=proposal.shops;
      statusPages=proposal.publication;
      confirmedPublication={...proposal.publication};
      account=acceptedAccount;
      syncState=acceptedState;
      syncProgress=acceptedProgress;
      syncedAt=checkedAt;
      lastError=shopsError='';
      cacheInfo={...cacheInfo,restored:false,lastChanges:proposal.changes};
      declinedCollectionRefresh='';
      collectionRefresh={state:'applied',checkedAt};
    })();
    collectionRefreshApplying=commit.catch(()=>{});
    try{await commit;}
    finally{collectionRefreshApplying=null;activeWrites--;}
    if(!closed)void queueRiskReview([...records.values()],{collectionRows:proposal.apiRows}).catch(()=>{});
    return collectionRefreshStatus();
  }

  async function syncWarehouses(runId,generation){
    const scope=await accountScope(),shops=[...shopDirectory.values()],next=new Map();
    const guard=async()=>{if(generation!==epoch||closed||await accountScope()!==scope||generation!==epoch||closed)throw new Error('妙手连接已变化，仓库同步已停止。');};
    const lastWarehouseSync=syncState.warehouses;
    phase('warehouses','syncing');
    Object.assign(syncProgress,{warehouseShopsTotal:shops.length,warehouseShopsSynced:0,warehouseShopsFailed:0});
    for(let offset=0;offset<shops.length;offset+=MIAOSHOU_WAREHOUSE_SHOPS_PER_REQUEST){
      const group=shops.slice(offset,offset+MIAOSHOU_WAREHOUSE_SHOPS_PER_REQUEST);
      await guard();let data;
      try{data=await api.call('warehouses',{shopIds:group.map(shop=>BigInt(shop.id))},{priority:'normal',guard});}catch{}
      await guard();const at=new Date().toISOString();
      for(const shop of group){
        const warehouses=normalizeMiaoshouWarehouseShop(data,shop);
        if(warehouses!==undefined){
          next.set(shop.id,{id:shop.id,at,stale:false,warehouses});syncProgress.warehouseShopsSynced++;
        }else{
          next.set(shop.id,{id:shop.id,at:'',...savedWarehouse(scope,shop.id),stale:true});syncProgress.warehouseShopsFailed++;
        }
      }
    }
    await guard();
    const failed=syncProgress.warehouseShopsFailed;
    if(failed)phase('warehouses','error',`${failed} 家店铺仓库未确认，已保留这些店铺此前成功同步的数据。`);
    else phase('warehouses','success');
    try{await saveCollectionCache(false,{runId,strict:true,warehouseSnapshot:[...next.values()]});}
    catch(error){syncState.warehouses=lastWarehouseSync;phase('warehouses','error','仓库数据未能保存，已保留此前成功同步的数据。');throw error;}
    await guard();warehouseScope=scope;warehouseDirectory=next;
  }

  async function refreshShopWarehouses(scope,shopId,guard){
    await guard();
    const shop=shopDirectory.get(shopId);
    if(!shop)throw Object.assign(new Error('当前店铺尚未同步，请同步妙手店铺后重试。'),{code:'MIAOSHOU_EDIT_STALE',status:409});
    const active=async()=>{
      await guard();
      const currentShop=shopDirectory.get(shopId);
      if(!currentShop||currentShop.siteCode!==shop.siteCode)throw Object.assign(new Error('当前店铺资料已变化，请重新读取商品后同步仓库。'),{code:'MIAOSHOU_EDIT_STALE',status:409});
    };
    let data;
    try{data=await api.call('warehouses',{shopIds:[BigInt(shopId)]},{priority:'normal',guard:active});}
    catch{await active();throw Object.assign(new Error('未能同步当前店铺仓库，请稍后重试。'),{code:'MIAOSHOU_WAREHOUSE_REFRESH_FAILED',status:502});}
    await active();
    const warehouses=normalizeMiaoshouWarehouseShop(data,shop);
    if(warehouses===undefined)throw Object.assign(new Error('妙手返回的当前店铺仓库资料不完整，请稍后重试。'),{code:'MIAOSHOU_WAREHOUSE_REFRESH_FAILED',status:502});
    const snapshot={id:shopId,at:new Date().toISOString(),stale:false,warehouses};
    if(root&&cacheScope){
      try{await collectionCache.updateWarehouse(cacheScope,snapshot);}
      catch{throw Object.assign(new Error('当前店铺仓库未能保存到本机，请重试。'),{code:'MIAOSHOU_WAREHOUSE_CACHE_FAILED',status:503});}
    }
    await active();
    if(warehouseScope!==scope)warehouseDirectory=new Map();
    warehouseScope=scope;
    warehouseDirectory.set(shopId,snapshot);
    return snapshot;
  }

  async function batchWarehouseOptions(detailIds,guard){
    if(!Array.isArray(detailIds)||!detailIds.length||detailIds.length>200)throw new Error('请选择 1–200 个商品。');
    const ids=detailIds.map(miaoshouId);
    if(new Set(ids).size!==ids.length)throw new Error('批量选择中存在重复链接。');
    const groups=new Map(),published=new Set(statusPages.published||[]);
    let skipped=0;
    for(const id of ids){
      const policy=singleShopPolicy(records.get(id)?.shopIds),shop=shopDirectory.get(policy.shopId);
      if(!shop||published.has(id)){skipped++;continue;}
      if(!groups.has(shop.id))groups.set(shop.id,{shopId:shop.id,shopName:shop.code||shop.name,count:0,warehouses:[]});
      groups.get(shop.id).count++;
    }
    const shops=[...groups.keys()];
    for(let offset=0;offset<shops.length;offset+=MIAOSHOU_WAREHOUSE_SHOPS_PER_REQUEST){
      await guard();
      const group=shops.slice(offset,offset+MIAOSHOU_WAREHOUSE_SHOPS_PER_REQUEST);
      let data;
      try{data=await api.call('warehouses',{shopIds:group.map(id=>BigInt(id))},{priority:'normal',guard});}catch{}
      await guard();
      for(const shopId of group){
        const entry=groups.get(shopId),options=normalizeMiaoshouWarehouseShop(data,shopDirectory.get(shopId));
        entry.warehouses=options?.filter(usableMiaoshouWarehouse)||[];
        if(!entry.warehouses.length)entry.error=options?'此店铺暂无可用仓库。':'未能读取此店铺仓库，请重试。';
      }
    }
    return {groups:[...groups.values()],skipped,published};
  }

  async function batchSettingsTemplateOptions(kind,scope,ids,shopIds,guard){
    const shopName=id=>shopDirectory.get(id)?.code||shopDirectory.get(id)?.name||id;
    const categoryName=id=>builtinMiaoshouCategoryName(id)?.path?.join(' / ')||id;
    if(!shopIds.length)return [];
    if(kind==='description'){
      const items=[];
      for(const shopId of shopIds){
        await guard();
        const library=await descriptionTemplates.list({accountScope:scope,shopId});
        items.push(...library.items.map(({id,name})=>({id,name,shopId,shopName:shopName(shopId)})));
      }
      return items;
    }
    if(kind==='sku'){
      const library=await skuStructures.list({accountScope:scope});
      return library.items.flatMap(({id,name,scope:rule})=>{
        const shopId=rule?.shop?.id,categoryId=rule?.category?.id;
        return shopId&&!shopIds.includes(shopId)?[]:[{id,name,...(shopId?{shopId,shopName:shopName(shopId)}:{}),...(categoryId?{categoryId,categoryName:categoryName(categoryId)}:{})}];
      });
    }
    const targets=ids.flatMap(detailId=>{
      const policy=singleShopPolicy(records.get(detailId)?.shopIds);
      return policy.allowed&&shopIds.includes(policy.shopId)?[{detailId,shopId:policy.shopId}]:[];
    });
    const categories=new Map();
    let reads=0;
    for(let offset=0;offset<targets.length;offset+=4){
      const group=await Promise.all(targets.slice(offset,offset+4).map(async target=>{
        await guard();
        try{
          const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)}),target);
          await guard();
          reads++;
          const info=detail.shopCollectItemInfo,categoryId=miaoshouId(info.cid);
          return [categoryId,readMiaoshouCategoryName({...info,categoryId})||categoryName(categoryId)];
        }catch{
          await guard();
          return null;
        }
      }));
      for(const entry of group)if(entry)categories.set(...entry);
    }
    if(targets.length&&!reads)throw new Error('无法读取所选商品的类目，请重新读取属性模板。');
    const library=await attributeTemplates.listAll({accountScope:scope,shopIds,categoryIds:[...categories.keys()],sharedOnly:true,guard});
    return library.items.filter(item=>item.attributes.length).map(({id,name,source:{categoryId}})=>({id,name,categoryId,categoryName:categories.get(categoryId)}));
  }

  function pruneBatchSettingsProgress(){
    const now=Date.now(),settled=[];
    for(const [key,entry] of batchSettingsProgress){
      if(entry.expires<=now)batchSettingsProgress.delete(key);
      else if(entry.expires)settled.push([key,entry.expires]);
    }
    if(settled.length>BATCH_SETTINGS_PROGRESS_LIMIT){
      settled.sort((a,b)=>a[1]-b[1]);
      for(const [key] of settled.slice(0,settled.length-BATCH_SETTINGS_PROGRESS_LIMIT))batchSettingsProgress.delete(key);
    }
  }

  async function previewBatchSettings({ids,settings:selection,scope,shopIds,readContext,guard,report=()=>{}}){
    report({stage:'templates',message:'正在读取所选模板…'});
    let descriptionTemplate,skuTemplate,attributeTemplate;
    if(selection.descriptionTemplate){
      const {id,shopId}=selection.descriptionTemplate;
      if(!shopIds.includes(shopId))throw batchSettingsError('描述模板店铺不在当前所选商品中。');
      const library=await descriptionTemplates.list({accountScope:scope,shopId});
      descriptionTemplate=library.items.find(item=>item.id===id);
      if(!descriptionTemplate)throw batchSettingsError('所选描述模板已不存在，请重新选择。');
    }
    if(selection.skuTemplate){
      const library=await skuStructures.list({accountScope:scope});
      const saved=library.items.find(item=>item.id===selection.skuTemplate.id);
      if(!saved||saved.scope?.shop&&!shopIds.includes(saved.scope.shop.id))throw batchSettingsError('所选规格模板不存在或不属于当前所选店铺。');
      const {name,dimensions,rows,scope:rule}=saved;
      skuTemplate=validateSkuStructureTemplate({name,dimensions,rows,...(rule?{scope:rule}:{})});
    }
    if(selection.attributeTemplate){
      const {id,categoryId}=selection.attributeTemplate;
      if(!shopIds.length)throw batchSettingsError('请选择当前账号已关联店铺的商品。');
      const {library}=await attributeTemplates.resolveSharedEditor({accountScope:scope,shopId:shopIds[0],categoryId,legacyShopIds:shopIds},{guard});
      attributeTemplate=library.items.find(item=>item.id===id);
      if(!attributeTemplate)throw batchSettingsError('所选属性模板已不存在，请重新选择。');
      if(!attributeTemplate.attributes.length)throw batchSettingsError('所选属性模板未设置任何属性，请选择含有属性值的模板。');
    }

    const warehouseReads=new Map();
    function readWarehouses(shop){
      if(!warehouseReads.has(shop.id))warehouseReads.set(shop.id,(async()=>{
        await guard();
        const response=await api.call('warehouses',{shopIds:[BigInt(shop.id)]});
        await guard();
        return normalizeMiaoshouWarehouseShop(response,shop)?.filter(usableMiaoshouWarehouse)||[];
      })());
      return warehouseReads.get(shop.id);
    }
    const items=[];
    let eligible=0;
    const settle=item=>{
      items.push(item);
      if(item.eligible)eligible++;
      report({done:items.length,eligible,skipped:items.length-eligible});
    };
    for(const detailId of ids){
      await guard();
      const row=records.get(detailId),policy=singleShopPolicy(row?.shopIds),shopId=policy.shopId,shop=shopDirectory.get(shopId);
      const item={detailId,title:row?.title||''};
      report({stage:'detail',message:'正在读取商品详情…',currentDetailId:detailId,currentTitle:sanitizeMiaoshouValue(item.title,[],160)});
      if(!row||!policy.allowed||!shop){
        settle({...item,eligible:false,error:!row?'该商品已不在列表中，请重新同步。':!policy.allowed?policy.message:'尚未核验当前关联店铺。'});
        continue;
      }
      if(descriptionTemplate&&selection.descriptionTemplate.shopId!==shopId){
        settle({...item,shopId,eligible:false,error:'所选描述模板仅适用于所属店铺。'});
        continue;
      }
      try{
        const target={detailId,shopId};
        if(batches.isSaving(detailId,{scope,contextId:readContext}))throw editQueueBusy();
        const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(detailId),shopId:BigInt(shopId)}),target);
        await guard();
        const info=detail.shopCollectItemInfo;
        const ctx=await loadMiaoshouEditContext({info,target,detail,client:api,guard,needs:[],allowMissingCategory:true});
        const {categoryId}=ctx;
        if(attributeTemplate&&selection.attributeTemplate.categoryId!==categoryId)throw new Error('所选属性模板与商品的末级类目不一致。');
        if(skuTemplate&&!skuPresetScopeMatches(skuTemplate.scope,ctx))throw new Error('商品不在所选规格模板的适用范围内。');
        if(await productEdits.hasPendingResult({detailId,shopIds:row.shopIds},{expectedScope:scope}))throw new Error('商品有待核对的保存结果，请先查询结果。');
        await guard();

        const changes={};
        if(selection.package){
          const {mode,...fixed}=selection.package;
          const fields=mode==='random'?randomMiaoshouPackage():fixed;
          Object.assign(changes,fields);
          if(categoryId)changes.allSkuWeightGrams=fields.weightGrams;
        }
        if(descriptionTemplate)changes.description=descriptionTemplate.description;
        if(attributeTemplate)changes.attributes=structuredClone(attributeTemplate.attributes);
        if(skuTemplate){
          if(!categoryId)throw new Error('商品缺少已确认的类目，不能套用规格模板。');
          report({stage:'warehouse',message:'正在核对库存仓库…'});
          const warehouses=await readWarehouses(shop);
          const defaults=warehouses.filter(warehouse=>['1','true'].includes(String(warehouse.isDefault)));
          const warehouseId=preferredMiaoshouBlanketWarehouse(ctx,warehouses)||
            (defaults.length===1?defaults[0].warehouseId:warehouses.length===1?warehouses[0].warehouseId:'');
          if(!warehouseId)throw new Error('无法确认店铺默认库存仓库，请同步仓库或在单品编辑中选择。');
          ctx.warehouses=warehouses;
          const {name,dimensions,rows}=skuTemplate;
          const local=localSkuTemplateForShop({name,dimensions,rows},{shopId,shopName:shop.code||shop.name||shopId});
          Object.assign(changes,localSkuReplacementChanges(local,ctx,{warehouseId}));
        }
        if(Object.hasOwn(changes,'allSkuWeightGrams')||changes.attributes){
          changes.contextShopId=shopId;
          changes.contextCategoryId=categoryId;
        }
        validateMiaoshouEditInput({action:'edit',changes});
        const structured=Object.fromEntries(Object.entries(changes).filter(([key])=>STRUCTURED_EDIT_KEYS.includes(key)));
        if(Object.keys(structured).length){
          if(skuTemplate||attributeTemplate){
            report({stage:'attributes',message:'正在核对类目和属性…'});
            const options=await editorOptions.load({contextId:readContext,accountScope:scope,shopId,categoryId,needs:['metadata'],guard});
            if(!options.metadata)throw new Error('未能读取该商品的类目选项，请重新设置。');
            ctx.metadata=options.metadata;
          }
          compileStructuredPatch(info,structured,ctx);
        }
        await guard();
        if(batches.isSaving(detailId,{scope,contextId:readContext}))throw editQueueBusy();
        settle({...item,title:ctx.product.title||item.title,eligible:true,shopId,categoryId,revision:ctx.revision,changes});
      }catch(error){
        await guard();
        settle({...item,shopId,eligible:false,error:sanitizeMiaoshouValue(error.message,[],350)||'无法核对此商品的批量设置。'});
      }
    }
    return {contextId:readContext,total:items.length,items};
  }

  async function sync(mode='all'){

    if(syncing)return;assertOpen();activeOperations++;syncing=true;activeSyncMode=mode;lastError='';shopsError='';
    collectionRefresh.controller?.abort();
    collectionRefresh={state:'idle'};

    const generation=epoch,apiCollectionRows=new Map(),reconciledRows=new Map();let before,runId,runScope,settled=false,runError='',collectionSyncedAt='',priorNotPublished,priorPublished;

    syncProgress={pages:0,records:0,complete:false,mode,scopeComplete:false,fullyComplete:false,stage:'shops',completedStatuses:[]};

    const signatures=(notPublished=statusPages.notPublished,published=statusPages.published)=>{const np=new Set(notPublished||[]),pub=new Set(published||[]);return new Map([...records].map(([id,row])=>[id,publicJSON([row,np.has(id),pub.has(id)])]));};

    const summarize=scopeIds=>{
      const changes={added:0,updated:0,removed:0,unchanged:0};
      const after=scopeIds?signatures(statusPages.notPublished,priorPublished):signatures();
      for(const [id,value]of after){if(scopeIds&&!scopeIds.has(id))continue;if(!before.has(id))changes.added++;else if(before.get(id)!==value)changes.updated++;else changes.unchanged++;}
      for(const id of before.keys())if((!scopeIds||scopeIds.has(id))&&!after.has(id))changes.removed++;
      cacheInfo.lastChanges=changes;cacheInfo.restored=false;
    };
    const applyUnpublished=(ids,saved)=>{
      const removed=saved?.removedIds??[...priorNotPublished].filter(id=>!ids.has(id)&&!priorPublished.has(id));
      for(const id of removed){const row=records.get(id);if(row)reconciledRows.set(id,row);records.delete(id);}
      confirmedPublication.notPublished=[...ids];
      summarize(new Set([...priorNotPublished,...ids,...removed]));
    };

    try{

      await ensureCollectionCache();if(generation!==epoch||closed)return;

      if(root){

        try{runScope=cacheScope;const started=await collectionCache.beginSync(runScope,{mode});if(!started?.runId)throw new Error();runId=started.runId;activeSyncRunId=runId;}

        catch{cacheInfo.error='同步历史未能保存到数据库，本次未开始读取妙手数据。';throw new Error(cacheInfo.error);}

      }

      priorNotPublished=new Set(confirmedPublication.notPublished);priorPublished=new Set(confirmedPublication.published);
      before=signatures(priorNotPublished,priorPublished);collectionSyncedAt=syncState.collection.at;if(mode==='all')statusPages={notPublished:null,published:null};

      for(const key of ['account','shops','warehouses','collection'])phase(key,['warehouses','collection'].includes(key)?'pending':'syncing');

      await saveCollectionCache(false,{runId,strict:true,completedStatuses:[]});

      if(generation!==epoch||closed)return;

      try{

        const incoming=await shops(()=>{if(generation!==epoch||closed)throw new Error('妙手同步已停止，未继续读取绑定店铺。');},'normal');

        if(generation!==epoch||closed)return;

        account={connection:'connected',profileAvailable:false,checkedAt:new Date().toISOString(),lastError:''};phase('account','success');

        const unnamed=incoming.filter(shop=>!shop.code).length;

        if(unnamed)throw new Error(`${unnamed} 个已绑定店铺未返回店铺代码，请核对授权后重新同步。`);

        shopDirectory=new Map(incoming.map(shop=>[shop.id,shop]));

        phase('shops','success');

      }catch(error){

        if(generation!==epoch||closed)return;

        if(syncState.account.state!=='success'){account={...account,connection:'error',lastError:sanitizeMiaoshouValue(error.message,[],1000)};phase('account','error',error.message);}

        shopsError='关联店铺信息未同步完成：'+error.message;phase('shops','error',shopsError);

        throw new Error('TikTok 绑定店铺尚未完成，采集箱未开始读取。');

      }

      await queueWarehouseUpdate(()=>syncWarehouses(runId,generation));

      if(generation!==epoch||closed)return;

      phase('collection','syncing');

      const observed=new Set();

      async function readPartition(status){

        const ids=new Set();syncProgress={...syncProgress,stage:status};

        for(let pageNo=1;Number.isSafeInteger(pageNo);pageNo++){

          const rows=normalizeMiaoshouPage(await api.call('list',{pageNo,pageSize:COLLECTION_PAGE_SIZE,...(status==='all'?{}:{filter:{status}})},{priority:'normal'}));

          if(generation!==epoch||closed)return null;

          let added=0;const pageRows=[];

          for(const row of rows)if(!ids.has(row.id)){ids.add(row.id);observed.add(row.id);apiCollectionRows.set(row.id,{...structuredClone(row),reviewApiReadAt:new Date().toISOString()});const merged=mergeIncoming(row,records.get(row.id)??reconciledRows.get(row.id));records.set(row.id,merged);pageRows.push(merged);added++;}

          const progress={...syncProgress,pages:syncProgress.pages+1,records:observed.size,complete:false};

          await patchCollectionCache(pageRows,[],{runId,strict:true,progress});syncProgress=progress;

          if(generation!==epoch||closed)return null;

          if(rows.length&&!added)throw new Error('妙手分页返回重复数据，请检查开放平台分页规则。');

          // Only an empty page completes a partition; short pages can be upstream-trimmed.

          if(!rows.length)return ids;

        }

        throw new Error('链接超过单次同步上限，请分批处理。');

      }

      if(mode==='notPublished'){

        const ids=await readPartition('notPublished');if(!ids||generation!==epoch||closed)return;

        const scopeRows=[...ids].map(id=>records.get(id)),missing=new Set(scopeRows.flatMap(row=>row.shopIds||[]).filter(id=>!shopDirectory.get(id)?.code));syncProgress.missingShops=missing.size;

        if(missing.size){shopsError=`${missing.size} 个关联店铺未返回简称，请核对妙手店铺授权后重新同步。`;phase('shops','error',shopsError);throw new Error(shopsError);}

        const completedAt=new Date().toISOString(),publication={...statusPages,notPublished:[...ids]},progress={...syncProgress,complete:false,mode,scopeComplete:true,fullyComplete:false,scopeSyncedAt:completedAt,stage:'complete',completedStatuses:['notPublished']};

        syncState.collection={state:'success',at:collectionSyncedAt,error:''};

        const saved=await saveCollectionCache(false,{runId,strict:true,mode,scopeComplete:true,completedStatuses:['notPublished'],finish:{status:'success',finishedAt:completedAt},snapshot:{records:scopeRows,shops:[...shopDirectory.values()],account,syncState,statusPages:publication,syncedAt,syncProgress:progress}});

        settled=true;
        if(generation!==epoch||closed)return;
        statusPages=publication;syncProgress=progress;applyUnpublished(ids,saved);lastError='';return;

      }

      for(const status of ['notPublished','published']){

        const ids=await readPartition(status);if(!ids||generation!==epoch||closed)return;

        const publication={...statusPages,[status]:[...ids]},progress={...syncProgress,completedStatuses:[...syncProgress.completedStatuses,status],stage:status==='notPublished'?'published':'all'};

        const checkpointRows=status==='notPublished'?[...ids].map(id=>records.get(id)):[...records.values()];
        const saved=await saveCollectionCache(false,{runId,strict:true,completedStatuses:progress.completedStatuses,snapshot:{records:checkpointRows,shops:[...shopDirectory.values()],account,syncState,statusPages:publication,syncedAt,syncProgress:progress}});

        if(generation!==epoch||closed)return;

        statusPages=publication;syncProgress=progress;
        if(status==='notPublished')applyUnpublished(ids,saved);
        else confirmedPublication.published=[...ids];

      }

      // The API also contains scheduled/future statuses, so verify all links last.

      const allIds=await readPartition('all');if(!allIds||generation!==epoch||closed)return;

      const currentIds=new Set([...allIds,...statusPages.notPublished,...statusPages.published]);

      const completedRecords=new Map([...records].filter(([id])=>currentIds.has(id)));

      const missing=new Set([...completedRecords.values()].flatMap(row=>row.shopIds||[]).filter(id=>!shopDirectory.get(id)?.code));

      syncProgress.missingShops=missing.size;

      if(missing.size){shopsError=shopsError||`${missing.size} 个关联店铺未返回简称，请核对妙手店铺授权后重新同步。`;phase('shops','error',shopsError);}

      phase('collection','success');syncProgress.complete=!shopsError&&!missing.size;syncProgress.scopeComplete=syncProgress.complete;syncProgress.fullyComplete=syncProgress.complete;if(syncProgress.complete)syncProgress.stage='complete';

      lastError=shopsError;runError=lastError;

      const completedAt=syncProgress.complete?new Date().toISOString():syncedAt;

      if(syncProgress.complete)syncProgress.scopeSyncedAt=completedAt;

      const saved=await saveCollectionCache(syncProgress.complete,{runId,strict:true,...(syncProgress.complete?{finish:{status:'success',finishedAt:completedAt}}:{}),snapshot:{records:[...(syncProgress.complete?completedRecords:records).values()],shops:[...shopDirectory.values()],account,syncState,statusPages,syncedAt:completedAt,syncProgress}});

      if(syncProgress.complete){records=completedRecords;syncedAt=completedAt;settled=true;}

      if(saved||!root)summarize();

    }catch(error){

      let redactions=[];try{const config=await settings.read?.();redactions=[config?.appKey,config?.appSecret];}catch{}

      shopsError=sanitizeMiaoshouValue(shopsError,redactions,1000);account.lastError=sanitizeMiaoshouValue(account.lastError,redactions,1000);for(const item of Object.values(syncState))item.error=sanitizeMiaoshouValue(item.error,redactions,1000);

      lastError=[shopsError,error.message].filter(Boolean).map(value=>sanitizeMiaoshouValue(value,redactions,1000)).join('；');runError=lastError;syncProgress.complete=false;syncProgress.scopeComplete=false;syncProgress.fullyComplete=false;delete syncProgress.scopeSyncedAt;phase('collection','error',lastError);
      if(['pending','syncing'].includes(syncState.warehouses.state))phase('warehouses','error','本次仓库同步未完成，已保留此前成功同步的数据。');

      if(!closed&&generation===epoch&&runId)await saveCollectionCache(false,{runId});

    }finally{

      if(runId&&!settled){try{await collectionCache.finishSync(runScope,{runId,status:closed||generation!==epoch?'interrupted':'failed',error:runError||(closed?'同步已停止，已保留已保存的数据。':'本次同步未完成。'),progress:syncProgress});}catch{cacheInfo.error='同步历史结算未能保存，数据库保留为未完成，请检查存储后重试。';if(!lastError)lastError=cacheInfo.error;}}

      activeSyncRunId=null;activeSyncMode=null;syncing=false;activeOperations--;

      if(settled&&!closed&&generation===epoch){const selected=mode==='notPublished'?new Set(statusPages.notPublished||[]):null;void queueRiskReview([...records.values()].filter(row=>!selected||selected.has(row.id)),{collectionRows:apiCollectionRows}).catch(()=>{});}

    }

  }

  async function shops(guard=()=>{},priority='foreground',signal){

    const result=new Map();

    for(let pageNo=1;Number.isSafeInteger(pageNo);pageNo++){

      guard();const data=await api.call('shops',{platform:'tiktok',pageNo,pageSize:100},{priority,guard,...(signal?{signal}:{})});guard();

      if(!Array.isArray(data?.shopList))throw new Error('妙手店铺列表格式不匹配。');

      let added=0;for(const shop of data.shopList){if(String(shop.platform).toLowerCase()!=='tiktok')continue;const id=miaoshouId(shop.shopId);if(!result.has(id)){added++;const code=String(shop.shopNick||'').trim();result.set(id,{id,name:code||'店铺简称未返回',code,platform:'tiktok',site:String(shop.siteName||shop.site||''),siteCode:String(shop.site||''),status:String(shop.status||''),authorizationExpiresAt:String(shop.gmtExpire||''),authorizedAt:String(shop.gmtLastAuth||'')});}}

      if(data.shopList.length<100)return [...result.values()];

      if(!added)throw new Error('店铺分页重复，请稍后重试。');

    }throw new Error('店铺列表超过读取上限。');

  }

  async function freshRecord(id){

    const hint=records.get(id)?.itemNum;

    if(typeof hint==='string'&&hint.trim()&&Array.from(hint).length<=255){

      try{

        const rows=normalizeMiaoshouPage(await api.call('list',{pageNo:1,pageSize:COLLECTION_PAGE_SIZE,filter:{sourceItemIdKeyword:hint.trim()}}));

        const row=rows.find(row=>row.id===id);if(row)return row;

      }catch(error){if(![400,422].includes(error.httpStatus))throw error;}

    }

    const seen=new Set();

    for(let pageNo=1;pageNo<=200;pageNo++){

      const rows=normalizeMiaoshouPage(await api.call('list',{pageNo,pageSize:COLLECTION_PAGE_SIZE}));

      const row=rows.find(r=>r.id===id);if(row)return row;

      if(!rows.length)return null;

      let added=0;for(const row of rows)if(!seen.has(row.id)){seen.add(row.id);added++;}

      if(!added)throw new Error('采集箱分页重复，无法核验商品。');

    }throw new Error('采集箱超过核验上限。');

  }

  const fingerprint=row=>publicJSON([row.id,row.title,[...(row.shopIds||[])].sort(),row.thumbnail]);

  const actionKey=(scope,action,id,shopId)=>createHash('sha256').update(publicJSON([scope,action,id,shopId||''])).digest('hex');

  const reviewData=entry=>({operationId:entry.operationId,action:entry.action,detailId:entry.detailId,shopId:entry.shopId||'',state:entry.state});

  const reviewError=(entry,message)=>Object.assign(new Error(message||'此操作已有提交记录，请先核对结果，避免重复操作。'),{status:409,code:'ACTION_REVIEW_REQUIRED',data:reviewData(entry)});

  const editQueueMessage='该商品仍在后台保存，请稍后查询。';
  const editQueueBusy=()=>Object.assign(new Error('该商品已在保存队列中，请先查询保存结果。'),{status:409,code:'MIAOSHOU_EDIT_BUSY'});

  async function prepareAction(input){

    if(!['claim','delete','publish'].includes(input.action))throw new Error('操作类型无效。');

    const singleShop=input.singleShop===true&&input.action==='publish';
    if(singleShop)assertContext(input,{required:true});
    const hasRevision=Object.hasOwn(input,'expectedRevision'),hasOssHash=Object.hasOwn(input,'expectedOssMd5Hash');
    const expectedRevision=input.expectedRevision,expectedOssMd5Hash=input.expectedOssMd5Hash;
    const validProof=value=>typeof value==='string'&&/^[a-f0-9]{64}$/u.test(value);
    if((hasRevision||hasOssHash)&&(!singleShop||hasRevision&&hasOssHash||
      hasRevision&&!validProof(expectedRevision)||hasOssHash&&!validProof(expectedOssMd5Hash)))
      throw Object.assign(new Error('商品发布版本无效，请重新读取当前商品。'),{status:400,code:'MIAOSHOU_EDITOR_PUBLISH_PROOF'});
    const generation=epoch,id=miaoshouId(input.detailId),row=await freshRecord(id);

    if(!row)throw new Error('采集箱商品已不存在，请刷新列表。');

    let shop;const scope=await accountScope();

    if(input.action!=='delete'){

      const id=miaoshouId(input.shopId);shop=(await shops()).find(s=>s.id===id);

      if(!shop)throw new Error('请选择当前账号的 TikTok 店铺。');

      if(input.action==='publish'&&!row.shopIds?.includes(id))throw new Error('该商品尚未认领到所选店铺。');
      if(singleShop&&row.shopIds.length!==1)throw new Error('请核对商品唯一的认领店铺后再发布。');

    }

    if(generation!==epoch)throw new Error('连接已变化，请重新操作。');

    const key=actionKey(scope,input.action,id,shop?.id),previous=await journal.find(key);if(previous)throw reviewError(previous);

    if(input.action==='claim'&&row.shopIds?.includes(shop.id))throw Object.assign(new Error('商品已关联目标店铺，无需重复认领，现有商品资料已保留。'),{code:'MIAOSHOU_ALREADY_CLAIMED',status:409});

    for(const [key,ticket] of actionTickets)if(ticket.expires<Date.now())actionTickets.delete(key);

    if(actionTickets.size>=200)throw new Error('待确认操作过多，请稍后重试。');

    const ticket=randomUUID();actionTickets.set(ticket,{action:input.action,row,shop,singleShop,expectedRevision,expectedOssMd5Hash,accountScope:scope,key,operationId:randomUUID(),fingerprint:fingerprint(row),epoch,expires:Date.now()+300000,state:'ready'});

    return {ticket,action:input.action,detailId:id,title:row.title,shop,associatedShopIds:row.shopIds||[]};

  }

  async function commitAction(input,{fromBatch=false}={}){

    const ticket=actionTickets.get(input.ticket);
    if(ticket?.singleShop)assertContext(input,{required:true});

    if(input.confirmed!==true||!ticket||ticket.epoch!==epoch||ticket.expires<Date.now())throw new Error('操作确认已失效，请重新选择商品。');

    if(ticket.state!=='ready')throw new Error('该操作已提交或结果待核对，请勿重复提交。');

    function checkWriteSlot(){
      const blockedByBatch=batchActive&&!fromBatch;
      if(!blockedByBatch&&!activeWrites&&!syncing&&!actionLocks.has(ticket.row.id))return;
      const message=blockedByBatch?'批量任务正在执行，请完成后操作。':'妙手任务正在执行，请完成后操作。';
      throw Object.assign(new Error(message),ticket.singleShop?{status:409,code:'MIAOSHOU_EDITOR_PUBLISH_BUSY'}:{});
    }
    checkWriteSlot();
    const previous=await journal.find(ticket.key);if(previous)throw reviewError(previous);
    // Reserve the local write slot immediately after the final check.
    checkWriteSlot();
    if(ticket.state!=='ready'||ticket.epoch!==epoch)throw new Error('操作确认已失效，请重新选择商品。');
    ticket.state='checking';activeWrites++;actionLocks.add(ticket.row.id);

    let operation,writeRejected=false;try{

      const row=await freshRecord(ticket.row.id);

      if(!row||fingerprint(row)!==ticket.fingerprint)throw new Error('商品或关联店铺已变化，请重新确认。');

      if(ticket.action==='claim'&&row.shopIds?.includes(ticket.shop.id))throw Object.assign(new Error('商品已关联目标店铺，无需重复认领。'),{code:'MIAOSHOU_ALREADY_CLAIMED',status:409});

      if(ticket.shop&&!(await shops()).some(shop=>shop.id===ticket.shop.id))throw new Error('目标店铺已不可用。');

      if(ticket.action==='publish'){

        const detail=await api.call('detail',{detailId:BigInt(row.id),shopId:BigInt(ticket.shop.id)});

        const associated=Array.isArray(detail?.claimToShopIds)?detail.claimToShopIds.map(miaoshouId):[];
        if(!associated.includes(ticket.shop.id)||miaoshouId(detail?.shopCollectItemInfo?.detailId)!==row.id||
            miaoshouId(detail?.shopCollectItemInfo?.shopId)!==ticket.shop.id||
            ticket.singleShop&&(associated.length!==1||row.shopIds?.length!==1))
          throw new Error('发布店铺关联已变化，请刷新后重试。');
        if(ticket.expectedRevision||ticket.expectedOssMd5Hash){
          const validDetail=validateMiaoshouDetail(detail,{detailId:row.id,shopId:ticket.shop.id});
          const matches=ticket.expectedRevision?miaoshouEditRevision(validDetail)===ticket.expectedRevision
            :createHash('sha256').update(validDetail.ossMd5).digest('hex')===ticket.expectedOssMd5Hash;
          if(!matches)throw Object.assign(new Error('妙手商品版本已变化，请重新读取并核对当前草稿后再发布。'),
            {status:409,code:'MIAOSHOU_EDITOR_PUBLISH_STALE'});
        }
        if(ticket.singleShop&&await productEdits.hasPendingResult({detailId:row.id,shopIds:[ticket.shop.id]},{expectedScope:ticket.accountScope}))
          throw new Error('此商品还有待核对的保存结果，请先查询保存结果。');

      }

      assertOpen();if(ticket.epoch!==epoch||await accountScope()!==ticket.accountScope)throw new Error('连接已变化，请重新确认。');

      const createdAt=new Date().toISOString();operation=await journal.reserve({operationId:ticket.operationId,key:ticket.key,accountScope:ticket.accountScope,action:ticket.action,detailId:row.id,shopId:ticket.shop?.id||'',state:'submitting',createdAt,updatedAt:createdAt});

      assertOpen();ticket.state='submitting';

      const payload={detailIds:[BigInt(row.id)],...(ticket.shop?{shopIds:[BigInt(ticket.shop.id)]}:{})};

      let result;try{result=await api.call(ticket.action,payload);}catch(error){writeRejected=error.definitive===true;throw error;}

      ticket.state='submitted';operation=await journal.transition(operation.operationId,operation.accountScope,'submitted');

      if(ticket.action==='delete'){

        if(result?.successNum!==1||result?.failNum!==0||Object.keys(result?.errorMap||{}).length){const definite=result?.successNum===0&&result?.failNum===1;writeRejected=definite;const config=settings.read?await settings.read():{};const reason=sanitizeMiaoshouValue(result?.errorMap?.[row.id]||result?.errorMsg,[config.appKey,config.appSecret]);throw Object.assign(new Error('妙手未确认删除成功'+(reason?'：'+reason:'，请核对删除结果。')),{definitive:definite});}

        const current=await freshRecord(row.id);if(current)throw new Error('删除请求已提交，但商品仍在列表中，请稍后刷新核对。');

        operation=await journal.transition(operation.operationId,operation.accountScope,'deleted');records.delete(row.id);await patchCollectionCache([],[row.id]);return {state:'deleted',message:'商品已从妙手采集箱删除并核验。'};

      }

      if(ticket.action==='claim'){

        const current=await freshRecord(row.id);if(!current?.shopIds?.includes(ticket.shop.id))throw new Error('认领请求已提交，关联结果尚未更新，请稍后同步核对。');

        operation=await journal.transition(operation.operationId,operation.accountScope,'claimed');records.set(row.id,{...current,sourceThumbnail:current.thumbnail});await patchCollectionCache([records.get(row.id)]);

        const guard=async()=>{assertOpen();if(ticket.epoch!==epoch||await accountScope()!==ticket.accountScope)throw new Error('妙手账号已变化，未继续自动套用。');assertOpen();};

        let claimDefaults;

        // claim_to_shop normally returns a SimpleSuccessResponse without data.

        // The client verifies that envelope; if counters are present they must

        // agree with this one-row operation before a follow-up write.

        const counted=result&&(Object.hasOwn(result,'successNum')||Object.hasOwn(result,'failNum'));

        if(counted&&(result.successNum!==1||result.failNum!==0)||Object.keys(result?.errorMap||{}).length)claimDefaults=skippedClaimDefaults('认领回执未确认本次单条成功，未自动修改。');

        else try{claimDefaults=await applyMiaoshouClaimDefaults({before:row.shopIds,after:current.shopIds,detailId:row.id,shopId:ticket.shop.id,scope:ticket.accountScope,guard,client:api,attributeTemplates,sizeCharts:claimSizeCharts,productEdits,isLeaf:isBuiltinMiaoshouLeafCategory});}

        catch{claimDefaults=reviewClaimDefaults();}

        await journal.recordClaimDefaults(operation.operationId,operation.accountScope,claimDefaults).catch(()=>{});

        return {state:'claimed',message:'已认领到 '+ticket.shop.name+'，关联店铺已刷新。',claimDefaults};

      }

      return {state:'submitted',message:'发布任务已提交到 '+ticket.shop.name+'，最终结果请查看发布记录。'};

    }catch(error){ticket.state=ticket.state==='checking'?'failed':'uncertain';if(operation){const state=writeRejected?'failed':'uncertain';try{operation=await journal.transition(operation.operationId,operation.accountScope,state);}catch{}throw reviewError({...operation,state},error.message);}if(error.code==='ACTION_REVIEW_REQUIRED'&&error.data)throw reviewError(error.data,error.message);throw error;}

    finally{activeWrites--;actionLocks.delete(ticket.row.id);}

  }

  async function publishRecords(input){

    const pageNo=Number(input.pageNo||1);if(!Number.isInteger(pageNo)||pageNo<1||pageNo>10000)throw new Error('页码无效。');

    const data=await api.call('publishRecords',{pageNo,pageSize:20});

    if(!Array.isArray(data?.moveCollectDetailList))throw new Error('发布记录格式不匹配。');

    const total=Number(data.total??0);if(!Number.isSafeInteger(total)||total<0)throw new Error('发布记录总数格式不匹配。');

    const config=settings.read?await settings.read():{},safe=(value,max=350)=>sanitizeMiaoshouValue(value,[config.appKey,config.appSecret],max);

    return {total,records:data.moveCollectDetailList.slice(0,20).map(r=>({shopId:safe(r.shopId,30),id:safe(r.moveCollectTaskDetailId,50),detailId:safe(r.collectBoxDetailId,30),shop:safe(shopDirectory.get(String(r.shopId))?.name||r.shopName||'店铺简称待同步'),title:safe(r.title),status:safe(r.status,100),reason:safe(r.reason),createdAt:safe(r.gmtCreate,80)}))};

  }

  async function reviewAction(input){

    const scope=await accountScope(),entry=await journal.operation(scope,input.operationId);if(!entry)throw new Error('当前妙手账号没有此操作记录。');

    let rows=[],message='操作已有提交记录，请在妙手核对；结果不确定时不会重复提交。';

    if(entry.action==='publish'){

      const data=await publishRecords({pageNo:1});rows=data.records.filter(row=>row.detailId===entry.detailId&&row.shopId===entry.shopId).slice(0,20);

      if(!rows.length)message='当前发布记录首页未匹配到该商品；这不表示提交失败，请在妙手核对。';

    }else{

      const row=await freshRecord(entry.detailId);

      if(entry.action==='delete')message=row?'该商品目前仍在采集箱中；不能据此认定此前删除失败，请在妙手核对。':'该商品目前已不在采集箱中。';

      else message=row?.shopIds?.includes(entry.shopId)?'当前商品已关联目标店铺。':'当前列表尚未确认关联目标店铺，请在妙手核对。';

      if(row)rows=[{id:row.id,detailId:row.id,shopId:entry.shopId,shop:shopDirectory.get(entry.shopId)?.name||'店铺简称待同步',title:row.title,status:'',reason:'',createdAt:row.createdAt}];

    }

    return {...reviewData(entry),message,retryAllowed:entry.state==='failed',records:rows,...(entry.action==='claim'&&entry.claimDefaults?{claimDefaults:entry.claimDefaults}:{})};

  }

  async function retryAction(input){

    if(input.retryConfirmed!==true)throw new Error('请先核对结果并确认重新操作。');const scope=await accountScope();await journal.release(input.operationId,scope);return {released:true,message:'已解除明确失败的操作记录，请重新选择商品并核对后提交。'};

  }

  async function body(req,limit=20000){let length=0,chunks=[];for await(const chunk of req){length+=chunk.length;if(length>limit)throw Object.assign(new Error('请求过大。'),{status:413});chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw Object.assign(new Error('请求格式无效。'),{status:400});}}

  async function configure(input){

    if(closed||configuring||syncing||activeWrites||activeOperations)throw new Error('妙手任务正在执行，请完成后修改连接。');

    configuring=true;try{await settings.save(input);collectionRefresh.controller?.abort();riskReview.reset();brandResearch?.reset();localCategoryAttributes.reset();riskApiSource.reset();referenceLayouts.reset();referenceGalleryReceipts.clear();contextId=randomUUID();batches.reset();editorSnapshots.clear();editorOptions.clear();epoch++;cacheLoaded=false;cacheLoading=null;cacheScope='';cacheInfo={restored:false,persisted:false,lastChanges:null,error:''};records=new Map();shopDirectory.clear();warehouseDirectory.clear();warehouseScope='';account=emptyAccount();syncState=emptySyncState();lastError='';syncedAt='';statusPages={notPublished:null,published:null};confirmedPublication={notPublished:[],published:[]};collectionRefresh={state:'idle'};nextCollectionRefreshAt=0;declinedCollectionRefresh='';shopsError='';syncProgress={pages:0,records:0,complete:false};actionTickets.clear();replacements=createMiaoshouReplacement({client:api});return await settings.status();}finally{configuring=false;}

  }

  async function probe(){

    if(closed||configuring)throw new Error('妙手连接正在更新，请稍后重试。');

    activeWrites++;activeOperations++;try{const rows=normalizeMiaoshouPage(await api.call('list',{pageNo:1,pageSize:20}));return {connected:true,readOnly:true,sampleCount:rows.length,singleShop:rows.filter(r=>r.policy.allowed).length,multipleShops:rows.filter(r=>r.policy.code==='MULTI_SHOP').length};}finally{activeWrites--;activeOperations--;}

  }

  async function syncHistory(url,detail=false){

    const allowed=detail?['runId','page','pageSize']:['page','pageSize'];

    if([...url.searchParams.keys()].some(key=>!allowed.includes(key)||url.searchParams.getAll(key).length!==1))throw new Error('同步历史查询参数无效。');

    const number=(key,fallback,max)=>{const value=url.searchParams.get(key);if(value===null)return fallback;if(!/^[1-9]\d{0,6}$/.test(value)||Number(value)>max)throw new Error('同步历史分页参数无效。');return Number(value);};

    const page=number('page',1,1000000),pageSize=number('pageSize',detail?50:20,100),runId=url.searchParams.get('runId');

    if(detail&&!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/.test(runId||''))throw new Error('同步历史记录编号无效。');

    const generation=epoch;assertOpen();await ensureCollectionCache();assertOpen();if(generation!==epoch)throw new Error('妙手连接已变化，请重新查看同步历史。');

    if(!root)return detail?null:{items:[],total:0,page,pageSize,storageAvailable:false};

    const scope=cacheScope,result=await (detail?collectionCache.historyDetail(scope,{runId,page,pageSize}):collectionCache.listHistory(scope,{page,pageSize}));

    assertOpen();if(generation!==epoch||scope!==cacheScope)throw new Error('妙手连接已变化，请重新查看同步历史。');

    if(detail)return result?{...result,run:{...result.run,active:result.run.runId===activeSyncRunId&&syncing}}:null;

    return {...result,storageAvailable:true,items:result.items.map(run=>({...run,active:run.runId===activeSyncRunId&&syncing}))};

  }

  async function loadListingTitle(input,{signal}){
    const {snapshot}=input,{titleBinding,ipRiskTerms=[],titleDraftUnverified}=snapshot.editorSelection;
    if(!titleBinding||input.images.length||typeof titleBinding.contextId!=='string'||
      typeof titleBinding.shopId!=='string'||!/^([a-f0-9]{64})$/u.test(titleBinding.revision||'')){
      throw new Error('请重新加载当前商品，再生成标题建议。');
    }
    const {contextId:readContext,shopId,revision}=titleBinding;
    const detailId=miaoshouId(snapshot.id),key=detailId+':'+revision;
    assertContext({contextId:readContext},{required:true});
    const scope=await accountScope(),binding=editorSnapshots.get(key),generation=epoch;
    const guard=async()=>{
      signal.throwIfAborted();
      assertOpen();
      assertContext({contextId:readContext},{required:true});
      const currentScope=await accountScope(),policy=singleShopPolicy(records.get(detailId)?.shopIds);
      if(generation!==epoch||currentScope!==scope||!policy.allowed||policy.shopId!==shopId||
        !binding||editorSnapshots.get(key)!==binding||binding.scope!==scope||binding.contextId!==readContext||
        binding.shopId!==shopId||binding.expires<Date.now())throw new Error('商品或店铺已变化，请重新加载后生成标题。');
      signal.throwIfAborted();
    };
    await guard();
    const target={detailId,shopId};
    const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(detailId),shopId:BigInt(shopId)},{guard}),target);
    if(miaoshouEditRevision(detail)!==revision)throw new Error('商品资料已更新，请重新加载后生成标题。');
    const info=detail.shopCollectItemInfo;
    const {product,categoryId}=await loadMiaoshouEditContext({info,target,client:api,guard,needs:[],allowMissingCategory:true});
    const {facts,category,attributes,specifications}=listingTitleFacts(info,product);
    const {images,imageCoverage,artworkHash}=await readListingTitleGallery(info,{imageReader,signal});
    const [reviewed,risk]=await Promise.all([
      readListingTitleEvidence(root,{accountScope:scope,shopId,detailId,categoryId,artworkHash}),
      riskReview.snapshot({accountScope:scope,contextId:readContext,ids:[detailId]}).catch(()=>null),
    ]);
    await guard();
    const currentRisk=risk?.results?.find(item=>item.id===detailId&&!item.stale);
    const observedTerms=(Array.isArray(currentRisk?.findings)?currentRisk.findings:[])
      .filter(item=>['ip','trademark','copyright'].includes(item.type)&&item.severity!=='low')
      .map(item=>item.subject).filter(term=>typeof term==='string'&&term.trim()&&Array.from(term).length<=80&&!/[<>\u0000-\u001f]/u.test(term));
    const excludedTerms=[...new Set([...(reviewed.excludedTerms||[]),...observedTerms,...ipRiskTerms])].slice(0,50);
    const authorization=titleDraftUnverified&&reviewed.authorization==='verified'?'unverified':reviewed.authorization;
    return {
      input:{field:'name',snapshot:{
        id:detailId,name:product.sourceTitle||product.title||'',profile:{category,brand:info.brandName},
        editorSelection:{workbench:'miaoshou',shopName:shopDirectory.get(shopId)?.name||product.shopName,
          attributes,specifications,ipReviewFlag:excludedTerms.length>0,titleDraftUnverified:titleDraftUnverified===true},
      },images},
      titleEvidence:{...reviewed,authorization,facts,excludedTerms,imageCoverage},guard,
    };
  }

  return {status:()=>settings.status(),configure,probe,loadListingTitle,supportsLocalDrafts:!!localDraftDisk,async handle(req,res,{isHost=false,localDraftHost=isHost}={}){let tracked=false;try{assertOpen();

    const url=new URL(req.url,'http://localhost'),path=url.pathname,op=path.split('/').pop();

    if(op!=='settings'){activeOperations++;tracked=true;}

    let syncInput;

    if(req.method==='POST'&&op==='sync'){syncInput=await body(req);if(!syncInput||typeof syncInput!=='object'||Array.isArray(syncInput)||Object.keys(syncInput).some(key=>key!=='mode')||syncInput.mode!==undefined&&!['all','notPublished'].includes(syncInput.mode))throw Object.assign(new Error('同步范围无效，请选择全部或仅未发布。'),{status:400,code:'MIAOSHOU_SYNC_MODE_INVALID'});}

    if(['list','sync','shops','collection-refresh-start','source-image','inspect','replace','risk-status','risk-retry','risk-brand-retry','action-prepare','action-commit','action-review','action-retry','batch-prepare','batch-commit','edit-context','edit-options','edit-prepare','edit-review','edit-review-release','description-images-preview'].includes(op))await ensureCollectionCache();

    if(req.method==='GET'&&op==='status'){
      const draftScope=await localDraftScope();
      return json(res,200,{success:true,data:{...await settings.status(),contextId,localDraftScope:draftScope,
        ...(localDraftHost&&draftScope&&localDraftDisk?{localDraftStorage:'host'}:{}),isHost,syncing,activeMode:activeSyncMode,
        syncProgress:{...syncProgress},syncedAt,lastError,total:records.size}});
    }

    if(req.method==='GET'&&op==='list'){
      const readContext=contextId,draftScope=await localDraftScope();
      const editTimes=draftScope&&records.size?await productEdits.confirmedSyncTimes().catch(()=>new Map()):new Map();
      assertContext({contextId:readContext},{required:true});
      const listed=[...records.values()].map(row=>{
        let latest=Date.parse(row.lastMiaoshouSyncAt);
        for(const shopId of row.shopIds||[]){
          const time=editTimes.get(row.id+':'+shopId);
          if(Number.isFinite(time)&&(!Number.isFinite(latest)||time>latest))latest=time;
        }
        return Number.isFinite(latest)?{...row,lastMiaoshouSyncAt:new Date(latest).toISOString()}:row;
      });
      return json(res,200,{success:true,data:{contextId,localDraftScope:draftScope,...(localDraftHost&&draftScope&&localDraftDisk?{localDraftStorage:'host'}:{}),records:listed,shops:[...shopDirectory.values()],boundShops:[...shopDirectory.values()],account:{...account},syncState:structuredClone(syncState),shopScope:'tiktok',statusPages,cache:{...cacheInfo},syncProgress:{...syncProgress},syncing,activeMode:activeSyncMode,syncedAt,lastError}});
    }

    if(req.method==='GET'&&op==='collection-refresh-status')return json(res,200,{success:true,data:collectionRefreshStatus()});
    if(req.method==='GET'&&['sync-history','sync-history-detail'].includes(op))return json(res,200,{success:true,data:await syncHistory(url,op==='sync-history-detail')});

    if(req.method!=='POST')return json(res,404,{success:false,message:'接口不存在。'});

    if(op==='title-translations'){
      const input=await body(req,1024*1024);
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['contextId','items'].includes(key)))throw new Error('标题翻译请求无效。');
      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),items=validateTitleItems(input.items);
      await ensureCollectionCache();
      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});if(await accountScope()!==scope)throw new Error('妙手账号已变化，停止旧标题翻译。');};
      await guard();
      if(items.some(item=>!records.has(item.id)))throw new Error('标题翻译商品已不在当前列表中，请刷新列表。');
      const data=await titleTranslations.request({accountScope:scope,contextId:selectedContext,items,guard});
      await guard();return json(res,200,{success:true,data});
    }

    if(MIAOSHOU_DRAFT_OPERATIONS.has(op)){
      if(!localDraftHost)throw Object.assign(new Error('主机草稿只能从运行设计器的本机读取或保存。'),{status:403,code:'LOCAL_DRAFT_HOST_ONLY'});
      if(!localDraftDisk)throw Object.assign(new Error('主机草稿服务尚未启用。'),{status:503,code:'LOCAL_DRAFT_UNAVAILABLE'});
      if(url.search||path!=='/__pod/miaoshou/'+op||String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase()!=='application/json'){
        throw Object.assign(new Error('主机草稿请求格式无效。'),{status:400,code:'LOCAL_DRAFT_DATA'});
      }
      const limit=op==='local-drafts-put'||op==='local-drafts-import'?MIAOSHOU_DRAFT_REQUEST_BYTES:20000;
      if(Number(req.headers['content-length'])>limit)throw Object.assign(new Error('本机草稿请求过大，已有记录仍保留。'),{status:413,code:'LOCAL_DRAFT_LIMIT'});
      const input=await body(req,limit);
      if(!input||typeof input!=='object'||Array.isArray(input))throw Object.assign(new Error('本机草稿参数无效。'),{status:400,code:'LOCAL_DRAFT_DATA'});
      assertOpen();assertContext(input,{required:true});
      const draftScope=await localDraftScope(), readContext=input.contextId;
      if(!draftScope)throw Object.assign(new Error('请先配置当前妙手账号，再使用主机草稿。'),{status:503,code:'LOCAL_DRAFT_UNAVAILABLE'});
      const guard=()=>{
        assertOpen();assertContext({contextId:readContext},{required:true});
        if(req.aborted||res.destroyed)throw Object.assign(new Error('本机草稿请求已取消。'),{status:409,code:'LOCAL_DRAFT_ABORTED'});
      };
      guard();
      const data=await runMiaoshouDraftOperation(localDraftDisk,op,input,draftScope,guard);
      return json(res,200,{success:true,data});
    }
    const input=syncInput??await body(req,op==='size-chart-library-save'?MIAOSHOU_SIZE_CHART_REQUEST_BYTES:['sku-structures-save','sku-structures-shop-save','edit-prepare','mockup-template-binding-save'].includes(op)?1024*1024:(op.startsWith('batch-')||op==='description-images-preview'||op==='reference-layout-start'||['attribute-templates-save','attribute-templates-editor-save','description-templates-save'].includes(op))?128*1024:20000);

    assertOpen();
    if(op==='collection-refresh-start')return json(res,202,{success:true,data:startCollectionRefresh(input)});
    if(op==='collection-refresh-resolve')return json(res,200,{success:true,data:await resolveCollectionRefresh(input)});

    if(['size-chart-library-list','size-chart-library-save','size-chart-library-read'].includes(op)){
      const keys=['contextId',...(op.endsWith('-save')?['name','type','data','url']:op.endsWith('-read')?['id']:[])];
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!keys.includes(key)))throw Object.assign(new Error('尺码表参数无效。'),{status:400});
      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope();
      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});if(req.aborted||await accountScope()!==scope)throw Object.assign(new Error('妙手连接已变化，请重新打开尺码表。'),{status:409,code:'CONTEXT_CHANGED'});};
      await guard();
      if(op.endsWith('-read')){
        const {type,bytes}=await sizeChartLibrary.read(scope,input.id);await guard();
        res.writeHead(200,{'Content-Type':type,'Content-Length':bytes.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});return res.end(bytes);
      }
      const result=op.endsWith('-save')?{item:await sizeChartLibrary.save(scope,input,guard)}:{items:await sizeChartLibrary.list(scope)};
      await guard();return json(res,200,{success:true,data:{contextId:selectedContext,...result}});
    }

    if(op==='listing-size-chart-image'){

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['contextId','shopId','sizeChartUrl'].includes(key)))throw Object.assign(new Error('尺码图参数无效。'),{status:400});

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),shopId=miaoshouId(input.shopId);await ensureCollectionCache();

      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});if(req.aborted||await accountScope()!==scope||!shopDirectory.has(shopId))throw Object.assign(new Error('来源店铺已变化。'),{status:409});const chart=await claimSizeCharts.list({accountScope:scope,shopId});if(!chart.sizeChartUrl||chart.sizeChartUrl!==input.sizeChartUrl)throw Object.assign(new Error('尺码图已更新，请重新读取。'),{status:409});return chart;};

      const chart=await guard(),controller=new AbortController(),cancel=()=>controller.abort();req.on?.('aborted',cancel);

      try{const image=await imageReader(chart.sizeChartUrl,{signal:controller.signal});await guard();res.writeHead(200,{'Content-Type':image.type,'Cache-Control':'no-store'});return res.end(image.bytes);}finally{req.removeListener?.('aborted',cancel);}

    }

    if(op==='listing-template-library'){
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['contextId','shopId','categoryId','kind'].includes(key))||!['attributes','sales','chart'].includes(input.kind))throw Object.assign(new Error('模板读取参数无效。'),{status:400});
      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),shopId=input.shopId?miaoshouId(input.shopId):null,categoryId=input.categoryId?miaoshouId(input.categoryId):null;
      if(categoryId&&!isBuiltinMiaoshouLeafCategory(categoryId))throw Object.assign(new Error('请选择已识别的末级细分类目。'),{status:400});
      await ensureCollectionCache();
      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});if(req.aborted||await accountScope()!==scope||shopId&&!shopDirectory.has(shopId))throw Object.assign(new Error('妙手账号或来源店铺已变化，请重新选择。'),{status:409});};
      await guard();const shopIds=[...shopDirectory.keys()],sourceName=source=>({...source,shopName:source.shopId?(shopDirectory.get(source.shopId)?.name||shopDirectory.get(source.shopId)?.code||source.shopId):'全部店铺',categoryName:source.categoryId?(builtinMiaoshouCategoryName(source.categoryId)?.path?.join(' / ')||source.categoryId):'全部类目'});let items=[];
      if(input.kind==='attributes'){
        const library=await attributeTemplates.listAll({accountScope:scope,shopIds,categoryIds:categoryId?[categoryId]:builtinMiaoshouLeafCategoryIds(),sharedOnly:true,guard});
        items=library.items.map(item=>({...item,source:sourceName(item.source),sourceLabel:'子类目通用'}));
      }else if(input.kind==='sales'){
        const library=await skuStructures.list({accountScope:scope});items=library.items.filter(item=>(!item.scope?.shop||shopDirectory.has(item.scope.shop.id))&&(!shopId||!item.scope?.shop||item.scope.shop.id===shopId)&&(!categoryId||!item.scope?.category||item.scope.category.id===categoryId)).map(item=>({...item,source:sourceName({shopId:item.scope?.shop?.id||'',categoryId:item.scope?.category?.id||'',scope:item.scope?.shop?'shop':item.scope?.category?'category':'all'})}));
      }else for(const id of shopId?[shopId]:shopIds){const chart=await claimSizeCharts.list({accountScope:scope,shopId:id});if(chart.sizeChartUrl)items.push({name:'店铺默认尺码表',sizeChartUrl:chart.sizeChartUrl,source:sourceName({shopId:id,categoryId:'',scope:'shop'})});}
      await guard();return json(res,200,{success:true,data:{contextId:selectedContext,shopId,categoryId,items}});
    }
    if(['claim-size-chart-list','claim-size-chart-save','claim-size-chart-delete'].includes(op)){

      const base=['contextId','shopId'],writing=op!=='claim-size-chart-list',allowed=writing?[...base,'revision',...(op==='claim-size-chart-save'?['sizeChartUrl']:[])]:base;

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))throw Object.assign(new Error('店铺认领尺码表参数无效。'),{status:400});

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),shopId=miaoshouId(input.shopId);

      await ensureCollectionCache();

      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});if(req.aborted||await accountScope()!==scope)throw Object.assign(new Error('妙手连接已变化，请重新读取店铺尺码表。'),{status:409,code:'CONTEXT_CHANGED'});if(!shopDirectory.has(shopId))throw Object.assign(new Error('请先同步妙手，再选择当前账号的 TikTok 店铺。'),{status:409,code:'MIAOSHOU_CLAIM_CHART_SHOP'});if(writing&&(activeWrites||batchActive))throw Object.assign(new Error('妙手认领或编辑正在执行，请完成后再保存尺码表配置。'),{status:409,code:'MIAOSHOU_CLAIM_CHART_BUSY'});};

      await guard();const storeScope={accountScope:scope,shopId};

      const data=writing?await claimSizeCharts[op==='claim-size-chart-save'?'save':'remove']({...storeScope,revision:input.revision,...(op==='claim-size-chart-save'?{sizeChartUrl:input.sizeChartUrl}:{})},{guard}):await claimSizeCharts.list(storeScope);

      assertContext({contextId:selectedContext},{required:true});return json(res,200,{success:true,data:{contextId:selectedContext,shopId,...data}});

    }

    if(LOCAL_ATTRIBUTE_OPERATIONS.includes(op)){
      if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('本机类目模板参数无效。');
      const ctx=await localAttributeContext(req,input);const data=await localCategoryAttributes.handle(op,input,ctx);return json(res,200,{success:true,data});
    }

    if(['attribute-templates-list','attribute-templates-save','attribute-templates-delete','attribute-templates-apply','attribute-templates-default'].includes(op)){

      const baseKeys=['contextId','detailId','sourceRevision','scope'];

      const allowed=op==='attribute-templates-list'?baseKeys:op==='attribute-templates-save'?[...baseKeys,'revision','id','template']:[...baseKeys,'revision','id'];

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key))||input.scope!==undefined&&input.scope!=='category'||typeof input.sourceRevision!=='string'||!/^[a-f0-9]{64}$/u.test(input.sourceRevision))throw Object.assign(new Error('类目属性模板参数或商品原件版本无效，请重新读取。'),{code:'MIAOSHOU_ATTRIBUTE_TEMPLATE_INVALID',status:400});

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),detailId=miaoshouId(input.detailId);

      const snapshot=editorSnapshots.get(detailId+':'+input.sourceRevision);

      const guard=async()=>{

        assertOpen();assertContext({contextId:selectedContext},{required:true});

        if(req.aborted||await accountScope()!==scope)throw Object.assign(new Error('妙手连接已变化，请重新读取属性模板。'),{code:'CONTEXT_CHANGED',status:409});

        const current=editorSnapshots.get(detailId+':'+input.sourceRevision),policy=singleShopPolicy(records.get(detailId)?.shopIds);

        if(!snapshot||current!==snapshot||snapshot.scope!==scope||snapshot.contextId!==selectedContext||snapshot.expires<Date.now()||!policy.allowed||policy.shopId!==snapshot.shopId)throw Object.assign(new Error('商品原件已失效，请重新读取属性模板。'),{code:'MIAOSHOU_EDIT_STALE',status:409});

      };

      await guard();const target={detailId,shopId:snapshot.shopId};

      const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(detailId),shopId:BigInt(target.shopId)}),target);await guard();

      if(miaoshouEditRevision(detail)!==input.sourceRevision||miaoshouId(detail.shopCollectItemInfo.cid)!==snapshot.categoryId)throw Object.assign(new Error('商品资料已变化，请重新读取后使用属性模板。'),{code:'MIAOSHOU_EDIT_STALE',status:409});

      if(!isBuiltinMiaoshouLeafCategory(snapshot.categoryId))throw Object.assign(new Error('尚未确认这是末级细分类目，暂不能保存或应用属性模板。'),{code:'MIAOSHOU_ATTRIBUTE_TEMPLATE_LEAF',status:400});

      const shared={scope:'category'};

      const storeScope={accountScope:scope,shopId:target.shopId,categoryId:snapshot.categoryId,...shared};

      const visibleScope={shopId:target.shopId,categoryId:snapshot.categoryId,categoryName:builtinMiaoshouCategoryName(snapshot.categoryId)?.path?.join(' / ')||'',...shared};

      let data,changes;

      if(op==='attribute-templates-list')data=(await attributeTemplates.resolveSharedEditor({...storeScope,legacyShopIds:[...shopDirectory.keys()]},{guard})).library;

      else if(op==='attribute-templates-delete')data=await attributeTemplates.remove({...storeScope,revision:input.revision,id:input.id},{guard});

      else if(op==='attribute-templates-default')data=await attributeTemplates.setDefault({...storeScope,revision:input.revision,id:input.id},{guard});

      else {

        const metadataResult=await api.call('categoryMetadata',{cid:BigInt(snapshot.categoryId),shopIds:[BigInt(target.shopId)]});await guard();

        const metadata=metadataResult?.categoryMetadata;if(!metadata||typeof metadata!=='object'||Array.isArray(metadata))throw new Error('未能读取当前店铺类目的真实属性选项。');

        if(op==='attribute-templates-save'){

          const template=validateCategoryAttributeTemplate(input.template);compileMiaoshouAttributeUpdates(template.attributes,metadata);

          data=await attributeTemplates[Object.hasOwn(input,'id')?'update':'create']({...storeScope,revision:input.revision,...(Object.hasOwn(input,'id')?{id:input.id}:{}),preset:template},{guard});

        }else{

          data=await attributeTemplates.list(storeScope);

          if(!Number.isSafeInteger(input.revision)||input.revision!==data.revision)throw Object.assign(new Error('属性模板库已变化，请刷新后重新选择。'),{code:'MIAOSHOU_ATTRIBUTE_TEMPLATE_CONFLICT',status:409});

          const item=data.items.find(item=>item.id===input.id);if(!item)throw Object.assign(new Error('属性模板不存在或不属于当前末级子类目。'),{code:'MIAOSHOU_ATTRIBUTE_TEMPLATE_NOT_FOUND',status:409});

          changes={contextShopId:target.shopId,contextCategoryId:snapshot.categoryId,attributes:structuredClone(item.attributes)};

          compileStructuredPatch(detail.shopCollectItemInfo,changes,{shopId:target.shopId,categoryId:snapshot.categoryId,metadata});

        }

      }

      await guard();return json(res,200,{success:true,data:{...data,contextId:selectedContext,scope:visibleScope,...(changes?{changes}:{})}});

    }

    if(['sku-presets-options','sku-presets-category'].includes(op)){

      const allowed=op==='sku-presets-options'?['contextId','shopId','query','page']:['contextId','shopId','detailId'];

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('SKU模板范围选项参数无效。');

      assertContext(input,{required:true});const readContext=contextId,scope=await accountScope();await ensureCollectionCache();

      const guard=async()=>{assertOpen();assertContext({contextId:readContext},{required:true});if(req.aborted||await accountScope()!==scope)throw new Error('范围读取已取消或账号已变化，请重新读取。');};await guard();

      const shopId=input.shopId===undefined?null:miaoshouId(input.shopId);if(shopId&&!shopDirectory.has(shopId))throw new Error('所选店铺未在当前妙手账号的绑定店铺中，请先同步妙手数据。');

      if(op==='sku-presets-options'){

        if(input.query!==undefined&&(typeof input.query!=='string'||input.query.length>100||/[\u0000-\u001f\u007f]/u.test(input.query))||input.page!==undefined&&(!Number.isSafeInteger(input.page)||input.page<1||input.page>1000000))throw new Error('SKU模板范围分页参数无效。');

        const page=input.page||1,query=(input.query||'').normalize('NFKC').trim().toLowerCase(),items=shopId?[...records.values()].filter(row=>row.shopIds?.length===1&&row.shopIds[0]===shopId&&(!query||(row.title+' '+row.id).normalize('NFKC').toLowerCase().includes(query))):[];

        const categories=[...skuPresetCategories.values()].filter(item=>item.scope===scope&&item.contextId===readContext&&item.shopId===shopId&&Date.now()-item.at<30*60*1000).map(({id,path,shopId,shopName})=>({id,path,shopId,shopName}));

        return json(res,200,{success:true,data:{contextId:readContext,shops:[...shopDirectory.values()].map(shop=>({id:shop.id,name:shop.code||shop.name})),categories,products:items.slice((page-1)*50,page*50).map(row=>({id:row.id,title:row.title})),total:items.length,page,pageSize:50,message:shopDirectory.size?'仅显示已读取的类目；可从当前店铺商品按需读取末级类目。':'请先同步妙手数据，再配置店铺与细分类目范围。'}});

      }

      if(!shopId)throw new Error('请先选择当前妙手账号的店铺。');const detailId=miaoshouId(input.detailId),row=records.get(detailId);

      if(row?.shopIds?.length!==1||row.shopIds[0]!==shopId)throw new Error('来源商品不属于所选单一店铺，请重新选择。');

      const key=[scope,readContext,shopId,detailId].join('|');let pending=skuPresetCategoryReads.get(key);

      if(!pending){if(skuPresetCategoryReads.size>=4)throw new Error('正在读取范围类目，请稍后重试。');pending=(async()=>{await guard();const target={detailId,shopId},detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(detailId),shopId:BigInt(shopId)}),target);await guard();const context=await loadMiaoshouEditContext({info:detail.shopCollectItemInfo,target,detail,client:api,guard,needs:[],partial:true});await guard();if(records.get(detailId)?.shopIds?.length!==1||records.get(detailId)?.shopIds[0]!==shopId)throw new Error('来源商品店铺已变化，请重新读取。');const category=rememberSkuPresetCategory(context,scope,readContext);if(!category)throw new Error('商品尚未返回可确认的末级类目路径，请选择其他商品。');return category;})();skuPresetCategoryReads.set(key,pending);const release=()=>{if(skuPresetCategoryReads.get(key)===pending)skuPresetCategoryReads.delete(key);};void pending.then(release,release);}

      const category=await pending;await guard();return json(res,200,{success:true,data:{contextId:readContext,id:category.id,path:category.path,shopId:category.shopId,shopName:category.shopName}});

    }

    if(['sku-presets-list','sku-presets-save','sku-presets-delete'].includes(op)){

      if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('SKU模板参数无效。');

      const allowed=op==='sku-presets-list'?['contextId']:op==='sku-presets-save'?['contextId','revision','id','preset']:['contextId','revision','id'];

      if(Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('SKU模板参数无效。');

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope();assertContext({contextId:selectedContext},{required:true});

      if(op==='sku-presets-save'){

        input.preset=validateSkuPreset(input.preset);const filter=input.preset.scope;

        if(filter?.shop){await ensureCollectionCache();assertContext({contextId:selectedContext},{required:true});const shop=shopDirectory.get(filter.shop.id);if(!shop)throw new Error('模板范围店铺不属于当前妙手账号的已同步绑定店铺。');filter.shop.name=shop.code||shop.name;

          if(filter.category){const category=skuPresetCategories.get([scope,selectedContext,shop.id,filter.category.id].join('|'));if(!category||Date.now()-category.at>=30*60*1000||category.path!==filter.category.path)throw new Error('请从当前店铺商品重新读取此末级细分类目后保存模板。');filter.category.path=category.path;}

        }

      }

      const data=op==='sku-presets-list'?await skuPresets.list({accountScope:scope}):op==='sku-presets-delete'?await skuPresets.remove({accountScope:scope,revision:input.revision,id:input.id}):await skuPresets[Object.hasOwn(input,'id')?'update':'create']({accountScope:scope,revision:input.revision,...(Object.hasOwn(input,'id')?{id:input.id}:{}),preset:input.preset});

      assertContext({contextId:selectedContext},{required:true});return json(res,200,{success:true,data:{...data,contextId:selectedContext}});

    }

    if(op==='mockup-template-binding-list'||op==='mockup-template-binding-save'){
      const save=op.endsWith('-save'),allowed=save?['contextId','shopId','revision','templateIds']:['contextId','shopId'];
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('店铺模板匹配参数无效。');
      assertContext(input,{required:true});
      const selectedContext=contextId,scope=await accountScope(),shopId=miaoshouId(input.shopId);
      await ensureCollectionCache();
      if(!shopDirectory.has(shopId))throw new Error('店铺不在当前妙手账号的已同步店铺中。');
      const guard=async()=>{
        const currentScope=await accountScope();
        assertOpen();
        assertContext({contextId:selectedContext},{required:true});
        if(req.aborted||currentScope!==scope||!shopDirectory.has(shopId))throw Object.assign(new Error('妙手账号或店铺已变化，请刷新后重新操作。'),{status:409,code:'CONTEXT_CHANGED'});
      };
      await guard();
      const target={accountScope:scope,shopId};
      const data=save?await mockupTemplateBindings.save({...target,revision:input.revision,templateIds:input.templateIds},{guard}):await mockupTemplateBindings.list(target);
      await guard();
      return json(res,200,{success:true,data:{...data,shopId,contextId:selectedContext}});
    }

    if(['description-templates-list','description-templates-save','description-templates-delete'].includes(op)){
      const base=['contextId','shopId'];
      const allowed=op==='description-templates-list'?base:op==='description-templates-save'?[...base,'revision','id','template']:[...base,'revision','id'];
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('产品描述模板参数无效。');
      assertContext(input,{required:true});
      const selectedContext=contextId,scope=await accountScope(),shopId=miaoshouId(input.shopId);
      await ensureCollectionCache();
      const shop=shopDirectory.get(shopId);
      if(!shop)throw new Error('描述模板的店铺不属于当前账号的已同步店铺。');
      const guard=async()=>{
        const currentScope=await accountScope();
        assertOpen();
        assertContext({contextId:selectedContext},{required:true});
        if(req.aborted||currentScope!==scope||!shopDirectory.has(shopId))throw Object.assign(new Error('店铺或账号已变化，请重新读取描述模板。'),{code:'CONTEXT_CHANGED',status:409});
      };
      await guard();
      const target={accountScope:scope,shopId},withId=Object.hasOwn(input,'id')?{id:input.id}:{};
      let data;
      if(op==='description-templates-list')data=await descriptionTemplates.list(target);
      else if(op==='description-templates-save')data=await descriptionTemplates.save({...target,revision:input.revision,...withId,template:input.template},{guard});
      else data=await descriptionTemplates.remove({...target,revision:input.revision,...withId},{guard});
      await guard();
      return json(res,200,{success:true,data:{...data,shopId,contextId:selectedContext}});
    }

    if(['sku-structures-shop-list','sku-structures-shop-save','sku-structures-shop-delete','sku-structures-shop-default'].includes(op)){
      const base=['contextId','shopId'],allowed=op==='sku-structures-shop-list'?base:op==='sku-structures-shop-save'?[...base,'revision','id','template','makeDefault']:[...base,'revision','id'];
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('本机店铺SKU模板参数无效。');
      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),shopId=miaoshouId(input.shopId),shop=shopDirectory.get(shopId);
      if(!shop)throw new Error('SKU模板店铺不属于当前账号的已同步店铺。');
      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});if(req.aborted||await accountScope()!==scope||shopDirectory.get(shopId)!==shop)throw Object.assign(new Error('店铺或账号已变化，请重新读取SKU模板。'),{code:'CONTEXT_CHANGED',status:409});};
      await guard();const target={accountScope:scope,shopId};let data;
      if(op==='sku-structures-shop-list')data=await skuStructures.listShop(target);
      else if(op==='sku-structures-shop-save')data=await skuStructures.saveShop({...target,shopName:shop.code||shop.name,revision:input.revision,...(Object.hasOwn(input,'id')?{id:input.id}:{}),template:input.template,...(Object.hasOwn(input,'makeDefault')?{makeDefault:input.makeDefault}:{})},{guard});
      else data=await skuStructures[op==='sku-structures-shop-delete'?'removeShop':'setShopDefault']({...target,revision:input.revision,id:input.id},{guard});
      await guard();return json(res,200,{success:true,data:{...data,shopId,contextId:selectedContext}});
    }

    if(['sku-structures-list','sku-structures-save','sku-structures-delete'].includes(op)){

      const allowed=op==='sku-structures-list'?['contextId']:op==='sku-structures-save'?['contextId','revision','id','template']:['contextId','revision','id'];

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('规格组合模板参数无效。');

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope();assertContext({contextId:selectedContext},{required:true});

      if(op==='sku-structures-save'){

        input.template=validateSkuStructureTemplate(input.template);const filter=input.template.scope;

        if(filter?.shop){await ensureCollectionCache();assertContext({contextId:selectedContext},{required:true});const shop=shopDirectory.get(filter.shop.id);if(!shop)throw new Error('模板店铺不属于当前账号的已同步绑定店铺。');filter.shop.name=shop.code||shop.name;

          if(filter.category){const category=skuPresetCategories.get([scope,selectedContext,shop.id,filter.category.id].join('|'));if(!category||Date.now()-category.at>=30*60*1000||category.path!==filter.category.path)throw new Error('请从当前店铺商品重新读取此末级细分类目后保存模板。');filter.category.path=category.path;}

        }

      }

      const data=op==='sku-structures-list'?await skuStructures.list({accountScope:scope}):op==='sku-structures-delete'?await skuStructures.remove({accountScope:scope,revision:input.revision,id:input.id}):await skuStructures[Object.hasOwn(input,'id')?'update':'create']({accountScope:scope,revision:input.revision,...(Object.hasOwn(input,'id')?{id:input.id}:{}),template:input.template});

      assertContext({contextId:selectedContext},{required:true});return json(res,200,{success:true,data:{...data,contextId:selectedContext}});

    }

    if(['reference-layout-start','reference-layout-status','reference-layout-cancel'].includes(op)){

      assertContext(input,{required:true});const allowed=op==='reference-layout-start'?['detailId','contextId','sourceUrl','sourceGallery','positions','purpose','strictPositions']:['detailId','contextId','jobId'];

      if(Object.keys(input).some(key=>!allowed.includes(key)))throw new Error('参考图识别参数无效。');

      const id=miaoshouId(input.detailId);if(!records.has(id))throw new Error('请先同步并选择商品。');

      if(typeof findExecutable!=='function'&&!referenceVision)throw new Error('主机 Codex 位置识别尚未就绪。');

      return json(res,op==='reference-layout-start'?202:200,{success:true,data:referenceLayouts[op==='reference-layout-start'?'start':op==='reference-layout-cancel'?'cancel':'status']({...input,detailId:id})});

    }

    if(['risk-status','risk-retry','risk-brand-retry'].includes(op)){

      if(!input||Object.keys(input).some(k=>!['contextId','ids'].includes(k))||!Array.isArray(input.ids)||input.ids.length>500)throw new Error('商品检查范围无效。');

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope(),ids=[...new Set(input.ids.map(miaoshouId))];

      if(ids.some(id=>!records.has(id)))throw new Error('商品不在当前采集箱中，请刷新后重试。');

      if(op==='risk-retry')await queueRiskReview(ids.map(id=>records.get(id)),{retry:true});

      const result=await riskReview.snapshot({accountScope:scope,contextId:selectedContext,ids});assertContext({contextId:selectedContext},{required:true});
      let brandSnapshot=null;
      if(brandResearch){
        const completed=(result.results||[]).filter(review=>['ready','partial'].includes(review.status)&&!review.stale&&/^[a-f0-9]{64}$/.test(review.inputHash||''));
        if(op==='risk-brand-retry'&&!completed.length)throw new Error('请等待当前商品风险检查完成，再更新品牌资料。');
        const request={accountScope:scope,contextId:selectedContext,reviews:completed};
        if(op==='risk-brand-retry')brandResearch.retry(request);else brandResearch.enqueue(request);
        brandSnapshot=await brandResearch.snapshot({accountScope:scope,contextId:selectedContext,ids});
        assertContext({contextId:selectedContext},{required:true});if(await accountScope()!==scope)throw new Error('妙手连接已变化，请刷新后重试。');
      }else if(op==='risk-brand-retry')throw new Error('品牌资料调查尚未连接，请更新主机程序后重试。');
      const brands=new Map((brandSnapshot?.results||[]).map(entry=>[entry.id,entry]));
      const results=(result.results||[]).map(review=>{const entry=brands.get(review.id);if(!entry||!review.inputHash||entry.inputHash!==review.inputHash||!['ready','partial'].includes(review.status)||review.stale)return review;
        return {...review,brandResearch:entry.brandResearch,brandResearchState:{id:entry.id,status:entry.brandResearchState,cached:entry.cached===true,refreshing:entry.refreshing===true,error:entry.error||''}};});
      return json(res,200,{success:true,data:{...result,results,contextId:selectedContext}});

    }

    if(['source-image','prepare','replace','edit-context','edit-options','batch-commit','batch-status'].includes(op))assertContext(input);

    if(op==='batch-category-catalog'){
      if(!input||Object.keys(input).some(key=>key!=='contextId'))throw new Error('类目读取参数无效。');
      assertContext(input,{required:true});
      const items=builtinMiaoshouLeafCategoryIds().flatMap(id=>{
        const entry=builtinMiaoshouCategoryName(id);
        return entry?.path?.length?[{id,path:entry.path}]:[];
      });
      if(!items.length)throw new Error('本机 TikTok 美国站类目库未就绪，请更新主机程序。');
      return json(res,200,{success:true,data:{contextId,items}});
    }

    if(op==='batch-settings-progress'){
      if(!batchSettingsObject(input,['contextId','progressId'])||!batchSettingsProgressId(input.progressId))
        throw batchSettingsError('批量设置进度编号无效。');
      assertContext(input,{required:true});
      const scope=await accountScope(),readContext=input.contextId;
      assertOpen();assertContext({contextId:readContext},{required:true});
      pruneBatchSettingsProgress();
      const key=[scope,readContext,input.progressId].join(':');
      const {snapshot}=batchSettingsProgress.get(key)||{};
      const data=snapshot||{contextId:readContext,progressId:input.progressId,state:'pending',stage:'pending',message:'正在等待批量设置准备…',done:0,total:0,eligible:0,skipped:0};
      return json(res,200,{success:true,data});
    }

    if(['batch-settings-options','batch-settings-plan','batch-settings-preview'].includes(op)){
      const options=op==='batch-settings-options';
      const isPlan=op==='batch-settings-plan';
      if(!batchSettingsObject(input,['contextId','detailIds',options?'kind':'settings',...(isPlan?['progressId']:[])])
        ||options&&!batchSettingsKind.includes(input.kind)||Object.hasOwn(input,'progressId')&&!batchSettingsProgressId(input.progressId))
        throw batchSettingsError('批量设置参数无效，请重新打开弹窗。');
      assertContext(input,{required:true});
      const readContext=contextId,ids=batchSettingsIds(input.detailIds),selection=options?undefined:parseBatchSettings(input.settings);
      const scope=await accountScope();
      assertOpen();assertContext({contextId:readContext},{required:true});
      let progress;
      if(input.progressId){
        pruneBatchSettingsProgress();
        const key=[scope,readContext,input.progressId].join(':');
        if(batchSettingsProgress.has(key))throw Object.assign(new Error('此批量设置准备编号已使用，请核对原任务。'),{code:'MIAOSHOU_BATCH_PROGRESS_DUPLICATE',status:409});
        if([...batchSettingsProgress.values()].filter(entry=>!entry.expires).length>=BATCH_SETTINGS_PROGRESS_LIMIT)
          throw Object.assign(new Error('正在准备的批量设置过多，请稍后重试。'),{code:'MIAOSHOU_BATCH_PROGRESS_BUSY',status:409});
        progress={snapshot:{contextId:readContext,progressId:input.progressId,state:'preparing',stage:'cache',message:'正在读取采集箱缓存…',done:0,total:ids.length,eligible:0,skipped:0}};
        batchSettingsProgress.set(key,progress);
      }
      const report=update=>{if(progress&&!progress.expires)Object.assign(progress.snapshot,update);};
      const finish=(state,message)=>{
        if(!progress||progress.expires)return;
        report({state,stage:state,message});
        delete progress.snapshot.currentDetailId;
        delete progress.snapshot.currentTitle;
        progress.expires=Date.now()+BATCH_SETTINGS_PROGRESS_TTL;
        pruneBatchSettingsProgress();
      };
      const canceled=()=>finish('canceled','批量设置准备已取消。');
      const guard=async()=>{
        const changed=()=>Object.assign(new Error('妙手连接已变化或批量设置已取消，请重新选择。'),{code:'CONTEXT_CHANGED',status:409});
        assertOpen();assertContext({contextId:readContext},{required:true});
        if(req.aborted||res.destroyed)throw changed();
        const currentScope=await accountScope();
        if(req.aborted||res.destroyed||currentScope!==scope)throw changed();
        assertOpen();assertContext({contextId:readContext},{required:true});
      };
      if(progress)res.once?.('close',canceled);
      try{
        await ensureCollectionCache();await guard();
        const shopIds=[...new Set(ids.flatMap(id=>{
          const policy=singleShopPolicy(records.get(id)?.shopIds);
          return policy.allowed&&shopDirectory.has(policy.shopId)?[policy.shopId]:[];
        }))];
        const result=options?{contextId:readContext,items:await batchSettingsTemplateOptions(input.kind,scope,ids,shopIds,guard)}:
          await previewBatchSettings({ids,settings:selection,scope,shopIds,readContext,guard,report});
        await guard();
        finish('complete','批量设置准备完成。');
        return json(res,200,{success:true,data:result});
      }catch(error){
        if(req.aborted||res.destroyed||error.code==='CONTEXT_CHANGED')canceled();
        else finish('failed','未能完成批量设置准备，请查看操作提示。');
        throw error;
      }finally{if(progress)res.removeListener?.('close',canceled);}
    }

    if(op==='batch-prepare'||op==='batch-warehouse-options'){

      if(op==='batch-prepare'&&!Object.hasOwn(input,'contextId'))return json(res,200,{success:true,data:await batches.prepare(input)});

      assertContext(input,{required:true});const selectedContext=contextId,scope=await accountScope();

      const guard=async()=>{assertOpen();assertContext({contextId:selectedContext},{required:true});const cancelled=()=>{if(req.aborted||res.destroyed)throw Object.assign(new Error('批量操作已关闭，已停止后续商品读取。'),{code:'MIAOSHOU_EDIT_CANCELLED',status:409});};cancelled();const currentScope=await accountScope();cancelled();if(currentScope!==scope)throw Object.assign(new Error('妙手连接已变化，请重新确认批量操作。'),{code:'CONTEXT_CHANGED',status:409});};

      const {contextId:ignored,directCategory,...request}=input;
      if(directCategory!==undefined&&(directCategory!==true||op!=='batch-prepare'||request.action!=='category'))
        throw new Error('直接设置类目参数无效。');

      if(op==='batch-warehouse-options'){
        if(Object.keys(request).length!==1||!Object.hasOwn(request,'detailIds'))throw new Error('批量仓库读取参数无效。');
        await ensureCollectionCache();await guard();
        const {groups,skipped}=await batchWarehouseOptions(request.detailIds,guard);
        return json(res,200,{success:true,data:{contextId:selectedContext,groups,skipped}});
      }

      let reviewCategory,reviewWarehouse;
      if(request.action==='category'){
        await ensureCollectionCache();await guard();
        const unpublished=new Set(statusPages.notPublished||[]),published=new Set(statusPages.published||[]),metadataByShop=new Map();
        reviewCategory=async(item,categoryId)=>{
          await guard();
          if(!unpublished.has(item.detailId)||published.has(item.detailId))return {eligible:false,error:'此商品不在已核验的未发布链接中。请同步未发布链接后再试。'};
          const shopId=singleShopPolicy(item.shopIds).shopId,shop=shopDirectory.get(shopId);
          if(!shop)return {eligible:false,error:'尚未核验当前关联店铺，请先同步妙手店铺。'};
          if(directCategory)return {eligible:true};
          try{
            const reviewed=await productEdits.previewCategory({...item,categoryId},{expectedScope:scope,guard,metadataByShop});
            return {...reviewed,previousCategory:builtinMiaoshouCategoryName(reviewed.previousCategoryId)?.path.join(' / ')||(reviewed.previousCategoryId?'当前类目名称未返回':'未设置类目')};
          }catch(error){
            await guard();
            return {eligible:false,error:sanitizeMiaoshouValue(error.message,[],350)||'无法核对此商品的目标类目。'};
          }
        };
      }

      if(request.action==='warehouse'){
        await ensureCollectionCache();await guard();
        const {groups,published}=await batchWarehouseOptions(request.detailIds,guard);
        const byShop=new Map(groups.map(group=>[group.shopId,group]));
        reviewWarehouse=async(item,shopId,warehouseId)=>{
          await guard();
          const group=byShop.get(shopId),shopName=group?.shopName||'';
          const skip=error=>({eligible:false,error,shopName});
          if(published.has(item.detailId))return skip('已发布商品请在店铺商品中设置仓库。');
          if(!group)return skip('尚未核验当前关联店铺，请先同步妙手店铺。');
          if(!warehouseId)return skip(group.error||'本次未为该店铺选择仓库。');
          const warehouse=group.warehouses.find(row=>row.warehouseId===warehouseId);
          if(!warehouse)return skip(group.error||'所选仓库已不可用或不属于当前店铺。');
          try{
            const preview=await productEdits.previewWarehouse({...item,warehouseId},{expectedScope:scope,guard});
            return {...preview,shopName,warehouseId,warehouseName:warehouse.warehouseName};
          }catch(error){
            await guard();
            return skip(sanitizeMiaoshouValue(error.message,[],350)||'无法核对该商品的原 SKU 库存。');
          }
        };
      }

      if(request.action==='edit'&&request.changes?.attributes){

        validateMiaoshouEditInput({action:'edit',changes:request.changes});

        if(!Array.isArray(request.detailIds)||!request.detailIds.length||request.detailIds.length>200)throw new Error('请选择1至200条同店铺同末级类目链接。');

        const shopId=request.changes.contextShopId,categoryId=request.changes.contextCategoryId;

        if(!isBuiltinMiaoshouLeafCategory(categoryId))throw new Error('尚未确认此末级类目，请重新读取样例商品。');

        for(const raw of request.detailIds){await guard();const id=miaoshouId(raw),row=records.get(id),policy=singleShopPolicy(row?.shopIds);if(!policy.allowed||policy.shopId!==shopId)throw new Error('批量属性模板只能应用到相同店铺的商品，请重新选择。');

          const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(id),shopId:BigInt(shopId)}),{detailId:id,shopId});await guard();

          if(miaoshouId(detail.shopCollectItemInfo.cid)!==categoryId)throw new Error('批量属性模板只能应用到相同末级类目的商品，请重新选择。');

        }

      }

      await guard();const plan=await batches.prepare(request,{expectedContextId:selectedContext,reviewCategory,reviewWarehouse,directCategory});await guard();return json(res,200,{success:true,data:{...plan,contextId:selectedContext}});

    }

    if(op==='batch-commit')return json(res,202,{success:true,data:await batches.commit(input)});

    if(op==='batch-status')return json(res,200,{success:true,data:await batches.status(input)});

    if(op==='edit-cancel'){
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(key=>!['ticket','contextId'].includes(key))||
        typeof input.ticket!=='string'||!input.ticket||input.ticket.length>128)
        throw Object.assign(new Error('取消保存请求无效。'),{status:400});
      assertContext(input,{required:true});
      const result=await batches.cancelEdit(input);
      assertContext(input,{required:true});
      return json(res,200,{success:true,data:result});
    }

    if(op==='batch-find'||op==='batch-review'){

      const key=op==='batch-find'?'ticket':'jobId';

      if(!input||typeof input!=='object'||Array.isArray(input)||typeof input[key]!=='string'||

        Object.keys(input).some(field=>![key,'contextId'].includes(field)))throw Object.assign(new Error('保存结果查询参数无效。'),{status:400});

      assertContext(input,{required:true});

      const data=await batches[op==='batch-find'?'find':'review'](input);

      return json(res,200,{success:true,data});

    }

    if(op==='edit-review'||op==='edit-review-release'){
      const releasing=op==='edit-review-release';
      const allowed=releasing?['detailId','contextId','operationId','revision','confirmed']:['detailId','contextId'];
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(field=>!allowed.includes(field))||
        releasing&&(input.confirmed!==true||typeof input.operationId!=='string'||!/^[a-zA-Z0-9_-]{1,128}$/u.test(input.operationId)||
          typeof input.revision!=='string'||!/^[a-f0-9]{64}$/u.test(input.revision)))
        throw Object.assign(new Error(releasing?'结束旧保存核对须使用最新查询结果并确认。':'商品保存查询参数无效。'),{status:400});

      assertContext(input,{required:true});

      const selectedContext=contextId,detailId=miaoshouId(input.detailId),row=records.get(detailId);

      const policy=singleShopPolicy(row?.shopIds);

      if(!policy.allowed)throw Object.assign(new Error(policy.message),{code:policy.code,status:409});

      const scope=await accountScope();

      const checkTarget=()=>{
        assertOpen();
        assertContext({contextId:selectedContext},{required:true});
        const current=singleShopPolicy(records.get(detailId)?.shopIds);
        if(records.get(detailId)!==row||!current.allowed||current.shopId!==policy.shopId)
          throw Object.assign(new Error('商品或关联店铺已变化，请重新读取。'),{status:409,code:'MIAOSHOU_EDIT_STALE'});
      };
      const queued=()=>batches.isSaving(detailId,{scope,contextId:selectedContext});
      const busy=()=>syncing||batchActive||queued();
      checkTarget();

      if(releasing){
        const verifyTarget=()=>{
          checkTarget();
          if(req.aborted||res.destroyed)throw Object.assign(new Error('核对窗口已关闭，请重新查询。'),{status:409,code:'MIAOSHOU_EDIT_REVIEW_CHANGED'});
          if(busy())throw Object.assign(new Error('妙手任务正在执行，请完成后再结束旧保存核对。'),{status:409,code:'MIAOSHOU_EDIT_BUSY'});
        };
        verifyTarget();
        if(activeWrites)throw Object.assign(new Error('妙手任务正在执行，请完成后再结束旧保存核对。'),{status:409,code:'MIAOSHOU_EDIT_BUSY'});
        // Use the same gate as other writes to keep the fresh detail valid during
        // journal release. This action itself only reads from the remote service.
        activeWrites++;
        try{
          const data=await productEdits.releasePendingResult({detailId,shopIds:row.shopIds,operationId:input.operationId,revision:input.revision},{expectedScope:scope,verifyTarget});
          return json(res,200,{success:true,data});
        }finally{activeWrites--;}
      }

      if(queued())return json(res,200,{success:true,data:{state:'queued',message:editQueueMessage}});

      const {state,result,recovery}=await productEdits.verifyPendingResult({detailId,shopIds:row.shopIds},{expectedScope:scope});

      checkTarget();

      if(queued())return json(res,200,{success:true,data:{state:'queued',message:editQueueMessage}});

      if(result?.verified){

        const changed={};

        for(const [field,key] of [['title','title'],['imgUrls','mainImages'],['notes','description']]){

          if(result.fields.includes(field))changed[key]=true;

        }

        await recordVerifiedProductEdit(detailId,changed,result);

      }

      const message={succeeded:result?.confirmation==='api_receipt'?'已保存到妙手采集箱。':'已读取妙手，指定修改内容已一致。',needs_review:'尚未取得可确认的保存结果，请在妙手核对该商品；不会重复提交。',none:'该商品没有待核对的保存记录。'}[state];

      return json(res,200,{success:true,data:{state,message,...(recovery&&!busy()&&!activeWrites?{recovery}:{}),...(result?{result:{detailId,shopId:policy.shopId,verified:result.verified===true,...(result.confirmation?{confirmation:result.confirmation}:{}),...(result.revision?{revision:result.revision}:{}),...(result.receipt?{receipt:result.receipt}:{}),...(result.fieldReview?{fieldReview:result.fieldReview}:{})}}:{})}});

    }

    if(op==='edit-prepare'){

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['detailId','revision','changes','contextId'].includes(k))||typeof input.revision!=='string'||!/^[a-f0-9]{64}$/u.test(input.revision))throw Object.assign(new Error('单品编辑参数或原件版本无效，请重新读取。'),{code:'MIAOSHOU_EDIT_INVALID',status:400});

      assertContext(input,{required:true});const readContext=contextId;

      validateMiaoshouEditInput({action:'edit',changes:input.changes});

      const row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('请先同步所选商品。');

      const policy=singleShopPolicy(row.shopIds);if(!policy.allowed)throw Object.assign(new Error(policy.message),{code:policy.code,status:409});

      const target={detailId:row.id,shopId:policy.shopId},scope=await accountScope();

      const snapshot=editorSnapshots.get(target.detailId+':'+input.revision);

      if(!snapshot||snapshot.scope!==scope||snapshot.shopId!==target.shopId||snapshot.contextId!==readContext||snapshot.expires<Date.now())throw Object.assign(new Error('商品编辑原件已失效，请重新读取并核对后保存。'),{code:'MIAOSHOU_EDIT_STALE',status:409});

      if(!snapshot.categoryId&&Object.keys(input.changes).some(key=>['contextCategoryId','codEnabled','sizeChartUrl'].includes(key)))throw Object.assign(new Error(MIAOSHOU_CATEGORY_UNASSIGNED),{code:'MIAOSHOU_CATEGORY_UNASSIGNED',status:409});

      const guard=async()=>{assertOpen();assertContext({contextId:readContext},{required:true});if(await accountScope()!==scope)throw new Error('妙手账号已变化，请重新读取。');};

      const checkQueue=()=>{if(batches.isSaving(target.detailId,{scope,contextId:readContext}))throw editQueueBusy();};
      await guard();checkQueue();

      const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)}),target);await guard();

      if(miaoshouEditRevision(detail)!==input.revision)throw Object.assign(new Error('商品已在别处修改，请重新读取并核对后保存。'),{code:'MIAOSHOU_EDIT_STALE',status:409});

      if(input.changes.replaceSkuStructure){

        const changes={contextShopId:input.changes.contextShopId,contextCategoryId:input.changes.contextCategoryId,replaceSkuStructure:input.changes.replaceSkuStructure};

        const context=await loadMiaoshouEditContext({info:detail.shopCollectItemInfo,target,client:api,guard,needs:structuredContextNeeds(changes)});await guard();

        compileStructuredPatch(detail.shopCollectItemInfo,changes,context);

      }

      checkQueue();
      const plan=await batches.prepare({action:'edit',detailIds:[target.detailId],changes:input.changes},{expectedSourceHash:input.revision,expectedContextId:readContext});await guard();checkQueue();

      return json(res,200,{success:true,data:{...plan,contextId:readContext}});

    }

    if(op==='description-images-preview'){

      if(Object.keys(input).some(k=>!['detailId','imageUrls'].includes(k)))throw new Error('描述图参数无效。');

      const row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('请先同步所选商品。');

      const policy=singleShopPolicy(row.shopIds);if(!policy.allowed)throw new Error(policy.message);

      const target={detailId:row.id,shopId:policy.shopId};

      const detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)}),target);

      return json(res,200,{success:true,data:await descriptionImages.generate({info:detail.shopCollectItemInfo,target,imageUrls:input.imageUrls})});

    }

    if(op==='edit-options'){

      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).some(k=>!['detailId','revision','contextId','needs','refreshWarehouses'].includes(k))||typeof input.revision!=='string'||!/^[a-f0-9]{64}$/u.test(input.revision)||!Array.isArray(input.needs)||input.needs.length<1||input.needs.length>4||new Set(input.needs).size!==input.needs.length||input.needs.some(key=>!MIAOSHOU_EDIT_OPTION_GROUPS.includes(key))||Object.hasOwn(input,'refreshWarehouses')&&(input.refreshWarehouses!==true||input.needs.length!==1||input.needs[0]!=='warehouses'))throw Object.assign(new Error('编辑选项参数无效，请重新读取。'),{code:'MIAOSHOU_EDIT_INVALID',status:400});

      assertContext(input,{required:true});const readContext=contextId,detailId=miaoshouId(input.detailId),scope=await accountScope(),snapshotKey=detailId+':'+input.revision;

      let snapshot;

      const guard=async()=>{

        assertOpen();assertContext({contextId:readContext},{required:true});if(await accountScope()!==scope)throw new Error('妙手账号已变化，请重新读取。');

        const current=editorSnapshots.get(snapshotKey),policy=singleShopPolicy(records.get(detailId)?.shopIds);

        if(!current||current.scope!==scope||current.contextId!==readContext||current.expires<Date.now()||!policy.allowed||current.shopId!==policy.shopId)throw Object.assign(new Error('商品编辑原件已失效，请重新读取并核对。'),{code:'MIAOSHOU_EDIT_STALE',status:409});

        if(snapshot&&(current.shopId!==snapshot.shopId||current.categoryId!==snapshot.categoryId))throw Object.assign(new Error('商品编辑选项来源已变化，请重新读取。'),{code:'MIAOSHOU_EDIT_STALE',status:409});snapshot=current;

      };

      await guard();
      if(input.refreshWarehouses){
        const warehouse=await queueWarehouseUpdate(()=>refreshShopWarehouses(scope,snapshot.shopId,guard));
        return json(res,200,{success:true,data:{detailId,shopId:snapshot.shopId,categoryId:snapshot.categoryId,revision:input.revision,contextId:readContext,warehouses:warehouse.warehouses,warehouseSnapshotAt:warehouse.at,warehouseSnapshotStale:false,errors:{}}});
      }
      const wantsWarehouses=input.needs.includes('warehouses'),cachedWarehouse=wantsWarehouses?savedWarehouse(scope,snapshot.shopId):undefined;
      const needs=cachedWarehouse?input.needs.filter(key=>key!=='warehouses'):input.needs;
      const result=await editorOptions.load({contextId:readContext,accountScope:scope,shopId:snapshot.shopId,categoryId:snapshot.categoryId,needs,guard});await guard();
      const warehouse=wantsWarehouses?savedWarehouse(scope,snapshot.shopId):undefined;
      if(warehouse?.warehouses){result.warehouses=structuredClone(warehouse.warehouses);delete result.errors.warehouses;}
      else if(warehouse||cachedWarehouse){delete result.warehouses;result.errors.warehouses='店铺仓库未同步成功，请重新同步妙手数据。';}

      return json(res,200,{success:true,data:{detailId,shopId:snapshot.shopId,categoryId:snapshot.categoryId,revision:input.revision,contextId:readContext,...result}});

    }

    if(op==='edit-context-cache'||op==='edit-context-cache-accept'){
      const saving=op.endsWith('-accept');
      if(Object.keys(input).some(key=>!['detailId','contextId',...(saving?['revision','expectedRevision']:[])].includes(key)))
        throw new Error('商品缓存请求无效。');
      assertContext(input,{required:true});
      await ensureCollectionCache();
      assertContext(input,{required:true});
      const row=records.get(miaoshouId(input.detailId)),policy=singleShopPolicy(row?.shopIds);
      if(!row||!policy.allowed)throw new Error('请先确认商品关联店铺。');
      const target={detailId:row.id,shopId:policy.shopId},scope=cacheScope;
      if(!root||!scope)return json(res,200,{success:true,data:null});
      let data;
      if(saving){
        const revision=/^[a-f0-9]{64}$/u;
        if(!revision.test(input.revision)||input.expectedRevision!==null&&!revision.test(input.expectedRevision))throw new Error('商品缓存版本无效。');
        const snapshot=editorSnapshots.get(target.detailId+':'+input.revision);
        if(!snapshot?.product||snapshot.shopId!==target.shopId||snapshot.contextId!==input.contextId||snapshot.expires<Date.now())
          throw Object.assign(new Error('商品详情已过期，请重新加载后采用。'),{status:409,code:'MIAOSHOU_CACHE_CONFLICT'});
        try{data=await collectionCache.saveProduct(scope,target,{revision:input.revision,product:snapshot.product},input.expectedRevision);}
        catch(error){if(error.code==='MIAOSHOU_CACHE_CONFLICT')error.status=409;throw error;}
      }else data=await collectionCache.loadProduct(scope,target);
      assertContext(input,{required:true});
      return json(res,200,{success:true,data});
    }

    if(op==='edit-context'){

      if(Object.keys(input).some(k=>!['detailId','contextId','phase','templateMode'].includes(k))||input.phase!==undefined&&!['core','full'].includes(input.phase)||input.templateMode!==undefined&&input.templateMode!=='local')throw new Error('编辑选项参数无效。');const readContext=contextId;

      const row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('请先同步所选商品。');

      const policy=singleShopPolicy(row.shopIds);if(!policy.allowed)throw new Error(policy.message);

      const target={detailId:row.id,shopId:policy.shopId},scope=await accountScope();

      const guardContext=async()=>{assertOpen();assertContext({contextId:readContext},{required:true});if(await accountScope()!==scope)throw new Error('妙手账号已变化，请重新读取。');};
      const disconnected=new AbortController(),deadline=AbortSignal.timeout(35000);
      const signal=AbortSignal.any([disconnected.signal,deadline]);
      const onDisconnect=()=>{if(!res.writableEnded)disconnected.abort();};
      const guard=async()=>{signal.throwIfAborted();await guardContext();};
      let detail;
      res.once?.('close',onDisconnect);
      if(res.destroyed)onDisconnect();
      try{
        detail=validateMiaoshouDetail(await api.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)},
          {guard,signal,timeoutMs:15000,maxRetries:1}),target);
        await guard();
      }catch(error){
        if(disconnected.signal.aborted)return;
        if(deadline.aborted)throw Object.assign(new Error('等待妙手商品详情超时，请稍后重新加载。'),{status:502,code:'REMOTE_TIMEOUT'});
        throw error;
      }finally{res.off?.('close',onDisconnect);}

      const fast=input.phase==='core'||input.templateMode==='local',cachedWarehouse=savedWarehouse(scope,target.shopId);
      const needs=fast?[]:cachedWarehouse?MIAOSHOU_EDIT_OPTION_GROUPS.filter(key=>key!=='warehouses'):MIAOSHOU_EDIT_OPTION_GROUPS;
      const context=await loadMiaoshouEditContext({info:detail.shopCollectItemInfo,target,detail,client:api,guard:guardContext,partial:true,needs,allowMissingCategory:true});
      if(fast)context.optionsPending=true;
      const warehouse=savedWarehouse(scope,target.shopId);
      if(warehouse||cachedWarehouse){
        context.optionsState={warehouses:warehouse?.warehouses?'ready':'failed'};
        context.warehouseSnapshotAt=warehouse?.at??'';
        context.warehouseSnapshotStale=warehouse?.stale??true;
        if(warehouse?.warehouses){context.warehouses=structuredClone(warehouse.warehouses);delete context.errors.warehouses;}
        else{delete context.warehouses;context.errors.warehouses='店铺仓库未同步成功，请重新同步妙手数据。';}
      }
      if(input.templateMode==='local'){
        context.localTemplateMode=true;
        context.savedSkuImages=readMiaoshouSavedSkuImages(context.info.skuPropertyList);
        if(context.categoryId)context.currentSkuImageOptions=readMiaoshouCurrentSkuImageOptions(context.info);
        context.info.productAttributes=[];context.info.skuMap={};context.info.skuPropertyList=[];
      }

      const shopName=shopDirectory.get(target.shopId)?.name;if(typeof shopName==='string'&&shopName)context.product.shopName=shopName;

      const [pendingSave,syncTimes]=await Promise.all([
        productEdits.hasPendingResult({detailId:target.detailId,shopIds:row.shopIds},{expectedScope:scope}).catch(()=>null),
        productEdits.confirmedSyncTimes().catch(()=>new Map()),
      ]);
      await guardContext();if(res.destroyed)return;
      const lastConfirmedSync=syncTimes.get(target.detailId+':'+target.shopId);
      if(Number.isFinite(lastConfirmedSync))context.lastMiaoshouSyncAt=new Date(lastConfirmedSync).toISOString();
      const queuedSave=batches.isSaving(target.detailId,{scope,contextId:readContext});
      context.saveState=queuedSave?'queued':pendingSave===null?'unavailable':pendingSave?'needs_review':'idle';
      if(queuedSave)context.saveReview={state:'needs_review',queueActive:true,message:editQueueMessage};
      else if(pendingSave)context.saveReview={state:'needs_review',message:'该商品有一笔待核对的保存，请先查询保存结果。'};
      rememberSkuPresetCategory(context,scope,readContext);for(const [key,snapshot]of editorSnapshots)if(snapshot.expires<Date.now())editorSnapshots.delete(key);

      editorSnapshots.set(target.detailId+':'+context.revision,{scope,shopId:target.shopId,categoryId:context.categoryId,contextId:readContext,
        product:context.product,expires:Date.now()+30*60*1000});context.contextId=readContext;

      while(editorSnapshots.size>500)editorSnapshots.delete(editorSnapshots.keys().next().value);

      return json(res,200,{success:true,data:context});

    }

    if(op==='shops')return json(res,200,{success:true,data:syncState.shops.at?[...shopDirectory.values()]:await shops()});

    if(op==='action-prepare'){assertContext(input);return json(res,200,{success:true,data:await prepareAction(input)});}

    if(op==='action-review'){assertContext(input);return json(res,200,{success:true,data:await reviewAction(input)});}

    if(op==='action-retry'){assertContext(input);return json(res,200,{success:true,data:await retryAction(input)});}

    if(op==='action-commit'){assertContext(input);return json(res,200,{success:true,data:await commitAction(input)});}

    if(op==='publish-records')return json(res,200,{success:true,data:await publishRecords(input)});

    if(op==='probe')return json(res,200,{success:true,data:await probe()});

    if(op==='settings'){if(!isHost)throw Object.assign(new Error('请在主机启动器的全局设置中配置妙手 API。'),{status:403});return json(res,200,{success:true,data:await configure(input)});}

    if(op==='sync'){if(activeWrites||batchActive)throw new Error('妙手任务正在执行，请稍后刷新。');const alreadyRunning=syncing;if(!syncing)syncTask=sync(input.mode||'all').catch(()=>{lastError='同步未完成，已保留本地数据，请重试。';syncing=false;});return json(res,202,{success:true,data:{syncing:true,alreadyRunning,mode:activeSyncMode,activeMode:activeSyncMode,syncProgress:{...syncProgress,mode:activeSyncMode}}});}

    if(op==='inspect'){

      const generation=epoch,row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('请先同步链接。');

      if(!row.policy.allowed)return json(res,200,{success:true,data:row});

      const target={detailId:row.id,shopId:row.policy.shopId};

      const detail=await api.call('detail',{detailId:BigInt(target.detailId),shopId:BigInt(target.shopId)});

      if(collectionRefreshApplying)await collectionRefreshApplying;
      if(generation!==epoch||records.get(row.id)!==row)throw Object.assign(new Error('列表已刷新，请重新读取主图。'),{status:409});

      const policy=singleShopPolicy(detail?.claimToShopIds);

      if(!policy.allowed||policy.shopId!==target.shopId){row.policy=policy.allowed?{allowed:false,code:'SHOP_CHANGED',message:'关联店铺已变化，请同步采集箱后重试。'}:policy;await patchCollectionCache([row]);return json(res,200,{success:true,data:row});}

      validateMiaoshouDetail(detail,target);

      row.thumbnail=detail.shopCollectItemInfo.imgUrls[0]||'';row.imageSource='shop';
      const leafCategory=extractionLeafCategory(detail.shopCollectItemInfo);
      if(leafCategory)row.leafCategory=leafCategory;
      await patchCollectionCache([row]);

      return json(res,200,{success:true,data:row});

    }

    if(op==='prepare'){const row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('请先同步并选择采集箱链接。');return json(res,200,{success:true,data:await replacements.prepare({detailId:row.id,shopIds:row.shopIds})});}

    if(op==='source-image'){

      if(Object.hasOwn(input,'selectedImageUrl')||Object.hasOwn(input,'imageNumber')){
        if(Object.keys(input).some(key=>!['detailId','contextId','selectedImageUrl','imageNumber'].includes(key))||!Number.isInteger(input.imageNumber)||input.imageNumber<1||input.imageNumber>15||typeof input.selectedImageUrl!=='string'||input.selectedImageUrl.length>8192)throw new Error('所选主图参数无效。');
        assertContext(input,{required:true});
        let address;try{address=new URL(input.selectedImageUrl);}catch{throw new Error('所选主图地址无效。');}
        if(address.protocol!=='https:'||address.username||address.password||address.port&&address.port!=='443')throw new Error('所选主图需要公网 HTTPS 地址或本地图片原件。');
        const detailId=miaoshouId(input.detailId),row=records.get(detailId),generation=epoch;
        if(!row)throw new Error('商品不在当前采集箱中。');
        const policy=singleShopPolicy(row.shopIds);
        if(!policy.allowed&&policy.code!=='NO_SHOP')throw new Error(policy.message||'无法确认关联店铺。');
        const controller=new AbortController(),cancel=()=>controller.abort();req.on?.('aborted',cancel);
        try{
          // A draft card may hold a just-uploaded URL. Use the same DNS-pinned,
          // public-address-only reader as original collection images.
          const image=await imageReader(address.href,{signal:controller.signal,usePublicFallback:true});controller.signal.throwIfAborted();
          assertOpen();assertContext(input,{required:true});
          if(generation!==epoch||records.get(detailId)!==row)throw Object.assign(new Error('商品或关联店铺已变化，请重新选择主图。'),{status:409,code:'STALE_PRODUCT'});
          res.writeHead(200,{'Content-Type':image.type,'Cache-Control':'no-store'});return res.end(image.bytes);
        }finally{req.removeListener?.('aborted',cancel);}
      }

      if(Object.hasOwn(input,'imageIndex')||Object.hasOwn(input,'galleryFingerprint')||Object.hasOwn(input,'sourceSha256')){

        if(Object.keys(input).some(key=>!['detailId','contextId','imageIndex','galleryFingerprint','sourceSha256'].includes(key))||!Number.isInteger(input.imageIndex)||input.imageIndex<1||input.imageIndex>15||!/^\w{64}$/.test(input.galleryFingerprint||'')||! /^[a-f0-9]{64}$/.test(input.sourceSha256||''))throw new Error('主图来源凭据无效，请重新识别。');

        const controller=new AbortController(),cancel=()=>controller.abort();req.on?.('aborted',cancel);

        try{

          const source=await referenceGallery(input,{signal:controller.signal}),receipt=referenceGalleryReceipts.get(input.galleryFingerprint);

          if(!receipt||receipt.contextId!==contextId||receipt.detailId!==String(input.detailId)||receipt.scope!==source.scope||Date.now()-receipt.at>30*60*1000||receipt.hashes[input.imageIndex-1]!==input.sourceSha256||!source.urls[input.imageIndex-1])throw new Error('主图来源已过期或与识别结果不一致，请重新识别。');

          const image=await imageReader(source.urls[input.imageIndex-1],{signal:controller.signal,usePublicFallback:true});controller.signal.throwIfAborted();

          if(createHash('sha256').update(image.bytes).digest('hex')!==input.sourceSha256)throw new Error('来源图片内容已变化，请重新识别后提取。');

          await referenceGallery(input,{signal:controller.signal});

          res.writeHead(200,{'Content-Type':image.type,'Cache-Control':'no-store'});return res.end(image.bytes);

        }finally{req.removeListener?.('aborted',cancel);}

      }

      if(Object.keys(input).some(key=>!['detailId','contextId'].includes(key)))throw new Error('主图读取参数无效。');

      const generation=epoch,row=records.get(miaoshouId(input.detailId));if(!row)throw new Error('请先同步链接。');

      const policy=singleShopPolicy(row.shopIds);let address;

      if(!row.policy?.allowed&&row.policy?.code!=='NO_SHOP')throw Object.assign(new Error(row.policy?.message||'无法确认关联店铺。'),{status:409,code:row.policy?.code||'SHOP_UNKNOWN'});

      if(policy.code==='NO_SHOP'){

        // Read only the authoritative collection image. No claim or replacement

        // ticket is created for unclaimed products.

        const fresh=await freshRecord(row.id);if(!fresh)throw Object.assign(new Error('该链接已不在采集箱，请刷新列表。'),{status:409,code:'STALE_PRODUCT'});

        const current=singleShopPolicy(fresh.shopIds);

        if(current.code!=='NO_SHOP')throw Object.assign(new Error(current.allowed?'链接关联店铺已变化，请刷新后重新抠图。':current.message),{status:409,code:current.allowed?'SHOP_CHANGED':current.code});

        address=fresh.thumbnail;

      }else{

        if(!policy.allowed)throw Object.assign(new Error(policy.message),{status:409,code:policy.code});

        const target=await replacements.prepare({detailId:row.id,shopIds:row.shopIds});address=target.mainImage;

      }

      const controller=new AbortController(),cancel=()=>controller.abort();req.on?.('aborted',cancel);
      if(req.aborted)cancel();
      try{
        const image=await imageReader(address,{signal:controller.signal,usePublicFallback:true});controller.signal.throwIfAborted();assertOpen();
        if(generation!==epoch||records.get(row.id)!==row)throw Object.assign(new Error('列表已刷新，请重新读取主图。'),{status:409,code:'STALE_PRODUCT'});
        res.writeHead(200,{'Content-Type':image.type,'Cache-Control':'no-store'});return res.end(image.bytes);
      }finally{req.removeListener?.('aborted',cancel);}

    }

    if(op==='replace'){
      if(activeWrites||batchActive)throw new Error('妙手任务正在执行，请稍后操作。');
      activeWrites++;
      try{
        const result=await replacements.replace(input),row=records.get(result.detailId);
        if(row){
          row.thumbnail=result.mainImage;
          row.imageSource='shop';
          if(result.verified&&row.shopIds?.includes(result.shopId)){
            row.lastMiaoshouSyncAt=new Date().toISOString();
            row.lastMiaoshouSyncShopId=result.shopId;
          }
          await patchCollectionCache([row]);
          try{await queueRiskReview([row],{changed:true});}catch{cacheInfo.error='商品已保存，风险检查更新尚未保存到本机，请重新检查该商品。';}
        }
        return json(res,200,{success:true,data:result});
      }finally{activeWrites--;}
    }

    return json(res,404,{success:false,message:'接口不存在。'});

  }catch(error){if(res.destroyed)return;return json(res,[400,403,409,413,502,503].includes(error.status)?error.status:400,{success:false,message:error.message||'妙手操作失败。',code:error.code||'MIAOSHOU_ERROR',...(error.data?{data:error.data}:{})});}finally{if(tracked)activeOperations--;}},async close(){closed=true;epoch++;await titleTranslations.close();collectionRefresh.controller?.abort();const riskClosing=riskReview.close();const brandClosing=brandResearch?.close();riskApiSource.close();referenceLayouts.close();referenceGalleryReceipts.clear();await skuPresets.close?.();await skuStructures.close?.();await descriptionTemplates.close();await mockupTemplateBindings.close();await attributeTemplates.close();localCategoryAttributes.close();editorSnapshots.clear();editorOptions.clear();await syncTask;await collectionRefreshApplying;await batches.close();await claimSizeCharts.close();await productEdits.close?.();await descriptionImages.close();await collectionCache.close();await localDraftDisk?.close();await Promise.allSettled([riskClosing,brandClosing]);await publicBrandClient?.close?.();}};

}

