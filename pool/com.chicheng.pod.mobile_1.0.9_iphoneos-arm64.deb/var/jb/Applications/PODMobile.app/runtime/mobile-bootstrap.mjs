import './mobile-compat.mjs';
import {mkdir,readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {isAbsolute,join,resolve} from 'node:path';
import {once} from 'node:events';
import {randomBytes,timingSafeEqual,createHash,createHmac} from 'node:crypto';
import {normalizeMobileConfig,createMobileProviderSettings,createMobileMiaoshouSettings,createMobileUploadSettings} from './pod-studio/mobile-settings.mjs';
import {readKeychainJSON,writeKeychainJSON} from './pod-studio/mobile-native.mjs';
import {applyPendingSnapshot} from './mobile-import.mjs';
import {createMobileSync} from './mobile-sync.mjs';

const runtimeRoot = fileURLToPath(new URL('./',import.meta.url));
const programRoot = join(runtimeRoot,'pod-studio');
export const MOBILE_CAPABILITIES = Object.freeze({localCodex:false,adsPower:false,remoteImages:true,miaoshou:true,localDrafts:true,localTemplates:true,remoteMaterials:true,codexTextTools:false,troSearch:false});
const unavailable = () => Object.assign(new Error('此功能需要电脑 Codex 或 AdsPower；手机可使用蓝移、硅基流动图像 API 和妙手开放平台。'),{code:'MOBILE_UNSUPPORTED',status:503});
const json = (res,status,value) => { res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}); res.end(JSON.stringify(value)); };
const same = (a,b) => timingSafeEqual(createHash('sha256').update(String(a)).digest(),createHash('sha256').update(String(b)).digest());
async function body(req) {
  let size=0; const chunks=[];
  for await (const chunk of req) { size+=chunk.length; if(size>65536) throw Object.assign(new Error('配置内容过大。'),{status:413}); chunks.push(chunk); }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('配置格式无效。'),{status:400}); }
}

/** Factories may be injected by isolated boot tests; production uses the native binding. */
export async function startMobileRuntime({dataRoot=process.env.POD_GLOBAL_CONFIG_HOME,port=Number(process.env.POD_HTTP_PORT || 18731),nativeToken=process.env.POD_NATIVE_TOKEN,config,fetchImpl=fetch,factories={},secretRead=readKeychainJSON,secretWrite=writeKeychainJSON,importSnapshot=applyPendingSnapshot,syncFactory=createMobileSync}={}) {
  if(typeof dataRoot!=='string'||!isAbsolute(dataRoot)||!Number.isInteger(port)||port<0||port>65535) throw Object.assign(new Error('手机数据目录或端口无效。'),{code:'MOBILE_BOOT_CONFIG'});
  if(typeof nativeToken!=='string'||!/^[\x21-\x7e]{32,4096}$/.test(nativeToken)) throw Object.assign(new Error('原生配置令牌不可用。'),{code:'MOBILE_NATIVE_TOKEN'});
  dataRoot=resolve(dataRoot); process.env.POD_GLOBAL_CONFIG_HOME=dataRoot;
  await mkdir(dataRoot,{recursive:true});
  let nativeCheck;try{if(process.platform==='android')nativeCheck=JSON.parse(await readFile(join(dataRoot,'.mobile-native-health.json'),'utf8'));}catch{}
  let currentConfig;
  try {
    const boot = config ?? (process.env.POD_NATIVE_CONFIG_JSON ? JSON.parse(process.env.POD_NATIVE_CONFIG_JSON) : secretRead('mobile-settings')) ?? {};
    currentConfig=normalizeMobileConfig(boot);
  } finally { delete process.env.POD_NATIVE_CONFIG_JSON; }
  // This is the only moment a completed desktop snapshot may be imported.
  const imported=await importSnapshot({dataRoot});
  const [{createLanServer},{createAssistantService},{createCodexBridge},{createMiaoshouService},{createHostTemplateStore},{createDesignFolderStore}] = await Promise.all([
    import('./pod-studio/lan-server.mjs'),import('./pod-studio/assistant-service.mjs'),import('./pod-studio/codex-bridge.mjs'),import('./pod-studio/miaoshou-service.mjs'),import('./pod-studio/host-templates.mjs'),import('./pod-studio/design-folder-store.mjs')]);
  let closed=false,ready=false,setting=false,fromNative=false,needsReopen=false;
  const getConfig=()=>currentConfig;
  const saveConfig=async value=>{
    if(setting)throw Object.assign(new Error('原生配置正在更新，请稍后重试。'),{status:409});
    const normalized=normalizeMobileConfig(value);
    if(await secretWrite('mobile-settings',normalized)!==true)throw new Error('iOS Keychain 保存失败。');
    currentConfig=normalized;
  };
  const providerSettings=createMobileProviderSettings({getConfig,saveConfig});
  const miaoshouSettings=createMobileMiaoshouSettings({getConfig,saveConfig:async value=>{
    if(fromNative){currentConfig={...currentConfig,miaoshou:value.miaoshou};return;}
    return saveConfig(value);
  }});
  const templateRoot=join(dataRoot,'模板库');await mkdir(templateRoot,{recursive:true});
  const templates=(factories.templates||createHostTemplateStore)({projectRoot:programRoot,libraryRoot:templateRoot,universalGeometry:true});
  const assistant=(factories.assistant||createAssistantService)({providerSettings,providerRoot:dataRoot,learningRoot:join(dataRoot,'design-learning'),fetchImpl,
    checkAccess:async()=>{throw unavailable();},
    createBridge:options=>createCodexBridge({...options,providerFetchImpl:fetchImpl,resolveNetworkEnvironment:async()=>({}),spawnImpl:()=>{throw unavailable();}})});
  const miaoshou=(factories.miaoshou||createMiaoshouService)({root:join(dataRoot,'miaoshou'),templateRoot,templatesReady:Promise.resolve(templateRoot),settings:miaoshouSettings});
  const mobileSync=syncFactory({dataRoot,getConfig,fetchImpl,onSyncComplete:()=>{needsReopen=true;}});
  const publishing={handle:async(_req,res)=>json(res,503,{success:false,code:'MOBILE_UNSUPPORTED',message:'AdsPower 浏览器发布仅在电脑运行；手机可通过妙手开放平台保存和发布。'})};
  const settingsStore=createMobileUploadSettings({getConfig,fetchImpl});
  const {server}=createLanServer({serviceAuthorization:'Bearer '+randomBytes(32).toString('hex'),addresses:['127.0.0.1'],staticRoot:join(programRoot,'dist'),fetchImpl,
    settingsStore,materialStore:mobileSync.materialStore,templateStore:templates,assistantService:assistant,miaoshouService:miaoshou,publishingService:publishing,
    designFolderStore:(factories.designFolder||createDesignFolderStore)({directory:join(dataRoot,'套图')})});
  const original=server.listeners('request')[0];server.removeListener('request',original);
  const version=JSON.parse(await readFile(join(programRoot,'package.json'),'utf8')).version;
  server.on('request',(req,res)=>void (async()=>{
    const peer=String(req.socket.remoteAddress||'').replace(/^::ffff:/,'');
    if(peer!=='127.0.0.1')return json(res,403,{success:false,message:'只允许手机本机访问。'});
    const expected='127.0.0.1:'+server.address().port;
    if(req.headers.host!==expected)return json(res,403,{success:false,message:'本机地址无效。'});
    const url=new URL(req.url,'http://'+expected);
    if(req.headers.origin&&req.headers.origin!=='http://'+expected)return json(res,403,{success:false,message:'来源无效。'});
    if(url.pathname==='/__pod/mobile/health'&&req.method==='GET'){
      const challenge=url.searchParams.get('challenge');
      if(challenge!==null){
        if(!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(challenge))return json(res,400,{success:false,message:'健康检查参数无效。'});
        res.setHeader('X-POD-Native-Proof',createHmac('sha256',nativeToken).update(challenge).digest('hex'));
      }
      return json(res,ready&&!closed?200:503,{success:ready&&!closed,data:{app:'pod-mobile',version,ready:ready&&!closed,capabilities:MOBILE_CAPABILITIES,...(nativeCheck?{nativeCheck}:{}),needsReopen,importedFiles:imported.imported,importConflicts:imported.conflicts.length}});
    }
    if(url.pathname==='/__pod/native/config') {
      if(req.method!=='POST')return json(res,405,{success:false,message:'请求方法无效。'});
      if(!same(req.headers['x-pod-native-token']||'',nativeToken))return json(res,403,{success:false,message:'原生设置授权无效。'});
      if(setting)return json(res,409,{success:false,message:'配置正在更新。'});
      setting=true;
      try {
        const next=normalizeMobileConfig(await body(req));
        // Native has already persisted this configuration in Keychain.
        // Ask Miaoshou to quiesce/change account before altering its live settings.
        fromNative=true;
        if(JSON.stringify(next.miaoshou)!==JSON.stringify(currentConfig.miaoshou)) await miaoshou.configure(next.miaoshou);
        currentConfig=next;
        await mobileSync.reconfigure();
        return json(res,200,{success:true,data:{applied:true}});
      } finally {fromNative=false;setting=false;}
    }
    if(await mobileSync.handle(req,res))return;
    return original(req,res);
  })().catch(error=>{if(!res.headersSent)json(res,[400,403,409,413,503].includes(error?.status)?error.status:503,{success:false,message:error?.code==='MOBILE_SETTINGS'?error.message:'手机服务暂未完成请求，请重试。'});else res.destroy();}));
  async function close(){
    if(closed)return;closed=true;mobileSync.close();
    server.closeAllConnections?.();await new Promise(done=>server.close(()=>done()));
    await Promise.allSettled([assistant.close(),miaoshou.close()]);
  }
  try {
    server.listen(port,'127.0.0.1');await once(server,'listening');
    await mobileSync.reconfigure();
    void assistant.start().catch(()=>{});
    void templates.scan().catch(()=>{});
    ready=true;
  }catch(error){await close();throw error;}
  return {server,close,assistant,miaoshou,mobileSync,url:'http://127.0.0.1:'+server.address().port};
}
