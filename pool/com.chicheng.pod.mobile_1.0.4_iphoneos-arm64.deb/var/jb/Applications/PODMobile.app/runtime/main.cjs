'use strict';
// The native host starts Node once for the lifetime of the iOS process.
import('./mobile-bootstrap.mjs').then(({startMobileRuntime}) => startMobileRuntime()).catch(error => {
  // Never print native settings, HTTP bodies or credential-bearing errors.
  process.stderr.write('POD mobile runtime could not start (' + (/^[A-Z_]{1,60}$/.test(error?.code || '') ? error.code : 'MOBILE_BOOT_FAILED') + ').\n');
  process.exitCode = 1;
});
