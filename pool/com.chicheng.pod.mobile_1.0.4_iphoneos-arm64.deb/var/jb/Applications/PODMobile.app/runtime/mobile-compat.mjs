import {webcrypto} from 'node:crypto';
// Loaded before the application graph. No credential or disk fallback.
if (!globalThis.crypto) globalThis.crypto = webcrypto;
if (!Promise.withResolvers) Promise.withResolvers = function () {
  let resolve, reject;
  const promise = new this((done, fail) => { resolve = done; reject = fail; });
  return {promise, resolve, reject};
};
if (!AbortSignal.any) AbortSignal.any = function (signals) {
  const controller = new AbortController(), cleanup = [];
  const abort = signal => {
    if (controller.signal.aborted) return;
    controller.abort(signal.reason);
    for (const remove of cleanup.splice(0)) remove();
  };
  for (const signal of signals) {
    if (!(signal instanceof AbortSignal)) throw new TypeError('Expected AbortSignal');
    if (signal.aborted) { abort(signal); break; }
    const listener = () => abort(signal);
    signal.addEventListener('abort', listener, {once:true});
    cleanup.push(() => signal.removeEventListener('abort', listener));
  }
  return controller.signal;
};
