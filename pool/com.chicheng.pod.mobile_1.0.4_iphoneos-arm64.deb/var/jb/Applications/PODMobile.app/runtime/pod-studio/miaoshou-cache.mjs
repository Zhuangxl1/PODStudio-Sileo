import {Worker,isMainThread,parentPort,workerData} from 'node:worker_threads';
import {mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
import {singleShopPolicy} from './dist/miaoshou-policy.js';

const failure=(code,message)=>Object.assign(new Error(message),{code});
const invalid=()=>failure('MIAOSHOU_CACHE_INVALID','妙手本地缓存数据格式无效，未保存本次变动。');
const empty=()=>({records:[],shops:[],incomplete:false,statusPages:{notPublished:null,published:null},syncedAt:'',syncProgress:{pages:0,records:0,complete:false}});
const stats=()=>({added:0,updated:0,removed:0,unchanged:0,shopsChanged:0});
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const id=value=>{if(typeof value!=='string'||! /^[1-9]\d{0,24}$/u.test(value))throw invalid();return value;};
const text=(value,max=4096)=>{if(value===undefined||value===null)return '';if(typeof value!=='string'||value.length>max||/[\u0000]/u.test(value))throw invalid();return value;};
const url=value=>{const result=text(value,8192);if(result){let parsed;try{parsed=new URL(result);}catch{throw invalid();}if(!['http:','https:'].includes(parsed.protocol)||parsed.username||parsed.password)throw invalid();}return result;};
function record(value){
  if(!object(value))throw invalid();
  const result={id:id(value.id)};
  for(const field of ['title','price','itemNum','createdAt','remark','groupId','groupName'])result[field]=text(value[field],field==='remark'?16384:4096);
  if(value.leafCategory!==undefined)result.leafCategory=text(value.leafCategory,120);
  if(value.sourceTitle!==undefined)result.sourceTitle=text(value.sourceTitle,4096);
  result.thumbnail=url(value.thumbnail);
  if(value.sourceThumbnail!==undefined)result.sourceThumbnail=url(value.sourceThumbnail);
  if(value.reviewSourceVersion!==undefined){if(typeof value.reviewSourceVersion!=='string'||!/^[a-f0-9]{64}$/u.test(value.reviewSourceVersion))throw invalid();result.reviewSourceVersion=value.reviewSourceVersion;}
  if(value.imageSource!==undefined){if(value.imageSource!=='shop')throw invalid();result.imageSource='shop';}
  if(value.imageCheckedAt!==undefined)result.imageCheckedAt=text(value.imageCheckedAt,80);
  if(value.shopIds!==undefined){if(!Array.isArray(value.shopIds)||value.shopIds.length>10000)throw invalid();result.shopIds=[...new Set(value.shopIds.map(id))].sort();}
  if(value.lastMiaoshouSyncAt!==undefined){
    const shopId=id(value.lastMiaoshouSyncShopId),at=text(value.lastMiaoshouSyncAt,80);
    if(!Number.isFinite(Date.parse(at)))throw invalid();
    if(result.shopIds?.includes(shopId)){
      result.lastMiaoshouSyncShopId=shopId;
      result.lastMiaoshouSyncAt=at;
    }
  }
  result.policy=singleShopPolicy(result.shopIds);
  // A failed live identity check must remain blocked after a restart.
  if(value.policy?.allowed===false&&result.policy.allowed){
    result.policy=value.policy.code==='SHOP_CHANGED'?{allowed:false,code:'SHOP_CHANGED',message:'关联店铺已变化，请同步采集箱后重试。'}:{allowed:false,code:'SHOP_UNKNOWN',message:'无法确认关联店铺，请刷新链接后重试。'};
  }
  return result;
}
function shop(value){
  if(!object(value))throw invalid();
  const result={id:id(value.id),name:text(value.name,4096),site:text(value.site,160)};
  for(const key of ['code','platform','siteCode','status','authorizationExpiresAt','authorizedAt'])if(value[key]!==undefined)result[key]=text(value[key],key==='code'?4096:160);
  return result;
}
function summary(snapshot){
  const result={};
  if(snapshot.account!==undefined){
    const value=snapshot.account;if(!object(value)||!['unverified','connected','error'].includes(value.connection)||value.profileAvailable!==false)throw invalid();
    result.account={connection:value.connection,profileAvailable:false,checkedAt:text(value.checkedAt,80),lastError:text(value.lastError,1000)};
  }
  if(snapshot.syncState!==undefined){
    if(!object(snapshot.syncState))throw invalid();result.syncState={};
    const keys=['account','shops','collection'];
    if(snapshot.syncState.warehouses!==undefined)keys.push('warehouses');
    for(const key of keys){
      const value=snapshot.syncState[key];if(!object(value)||!['pending','syncing','success','error','unsupported'].includes(value.state))throw invalid();
      result.syncState[key]={state:value.state,at:text(value.at,80),error:text(value.error,1000)};
    }
  }
  if(snapshot.warehouseSnapshot!==undefined)result.warehouseSnapshot=list(snapshot.warehouseSnapshot,warehouseSnapshot);
  return result;
}
function warehouseSnapshot(value){
  if(!object(value)||typeof value.stale!=='boolean')throw invalid();
  const entry={id:id(value.id),at:text(value.at,80),stale:value.stale};
  if(value.warehouses===undefined){if(entry.at||!entry.stale)throw invalid();return entry;}
  entry.at=timestamp(entry.at,false);
  if(!Array.isArray(value.warehouses)||value.warehouses.length>10000)throw invalid();
  const seen=new Set();
  entry.warehouses=value.warehouses.map(row=>{
    if(!object(row))throw invalid();
    const warehouseId=id(row.warehouseId),warehouseName=text(row.warehouseName);
    if(!warehouseName.trim()||seen.has(warehouseId))throw invalid();
    seen.add(warehouseId);
    const normalized={warehouseId,warehouseName};
    for(const key of ['warehouseSubType','warehouseEffectStatus','isDefault'])if(row[key]!==undefined)normalized[key]=text(row[key],160);
    return normalized;
  });
  return entry;
}
function list(value,normalize){if(!Array.isArray(value)||value.length>500000)throw invalid();const result=value.map(normalize),seen=new Set();for(const row of result){if(seen.has(row.id))throw invalid();seen.add(row.id);}return result;}
function progressSummary(progress={}){
  if(!object(progress))throw invalid();const syncProgress={};
  for(const key of ['pages','records','missingShops','warehouseShopsTotal','warehouseShopsSynced','warehouseShopsFailed'])if(progress[key]!==undefined){if(!Number.isSafeInteger(progress[key])||progress[key]<0)throw invalid();syncProgress[key]=progress[key];}
  if(progress.complete!==undefined&&typeof progress.complete!=='boolean')throw invalid();syncProgress.complete=progress.complete===true;
  if(progress.mode!==undefined){if(!['all','notPublished'].includes(progress.mode))throw invalid();syncProgress.mode=progress.mode;}
  for(const key of ['scopeComplete','fullyComplete'])if(progress[key]!==undefined){if(typeof progress[key]!=='boolean')throw invalid();syncProgress[key]=progress[key];}
  if(progress.scopeSyncedAt!==undefined)syncProgress.scopeSyncedAt=timestamp(progress.scopeSyncedAt,false);
  if(progress.mode==='notPublished'&&(progress.complete===true||progress.fullyComplete===true))throw invalid();
  if(progress.fullyComplete===true&&progress.complete!==true)throw invalid();
  if(progress.scopeComplete===true&&progress.complete!==true&&progress.mode!=='notPublished')throw invalid();
  if(progress.stage!==undefined){if(!['shops','notPublished','published','all','complete'].includes(progress.stage))throw invalid();syncProgress.stage=progress.stage;}
  if(progress.completedStatuses!==undefined)syncProgress.completedStatuses=completedStatuses(progress.completedStatuses);
  return syncProgress;
}
function completedStatuses(value){
  if(!Array.isArray(value)||value.length>2||value.some(status=>!['notPublished','published'].includes(status))||new Set(value).size!==value.length)throw invalid();
  return [...value];
}
function metadata(snapshot){
  const syncProgress=progressSummary(snapshot.syncProgress),syncedAt=text(snapshot.syncedAt,80),statusPages={};
  if(!object(snapshot.statusPages))throw invalid();
  for(const key of ['notPublished','published']){const value=snapshot.statusPages[key];if(value!==null&&!Array.isArray(value))throw invalid();statusPages[key]=value===null?null:[...new Set(value.map(id))];}
  return {syncedAt,syncProgress,statusPages};
}
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const validScope=value=>typeof value==='string'&&/^[a-f0-9]{64}$/u.test(value);
const runId=value=>{if(typeof value!=='string'||!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/u.test(value))throw invalid();return value;};
const timestamp=(value,now=true)=>{if(value===undefined&&now)return new Date().toISOString();if(typeof value!=='string'||value.length>80||!/^\d{4}-\d{2}-\d{2}T/u.test(value)||!Number.isFinite(Date.parse(value)))throw invalid();return new Date(value).toISOString();};
function pagination(value,defaultSize){
  if(!object(value))throw invalid();const page=value.page??1,pageSize=value.pageSize??defaultSize;
  if(!Number.isSafeInteger(page)||page<1||page>1000000||!Number.isSafeInteger(pageSize)||pageSize<1||pageSize>100)throw invalid();
  return {page,pageSize};
}
// History stores a safe outcome, never an upstream error that may contain a token or URL.
const outcomeError=(value,status)=>{if(value===undefined||value===null||value==='')return '';text(value,10000);return status==='interrupted'?'同步已中断，已保留此前保存的数据。':'同步未完成，已保留此前保存的数据。';};
function historyInput(operation,payload={}){
  if(!object(payload))throw invalid();
  if(operation==='beginSync'){if(payload.mode!==undefined&&!['all','notPublished'].includes(payload.mode))throw invalid();return {startedAt:timestamp(payload.startedAt),...(payload.mode!==undefined?{mode:payload.mode}:{})};}
  if(operation==='finishSync'){
    if(!['failed','interrupted'].includes(payload.status))throw invalid();
    return {runId:runId(payload.runId),status:payload.status,error:outcomeError(payload.error,payload.status),finishedAt:timestamp(payload.finishedAt),progress:payload.progress===undefined?undefined:progressSummary(payload.progress)};
  }
  if(operation==='listHistory')return pagination(payload,20);
  if(operation==='historyDetail')return {...pagination(payload,50),runId:runId(payload.runId)};
  throw invalid();
}

/** The caller supplies an account/site hash; neither keys nor raw API payloads are persisted. */
export function createMiaoshouCache({root,useWorkers=process.platform!=='ios'}={}){
  let closed=false,queue=Promise.resolve();
  const run=(scope,operation,payload)=>{
    if(closed)return Promise.reject(failure('MIAOSHOU_CACHE_CLOSED','妙手本地缓存已关闭。'));
    if(!validScope(scope))return Promise.reject(invalid());
    const next=queue.then(async()=>{
      if(!root){
        if(operation==='load')return empty();
        if(operation==='loadProduct'||operation==='saveProduct')return null;
        if(['commit','patch'].includes(operation))return stats();
        if(operation==='updateWarehouse')return warehouseSnapshot(payload);
        const input=historyInput(operation,payload);
        if(operation==='listHistory')return {items:[],total:0,...input,storageAvailable:false};
        if(operation==='historyDetail')return null;
        if(operation==='beginSync')return {runId:null,startedAt:input.startedAt,persisted:false};
        return {runId:input.runId,status:input.status,persisted:false};
      }
      // iOS shares a process with UIKit. Avoid creating a V8 isolate for every
      // sync-history/SQLite write; the queue still serializes transactions.
      if(!useWorkers){await new Promise(resolve=>setImmediate(resolve));return workerOperation({root:resolve(root),scope,operation,payload});}
      return new Promise((done,reject)=>{
        const worker=new Worker(new URL(import.meta.url),{workerData:{miaoshouCache:true,root:resolve(root),scope,operation,payload}});
        let settled=false;
        worker.once('message',message=>{settled=true;if(message.ok)done(message.data);else reject(failure(message.code||'MIAOSHOU_CACHE_STORAGE',message.message||'妙手本地缓存无法读取或保存。'));});
        worker.once('error',()=>{if(!settled){settled=true;reject(failure('MIAOSHOU_CACHE_STORAGE','妙手本地缓存无法读取或保存。'));}});
        worker.once('exit',code=>{if(!settled){settled=true;reject(failure('MIAOSHOU_CACHE_STORAGE','妙手本地缓存无法读取或保存。'));}});
      });
    });queue=next.catch(()=>{});return next;
  };
  return {
    load:scope=>run(scope,'load'),
    loadProduct:(scope,target)=>run(scope,'loadProduct',target),
    saveProduct:(scope,target,snapshot,expectedRevision)=>run(scope,'saveProduct',{...target,snapshot,expectedRevision}),
    commit:(scope,snapshot,{complete=true,mode='all',scopeComplete=false,runId,finish,completedStatuses}={})=>run(scope,'commit',{snapshot,complete,mode,scopeComplete,runId,finish,completedStatuses}),
    patch:(scope,changes={})=>run(scope,'patch',changes),
    updateWarehouse:(scope,snapshot)=>run(scope,'updateWarehouse',snapshot),
    beginSync:(scope,options={})=>run(scope,'beginSync',options),
    finishSync:(scope,options)=>run(scope,'finishSync',options),
    listHistory:(scope,options={})=>run(scope,'listHistory',options),
    historyDetail:(scope,options)=>run(scope,'historyDetail',options),
    async close(){closed=true;await queue;}
  };
}

function versionWriter(db){
  const insert=db.prepare('INSERT OR IGNORE INTO history_versions(entity_kind,entity_id,hash,payload,not_published,published,recorded_at) VALUES(?,?,?,?,?,?,?)');
  const find=db.prepare('SELECT version_id FROM history_versions WHERE entity_kind=? AND entity_id=? AND hash=?');
  return (entity,value,notPublished=null,published=null,at=new Date().toISOString())=>{
    const normalized=entity==='record'?record(value):shop(value),publication=entity==='record'?{notPublished,published}:undefined;
    const hash=digest({payload:normalized,...(publication?{publication}:{})});
    insert.run(entity,normalized.id,hash,JSON.stringify(normalized),notPublished,published,at);
    return find.get(entity,normalized.id,hash).version_id;
  };
}
function changeWriter(db){
  const writeVersion=versionWriter(db),insert=db.prepare('INSERT INTO history_changes(run_id,entity_kind,entity_id,operation,source,before_version,after_version,recorded_at) VALUES(?,?,?,?,?,?,?,?)');
  return (entity,entityId,before,after,currentRunId=null,source=currentRunId?'sync':'local',at=new Date().toISOString())=>{
    const version=value=>value?writeVersion(entity,value.payload,value.not_published??null,value.published??null,at):null;
    const beforeId=version(before),afterId=version(after);
    if(beforeId!==afterId)insert.run(currentRunId,entity,entityId,beforeId===null?'added':afterId===null?'removed':'updated',source,beforeId,afterId,at);
  };
}
function migrateHistory(db){
  db.exec('BEGIN IMMEDIATE');
  try{
    db.exec(`CREATE TABLE IF NOT EXISTS sync_runs(run_id TEXT PRIMARY KEY,kind TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT,status TEXT NOT NULL,error TEXT NOT NULL DEFAULT '',progress TEXT NOT NULL DEFAULT '{}',summary TEXT NOT NULL DEFAULT '{}');
      CREATE TABLE IF NOT EXISTS history_versions(version_id INTEGER PRIMARY KEY,entity_kind TEXT NOT NULL,entity_id TEXT NOT NULL,hash TEXT NOT NULL,payload TEXT NOT NULL,not_published INTEGER,published INTEGER,recorded_at TEXT NOT NULL,UNIQUE(entity_kind,entity_id,hash));
      CREATE TABLE IF NOT EXISTS history_changes(change_id INTEGER PRIMARY KEY,run_id TEXT,entity_kind TEXT NOT NULL,entity_id TEXT NOT NULL,operation TEXT NOT NULL,source TEXT NOT NULL,before_version INTEGER,after_version INTEGER,recorded_at TEXT NOT NULL,FOREIGN KEY(run_id) REFERENCES sync_runs(run_id),FOREIGN KEY(before_version) REFERENCES history_versions(version_id),FOREIGN KEY(after_version) REFERENCES history_versions(version_id));
      CREATE INDEX IF NOT EXISTS history_changes_run ON history_changes(run_id,change_id);
      CREATE INDEX IF NOT EXISTS sync_runs_started ON sync_runs(started_at DESC,run_id);
      CREATE TABLE IF NOT EXISTS history_meta(key TEXT PRIMARY KEY,payload TEXT NOT NULL);`);
    if(!db.prepare("SELECT 1 FROM history_meta WHERE key='schema' AND payload='1'").get()){
      const records=db.prepare('SELECT payload,not_published,published FROM records ORDER BY rowid').all(),shops=db.prepare('SELECT payload FROM shops ORDER BY rowid').all();
      if(records.length||shops.length){
        const baselineId=randomUUID(),at=new Date().toISOString(),state=db.prepare("SELECT payload FROM metadata WHERE key='state'").get();
        const saved=state?JSON.parse(state.payload):{},baselineSummary={label:'升级前保存的数据基线',sourceSyncedAt:text(saved.syncedAt,80),records:records.length,shops:shops.length};
        db.prepare('INSERT INTO sync_runs(run_id,kind,started_at,finished_at,status,summary) VALUES(?,?,?,?,?,?)').run(baselineId,'baseline',at,at,'success',JSON.stringify(baselineSummary));
        const writeChange=changeWriter(db);
        for(const row of records){const payload=record(JSON.parse(row.payload));writeChange('record',payload.id,null,{...row,payload},baselineId,'baseline',at);}
        for(const row of shops){const payload=shop(JSON.parse(row.payload));writeChange('shop',payload.id,null,{payload},baselineId,'baseline',at);}
      }
      db.prepare("INSERT INTO history_meta(key,payload) VALUES('schema','1') ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run();
    }
    db.exec('COMMIT');
  }catch(error){db.exec('ROLLBACK');throw error;}
}
function readRun(db,row){
  if(!row)return null;
  const counts={added:0,updated:0,removed:0,shopsChanged:0};let changesCount=0;
  for(const change of db.prepare('SELECT entity_kind,operation,COUNT(*) AS count FROM history_changes WHERE run_id=? GROUP BY entity_kind,operation').all(row.run_id)){
    changesCount+=change.count;if(change.entity_kind==='record')counts[change.operation]+=change.count;else counts.shopsChanged+=change.count;
  }
  return {runId:row.run_id,kind:row.kind,startedAt:row.started_at,finishedAt:row.finished_at??'',status:row.status,error:row.error,progress:JSON.parse(row.progress),summary:JSON.parse(row.summary),counts,changesCount};
}
function requireOpenRun(db,currentRunId){
  if(!currentRunId)return;
  const row=db.prepare('SELECT status FROM sync_runs WHERE run_id=?').get(currentRunId);
  if(!row||row.status!=='incomplete')throw invalid();
}
function readChange(row){
  const version=prefix=>row[prefix+'_payload']===null?null:{payload:JSON.parse(row[prefix+'_payload']),...(row.entity_kind==='record'?{publication:{notPublished:row[prefix+'_not_published'],published:row[prefix+'_published']}}:{})};
  return {entity:row.entity_kind,entityId:row.entity_id,operation:row.operation,source:row.source,recordedAt:row.recorded_at,before:version('before'),after:version('after')};
}

async function workerOperation({root,scope,operation,payload}){
  if(!validScope(scope))throw invalid();
  let input;
  // Validate all inputs before opening a transaction so malformed batches are atomic failures.
  if(operation==='commit'){
    if(!object(payload)||!object(payload.snapshot)||typeof payload.complete!=='boolean'||!['all','notPublished'].includes(payload.mode??'all')||payload.scopeComplete!==undefined&&typeof payload.scopeComplete!=='boolean')throw invalid();
    input={records:list(payload.snapshot.records,record),shops:list(payload.snapshot.shops,shop),complete:payload.complete,mode:payload.mode??'all',scopeComplete:payload.scopeComplete===true,summary:summary(payload.snapshot),progress:progressSummary(payload.snapshot.syncProgress),runId:payload.runId===undefined?undefined:runId(payload.runId)};
    if(input.mode==='notPublished'&&(input.complete||input.progress.mode!=='notPublished'||input.progress.complete||input.progress.fullyComplete===true))throw invalid();
    if(input.mode==='all'&&(input.scopeComplete||input.progress.mode==='notPublished'))throw invalid();
    if(payload.completedStatuses!==undefined){if(input.complete||input.progress.complete)throw invalid();input.completedStatuses=completedStatuses(payload.completedStatuses);}
    if(input.mode==='notPublished'&&input.completedStatuses?.some(status=>status!=='notPublished'))throw invalid();
    if(input.mode==='notPublished'&&input.completedStatuses?.includes('notPublished')&&!input.scopeComplete)throw invalid();
    if(input.scopeComplete&&(!input.runId||input.progress.scopeComplete!==true||input.progress.fullyComplete!==false||!input.progress.scopeSyncedAt||input.completedStatuses?.length!==1||input.completedStatuses[0]!=='notPublished'||!object(payload.finish)||payload.finish.status!=='success'))throw invalid();
    if(input.progress.scopeComplete===true&&input.mode==='notPublished'&&!input.scopeComplete)throw invalid();
    if(input.complete||input.completedStatuses){input.meta=metadata(payload.snapshot);const ids=new Set(input.records.map(row=>row.id));for(const status of input.completedStatuses??['notPublished','published']){const rows=input.meta.statusPages[status];if(input.completedStatuses&&rows===null)throw invalid();if(rows?.some(value=>!ids.has(value)))throw invalid();}if(input.scopeComplete){const selected=new Set(input.meta.statusPages.notPublished);if(input.records.some(row=>!selected.has(row.id)))throw invalid();}}
    input.fullyComplete=input.mode==='all'&&input.complete&&input.meta.syncProgress.complete===true;
    if(payload.finish!==undefined){if(!object(payload.finish)||payload.finish.status!=='success'||!input.runId||!(input.fullyComplete||input.scopeComplete))throw invalid();input.finish={finishedAt:timestamp(payload.finish.finishedAt)};}
  }else if(operation==='patch'){
    if(!object(payload)||!Array.isArray(payload.removeIds??[])||(payload.removeIds??[]).length>500000)throw invalid();input={records:list(payload.records??[],record),removeIds:[...new Set((payload.removeIds??[]).map(id))],runId:payload.runId===undefined?undefined:runId(payload.runId)};
    if(input.records.some(row=>input.removeIds.includes(row.id)))throw invalid();
    if(payload.progress!==undefined){if(!input.runId)throw invalid();input.progress=progressSummary(payload.progress);if(input.progress.complete)throw invalid();}
  }else if(operation==='updateWarehouse')input=warehouseSnapshot(payload);
  else if(operation==='loadProduct'||operation==='saveProduct'){
    input={detailId:id(payload.detailId),shopId:id(payload.shopId)};
    if(operation==='saveProduct'){
      const {snapshot,expectedRevision}=payload,hash=/^[a-f0-9]{64}$/u;
      if(!object(snapshot)||!hash.test(snapshot.revision)||!object(snapshot.product)||
        snapshot.product.detailId!==input.detailId||snapshot.product.shopId!==input.shopId||
        expectedRevision!==null&&!hash.test(expectedRevision))throw invalid();
      input.snapshot={revision:snapshot.revision,product:snapshot.product,updatedAt:timestamp(snapshot.updatedAt)};
      input.expectedRevision=expectedRevision;
    }
  }
  else if(operation!=='load')input=historyInput(operation,payload);
  const directory=resolve(root,'collection-cache');await mkdir(directory,{recursive:true});
  const {DatabaseSync}=await import('./mobile-sqlite.mjs');const db=new DatabaseSync(resolve(directory,scope+'.sqlite'));
  try{
    db.exec('PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON; CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,payload TEXT NOT NULL,hash TEXT NOT NULL,not_published INTEGER,published INTEGER); CREATE TABLE IF NOT EXISTS shops(id TEXT PRIMARY KEY,payload TEXT NOT NULL,hash TEXT NOT NULL); CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,payload TEXT NOT NULL);');
    if(operation==='loadProduct'||operation==='saveProduct'){
      db.exec('CREATE TABLE IF NOT EXISTS product_previews(detail_id TEXT NOT NULL,shop_id TEXT NOT NULL,revision TEXT NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(detail_id,shop_id));');
      const read=db.prepare('SELECT revision,payload FROM product_previews WHERE detail_id=? AND shop_id=?');
      if(operation==='loadProduct'){
        const row=read.get(input.detailId,input.shopId);
        return row?JSON.parse(row.payload):null;
      }
      db.exec('BEGIN IMMEDIATE');
      try{
        const row=read.get(input.detailId,input.shopId);
        if(row?.revision===input.snapshot.revision){db.exec('COMMIT');return JSON.parse(row.payload);}
        if((row?.revision??null)!==input.expectedRevision)throw failure('MIAOSHOU_CACHE_CONFLICT','本机商品缓存已更新，请重新加载商品。');
        db.prepare('INSERT INTO product_previews(detail_id,shop_id,revision,payload) VALUES(?,?,?,?) ON CONFLICT(detail_id,shop_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload')
          .run(input.detailId,input.shopId,input.snapshot.revision,JSON.stringify(input.snapshot));
        db.exec('COMMIT');return input.snapshot;
      }catch(error){db.exec('ROLLBACK');throw error;}
    }
    migrateHistory(db);
    if(operation==='updateWarehouse'){
      db.exec('BEGIN IMMEDIATE');
      try{
        const stored=db.prepare("SELECT payload FROM metadata WHERE key='warehouseSnapshot'").get();
        const entries=stored?list(JSON.parse(stored.payload),warehouseSnapshot):[];
        const snapshots=new Map(entries.map(entry=>[entry.id,entry]));
        snapshots.set(input.id,input);
        db.prepare("INSERT INTO metadata(key,payload) VALUES('warehouseSnapshot',?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run(JSON.stringify([...snapshots.values()]));
        db.exec('COMMIT');
        return input;
      }catch(error){db.exec('ROLLBACK');throw error;}
    }
    if(operation==='beginSync'){
      const currentRunId=randomUUID();db.exec('BEGIN IMMEDIATE');try{
        db.prepare("INSERT INTO sync_runs(run_id,kind,started_at,status,progress) VALUES(?,'sync',?,'incomplete',?)").run(currentRunId,input.startedAt,JSON.stringify(input.mode?{mode:input.mode}:{}));
        db.prepare("INSERT INTO metadata(key,payload) VALUES('incomplete','true') ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run();
        if(input.mode!==undefined){
          const stored=db.prepare("SELECT payload FROM metadata WHERE key='state'").get(),old=stored?JSON.parse(stored.payload):{};
          const progress={mode:input.mode,pages:0,records:0,stage:'shops',complete:false,scopeComplete:false,fullyComplete:false,completedStatuses:[]};
          db.prepare("INSERT INTO metadata(key,payload) VALUES('state',?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run(JSON.stringify({...old,syncedAt:old.syncedAt??'',statusKnown:old.statusKnown??{},syncProgress:progress}));
        }
        db.exec('COMMIT');return {runId:currentRunId,startedAt:input.startedAt};
      }catch(error){db.exec('ROLLBACK');throw error;}
    }
    if(operation==='listHistory'){
      const {page,pageSize}=input,total=db.prepare('SELECT COUNT(*) AS count FROM sync_runs').get().count;
      const rows=db.prepare('SELECT * FROM sync_runs ORDER BY started_at DESC,rowid DESC LIMIT ? OFFSET ?').all(pageSize,(page-1)*pageSize);
      return {items:rows.map(row=>readRun(db,row)),total,page,pageSize};
    }
    if(operation==='historyDetail'){
      const row=db.prepare('SELECT * FROM sync_runs WHERE run_id=?').get(input.runId);if(!row)return null;
      const run=readRun(db,row),{page,pageSize}=input;
      const changes=db.prepare(`SELECT c.*,b.payload AS before_payload,b.not_published AS before_not_published,b.published AS before_published,a.payload AS after_payload,a.not_published AS after_not_published,a.published AS after_published FROM history_changes c LEFT JOIN history_versions b ON b.version_id=c.before_version LEFT JOIN history_versions a ON a.version_id=c.after_version WHERE c.run_id=? ORDER BY c.change_id LIMIT ? OFFSET ?`).all(input.runId,pageSize,(page-1)*pageSize).map(readChange);
      return {run,changes,total:run.changesCount,page,pageSize};
    }
    if(operation==='finishSync'){
      db.exec('BEGIN IMMEDIATE');try{
        const row=db.prepare('SELECT * FROM sync_runs WHERE run_id=?').get(input.runId);if(!row||row.kind!=='sync'||(row.status!=='incomplete'&&row.status!==input.status))throw invalid();
        if(row.status==='incomplete')db.prepare('UPDATE sync_runs SET status=?,finished_at=?,error=?,progress=? WHERE run_id=?').run(input.status,input.finishedAt,input.error,input.progress===undefined?row.progress:JSON.stringify(input.progress),input.runId);
        const result=readRun(db,db.prepare('SELECT * FROM sync_runs WHERE run_id=?').get(input.runId));db.exec('COMMIT');return result;
      }catch(error){db.exec('ROLLBACK');throw error;}
    }
    if(operation==='load'){
      const stored=db.prepare("SELECT payload FROM metadata WHERE key='state'").get(),meta=stored?JSON.parse(stored.payload):{},known=meta.statusKnown??{},result=empty();
      result.syncedAt=meta.syncedAt??'';result.syncProgress=meta.syncProgress??result.syncProgress;
      result.incomplete=db.prepare("SELECT payload FROM metadata WHERE key='incomplete'").get()?.payload==='true';
      result.statusPages={notPublished:known.notPublished?[]:null,published:known.published?[]:null};
      for(const row of db.prepare('SELECT id,payload,not_published,published FROM records ORDER BY rowid').all()){
        result.records.push(record(JSON.parse(row.payload)));if(known.notPublished&&row.not_published===1)result.statusPages.notPublished.push(row.id);if(known.published&&row.published===1)result.statusPages.published.push(row.id);
      }
      result.shops=db.prepare('SELECT payload FROM shops ORDER BY rowid').all().map(row=>shop(JSON.parse(row.payload)));
      for(const key of ['account','syncState','warehouseSnapshot']){const stored=db.prepare('SELECT payload FROM metadata WHERE key=?').get(key);if(stored)Object.assign(result,summary({[key]:JSON.parse(stored.payload)}));}
      return result;
    }
    const result=stats();db.exec('BEGIN IMMEDIATE');
    try{
      requireOpenRun(db,input.runId);const writeChange=changeWriter(db);
      const existing=new Map(db.prepare('SELECT id,payload,hash,not_published,published FROM records').all().map(row=>[row.id,row]));
      const upsert=db.prepare('INSERT INTO records(id,payload,hash,not_published,published) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,hash=excluded.hash,not_published=excluded.not_published,published=excluded.published');
      const published=input.meta?.statusPages.published===null?null:new Set(input.meta?.statusPages.published??[]),notPublished=input.meta?.statusPages.notPublished===null?null:new Set(input.meta?.statusPages.notPublished??[]);
      const checkpoint=new Set(input.completedStatuses??[]),membership=(status,values,key,old)=>input.fullyComplete||checkpoint.has(status)?(values===null?null:Number(values.has(key))):old;
      const removedUnpublished=new Set();
      if(checkpoint.size===1&&checkpoint.has('notPublished')){
        // Reconcile only prior unpublished rows. Previously published rows can outlive the visible checkpoint.
        for(const old of existing.values())if(old.not_published===1&&old.published!==1&&!notPublished.has(old.id)&&!published?.has(old.id))removedUnpublished.add(old.id);
        result.removedIds=[...removedUnpublished];
      }
      for(const row of input.records){
        if(removedUnpublished.has(row.id))continue;
        const old=existing.get(row.id),serialized=JSON.stringify(row),hash=digest(row);
        const np=membership('notPublished',notPublished,row.id,old?.not_published??null),pub=membership('published',published,row.id,old?.published??null);
        if(old&&old.hash===hash&&old.not_published===np&&old.published===pub){result.unchanged++;continue;}
        writeChange('record',row.id,old?{...old,payload:JSON.parse(old.payload)}:null,{payload:row,not_published:np,published:pub},input.runId);
        upsert.run(row.id,serialized,hash,np,pub);if(old)result.updated++;else result.added++;
      }
      if(checkpoint.size){const incoming=new Set(input.records.map(row=>row.id));for(const old of existing.values())if(!incoming.has(old.id)&&!removedUnpublished.has(old.id)){
        const np=membership('notPublished',notPublished,old.id,old.not_published),pub=membership('published',published,old.id,old.published);
        if(np!==old.not_published||pub!==old.published){const row=JSON.parse(old.payload);writeChange('record',old.id,{...old,payload:row},{payload:row,not_published:np,published:pub},input.runId);upsert.run(old.id,old.payload,old.hash,np,pub);result.updated++;}
      }}
      const remove=db.prepare('DELETE FROM records WHERE id=?');
      const removeRecord=key=>{const old=existing.get(key);writeChange('record',key,{...old,payload:JSON.parse(old.payload)},null,input.runId);remove.run(key);result.removed++;};
      for(const key of removedUnpublished)removeRecord(key);
      if(input.fullyComplete){const current=new Set(input.records.map(row=>row.id));for(const key of existing.keys())if(!current.has(key))removeRecord(key);}
      else for(const key of input.removeIds??[])if(existing.has(key))removeRecord(key);
      if(operation==='commit'){
        for(const [key,value]of Object.entries(input.summary)){const old=db.prepare('SELECT payload FROM metadata WHERE key=?').get(key);if(key==='syncState'&&input.mode==='notPublished'){const saved=old?JSON.parse(old.payload):{};value.collection={...value.collection,at:saved.collection?.at??''};}const serialized=JSON.stringify(value);if(old?.payload!==serialized)db.prepare('INSERT INTO metadata(key,payload) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload').run(key,serialized);}
        const incomplete=JSON.stringify(!(input.fullyComplete||input.scopeComplete)),oldIncomplete=db.prepare("SELECT payload FROM metadata WHERE key='incomplete'").get();
        if(oldIncomplete?.payload!==incomplete)db.prepare("INSERT INTO metadata(key,payload) VALUES('incomplete',?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run(incomplete);
        const oldShops=new Map(db.prepare('SELECT id,payload,hash FROM shops').all().map(row=>[row.id,row])),upsertShop=db.prepare('INSERT INTO shops(id,payload,hash) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,hash=excluded.hash');
        for(const row of input.shops){const hash=digest(row),old=oldShops.get(row.id);if(old?.hash!==hash){writeChange('shop',row.id,old?{payload:JSON.parse(old.payload)}:null,{payload:row},input.runId);upsertShop.run(row.id,JSON.stringify(row),hash);result.shopsChanged++;}}
        // A complete shop directory is independent of collection pagination.
        const shopsComplete=input.summary.syncState?input.summary.syncState.shops.state==='success'&&(!input.complete||input.fullyComplete):input.fullyComplete;
        if(shopsComplete){const current=new Set(input.shops.map(row=>row.id)),removeShop=db.prepare('DELETE FROM shops WHERE id=?');for(const key of oldShops.keys())if(!current.has(key)){writeChange('shop',key,{payload:JSON.parse(oldShops.get(key).payload)},null,input.runId);removeShop.run(key);result.shopsChanged++;}}
        if(input.fullyComplete){
          const state={syncedAt:input.meta.syncedAt,syncProgress:input.meta.syncProgress,statusKnown:Object.fromEntries(Object.entries(input.meta.statusPages).map(([key,value])=>[key,value!==null]))},serialized=JSON.stringify(state),old=db.prepare("SELECT payload FROM metadata WHERE key='state'").get();
          if(old?.payload!==serialized)db.prepare("INSERT INTO metadata(key,payload) VALUES('state',?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run(serialized);
        }else if(input.completedStatuses){
          const stored=db.prepare("SELECT payload FROM metadata WHERE key='state'").get(),old=stored?JSON.parse(stored.payload):{},known={...old.statusKnown};
          for(const status of ['notPublished','published'])if(checkpoint.has(status))known[status]=true;else if(input.mode!=='notPublished'&&input.meta.statusPages[status]===null)known[status]=false;
          db.prepare("INSERT INTO metadata(key,payload) VALUES('state',?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run(JSON.stringify({syncedAt:old.syncedAt??'',syncProgress:input.progress,statusKnown:known}));
        }
        if(input.finish)db.prepare("UPDATE sync_runs SET status='success',finished_at=?,error='' WHERE run_id=?").run(input.finish.finishedAt,input.runId);
      }
      if(input.runId&&input.progress){
        db.prepare('UPDATE sync_runs SET progress=? WHERE run_id=?').run(JSON.stringify(input.progress),input.runId);
        if(operation==='patch'||input.mode==='notPublished'){const stored=db.prepare("SELECT payload FROM metadata WHERE key='state'").get(),old=stored?JSON.parse(stored.payload):{};db.prepare("INSERT INTO metadata(key,payload) VALUES('state',?) ON CONFLICT(key) DO UPDATE SET payload=excluded.payload").run(JSON.stringify({syncedAt:old.syncedAt??'',syncProgress:input.progress,statusKnown:old.statusKnown??{}}));}
      }
      if(input.runId){const savedSummary={records:db.prepare('SELECT COUNT(*) AS count FROM records').get().count,shops:db.prepare('SELECT COUNT(*) AS count FROM shops').get().count};db.prepare('UPDATE sync_runs SET summary=? WHERE run_id=?').run(JSON.stringify(savedSummary),input.runId);}
      db.exec('COMMIT');return result;
    }catch(error){db.exec('ROLLBACK');throw error;}
  }finally{db.close();}
}
if(!isMainThread&&workerData?.miaoshouCache){
  try{parentPort.postMessage({ok:true,data:await workerOperation(workerData)});}catch(error){
    const known=['MIAOSHOU_CACHE_INVALID','MIAOSHOU_CACHE_CONFLICT'].includes(error.code);
    parentPort.postMessage({ok:false,code:known?error.code:'MIAOSHOU_CACHE_STORAGE',message:known?error.message:'妙手本地缓存无法读取或保存，请保留现有缓存后重试。'});
  }
}
