import {createRequire} from 'node:module';
const require = createRequire(import.meta.url);
let binding;
export function nativeBinding() {
  if (!binding) binding = require('../native/sqlite.node');
  return binding;
}
export function readKeychainJSON(name) {
  const raw = nativeBinding().keychainRead(name);
  return raw == null ? null : JSON.parse(raw);
}
export function writeKeychainJSON(name, value) {
  if (nativeBinding().keychainWrite(name, JSON.stringify(value)) !== true) throw new Error('iOS Keychain 保存失败。');
  return true;
}
